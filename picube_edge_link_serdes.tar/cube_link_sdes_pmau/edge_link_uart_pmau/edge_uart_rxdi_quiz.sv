
module	edge_uart_rxdi_quiz(
	input								cube_uart_rxdi_drdy		,
	input		[ 7: 0]					cube_uart_rxdi_data		,
	input								cube_bclk				,
	input								cube_rstn				,

	input		[ 7: 0]					rv32_uart_quiz_enab		,
	output		[ 7: 0]					rv32_uart_quiz_stat		,
	input								rv32_bclk				,
	input								rv32_rstn				);
/**********************************************************************************************************************/
	wire		[ 7: 0]					cube_uart_quiz_enab	;	
	wire		[ 7: 0]					cube_uart_quiz_stat	;	
	
	wire		enab_ispm_entr_quiz	=	cube_uart_quiz_enab[0]	;
	wire		enab_ispm_down_quiz	=	cube_uart_quiz_enab[1]	;
	wire		enab_ispm_gook_quiz	=	cube_uart_quiz_enab[2]	;
	wire		enab_ispm_boot_quiz	=	cube_uart_quiz_enab[3]	;
	wire		enab_ddrs_init_quiz	=	cube_uart_quiz_enab[4]	;
	wire		enab_ddrs_scan_quiz	=	cube_uart_quiz_enab[5]	;
	wire		enab_ddr0_scan_quiz	=	cube_uart_quiz_enab[6]	;
	wire		enab_ddr1_scan_quiz	=	cube_uart_quiz_enab[7]	;
//-=----------------------------------------------------------------------------
	gens_gray_code #(.MSB (7 ))		u_cube_uart_rxdi_quiz(	
		.dtar_data						(cube_uart_quiz_enab	),//output	reg [MSB: 0]
		.dtar_clki						(cube_bclk				),//input				
		.dtar_rstn						(cube_rstn				),//input				

		.dsrc_data						(rv32_uart_quiz_enab	),//input		[MSB: 0]	
		.dsrc_clki						(rv32_bclk				));//input					
//-=----------------------------------------------------------------------------
	gens_gray_code #(.MSB (7 ))		u_rv32_uart_rxdi_stat(	
		.dtar_data						(rv32_uart_quiz_stat	),//output	reg [MSB: 0]
		.dtar_clki						(rv32_bclk				),//input				
		.dtar_rstn						(rv32_rstn				),//input				

		.dsrc_data						(cube_uart_quiz_stat	),//input		[MSB: 0]	
		.dsrc_clki						(cube_bclk				));//input					
/**********************************************************************************************************************/
	wire                  				quiz_ispm_entr_beok ;
	wire                  				quiz_ispm_down_beok ;
	wire                  				quiz_ispm_gook_beok ;
	wire                  				quiz_ispm_boot_beok ;
	wire                  				quiz_ddrs_init_beok ;
	wire                  				quiz_ddrs_scan_beok ;
	wire                  				quiz_ddr0_scan_fail	;
	wire                  				quiz_ddr1_scan_fail	;

	assign		cube_uart_quiz_stat	= {	quiz_ddr1_scan_fail	,
										quiz_ddr0_scan_fail ,		
										quiz_ddrs_scan_beok ,
										quiz_ddrs_init_beok ,
										quiz_ispm_boot_beok ,
										quiz_ispm_gook_beok ,
										quiz_ispm_down_beok ,
										quiz_ispm_entr_beok	};
//----------------------------------------------------------------------------------------------------------
//  key words: "ISP OK"
//    ASCII (0x):49 53 50 20 4F 4B
	reg     	[ 3: 0]					quiz_ispm_entr_mfsm	;
	assign    	quiz_ispm_entr_beok = 	quiz_ispm_entr_mfsm == 4'H6	;
	
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						quiz_ispm_entr_mfsm <= 4'H0	;
	else if(~enab_ispm_entr_quiz)		quiz_ispm_entr_mfsm <= 4'H0	;
	else if( cube_uart_rxdi_drdy)		begin
		case(quiz_ispm_entr_mfsm)
			4'H0	:					quiz_ispm_entr_mfsm	<=(cube_uart_rxdi_data	==	8'H49)	?	4'H1	:	4'H0	;
			4'H1	:					quiz_ispm_entr_mfsm	<=(cube_uart_rxdi_data	==	8'H53)	?	4'H2	:	4'H0	;
			4'H2	:					quiz_ispm_entr_mfsm	<=(cube_uart_rxdi_data	==	8'H50)	?	4'H3	:	4'H0	;
			4'H3	:					quiz_ispm_entr_mfsm	<=(cube_uart_rxdi_data	==	8'H20)	?	4'H4	:	4'H0	;
			4'H4	:					quiz_ispm_entr_mfsm	<=(cube_uart_rxdi_data	==	8'H4f)	?	4'H5	:	4'H0	;
			4'H5	:					quiz_ispm_entr_mfsm	<=(cube_uart_rxdi_data	==	8'H4b)	?	4'H6	:	4'H0	;
			4'H6	:					quiz_ispm_entr_mfsm	<=													4'H6	;
			default	:					quiz_ispm_entr_mfsm	<=													4'H0	;
    	endcase
	end
//----------------------------------------------------------------------------------------------------------
//  key words when dnld ok: "W_OK"
//    ASCII(0x): 57 5f 4F 4B
	reg			[ 3: 0]       			quiz_ispm_down_mfsm	;
	assign		quiz_ispm_down_beok = 	quiz_ispm_down_mfsm == 4'H4	;

	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						quiz_ispm_down_mfsm	<= 4'H0	;
	else if(~enab_ispm_down_quiz)		quiz_ispm_down_mfsm	<= 4'H0	;
	else if(cube_uart_rxdi_drdy)		begin
		case(quiz_ispm_down_mfsm)
			4'H0		:				quiz_ispm_down_mfsm	<=(cube_uart_rxdi_data	==	8'H57)	?	4'H1	:	4'H0	;
	    	4'H1		:				quiz_ispm_down_mfsm	<=(cube_uart_rxdi_data	==	8'H5f)	?	4'H2	:	4'H0	;
	    	4'H2		:				quiz_ispm_down_mfsm	<=(cube_uart_rxdi_data	==	8'H4f)	?	4'H3	:	4'H0	;
	    	4'H3		:				quiz_ispm_down_mfsm	<=(cube_uart_rxdi_data	==	8'H4b)	?	4'H4	:	4'H0	;
	    	4'H4		:				quiz_ispm_down_mfsm	<= 													4'H4	;
	    	default		:				quiz_ispm_down_mfsm <= 											  		4'H0	;
		endcase
	end		
//----------------------------------------------------------------------------------------------------------
//  key words: "G_OK"
//    ASCII (0x):47 5f 4f 4b
	reg     	[ 3: 0] 				quiz_ispm_gook_mfsm	;
	assign    	quiz_ispm_gook_beok = 	quiz_ispm_gook_mfsm == 4'H4	;
	
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						quiz_ispm_gook_mfsm	<= 4'H0	;
	else if(~enab_ispm_gook_quiz)		quiz_ispm_gook_mfsm	<= 4'H0	;
	else if(cube_uart_rxdi_drdy)		begin
		case(quiz_ispm_gook_mfsm)
			4'H0	:					quiz_ispm_gook_mfsm	<=(cube_uart_rxdi_data	==	8'H47)	?	4'H1	:	4'H0	;
			4'H1	:					quiz_ispm_gook_mfsm	<=(cube_uart_rxdi_data	==	8'H5f)	?	4'H2	:	4'H0	;
			4'H2	:					quiz_ispm_gook_mfsm	<=(cube_uart_rxdi_data	==	8'H4f)	?	4'H3	:	4'H0	;
			4'H3	:					quiz_ispm_gook_mfsm	<=(cube_uart_rxdi_data	==	8'H4b)	?	4'H4	:	4'H0	;
			4'H4	:					quiz_ispm_gook_mfsm	<=													4'H4	;
			default	:					quiz_ispm_gook_mfsm	<=													4'H0	;
    	endcase
	end
//----------------------------------------------------------------------------------------------------------
//  key words: "2nd OK"
//    ASCII (0x): 32 6E  64  20 4F 4B
	reg			[ 3: 0]					quiz_ispm_boot_mfsm	;
	assign		quiz_ispm_boot_beok	= 	quiz_ispm_boot_mfsm == 4'H6	;

	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						quiz_ispm_boot_mfsm	<= 4'H0	;
	else if(~enab_ispm_boot_quiz)		quiz_ispm_boot_mfsm	<= 4'H0	;
	else if(cube_uart_rxdi_drdy)		begin
		case(quiz_ispm_boot_mfsm)
			4'H0	: 					quiz_ispm_boot_mfsm	<=(cube_uart_rxdi_data	==	8'H32)	?	4'H1	:	4'H0	;
    		4'H1	: 					quiz_ispm_boot_mfsm	<=(cube_uart_rxdi_data	==	8'H6e)	?	4'H2	:	4'H0	;
    		4'H2	: 					quiz_ispm_boot_mfsm	<=(cube_uart_rxdi_data	==	8'H64)	?	4'H3	:	4'H0	;
    		4'H3	: 					quiz_ispm_boot_mfsm	<=(cube_uart_rxdi_data	==	8'H20)	?	4'H4	:	4'H0	;
    		4'H4	: 					quiz_ispm_boot_mfsm	<=(cube_uart_rxdi_data	==	8'H4f)	?	4'H5	:	4'H0	;
    		4'H5	: 					quiz_ispm_boot_mfsm	<=(cube_uart_rxdi_data	==	8'H4b)	?	4'H6	:	4'H0	;
    		4'H6	: 					quiz_ispm_boot_mfsm	<=													4'H6	;
    		default	: 					quiz_ispm_boot_mfsm <=				 									4'H0	;
    	endcase
	end	
//----------------------------------------------------------------------------------------------------------
//  key words: "DDRIOK"
//    ASCII (0x):44 44 52 49 4F 4B
	reg    	 	[ 3: 0] 				quiz_ddrs_init_mfsm	;
	assign    	quiz_ddrs_init_beok = 	quiz_ddrs_init_mfsm == 4'H6	;
	
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						quiz_ddrs_init_mfsm <= 4'H0	;
	else if(~enab_ddrs_init_quiz)		quiz_ddrs_init_mfsm <= 4'H0	;
	else if(cube_uart_rxdi_drdy)		begin
		case(quiz_ddrs_init_mfsm)
			4'H0	:					quiz_ddrs_init_mfsm	<=(cube_uart_rxdi_data	==	8'H44)	?	4'H1	:	4'H0	;
			4'H1	:					quiz_ddrs_init_mfsm	<=(cube_uart_rxdi_data	==	8'H44)	?	4'H2	:	4'H0	;
			4'H2	:					quiz_ddrs_init_mfsm	<=(cube_uart_rxdi_data	==	8'H52)	?	4'H3	:	4'H0	;
			4'H3	:					quiz_ddrs_init_mfsm	<=(cube_uart_rxdi_data	==	8'H49)	?	4'H4	:	4'H0	;
			4'H4	:					quiz_ddrs_init_mfsm	<=(cube_uart_rxdi_data	==	8'H4f)	?	4'H5	:	4'H0	;
			4'H5	:					quiz_ddrs_init_mfsm	<=(cube_uart_rxdi_data	==	8'H4b)	?	4'H6	:	4'H0	;
			4'H6	:					quiz_ddrs_init_mfsm	<=													4'H6	;
			default	:					quiz_ddrs_init_mfsm <=													4'H0	;
    	endcase
	end
//----------------------------------------------------------------------------------------------------------
//  key words: "DDRSOK"
//    ASCII (0x):44 44 52 53 4F 4B
	reg     	[ 3: 0] 				quiz_ddrs_scan_mfsm	;
	assign    	quiz_ddrs_scan_beok =	quiz_ddrs_scan_mfsm == 4'H6	;
	
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						quiz_ddrs_scan_mfsm <= 4'H0	;
	else if(~enab_ddrs_scan_quiz)		quiz_ddrs_scan_mfsm <= 4'H0	;
	else if(cube_uart_rxdi_drdy)		begin
		case(quiz_ddrs_scan_mfsm)
			4'H0	:					quiz_ddrs_scan_mfsm	<=(cube_uart_rxdi_data	==	8'H44)	?	4'H1	:	4'H0	;
			4'H1	:					quiz_ddrs_scan_mfsm	<=(cube_uart_rxdi_data	==	8'H44)	?	4'H2	:	4'H0	;
			4'H2	:					quiz_ddrs_scan_mfsm	<=(cube_uart_rxdi_data	==	8'H52)	?	4'H3	:	4'H0	;
			4'H3	:					quiz_ddrs_scan_mfsm	<=(cube_uart_rxdi_data	==	8'H53)	?	4'H4	:	4'H0	;
			4'H4	:					quiz_ddrs_scan_mfsm	<=(cube_uart_rxdi_data	==	8'H4f)	?	4'H5	:	4'H0	;
			4'H5	:					quiz_ddrs_scan_mfsm	<=(cube_uart_rxdi_data	==	8'H4b)	?	4'H6	:	4'H0	;
			4'H6	:					quiz_ddrs_scan_mfsm	<=													4'H6	;
			default	:					quiz_ddrs_scan_mfsm	<=													4'H0	;
    	endcase
	end
//----------------------------------------------------------------------------------------------------------
//  key words: "DDRFAIL0"
//    ASCII (0x):44 44 52 46 41 49 4C 30
	reg     	[ 3: 0] 				quiz_ddr0_fail_mfsm	;
	assign    	quiz_ddr0_scan_fail = 	quiz_ddr0_fail_mfsm == 4'H8	;

	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						quiz_ddr0_fail_mfsm	<= 4'H0	;
	else if(~enab_ddr0_scan_quiz)		quiz_ddr0_fail_mfsm	<= 4'H0	;
	else if(cube_uart_rxdi_drdy)			begin
		case(quiz_ddr0_fail_mfsm)
			4'H0	:					quiz_ddr0_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H44)	?	4'H1	:	4'H0	;
			4'H1	:					quiz_ddr0_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H44)	?	4'H2	:	4'H0	;
			4'H2	:					quiz_ddr0_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H52)	?	4'H3	:	4'H0	;
			4'H3	:					quiz_ddr0_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H46)	?	4'H4	:	4'H0	;
			4'H4	:					quiz_ddr0_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H41)	?	4'H5	:	4'H0	;
			4'H5	:					quiz_ddr0_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H49)	?	4'H6	:	4'H0	;
			4'H6	:					quiz_ddr0_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H4C)	?	4'H7	:	4'H0	;
			4'H6	:					quiz_ddr0_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H30)	?	4'H8	:	4'H0	;
			4'H8	:					quiz_ddr0_fail_mfsm	<=													4'H8	;
			default	:					quiz_ddr0_fail_mfsm	<=													4'H0	;
	 	endcase
	end
//----------------------------------------------------------------------------------------------------------
//  key words: "DDRFAIL1"
//    ASCII (0x):44 44 52 46 41 49 4C 31
	reg     	[ 3: 0] 				quiz_ddr1_fail_mfsm	;
	assign    	quiz_ddr1_scan_fail	= 	quiz_ddr1_fail_mfsm == 4'H8	;

	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						quiz_ddr1_fail_mfsm <= 4'H0	;
	else if(~enab_ddr1_scan_quiz)		quiz_ddr1_fail_mfsm <= 4'H0	;
	else if(cube_uart_rxdi_drdy)		begin
		case(quiz_ddr1_fail_mfsm)
			4'H0	:					quiz_ddr1_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H44)	?	4'H1	:	4'H0	;
			4'H1	:					quiz_ddr1_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H44)	?	4'H2	:	4'H0	;
			4'H2	:					quiz_ddr1_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H52)	?	4'H3	:	4'H0	;
			4'H3	:					quiz_ddr1_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H46)	?	4'H4	:	4'H0	;
			4'H4	:					quiz_ddr1_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H41)	?	4'H5	:	4'H0	;
			4'H5	:					quiz_ddr1_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H49)	?	4'H6	:	4'H0	;
			4'H6	:					quiz_ddr1_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H4C)	?	4'H7	:	4'H0	;
			4'H6	:					quiz_ddr1_fail_mfsm	<=(cube_uart_rxdi_data	==	8'H31)	?	4'H8	:	4'H0	;
			4'H8	:					quiz_ddr1_fail_mfsm	<=													4'H8	;
			default	:					quiz_ddr1_fail_mfsm	<=													4'H0	;
	 	endcase
	end

endmodule

