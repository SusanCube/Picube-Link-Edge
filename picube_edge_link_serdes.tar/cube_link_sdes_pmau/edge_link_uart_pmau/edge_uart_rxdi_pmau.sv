
module	edge_uart_rxdi_pmau(
	input								cube_uart_rxdi_port		,
	input		[11: 0]					cube_uart_rxdi_baud		,
	input								cube_bclk				,
	input								cube_rstn				,

	input								rv32_uart_rxdi_enab		,
	input		[ 7: 0]					rv32_uart_quiz_enab		,
	output		[ 7: 0]					rv32_uart_quiz_stat		,		
	input								rv32_bclk				,
	input								rv32_rstn				);
//----------------------------------------------------------------------------------------------------------------------
	wire		[ 7:0]					cube_uart_rxdi_data		;

	edge_uart_rxdi_dmau				u_edge_uart_rxdi_dmau(
		.cube_uart_rxdi_port			(cube_uart_rxdi_port	),//input				
		.cube_uart_rxdi_baud			(cube_uart_rxdi_baud	),//input	[11: 0]		
		.cube_uart_rxdi_drdy			(cube_uart_rxdi_drdy	),//output	reg			
		.cube_uart_rxdi_data			(cube_uart_rxdi_data	),//output	reg [ 7: 0]	
		.cube_bclk						(cube_bclk				),//input				
		.cube_rstn						(cube_rstn				),//input				

		.rv32_uart_rxdi_enab			(rv32_uart_rxdi_enab	),//input	
		.rv32_bclk						(rv32_bclk				),//input	
		.rv32_rstn						(rv32_rstn				));//input	
//----------------------------------------------------------------------------------------------------------------------
	edge_uart_rxdi_quiz				u_edge_uart_rxdi_quiz(
		.cube_uart_rxdi_drdy			(cube_uart_rxdi_drdy	),//input				
		.cube_uart_rxdi_data			(cube_uart_rxdi_data	),//input		[ 7: 0]	
		.cube_bclk						(cube_bclk				),//input				
		.cube_rstn						(cube_rstn				),//input				

		.rv32_uart_quiz_enab			(rv32_uart_quiz_enab	),//input		[ 7: 0]	
		.rv32_uart_quiz_stat			(rv32_uart_quiz_stat	),//output		[ 7: 0]	
		.rv32_bclk						(rv32_bclk				),//input				
		.rv32_rstn						(rv32_rstn				));//input				

endmodule




