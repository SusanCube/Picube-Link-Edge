module	edge_link_uart_pmau(
	output								cube_uart_txdo_port		,
	input								cube_uart_rxdi_port		,
	input		[11: 0]					cube_uart_baud_rate		,
	input								cube_bclk				,
	input								cube_rstn				,

	input								rv32_uart_rxdi_enab		,
	input		[ 7: 0]					rv32_uart_quiz_enab		,
	output		[ 7: 0]					rv32_uart_quiz_stat		,
	output								rv32_uart_txdo_done		,
	input								rv32_uart_txdo_enab		,
	input								rv32_uart_tbuf_wrcs		,
	input		[31: 0]					rv32_uart_tbuf_wdin		,
	input								rv32_bclk				,
	input								rv32_rstn				);
//------------------------------------------------------------------------------
	edge_uart_rxdi_pmau				u_edge_uart_rxdi_pmau(
		.cube_uart_rxdi_port			(cube_uart_rxdi_port	),//input				
		.cube_uart_rxdi_baud			(cube_uart_baud_rate	),//input		[11: 0]	
		.cube_bclk						(cube_bclk				),//input				
		.cube_rstn						(cube_rstn				),//input				

		.rv32_uart_rxdi_enab			(rv32_uart_rxdi_enab	),//input				
		.rv32_uart_quiz_enab			(rv32_uart_quiz_enab	),//input		[ 7: 0]	
		.rv32_uart_quiz_stat			(rv32_uart_quiz_stat	),//output		[ 7: 0]	
		.rv32_bclk						(rv32_bclk				),//input				
		.rv32_rstn						(rv32_rstn				));//input				
//------------------------------------------------------------------------------
	edge_uart_txdo_pmau				u_edge_uart_txdo_pmau(
		.cube_uart_txdo_port			(cube_uart_txdo_port	),//output				
		.cube_uart_txdo_baud			(cube_uart_baud_rate	),//input		[11: 0]	
		.cube_bclk						(cube_bclk				),//input				
		.cube_rstn						(cube_rstn				),//input				

		.rv32_uart_txdo_done			(rv32_uart_txdo_done	),//output				
		.rv32_uart_txdo_enab			(rv32_uart_txdo_enab	),//input				
		.rv32_uart_tbuf_wrcs			(rv32_uart_tbuf_wrcs	),//input				
		.rv32_uart_tbuf_wdin			(rv32_uart_tbuf_wdin	),//input		[31: 0]	
		.rv32_bclk						(rv32_bclk				),//input				
		.rv32_rstn						(rv32_rstn				));//input				
//------------------------------------------------------------------------------
endmodule