
module	edge_uart_txdo_pmau(
	output								cube_uart_txdo_port	,
	input		[11: 0]					cube_uart_txdo_baud	,
	input								cube_bclk			,
	input								cube_rstn			,

	output								rv32_uart_txdo_done	,
	input								rv32_uart_txdo_enab	,
	input								rv32_uart_tbuf_wrcs	,
	input		[31: 0]					rv32_uart_tbuf_wdin	,
	input								rv32_bclk			,
	input								rv32_rstn			);
//*********************************************************************************************************************//
	wire								cube_uart_txdo_enab	;
	wire								cube_uart_txdo_done	;
//------------------------------------------------------------------------------
	gens_sync_mark 					u_gens_rv32_uart_txen(	
		.dtar_mark						(cube_uart_txdo_enab	),//output	
		.dtar_clki						(cube_bclk				),//input	
		.dtar_rstn						(cube_rstn				),//input	

		.dsrc_mark						(rv32_uart_txdo_enab	),//input
		.dsrc_clki						(rv32_bclk				),//input
		.dsrc_rstn						(rv32_rstn				));//input
//------------------------------------------------------------------------------
	gens_sync_mark 					u_gens_rv32_uart_txok(	
		.dtar_mark						(rv32_uart_txdo_done	),//output	
		.dtar_clki						(rv32_bclk				),//input	
		.dtar_rstn						(rv32_rstn				),//input	

		.dsrc_mark						(cube_uart_txdo_done	),//input
		.dsrc_clki						(cube_bclk				),//input
		.dsrc_rstn						(cube_rstn				));//input
//------------------------------------------------------------------------------
	reg			[ 3: 0]					rv32_uart_tbuf_wptr	;
	wire		[ 3: 0]					cube_uart_tbuf_wptr	;	
	reg			[ 3: 0]					cube_uart_tbuf_rptr	;	
	wire		[31: 0]					cube_uart_tbuf_rout	;	
	
	always@(posedge rv32_bclk or negedge rv32_rstn)
	if(~rv32_rstn)						rv32_uart_tbuf_wptr	<=	0	;
	else if(~rv32_uart_txdo_enab)		rv32_uart_tbuf_wptr	<=	0	;
	else if( rv32_uart_tbuf_wrcs)		rv32_uart_tbuf_wptr	<=	rv32_uart_tbuf_wptr + 1	;
//------------------------------------------------------------------------------
	gens_gray_code #(
		.MSB		( 3	))	
									u_cube_uart_tbuf_wptr(	
		.dtar_data						(cube_uart_tbuf_wptr	),//output	reg [MSB: 0]
		.dtar_clki						(cube_bclk				),//input				
		.dtar_rstn						(cube_rstn				),//input				

		.dsrc_data						(rv32_uart_tbuf_wptr	),//input		[MSB: 0]
		.dsrc_clki						(rv32_bclk				));//input				
//------------------------------------------------------------------------------
	bram_dual_port	#(	
		.ADDR_BITS 	( 4		), 
		.DATA_BITS 	( 32 	))	
									u_uart_txdo_fifo(
		.wport_csen						(rv32_uart_tbuf_wrcs	),//input  				 		
		.wport_addr						(rv32_uart_tbuf_wptr	),//input		[ADDR_BITS-1:0]	
		.wport_data						(rv32_uart_tbuf_wdin	),//input		[DATA_BITS-1:0]	
		.wport_clki						(rv32_bclk				),//input						

		.rport_addr						(cube_uart_tbuf_rptr	),//input		[ADDR_BITS-1:0] 
		.rport_data						(cube_uart_tbuf_rout	),//output	reg	[DATA_BITS-1:0] 
		.rport_clki						(cube_bclk				));//input						
//*********************************************************************************************************************//
//*********************************************************************************************************************//
	reg		[ 2: 0]						uart_txdo_mfsm	;
		
	parameter	UART_TXDO_IDLE		=	3'H0	;
	parameter	UART_WORD_LOAD		=	3'H1	;
	parameter	UART_BYTE_LOAD		=	3'H2	;
	parameter	UART_BYTE_SHFT		=	3'H3	;
	parameter	UART_BYTE_MUTE		=	3'H4	;
	parameter	UART_BYTE_DONE		=	3'H5	;
	parameter	UART_TXDO_DONE		=	3'H6	;

	
	wire		cube_uart_txdo_idle	=		uart_txdo_mfsm	==	UART_TXDO_IDLE	;
	wire		cube_txdo_word_load	=		uart_txdo_mfsm	==	UART_WORD_LOAD	;
	wire		cube_txdo_byte_load	=		uart_txdo_mfsm	==	UART_BYTE_LOAD	;
	wire		cube_txdo_byte_shft	=		uart_txdo_mfsm	==	UART_BYTE_SHFT	;
	wire		cube_txdo_byte_mute	=		uart_txdo_mfsm	==	UART_BYTE_MUTE	;
	wire		cube_txdo_byte_done	=		uart_txdo_mfsm	==	UART_BYTE_DONE	;
	assign		cube_uart_txdo_done	=		uart_txdo_mfsm	==	UART_TXDO_DONE	;
	
	wire								cube_txdo_data_vlid	;
	wire								cube_txdo_sbit_last	;
	wire								cube_txdo_byte_last	;
	wire								cube_txdo_mute_last	;
	
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						uart_txdo_mfsm	<=	UART_TXDO_IDLE	;
	else if(~cube_uart_txdo_enab)		uart_txdo_mfsm	<=	UART_TXDO_IDLE	;
	else begin
		case(uart_txdo_mfsm)	
			UART_TXDO_IDLE	:			uart_txdo_mfsm	<=	cube_txdo_data_vlid	?	UART_WORD_LOAD	:	UART_TXDO_DONE	;
			UART_WORD_LOAD	:			uart_txdo_mfsm	<=												UART_BYTE_LOAD	;
			UART_BYTE_LOAD	:			uart_txdo_mfsm	<=												UART_BYTE_SHFT	;
			UART_BYTE_SHFT	:			uart_txdo_mfsm	<=	cube_txdo_sbit_last	?	UART_BYTE_MUTE	:	UART_BYTE_SHFT	;
			UART_BYTE_MUTE	:			uart_txdo_mfsm	<=	cube_txdo_mute_last	?	UART_BYTE_DONE	:	UART_BYTE_MUTE	;
			UART_BYTE_DONE	:			uart_txdo_mfsm	<=	cube_txdo_byte_last	?	UART_TXDO_IDLE	:	UART_BYTE_LOAD	;
			UART_TXDO_DONE	:			uart_txdo_mfsm	<=	cube_uart_txdo_enab	?	UART_TXDO_DONE	:	UART_TXDO_IDLE	;
			
			default			:			uart_txdo_mfsm	<=												UART_TXDO_IDLE	;
		endcase
	end		
//********************************************************************************************************************//
	reg			[ 3: 0]					cube_uart_txdo_rptr	;
	assign		cube_txdo_data_vlid	=&{	cube_uart_tbuf_wptr	>	cube_uart_txdo_rptr	,
										cube_uart_txdo_enab	,	cube_uart_txdo_idle	};	

	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						cube_uart_txdo_rptr	<=	0	;
	else if(~cube_uart_txdo_enab)		cube_uart_txdo_rptr	<=	0	;
	else if( cube_txdo_word_load)		cube_uart_txdo_rptr	<=	cube_uart_txdo_rptr + 1	;
//********************************************************************************************************************//
	wire								cube_txdo_full_baud	;
	wire								cube_txdo_half_baud	;
	
	reg			[31: 0]					cube_txdo_word_buff	;
	reg			[ 2: 0]					cube_txdo_byte_indx	;

	assign		cube_txdo_byte_last	=	cube_txdo_byte_indx	==	2'H3	;
		
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						cube_txdo_byte_indx	<=	0	;
	else if(cube_uart_txdo_idle)		cube_txdo_byte_indx	<=	0	;
	else if(cube_txdo_word_load)		cube_txdo_byte_indx	<=	0	;
	else if(cube_txdo_byte_done)		cube_txdo_byte_indx	<=	cube_txdo_byte_indx + 1 ;

	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						cube_txdo_word_buff	<=	0	;
	else if(cube_uart_txdo_idle)		cube_txdo_word_buff	<=	0	;
	else if(cube_txdo_word_load)		cube_txdo_word_buff	<=	cube_uart_tbuf_rout	;

	wire		[9: 0]					cube_txdo_byte_patn	;
	wire		[7: 0]					cube_txdo_byte_sect	;	

	assign		cube_txdo_byte_sect	=	cube_txdo_byte_indx == 0	?	cube_txdo_word_buff[ 7: 0]	:
										cube_txdo_byte_indx == 1	?	cube_txdo_word_buff[15: 8]	:
										cube_txdo_byte_indx == 2	?	cube_txdo_word_buff[23:16]	:	cube_txdo_word_buff[31:24]	;
								
	assign		cube_txdo_byte_patn	= {	2'B10	,
										cube_txdo_byte_sect[0] , cube_txdo_byte_sect[1]	,cube_txdo_byte_sect[2]	,cube_txdo_byte_sect[3]	,
										cube_txdo_byte_sect[4] , cube_txdo_byte_sect[5]	,cube_txdo_byte_sect[6]	,cube_txdo_byte_sect[7]	};

//----------------------------------------------------------------------
	wire		[9: 0]					cube_txdo_shft_patn	;
	reg			[9: 0]					cube_txdo_byte_buff	;

	assign		cube_txdo_shft_patn	= {	cube_txdo_byte_buff[8:0],	1'B1		};

	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						cube_txdo_byte_buff	<=	10'H3FF	;
	else if(cube_uart_txdo_idle)		cube_txdo_byte_buff	<=	10'H3FF	;
	else if(cube_txdo_word_load)		cube_txdo_byte_buff	<=	10'H3FF	;
	else if(cube_txdo_byte_load)		cube_txdo_byte_buff	<=	cube_txdo_byte_patn	;
	else if(cube_txdo_byte_shft)		cube_txdo_byte_buff	<=	cube_txdo_full_baud	?	cube_txdo_shft_patn	:	cube_txdo_byte_buff	;

	assign		cube_uart_txdo_port	=	cube_txdo_byte_buff[9]	;
//----------------------------------------------------------------------
	reg			[ 3: 0]					cube_txdo_sbit_cnts	;
	
	assign		cube_txdo_sbit_last	=	cube_txdo_sbit_cnts	==	4'HB	;

	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						cube_txdo_sbit_cnts	<=	4'H0	;
	else if(cube_uart_txdo_idle)		cube_txdo_sbit_cnts	<=	4'H0	;
	else if(cube_txdo_word_load)		cube_txdo_sbit_cnts	<=	4'H0	;
	else if(cube_txdo_byte_load)		cube_txdo_sbit_cnts	<=	4'H0 	;	
	else if(cube_txdo_byte_shft)		cube_txdo_sbit_cnts	<=	cube_txdo_sbit_cnts + cube_txdo_half_baud	;	
//----------------------------------------------------------------------
	reg			[11: 0]					cube_txdo_baud_time	;

	wire		txdo_baud_clrs	= |{	cube_uart_txdo_idle	,	cube_txdo_word_load	,	
										cube_txdo_byte_load	,	cube_txdo_byte_done	};

	assign		cube_txdo_full_baud	=	cube_txdo_baud_time	==		cube_uart_txdo_baud	;
	assign		cube_txdo_half_baud	=	cube_txdo_baud_time	=={1'b0,cube_uart_txdo_baud[11:1]}	;
	
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						cube_txdo_baud_time	<=	12'H00	;
	else if( txdo_baud_clrs)			cube_txdo_baud_time	<=	12'H00	;
	else if(~cube_txdo_full_baud)		cube_txdo_baud_time	<=	cube_txdo_baud_time + 1 	;
	else								cube_txdo_baud_time	<=	12'H00	;
//----------------------------------------------------------------------
	reg									cube_txdo_mute_cnts	;

	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						cube_txdo_mute_cnts	<=	0					;
	else if(~cube_txdo_byte_mute)		cube_txdo_mute_cnts	<=	0					;
	else if( cube_txdo_full_baud)		cube_txdo_mute_cnts	<=	cube_txdo_mute_cnts + 1 	;

	assign	cube_txdo_mute_last	= &{	cube_txdo_full_baud	,	cube_txdo_mute_cnts		};
//********************************************************************************************************************//
//********************************************************************************************************************//
	
	

endmodule
 