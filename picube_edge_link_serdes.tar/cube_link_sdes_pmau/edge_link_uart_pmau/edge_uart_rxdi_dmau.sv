
module	edge_uart_rxdi_dmau(
	input								cube_uart_rxdi_port	,
	input	[11: 0]						cube_uart_rxdi_baud	,
	output	reg							cube_uart_rxdi_drdy	,
	output	reg [ 7: 0]					cube_uart_rxdi_data	,
	input								cube_bclk			,
	input								cube_rstn			,

	input								rv32_uart_rxdi_enab	,
	input								rv32_bclk			,
	input								rv32_rstn			);
//********************************************************************************************************************//
	reg			[ 2: 0]					cube_uart_rxdi_samp	;
	wire								cube_uart_rxdi_enab	;
	wire								cube_uart_rxdi_sdin	=	cube_uart_rxdi_samp[  0]		;
	wire								cube_uart_rxdi_rise	=	cube_uart_rxdi_samp[1:0]==2'B10	;
	wire								cube_uart_rxdi_fall	=	cube_uart_rxdi_samp[1:0]==2'B01	;
	wire								cube_uart_rxdi_xchg	= |{cube_uart_rxdi_rise	,	cube_uart_rxdi_fall	};
//------------------------------------------------------------------------------
	gens_sync_mark 					u_cube_uart_rxdi_enab(	
		.dtar_mark						(cube_uart_rxdi_enab	),//output	
		.dtar_clki						(cube_bclk				),//input	
		.dtar_rstn						(cube_rstn				),//input	

		.dsrc_mark						(rv32_uart_rxdi_enab	),//input
		.dsrc_clki						(rv32_bclk				),//input
		.dsrc_rstn						(rv32_rstn				));//input
//----------------------------------------------------------------------
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						cube_uart_rxdi_samp	<=	3'H7	;
	else if(~cube_uart_rxdi_enab) 		cube_uart_rxdi_samp	<=	3'H7	;
	else								cube_uart_rxdi_samp	<= {cube_uart_rxdi_port	,	cube_uart_rxdi_samp[2:1]	};
//********************************************************************************************************************//
	reg			[ 1: 0]					uart_rxdi_mfsm	;

	parameter	UART_RXDI_IDLE		=	2'H0	;
	parameter	UART_RXDI_LEAD		=	2'H1	;
	parameter	UART_RXDI_SBIT		=	2'H2	;
	parameter	UART_RXDI_STOP		=	2'H3	;

	wire		uart_rxdi_hits_idle	=	uart_rxdi_mfsm	==	UART_RXDI_IDLE	;
	wire		uart_rxdi_hits_lead	=	uart_rxdi_mfsm	==	UART_RXDI_LEAD	;
	wire		uart_rxdi_hits_data	=	uart_rxdi_mfsm	==	UART_RXDI_SBIT	;
	wire		rxdi_hits_stop		=	uart_rxdi_mfsm	==	UART_RXDI_STOP	;

	reg									uart_rxdi_lead_good	;
	reg									uart_rxdi_byte_done	;
	wire								uart_rxdi_full_baud	;
	wire								uart_rxdi_half_baud	;
//------------------------------------------------------------------------------
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						uart_rxdi_mfsm	<=	UART_RXDI_IDLE	;
	else if(~cube_uart_rxdi_enab)		uart_rxdi_mfsm	<=	UART_RXDI_IDLE	;
	else begin
		case(uart_rxdi_mfsm)
			UART_RXDI_IDLE	:			uart_rxdi_mfsm	<=	cube_uart_rxdi_fall	?	UART_RXDI_LEAD	:	UART_RXDI_IDLE	;
			UART_RXDI_LEAD	:		
				if(uart_rxdi_full_baud)	uart_rxdi_mfsm	<=	uart_rxdi_lead_good	? 	UART_RXDI_SBIT	:	UART_RXDI_IDLE	;
				else					uart_rxdi_mfsm	<=												UART_RXDI_LEAD	;
			UART_RXDI_SBIT	:			uart_rxdi_mfsm	<=	uart_rxdi_byte_done	?	UART_RXDI_STOP	:	UART_RXDI_SBIT	;
			UART_RXDI_STOP	:			uart_rxdi_mfsm	<=	uart_rxdi_full_baud	? 	UART_RXDI_IDLE	:	UART_RXDI_STOP	;
			default			:			uart_rxdi_mfsm	<=												UART_RXDI_IDLE	;	
		endcase
	end
//********************************************************************************************************************//
	reg			[11: 0]					uart_rxdi_baud_time	;
	reg			[ 2: 0]					uart_rxdi_sbit_cnts	;

	assign		uart_rxdi_half_baud	=	uart_rxdi_baud_time	=={1'B0,cube_uart_rxdi_baud[11: 1]	};
	assign		uart_rxdi_full_baud	=	uart_rxdi_baud_time	==	cube_uart_rxdi_baud	;
	wire		uart_rxdi_full_sbit	= &{uart_rxdi_hits_data	,	uart_rxdi_sbit_cnts , uart_rxdi_half_baud	};	
//------------------------------------------------------------------------------
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						uart_rxdi_baud_time	<=	12'B0	;
	else if(~cube_uart_rxdi_enab) 		uart_rxdi_baud_time	<=	12'B0	;
	else if( cube_uart_rxdi_xchg)		uart_rxdi_baud_time	<=	12'B0	;
	else if( uart_rxdi_hits_idle)		uart_rxdi_baud_time	<=	12'B0	;
	else if( uart_rxdi_full_baud)		uart_rxdi_baud_time	<=	12'B0	;
	else								uart_rxdi_baud_time	<=	uart_rxdi_baud_time + 1	;
//------------------------------------------------------------------------------
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						uart_rxdi_lead_good	<=	0	;
	else if(~cube_uart_rxdi_enab)		uart_rxdi_lead_good	<=	0	;
	else if( uart_rxdi_hits_lead&uart_rxdi_half_baud )
										uart_rxdi_lead_good	<= ~cube_uart_rxdi_sdin	;
//------------------------------------------------------------------------------
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						uart_rxdi_sbit_cnts	<=	0	;
	else if(~uart_rxdi_hits_data)		uart_rxdi_sbit_cnts	<=	0	;
	else if( uart_rxdi_half_baud)		uart_rxdi_sbit_cnts	<=	uart_rxdi_sbit_cnts	+ 1	;
//------------------------------------------------------------------------------
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						uart_rxdi_byte_done	<=	0	;
	else if(~uart_rxdi_hits_data)		uart_rxdi_byte_done	<=	0	;
	else								uart_rxdi_byte_done	<=	uart_rxdi_full_sbit	;
//********************************************************************************************************************//
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						cube_uart_rxdi_data	<=	0	;
	else if(uart_rxdi_hits_idle)		cube_uart_rxdi_data	<=	0	;
	else if(uart_rxdi_hits_data&uart_rxdi_half_baud)		
										cube_uart_rxdi_data	<={ cube_uart_rxdi_sdin	,	cube_uart_rxdi_data[7:1]}	;	
//----------------------------------------------------------------------
	always@(posedge cube_bclk or negedge cube_rstn)
	if(~cube_rstn)						cube_uart_rxdi_drdy	<=	0	;
	else								cube_uart_rxdi_drdy	<=	uart_rxdi_byte_done	;
//********************************************************************************************************************//
endmodule	
