/******************************************************************************/
//max_rows_burst_leng :: 64K halfword~16K ddrs's data_pack when gather 1/4 Vocaburury

module	bram_gmsl_link_data(
	input								dlnk_enab	,
	input								dlnk_rank	,
	input		[10: 0]					dlnk_addr	,
	output	reg	[31: 0]					dlnk_data	,
	input								dlnk_bclk	,
	input								dlnk_rstn	,

	input		[15: 0]					gmsl_data	,
	input								gmsl_drdy	,
	input								gmsl_rrdy	,//hsyn_fall_edge(rows_ready) indicator  
	input								gmsl_bclk	,
	input								gmsl_rstn	);
/**********************************************************************************************************************/
	wire								gmsl_enab	;

	gens_sync_mark 					u_gens_gmsl_mark(	
		.dtar_mark						(gmsl_enab		),//output	
		.dtar_clki						(gmsl_bclk		),//input	
		.dtar_rstn						(gmsl_rstn		),//input	

		.dsrc_mark						(dlnk_enab		),//input   
		.dsrc_clki						(dlnk_bclk		),//input	
		.dsrc_rstn						(dlnk_rstn		));//input	
/**********************************************************************************************************************/
	reg									gmsl_rank	;
	reg									gmsl_wmsb	;
	reg									gmsl_wrdy	;
	reg			[10: 0]					gmsl_wadd	;//2K WORD DEPTH
	reg			[31: 0]					gmsl_word	;

	wire		[15: 0]					gmsl_mhwd	;
	wire		[10: 0]					gmsl_next	;

	assign		gmsl_next	=			gmsl_wadd	+  1	;
	assign		gmsl_mhwd	=			gmsl_word[31:16]	;


	always@(posedge gmsl_bclk or negedge gmsl_rstn)
	if(~gmsl_rstn)						gmsl_rank	<=	0			;
	else if(~gmsl_enab)					gmsl_rank	<=	0			;
	else if( gmsl_rrdy)					gmsl_rank	<= ~gmsl_rank	;

	always@(posedge gmsl_bclk or negedge gmsl_rstn)
	if(~gmsl_rstn)						gmsl_wmsb	<=	0			;
	else if(~gmsl_enab)					gmsl_wmsb	<=	0			;
	else if( gmsl_rrdy)					gmsl_wmsb	<=	0			;
	else if( gmsl_drdy)					gmsl_wmsb	<= ~gmsl_wmsb	;

	always@(posedge gmsl_bclk or negedge gmsl_rstn)
	if(~gmsl_rstn)						gmsl_wrdy	<=	0	;
	else if(~gmsl_enab)					gmsl_wrdy	<=	0	;
	else 								gmsl_wrdy	<=&{gmsl_drdy	,	gmsl_wmsb	};

	always@(posedge gmsl_bclk or negedge gmsl_rstn)
	if(~gmsl_rstn)						gmsl_wadd	<=	0			;
	else if(~gmsl_enab)					gmsl_wadd	<=	0			;
	else if( gmsl_rrdy)					gmsl_wadd	<=	0			;
	else if( gmsl_wrdy)					gmsl_wadd	<=	gmsl_next	;

	always@(posedge gmsl_bclk or negedge gmsl_rstn)
	if(~gmsl_rstn)						gmsl_word	<=	0	;
	else if(~gmsl_enab)					gmsl_word	<=	0	;
	else if( gmsl_drdy)					gmsl_word	<= {gmsl_data	,	gmsl_mhwd	};
/**********************************************************************************************************************/
(*ram_style="block"*) 				
	reg 		[31: 0] 				gmsl_memo[0:4095]	;
	wire		[11: 0]					gmsl_wdpt	= {	gmsl_rank,	gmsl_wadd	};
	
	always@(posedge gmsl_bclk)
	if(gmsl_wrdy)						gmsl_memo[gmsl_wdpt]	<=	gmsl_word	;
//------------------------------------------------------------------------------
	wire		[11: 0]					dlnk_radd	= {	dlnk_rank,	dlnk_addr	};

	always@(posedge dlnk_bclk or negedge dlnk_rstn)
	if(~dlnk_rstn)						dlnk_data	<=	0						;
	else								dlnk_data	<=	gmsl_memo[dlnk_radd]	;
/**********************************************************************************************************************/

endmodule

