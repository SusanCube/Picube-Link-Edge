/******************************************************************************/
//max_rows_burst_leng :: 64K halfword~16K ddrs's data_pack when gather 1/4 Vocaburury

module	edge_txds_hubs_data(
	output								rora_user_tlnk_csen	,//CD:MGTH	
	output		[31: 0]					rora_user_tlnk_data	,//CD:MGTH
	output								rora_user_tlnk_drdy	,//CD:MGTH
	output								rora_user_tlnk_last	,//CD:MGTH
	input								rora_user_tlnk_trdy	,//CD:MGTH
	
	input								etoh_user_alnk_reqs	,//CD:MGTH	
	output	reg							etoh_user_alnk_done	,//CD:MGTH
	input		[31: 0]					etoh_user_alnk_data	,//CD:MGTH

	input								etoh_user_dlnk_enab	,//CD:MGTH
	input		[19: 0]					etoh_user_dlnk_cols	,//CD:MGTH
	input								etoh_user_dlnk_reqs	,//CD:MGTH
	output	reg							etoh_user_dlnk_done	,//CD:MGTH
	input								rora_bclk			,
	input								rora_rstn			,

	input		[15: 0]					gmsl_slnk_rows_data	,
	input								gmsl_slnk_rows_drdy	,
	input								gmsl_slnk_rows_tail	,
	input								gmsl_bclk			,
	input								gmsl_rstn			);
/**********************************************************************************************************************/
	wire								etoh_user_alnk_csen	;
	reg									etoh_user_dlnk_csen	;

	wire								etoh_user_alnk_trdy	;
	wire								etoh_user_dlnk_trdy	;

	wire								etoh_user_alnk_drdy	=	1'B1	;
	wire								etoh_user_dlnk_drdy	=	1'B1	;

	wire		[31: 0]					etoh_user_dlnk_data	;
//------------------------------------------------------------------------------
	wire		rora_user_tlnk_txok	= &{rora_user_tlnk_drdy	,	rora_user_tlnk_trdy};
	assign		etoh_user_alnk_csen	=	etoh_user_alnk_reqs	;
	assign		rora_user_tlnk_csen	= |{etoh_user_alnk_csen	,	etoh_user_dlnk_csen};
	assign		etoh_user_alnk_trdy	= &{etoh_user_alnk_csen	,	rora_user_tlnk_txok};
	assign		etoh_user_dlnk_trdy	= &{etoh_user_dlnk_csen	,	rora_user_tlnk_txok};
//------------------------------------------------------------------------------
	assign		rora_user_tlnk_drdy	= 	etoh_user_alnk_csen	?	etoh_user_alnk_drdy	:
										etoh_user_dlnk_csen	?	etoh_user_dlnk_drdy	:	1'B0	;
	
	assign		rora_user_tlnk_data	=	etoh_user_alnk_csen	?	etoh_user_alnk_data	:
										etoh_user_dlnk_csen	?	etoh_user_dlnk_data	:	31'H0	;

	assign		rora_user_tlnk_last	=	etoh_user_alnk_csen	?	etoh_user_alnk_done	:
										etoh_user_dlnk_csen	?	etoh_user_dlnk_done	:	 1'H0	;
/**********************************************************************************************************************/
//HUBS_TXDS_ROOT_ACKS
/**********************************************************************************************************************/
	assign		etoh_user_alnk_done	=	etoh_user_alnk_trdy	;		

//	always@(posedge rora_bclk or negedge rora_rstn)
//	if(~rora_rstn)						etoh_user_alnk_csen	<=	0	;
//	else if(etoh_user_alnk_reqs)		etoh_user_alnk_csen	<=	1	;
//	else if(etoh_user_alnk_done)		etoh_user_alnk_csen	<=	0	;
/**********************************************************************************************************************/
//HUBS_TDMA_ROOT_DLNK
/**********************************************************************************************************************/
	reg									etoh_user_dlnk_rank	;
	reg		[10: 0]						etoh_user_dlnk_dptr	;

	wire								etoh_user_dlnk_txok	;
	wire								etoh_user_dlnk_last	;
	wire	[10: 0]						etoh_user_dlnk_next	;
	wire	[10: 0]						etoh_user_dlnk_addr	;

	assign		etoh_user_dlnk_txok	= &{etoh_user_dlnk_csen	,	rora_user_tlnk_trdy	};
	assign		etoh_user_dlnk_next	=	etoh_user_dlnk_dptr + 1	;
	assign		etoh_user_dlnk_addr	=	etoh_user_dlnk_txok	?	etoh_user_dlnk_next	:	etoh_user_dlnk_dptr	;
	assign		etoh_user_dlnk_done	= &{etoh_user_dlnk_txok	,	etoh_user_dlnk_next	==	etoh_user_dlnk_cols[11:1]};
//------------------------------------------------------------------------------
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						etoh_user_dlnk_csen	<=	0	;
	else if(~etoh_user_dlnk_enab)		etoh_user_dlnk_csen	<=	0	;
	else if( etoh_user_dlnk_done)		etoh_user_dlnk_csen	<=	0	;
	else if( etoh_user_dlnk_reqs)		etoh_user_dlnk_csen	<=	1	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						etoh_user_dlnk_rank	<=	0	;
	else if(~etoh_user_dlnk_enab)		etoh_user_dlnk_rank	<=	0	;
	else if( etoh_user_dlnk_done)		etoh_user_dlnk_rank	<= ~etoh_user_dlnk_rank	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						etoh_user_dlnk_dptr	<=	0	;
	else if(~etoh_user_dlnk_enab)		etoh_user_dlnk_dptr	<=	0	;
	else if(~etoh_user_dlnk_csen)		etoh_user_dlnk_dptr	<=	0	;
	else if( etoh_user_dlnk_txok)		etoh_user_dlnk_dptr	<=	etoh_user_dlnk_next	;
//u_htor_txdo_fifo_data------------------------------------------------------------------------------
	bram_gmsl_link_data				u_bram_gmsl_link_data(
		.dlnk_enab						(etoh_user_dlnk_enab	),//input				
		.dlnk_rank						(etoh_user_dlnk_rank	),//input				
		.dlnk_addr						(etoh_user_dlnk_addr	),//input		[10: 0]	
		.dlnk_data						(etoh_user_dlnk_data	),//output		[31: 0]	
		.dlnk_bclk						(rora_bclk				),//input				
		.dlnk_rstn						(rora_rstn				),//input				

		.gmsl_data						(gmsl_slnk_rows_data	),//input		[15: 0]	
		.gmsl_drdy						(gmsl_slnk_rows_drdy	),//input				
		.gmsl_rrdy						(gmsl_slnk_rows_tail	),//input		//horizon indicator fall edge 
		.gmsl_bclk						(gmsl_bclk				),//input				
		.gmsl_rstn						(gmsl_rstn				));//input				


endmodule

 