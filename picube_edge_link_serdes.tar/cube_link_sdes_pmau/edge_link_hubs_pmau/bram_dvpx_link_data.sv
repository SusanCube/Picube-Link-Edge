module	bram_dvpx_link_data	(	
	input								wport_rank	,
	input  				 				wport_csen	,
	input		[10: 0]					wport_addr	,
	input		[31: 0]					wport_data	,
	input								wport_clki	,

	input								rport_rank	,
	input		[10: 0]			 		rport_addr	,
	output	reg	[31: 0]			 		rport_data	,
	input								rport_clki	);
/**********************************************************************************************************************/
	(*ram_style="block"*) 				
	reg 		[31: 0] 				memo[0:4095]	;
	wire		[11: 0]					page_wadd	= {	wport_rank,	wport_addr	};
	
	always@(posedge wport_clki)
	if(wport_csen)						memo[page_wadd]	<=	wport_data	;
/**********************************************************************************************************************/
	reg			[31: 0]					page_read	;		
	wire		[11: 0]					page_radd	;

	assign		page_radd 	= 		{	rport_rank	,	rport_addr	};
//	assign		rport_data	=			page_hwda	?	page_read[31:16]	:	page_read[15:0]	;

	always@(posedge rport_clki)			rport_data		<=	memo[page_radd]	;

//	wire		[10: 0]					page_wrda	;
//	wire								page_hwad	;
//	wire		[11: 0]					page_radd	;
//	assign		page_wrda	=			rport_addr[11: 1]	;
//	assign		page_hwda	=			rport_addr[  0  ]	;
//	assign		page_radd 	= 		{	rport_rank	,	page_wrda	};
//	assign		rport_data	=			page_hwda	?	page_read[31:16]	:	page_read[15:0]	;
//
//	always@(posedge rport_clki)			page_read		<=	memo[page_radd]	;
/**********************************************************************************************************************/

endmodule