
module	edge_txds_hubs_ufcm(
	output	reg							rora_ufcm_tlnk_csen	,
	output	reg	[31: 0]					rora_ufcm_tlnk_data	,
	output	reg							rora_ufcm_tlnk_reqs	,
	input								rora_ufcm_tlnk_acks	,
	
	output								etoh_ufcm_tlnk_done	,
	input								etoh_ufcm_tlnk_reqs	,
	input								etoh_ufcm_acks_lead	,
	input								etoh_ufcm_acks_coda	,
	input								etoh_ufcm_data_lead	,
	input								etoh_ufcm_data_coda	,
	input								etoh_ufcm_resp_tokn	,
	input								etoh_ufcm_trdy_tokn	,
	
	input								rora_bclk			,
	input								rora_rstn			);
/**********************************************************************************************************************/
	reg			[ 2: 0]					rora_ufcm_tlnk_mfsm	;

	parameter	ETOH_UFCM_IDLE	=	3'H0	;
	parameter	ETOH_UFCM_ACKS	=	3'H1	;
	parameter	ETOH_UFCM_MSWD	=	3'H2	;
	parameter	ETOH_UFCM_LSWD	=	3'H3	;
	parameter	ETOH_UFCM_DONE	=	3'H4	;
//------------------------------------------------------------------------------
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_ufcm_tlnk_mfsm	<=	ETOH_UFCM_IDLE	;
	else	begin
		case(rora_ufcm_tlnk_mfsm)	
			ETOH_UFCM_IDLE		:		rora_ufcm_tlnk_mfsm	<=	etoh_ufcm_tlnk_reqs	?	ETOH_UFCM_ACKS	:	ETOH_UFCM_IDLE	;
			ETOH_UFCM_ACKS		:		rora_ufcm_tlnk_mfsm	<=	rora_ufcm_tlnk_acks	?	ETOH_UFCM_MSWD	:	ETOH_UFCM_ACKS	;
			ETOH_UFCM_MSWD		:		rora_ufcm_tlnk_mfsm	<=												ETOH_UFCM_LSWD	;
			ETOH_UFCM_LSWD		:		rora_ufcm_tlnk_mfsm	<=												ETOH_UFCM_DONE	;
			ETOH_UFCM_DONE		:		rora_ufcm_tlnk_mfsm	<=	etoh_ufcm_tlnk_reqs	?	ETOH_UFCM_DONE	:	ETOH_UFCM_IDLE	;
			default				:		rora_ufcm_tlnk_mfsm	<=												ETOH_UFCM_IDLE	;	
		endcase
	end 
/**********************************************************************************************************************/
	assign		etoh_ufcm_tlnk_done	=	rora_ufcm_tlnk_mfsm	==	ETOH_UFCM_DONE	;
	wire		etoh_ufcm_hits_idle	=	rora_ufcm_tlnk_mfsm	==	ETOH_UFCM_IDLE	;
	wire		etoh_ufcm_hits_acks	=	rora_ufcm_tlnk_mfsm	==	ETOH_UFCM_ACKS	;
	wire		etoh_ufcm_hits_mswd	=	rora_ufcm_tlnk_mfsm	==	ETOH_UFCM_MSWD	;
	
	wire		etoh_ufcm_link_issu	= &{etoh_ufcm_hits_idle	,	etoh_ufcm_tlnk_reqs	};
	wire		etoh_ufcm_txdo_mswd	= &{etoh_ufcm_hits_acks	,	rora_ufcm_tlnk_acks	};
	wire		etoh_ufcm_txdo_lswd	= 	rora_ufcm_tlnk_mfsm	==	ETOH_UFCM_MSWD	;
//------------------------------------------------------------------------------
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_ufcm_tlnk_csen	<=	0	;
	else if(etoh_ufcm_link_issu)		rora_ufcm_tlnk_csen	<=	1	;
	else if(etoh_ufcm_tlnk_done)		rora_ufcm_tlnk_csen	<=	0	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_ufcm_tlnk_reqs	<=	0	;
	else if(etoh_ufcm_link_issu)		rora_ufcm_tlnk_reqs	<=	1	;
	else if(rora_ufcm_tlnk_acks)		rora_ufcm_tlnk_reqs	<=	0	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_ufcm_tlnk_data	<=	0	;
	else if(etoh_ufcm_txdo_mswd)		rora_ufcm_tlnk_data	<=	etoh_ufcm_acks_lead	?	"ACKS"	:
																etoh_ufcm_acks_coda	?	"ACKS"	:	
																etoh_ufcm_data_lead	?	"DATA"	:
																etoh_ufcm_data_coda	?	"DATA"	:	
																etoh_ufcm_resp_tokn	?	"RESP"	:	
																etoh_ufcm_trdy_tokn	?	"DATA"	:	32'H0	;
	else if(etoh_ufcm_txdo_lswd)		rora_ufcm_tlnk_data	<=	etoh_ufcm_acks_lead	?	"LEAD"	:
																etoh_ufcm_acks_coda	?	"CODA"	:	
																etoh_ufcm_data_lead	?	"LEAD"	:
																etoh_ufcm_data_coda	?	"CODA"	:	
																etoh_ufcm_resp_tokn	?	"ONSE"	:	
																etoh_ufcm_trdy_tokn	?	"TRDY"	:	32'H0	;
	else								rora_ufcm_tlnk_data	<=	0	;
	

	





endmodule


