module	edge_link_hubs_pmau(
	input		[31: 0]					rora_user_rxln_data	,
	input								rora_user_rxln_drdy	,
	input		[31: 0]					rora_ufcm_rxln_data	,
	input								rora_ufcm_rxln_drdy	,
	input								rora_ufcm_rxln_last	,

	output		[31: 0]					rora_user_txln_data	,
	output								rora_user_txln_drdy	,
	output								rora_user_txln_last	,
	input								rora_user_txln_trdy	,
	output								rora_ufcm_txln_reqs	,
	input								rora_ufcm_txln_acks	,

	output		[ 3: 0]					rora_rxln_cmnd_addr	,
	output		[31: 0]					rora_rxln_cmnd_data	,
	output								rora_rxln_cmnd_drdy	,
	output								rora_rxln_cmnd_coda	,
	output								rora_rxln_data_coda	,
//======================================================================================================================
	output								rora_acks_txln_done	,//to 	rv32_controller
	input								rora_acks_rv32_reqs	,//from rv32_controller
	input		[31: 0]					rora_acks_rv32_data	,//from rv32_controller
	input								rora_acks_cube_reqs	,//from cube(ufcm)_link_controller
	input		[31: 0]					rora_acks_cube_data	,//from cube(ufcm)_link_controller
	
	output								rora_resp_txln_done	,//to 	cube(ufcm)_link_controller
	input								rora_resp_cube_reqs	,//from cube(ufcm)_link_controller

	output								rora_trdy_txln_done	,//to 	cube(dvpx)_link_controller
	input								rora_trdy_cube_reqs	,//from cube(dvpx)_link_controller

	output								rora_gmsl_slnk_done	,//to 	cube(gmsl)_link_controller
	input								rora_gmsl_slnk_enab	,//from cube(gmsl)_link_controller
	input		[19: 0]					rora_gmsl_slnk_rows	,
	input		[19: 0]					rora_gmsl_slnk_cols	,
	input								rora_gmsl_slnk_reqs	,//from cube(gmsl)_link_controller

	input								rora_bclk			,
	input								rora_rstn			,
//======================================================================================================================
	input								dvpx_dlnk_memo_rank	,
	input		[10: 0]					dvpx_dlnk_memo_addr	,
	output		[31: 0]					dvpx_dlnk_memo_data	,
	input								dvpx_bclk			,

	input		[15: 0]					gmsl_slnk_rows_data	,
	input								gmsl_slnk_rows_drdy	,
	input								gmsl_slnk_rows_tail	,
	input								gmsl_bclk			,
	input								gmsl_rstn			);
//======================================================================================================================
	edge_rxln_hubs_pmau				u_edge_rxds_hubs_pmau(
		.rora_user_rxln_data			(rora_user_rxln_data	),//input		[31: 0]	
		.rora_user_rxln_drdy			(rora_user_rxln_drdy	),//input				
		.rora_ufcm_rxln_data			(rora_ufcm_rxln_data	),//input		[31: 0]	
		.rora_ufcm_rxln_drdy			(rora_ufcm_rxln_drdy	),//input				
		.rora_ufcm_rxln_last			(rora_ufcm_rxln_last	),//input				

		.rora_rxln_cmnd_addr			(rora_rxln_cmnd_addr	),//output		[ 3: 0]	
		.rora_rxln_cmnd_data			(rora_rxln_cmnd_data	),//output		[31: 0]	
		.rora_rxln_cmnd_drdy			(rora_rxln_cmnd_drdy	),//output				
		.rora_rxln_cmnd_coda			(rora_rxln_cmnd_coda	),//output						

		.rora_rxln_data_lead			(rora_rxln_data_lead	),//output						
		.rora_rxln_data_coda			(rora_rxln_data_coda	),//output						
		.rora_bclk						(rora_bclk				),//input
		.rora_rstn						(rora_rstn				),//input

		.dvpx_dlnk_memo_rank			(dvpx_dlnk_memo_rank	),//input				
		.dvpx_dlnk_memo_addr			(dvpx_dlnk_memo_addr	),//input		[10: 0]	
		.dvpx_dlnk_memo_data			(dvpx_dlnk_memo_data	),//output		[31: 0]	
		.dvpx_bclk						(dvpx_bclk				));//input				
//======================================================================================================================
	edge_txln_hubs_pmau				u_edge_txds_hubs_pmau(
		.rora_user_txln_data			(rora_user_txln_data	),//output		[31: 0]	
		.rora_user_txln_drdy			(rora_user_txln_drdy	),//output				
		.rora_user_txln_last			(rora_user_txln_last	),//output				
		.rora_user_txln_trdy			(rora_user_txln_trdy	),//input	
					
		.rora_ufcm_txln_reqs			(rora_ufcm_txln_reqs	),//output				
		.rora_ufcm_txln_acks			(rora_ufcm_txln_acks	),//input				

		.rora_acks_txln_done			(rora_acks_txln_done	),//output				//to 	rv32_controller
		.rora_acks_rv32_reqs			(rora_acks_rv32_reqs	),//input				//from rv32_controller
		.rora_acks_rv32_data			(rora_acks_rv32_data	),//input		[31: 0]	//from rv32_controller
		.rora_acks_cube_reqs			(rora_acks_cube_reqs	),//input				//from cube(ufcm)_link_controller
		.rora_acks_cube_data			(rora_acks_cube_data	),//input		[31: 0]	//from cube(ufcm)_link_controller
	
		.rora_resp_txln_done			(rora_resp_txln_done	),//output				//to 	cube(ufcm)_link_controller
		.rora_resp_cube_reqs			(rora_resp_cube_reqs	),//input				//from cube(ufcm)_link_controller

		.rora_trdy_txln_done			(rora_trdy_txln_done	),//output				//to 	cube(ufcm)_link_controller
		.rora_trdy_cube_reqs			(rora_trdy_cube_reqs	),//input				//from cube(ufcm)_link_controller

		.rora_gmsl_slnk_done			(rora_gmsl_slnk_done	),//output				//to 	cube(gmsl)_link_controller
		.rora_gmsl_slnk_enab			(rora_gmsl_slnk_enab	),//input				//from cube(gmsl)_link_controller
		.rora_gmsl_slnk_rows			(rora_gmsl_slnk_rows	),//input		[19: 0]	
		.rora_gmsl_slnk_cols			(rora_gmsl_slnk_cols	),//input		[19: 0]	
		.rora_gmsl_slnk_reqs			(rora_gmsl_slnk_reqs	),//input				//from cube(gmsl)_link_controller
		.rora_bclk						(rora_bclk				),//input				
		.rora_rstn						(rora_rstn				),//input				

		.gmsl_slnk_rows_data			(gmsl_slnk_rows_data	),//input		[15: 0]	
		.gmsl_slnk_rows_drdy			(gmsl_slnk_rows_drdy	),//input				
		.gmsl_slnk_rows_tail			(gmsl_slnk_rows_tail	),//input				
		.gmsl_bclk						(gmsl_bclk				),//input				
		.gmsl_rstn						(gmsl_rstn				));//input				
//======================================================================================================================	
endmodule
