/**********************************************************************************************************************/
module	edge_txln_hubs_pmau(
	output		[31: 0]					rora_user_txln_data	,
	output								rora_user_txln_drdy	,
	output								rora_user_txln_last	,
	input								rora_user_txln_trdy	,

	output								rora_ufcm_txln_reqs	,
	input								rora_ufcm_txln_acks	,

	output								rora_acks_txln_done	,//to 	rv32_controller
	input								rora_acks_rv32_reqs	,//from rv32_controller
	input		[31: 0]					rora_acks_rv32_data	,//from rv32_controller
	input								rora_acks_cube_reqs	,//from cube(ufcm)_link_controller
	input		[31: 0]					rora_acks_cube_data	,//from cube(ufcm)_link_controller

	output								rora_resp_txln_done	,//to 	cube(ufcm)_link_controller
	input								rora_resp_cube_reqs	,//from cube(ufcm)_link_controller
	
	output								rora_trdy_txln_done	,//to 	cube(dvpx)_link_controller
	input								rora_trdy_cube_reqs	,//from cube(dvpx)_link_controller
	
	output								rora_gmsl_slnk_done	,//to 	cube(gmsl)_link_controller
	input								rora_gmsl_slnk_enab	,//from cube(gmsl)_link_controller
	input		[19: 0]					rora_gmsl_slnk_rows	,
	input		[19: 0]					rora_gmsl_slnk_cols	,
	input								rora_gmsl_slnk_reqs	,//from cube(gmsl)_link_controller
	input								rora_bclk			,
	input								rora_rstn			,

	input		[15: 0]					gmsl_slnk_rows_data	,
	input								gmsl_slnk_rows_drdy	,
	input								gmsl_slnk_rows_tail	,
	input								gmsl_bclk			,
	input								gmsl_rstn			);
/**********************************************************************************************************************/
	wire								rora_ufcm_tlnk_csen	;
	wire		[31: 0]					rora_ufcm_tlnk_data	;

	wire								rora_user_tlnk_csen	;//CD:MGTH
	wire		[31: 0]					rora_user_tlnk_data	;//CD:MGTH
	wire								rora_user_tlnk_drdy	;//CD:MGTH
	wire								rora_user_tlnk_last	;//CD:MGTH

	assign		rora_user_txln_data	=	rora_ufcm_tlnk_csen	?	rora_ufcm_tlnk_data	:
										rora_user_tlnk_csen	?	rora_user_tlnk_data	:	32'H0	;
	assign		rora_user_txln_drdy	= &{rora_user_tlnk_csen	&	rora_user_tlnk_drdy	};//:	1'H0	;
	assign		rora_user_txln_last	= &{rora_user_tlnk_csen	&	rora_user_tlnk_last	};//:	1'H0	;
/**********************************************************************************************************************/
	wire		[31: 0]					etoh_user_alnk_data	;

	edge_txds_hubs_dmau				u_edge_txds_hubs_dmau(
		.rora_acks_txln_done			(rora_acks_txln_done	),//output				//to 	ALL
		
		.rora_acks_rv32_reqs			(rora_acks_rv32_reqs	),//input				//from 	rv32_controller
		.rora_acks_rv32_data			(rora_acks_rv32_data	),//input		[31: 0]	//from 	rv32_controller
		
		.rora_acks_cube_reqs			(rora_acks_cube_reqs	),//input				//from 	cube(ufcm)_link_controller
		.rora_acks_cube_data			(rora_acks_cube_data	),//input		[31: 0]	//from 	cube(ufcm)_link_controller

		.rora_resp_txln_done			(rora_resp_txln_done	),//input				//to 	cube(ufcm)_link_controller
		.rora_resp_cube_reqs			(rora_resp_cube_reqs	),//input				//from 	cube(ufcm)_link_controller

		.rora_trdy_txln_done			(rora_trdy_txln_done	),//output				//to 	cube(dvpx)_link_controller
		.rora_trdy_cube_reqs			(rora_trdy_cube_reqs	),//input				//from 	cube(dvpx)_link_controller

		.rora_gmsl_txln_rows			(rora_gmsl_slnk_rows	),//input		[19: 0]	//from 	rv32_controller		
		.rora_gmsl_txln_done			(rora_gmsl_slnk_done	),//output				//to 	cube(gmsl)_link_controller
		.rora_gmsl_txln_enab			(rora_gmsl_slnk_enab	),//input				//from 	cube(gmsl)_link_controller
		.rora_gmsl_txln_reqs			(rora_gmsl_slnk_reqs	),//input				//from 	cube(gmsl)_link_controller

		.etoh_ufcm_tlnk_done			(etoh_ufcm_tlnk_done	),//input				//from	txds_ufcm_pmau
		.etoh_ufcm_tlnk_reqs			(etoh_ufcm_tlnk_reqs	),//output				//to	txds_ufcm_pmau
		.etoh_ufcm_acks_lead			(etoh_ufcm_acks_lead	),//output				//to	txds_ufcm_pmau
		.etoh_ufcm_acks_coda			(etoh_ufcm_acks_coda	),//output				//to	txds_ufcm_pmau
		.etoh_ufcm_data_lead			(etoh_ufcm_data_lead	),//output				//to	txds_ufcm_pmau
		.etoh_ufcm_data_coda			(etoh_ufcm_data_coda	),//output				//to	txds_ufcm_pmau
		.etoh_ufcm_resp_tokn			(etoh_ufcm_resp_tokn	),//output				//to	txds_ufcm_pmau
		.etoh_ufcm_trdy_tokn			(etoh_ufcm_trdy_tokn	),//output				//to	txds_ufcm_pmau

		.etoh_user_alnk_done			(etoh_user_alnk_done	),//input				//from	txds_data_pmau
		.etoh_user_alnk_reqs			(etoh_user_alnk_reqs	),//output				//to 	txds_data_pmau
		.etoh_user_alnk_data			(etoh_user_alnk_data	),//output		[31: 0]	//to 	txds_data_pmau
		.etoh_user_dlnk_done			(etoh_user_dlnk_done	),//input				//from	txds_data_pmau
		.etoh_user_dlnk_reqs			(etoh_user_dlnk_reqs	),//output				//to 	txds_data_pmau

		.rora_bclk						(rora_bclk				),//input				
		.rora_rstn						(rora_rstn				));//input				
//------------------------------------------------------------------------------
	edge_txds_hubs_ufcm				u_edge_txds_hubs_ufcm(
		.rora_ufcm_tlnk_csen			(rora_ufcm_tlnk_csen	),//output	reg			
		.rora_ufcm_tlnk_data			(rora_ufcm_tlnk_data	),//output	reg	[63: 0]	
		.rora_ufcm_tlnk_reqs			(rora_ufcm_txln_reqs	),//output	reg			
		.rora_ufcm_tlnk_acks			(rora_ufcm_txln_acks	),//input				
	
		.etoh_ufcm_tlnk_done			(etoh_ufcm_tlnk_done	),//output	
		.etoh_ufcm_tlnk_reqs			(etoh_ufcm_tlnk_reqs	),//input	
		.etoh_ufcm_acks_lead			(etoh_ufcm_acks_lead	),//input	
		.etoh_ufcm_acks_coda			(etoh_ufcm_acks_coda	),//input	
		.etoh_ufcm_data_lead			(etoh_ufcm_data_lead	),//input	
		.etoh_ufcm_data_coda			(etoh_ufcm_data_coda	),//input	
		.etoh_ufcm_resp_tokn			(etoh_ufcm_resp_tokn	),//input	
		.etoh_ufcm_trdy_tokn			(etoh_ufcm_trdy_tokn	),//input	

		.rora_bclk						(rora_bclk				),//input	
		.rora_rstn						(rora_rstn				));//input	
//------------------------------------------------------------------------------
	edge_txds_hubs_data				u_edge_txds_hubs_data(
		.rora_user_tlnk_csen			(rora_user_tlnk_csen	),//output					//CD:MGTH	
		.rora_user_tlnk_data			(rora_user_tlnk_data	),//output		[63: 0]		//CD:MGTH
		.rora_user_tlnk_drdy			(rora_user_tlnk_drdy	),//output					//CD:MGTH
		.rora_user_tlnk_last			(rora_user_tlnk_last	),//output					//CD:MGTH
		.rora_user_tlnk_trdy			(rora_user_txln_trdy	),//input					//CD:MGTH
	
		.etoh_user_alnk_done			(etoh_user_alnk_done	),//output	reg				//CD:MGTH
		.etoh_user_alnk_reqs			(etoh_user_alnk_reqs	),//input					//CD:MGTH	
		.etoh_user_alnk_data			(etoh_user_alnk_data	),//input		[63: 0]		//CD:MGTH

		.etoh_user_dlnk_enab			(rora_gmsl_slnk_enab	),//input					//CD:MGTH
		.etoh_user_dlnk_cols			(rora_gmsl_slnk_cols	),//input		[19: 0]		//CD:MGTH
		.etoh_user_dlnk_done			(etoh_user_dlnk_done	),//output	reg				//CD:MGTH
		.etoh_user_dlnk_reqs			(etoh_user_dlnk_reqs	),//input					//CD:MGTH
		.rora_bclk						(rora_bclk				),//input				
		.rora_rstn						(rora_rstn				),//input				

		.gmsl_slnk_rows_data			(gmsl_slnk_rows_data	),//input		[15: 0]	
		.gmsl_slnk_rows_drdy			(gmsl_slnk_rows_drdy	),//input				
		.gmsl_slnk_rows_tail			(gmsl_slnk_rows_tail	),//input				
		
		.gmsl_bclk						(gmsl_bclk				),//input				
		.gmsl_rstn						(gmsl_rstn				));//input				
	
endmodule

 