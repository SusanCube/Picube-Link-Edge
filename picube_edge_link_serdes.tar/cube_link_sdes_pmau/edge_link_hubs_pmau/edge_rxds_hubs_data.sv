//	AUTHOR	: 	EDWARD YANG
//	VERSION	:	20260902 - VER1.0
module	edge_rxds_hubs_data(
	input		[31: 0]					rora_rxln_user_data	,
	input								rora_rxln_user_drdy	,

	input								rora_rxln_cmnd_lead	,
	input								rora_rxln_cmnd_coda	,
	input								rora_rxln_data_lead	,
	input								rora_rxln_data_coda	,

	output	reg	[ 3: 0]					rora_rxln_cmnd_addr	,
	output		[31: 0]					rora_rxln_cmnd_data	,
	output								rora_rxln_cmnd_drdy	,
	input								rora_bclk			,
	input								rora_rstn			,

	input								dvpx_dlnk_memo_rank	,
	input		[10: 0]					dvpx_dlnk_memo_addr	,
	output		[31: 0]					dvpx_dlnk_memo_data	,
	input								dvpx_bclk			);
/**********************************************************************************************************************/
	reg									rora_rxln_cmnd_csen	;

	assign		rora_rxln_cmnd_drdy	= &{rora_rxln_cmnd_csen	,	rora_rxln_user_drdy	};
	assign		rora_rxln_cmnd_data	= 	rora_rxln_cmnd_csen	?	rora_rxln_user_data	:	32'H0	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_rxln_cmnd_csen	<=	0	;
	else if(rora_rxln_cmnd_lead)		rora_rxln_cmnd_csen	<=	1	;
	else if(rora_rxln_cmnd_coda)		rora_rxln_cmnd_csen	<= 	0	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_rxln_cmnd_addr	<=	0	;
	else if(~rora_rxln_cmnd_csen)		rora_rxln_cmnd_addr	<=	0	;
	else if (rora_rxln_cmnd_drdy)		rora_rxln_cmnd_addr	<= 	rora_rxln_cmnd_addr + 1	;
/**********************************************************************************************************************/
	reg									rora_rxln_data_csen	;
	reg									rora_rxln_data_rank	;
	reg			[10: 0]					rora_rxln_data_addr	;

	wire		rora_rxln_data_drdy	= &{rora_rxln_data_csen	,	rora_rxln_user_drdy	};
	
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_rxln_data_csen	<=	0	;
	else if( rora_rxln_data_lead)		rora_rxln_data_csen	<=	1	;
	else if( rora_rxln_data_coda)		rora_rxln_data_csen	<= 	0	;


	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_rxln_data_rank	<=	0	;
	else if( rora_rxln_cmnd_lead)		rora_rxln_data_rank	<=	0	;
	else if( rora_rxln_data_coda)		rora_rxln_data_rank	<= ~rora_rxln_data_rank	;
	
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_rxln_data_addr	<=	0	;
	else if(~rora_rxln_data_csen)		rora_rxln_data_addr	<=	0	;
	else if( rora_rxln_data_drdy)		rora_rxln_data_addr	<=	rora_rxln_data_addr + 1	;
/**********************************************************************************************************************/
	bram_dvpx_link_data				u_dvpx_dlnk_wdma_memo(	
		.wport_rank						(rora_rxln_data_rank	),//input					
		.wport_csen						(rora_rxln_data_drdy	),//input  				 	
		.wport_addr						(rora_rxln_data_addr	),//input		[10:0]	
		.wport_data						(rora_rxln_user_data	),//input		[31:0]	
		.wport_clki						(rora_bclk				),//input					

		.rport_rank						(dvpx_dlnk_memo_rank	),	//input				
		.rport_addr						(dvpx_dlnk_memo_addr	),	//input		[10: 0]	
		.rport_data						(dvpx_dlnk_memo_data	),	//output	reg	[31: 0]	
		.rport_clki						(dvpx_bclk				));	//input				


endmodule
