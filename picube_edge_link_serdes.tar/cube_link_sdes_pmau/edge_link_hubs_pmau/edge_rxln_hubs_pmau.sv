module	edge_rxln_hubs_pmau(
	input		[31: 0]					rora_user_rxln_data	,
	input								rora_user_rxln_drdy	,
	input		[31: 0]					rora_ufcm_rxln_data	,
	input								rora_ufcm_rxln_drdy	,
	input								rora_ufcm_rxln_last	,
	
	output								rora_rxln_cmnd_coda	,
	output		[ 3: 0]					rora_rxln_cmnd_addr	,
	output		[31: 0]					rora_rxln_cmnd_data	,
	output								rora_rxln_cmnd_drdy	,

	output								rora_rxln_data_lead	,
	output								rora_rxln_data_coda	,
	input								rora_bclk			,
	input								rora_rstn			,

	input								dvpx_dlnk_memo_rank	,
	input		[10: 0]					dvpx_dlnk_memo_addr	,
	output		[31: 0]					dvpx_dlnk_memo_data	,
	input								dvpx_bclk			);
//----------------------------------------------------------------------------------------------------------------------
	edge_rxds_hubs_ufcm				u_edge_rxds_hubs_ufcm(
		.rora_rxln_ufcm_data			(rora_ufcm_rxln_data	),//input		[31: 0]	
		.rora_rxln_ufcm_drdy			(rora_ufcm_rxln_drdy	),//input				
		.rora_rxln_ufcm_last			(rora_ufcm_rxln_last	),//input				
		.rora_rxln_cmnd_lead			(rora_rxln_cmnd_lead	),//output	reg			
		.rora_rxln_cmnd_coda			(rora_rxln_cmnd_coda	),//output	reg			
		.rora_rxln_data_lead			(rora_rxln_data_lead	),//output	reg			
		.rora_rxln_data_coda			(rora_rxln_data_coda	),//output	reg			
		.rora_bclk						(rora_bclk				),//input				
		.rora_rstn						(rora_rstn				));//input				
//----------------------------------------------------------------------------------------------------------------------
	edge_rxds_hubs_data				u_edge_rxds_hubs_data(
		.rora_rxln_user_data			(rora_user_rxln_data	),//input		[31: 0]			
		.rora_rxln_user_drdy			(rora_user_rxln_drdy	),//input						

		.rora_rxln_cmnd_lead			(rora_rxln_cmnd_lead	),//input						
		.rora_rxln_cmnd_coda			(rora_rxln_cmnd_coda	),//input						
		.rora_rxln_data_lead			(rora_rxln_data_lead	),//input						
		.rora_rxln_data_coda			(rora_rxln_data_coda	),//input						

		.rora_rxln_cmnd_addr			(rora_rxln_cmnd_addr	),//output	reg	[ 3: 0]	
		.rora_rxln_cmnd_data			(rora_rxln_cmnd_data	),//output		[31: 0]	
		.rora_rxln_cmnd_drdy			(rora_rxln_cmnd_drdy	),//output				
		.rora_bclk						(rora_bclk				),//input						
		.rora_rstn						(rora_rstn				),//input						

		.dvpx_dlnk_memo_rank			(dvpx_dlnk_memo_rank	),//input						
		.dvpx_dlnk_memo_addr			(dvpx_dlnk_memo_addr	),//input		[10: 0]			
		.dvpx_dlnk_memo_data			(dvpx_dlnk_memo_data	),//output		[31: 0]			
		.dvpx_bclk						(dvpx_bclk				));//input						

endmodule
