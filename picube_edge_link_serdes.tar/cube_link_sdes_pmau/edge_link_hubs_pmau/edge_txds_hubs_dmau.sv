/******************************************************************************/
module	edge_txds_hubs_dmau(
	output								rora_acks_txln_done	,
	
	input								rora_acks_rv32_reqs	,
	input		[31: 0]					rora_acks_rv32_data	,

	input								rora_acks_cube_reqs	,
	input		[31: 0]					rora_acks_cube_data	,

	output								rora_resp_txln_done	,//to 	cube(ufcm)_link_controller
	input								rora_resp_cube_reqs	,//from cube(ufcm)_link_controller

	output								rora_trdy_txln_done	,//from cube(dvpx)_link_controller
	input								rora_trdy_cube_reqs	,//from cube(dvpx)_link_controller

	output								rora_gmsl_txln_done	,//to 	cube(gmsl)_link_controller
	input		[19: 0]					rora_gmsl_txln_rows	,//from rv32_controller
	input								rora_gmsl_txln_enab	,//from cube(gmsl)_link_controller
	input								rora_gmsl_txln_reqs	,//from cube(gmsl)_link_controller

	input								etoh_ufcm_tlnk_done	,//from	txds_ufcm_pmau
	output								etoh_ufcm_tlnk_reqs	,//to	txds_ufcm_pmau
	output								etoh_ufcm_acks_lead	,//to	txds_ufcm_pmau
	output								etoh_ufcm_acks_coda	,//to	txds_ufcm_pmau
	output								etoh_ufcm_data_lead	,//to	txds_ufcm_pmau
	output								etoh_ufcm_data_coda	,//to	txds_ufcm_pmau
	output								etoh_ufcm_resp_tokn	,//to	txds_ufcm_pmau
	output								etoh_ufcm_trdy_tokn	,//to	txds_ufcm_pmau

	input								etoh_user_dlnk_done	,//from	txds_data_pmau
	output								etoh_user_dlnk_reqs	,//to 	txds_data_pmau
	input								etoh_user_alnk_done	,//from	txds_data_pmau
	output								etoh_user_alnk_reqs	,//to 	txds_data_pmau
	output	reg	[31: 0]					etoh_user_alnk_data	,//to 	txds_data_pmau
	
	input								rora_bclk			,
	input								rora_rstn			);
/**********************************************************************************************************************/
	reg			[ 3: 0]					etoh_dmau_txds_mfsm	;

	parameter	ETOH_LINK_IDLE		=	4'H0	;
	
	parameter	ETOH_TRDY_TOKN		=	4'H1	;
	parameter	ETOH_TRDY_DONE		=	4'H2	;

	parameter	ETOH_RESP_TOKN		=	4'H3	;
	parameter	ETOH_RESP_DONE		=	4'H4	;
	
	parameter	ETOH_ACKS_LEAD		=	4'H5	;
	parameter	ETOH_ACKS_PACK		=	4'H6	;
	parameter	ETOH_ACKS_CODA		=	4'H7	;
	parameter	ETOH_ACKS_DONE		=	4'H8	;

	
	parameter	ETOH_FRAM_ROWS		=	4'H9	;
	parameter	ETOH_ROWS_LEAD		=	4'HA	;
	parameter	ETOH_ROWS_PACK		=	4'HB	;
	parameter	ETOH_ROWS_CODA		=	4'HC	;
	parameter	ETOH_ROWS_LOOP		=	4'HD	;
	parameter	ETOH_FRAM_DONE		=	4'HE	;
//----------------------------------------------------------------------------------------------------------------------
	wire								mixs_acks_link_reqs	;
	wire								cube_fram_rows_maxi	;

	assign		mixs_acks_link_reqs	= |{rora_acks_rv32_reqs	,	rora_acks_cube_reqs	};	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						etoh_dmau_txds_mfsm	<=							ETOH_LINK_IDLE	;
	else 								begin
        case(etoh_dmau_txds_mfsm)
			ETOH_LINK_IDLE		:		etoh_dmau_txds_mfsm	<=	rora_gmsl_txln_enab	?	ETOH_FRAM_ROWS	:
																rora_resp_cube_reqs	?	ETOH_RESP_TOKN	:
																rora_trdy_cube_reqs	?	ETOH_TRDY_TOKN	:
																mixs_acks_link_reqs	?	ETOH_ACKS_LEAD	:	ETOH_LINK_IDLE	;

			ETOH_TRDY_TOKN		:		etoh_dmau_txds_mfsm	<=	etoh_ufcm_tlnk_done	?	ETOH_TRDY_DONE	:	ETOH_TRDY_TOKN	;
			ETOH_TRDY_DONE		:		etoh_dmau_txds_mfsm	<=	rora_trdy_cube_reqs	?	ETOH_TRDY_DONE	:	ETOH_LINK_IDLE	;

			ETOH_RESP_TOKN		:		etoh_dmau_txds_mfsm	<=	etoh_ufcm_tlnk_done	?	ETOH_RESP_DONE	:	ETOH_RESP_TOKN	;
			ETOH_RESP_DONE		:		etoh_dmau_txds_mfsm	<=	rora_resp_cube_reqs	?	ETOH_RESP_DONE	:	ETOH_LINK_IDLE	;
			
			ETOH_ACKS_LEAD		:		etoh_dmau_txds_mfsm	<=	etoh_ufcm_tlnk_done	?	ETOH_ACKS_PACK	:	ETOH_ACKS_LEAD	;
			ETOH_ACKS_PACK		:		etoh_dmau_txds_mfsm	<=	etoh_user_alnk_done	?	ETOH_ACKS_CODA	:	ETOH_ACKS_PACK	;
			ETOH_ACKS_CODA		:		etoh_dmau_txds_mfsm	<=	etoh_ufcm_tlnk_done	?	ETOH_ACKS_DONE	:	ETOH_ACKS_CODA	;
			ETOH_ACKS_DONE		:		etoh_dmau_txds_mfsm	<=	mixs_acks_link_reqs	?	ETOH_ACKS_DONE	:	ETOH_LINK_IDLE	;
			
			ETOH_FRAM_ROWS		:		etoh_dmau_txds_mfsm	<=	rora_gmsl_txln_reqs	?	ETOH_ROWS_LEAD	:	ETOH_FRAM_ROWS	;
			ETOH_ROWS_LEAD		:		etoh_dmau_txds_mfsm	<=	etoh_ufcm_tlnk_done	?	ETOH_ROWS_PACK	:	ETOH_ROWS_LEAD	;
			ETOH_ROWS_PACK		:		etoh_dmau_txds_mfsm	<=	etoh_user_dlnk_done	?	ETOH_ROWS_CODA	:	ETOH_ROWS_PACK	;
			ETOH_ROWS_CODA		:		etoh_dmau_txds_mfsm	<=	etoh_ufcm_tlnk_done	?	ETOH_ROWS_LOOP	:	ETOH_ROWS_CODA	;
			ETOH_ROWS_LOOP		:		etoh_dmau_txds_mfsm	<=	cube_fram_rows_maxi	?	ETOH_FRAM_DONE	:	ETOH_FRAM_ROWS	;
			ETOH_FRAM_DONE		:		etoh_dmau_txds_mfsm	<=	rora_gmsl_txln_enab	?	ETOH_FRAM_DONE	:	ETOH_LINK_IDLE	;
			default				:		etoh_dmau_txds_mfsm	<=												ETOH_LINK_IDLE	;
		endcase
	end			
/**********************************************************************************************************************/
	assign		etoh_ufcm_acks_lead	=	etoh_dmau_txds_mfsm	==	ETOH_ACKS_LEAD	;
	assign		etoh_ufcm_acks_coda	=	etoh_dmau_txds_mfsm	==	ETOH_ACKS_CODA	;
	assign		etoh_ufcm_data_lead	=	etoh_dmau_txds_mfsm	==	ETOH_ROWS_LEAD	;
	assign		etoh_ufcm_data_coda	=	etoh_dmau_txds_mfsm	==	ETOH_ROWS_CODA	;
	assign		etoh_ufcm_resp_tokn	=	etoh_dmau_txds_mfsm	==	ETOH_RESP_TOKN	;
	assign		etoh_ufcm_trdy_tokn	=	etoh_dmau_txds_mfsm	==	ETOH_TRDY_TOKN	;

	assign		etoh_ufcm_tlnk_reqs	= |{etoh_ufcm_acks_lead	,	etoh_ufcm_acks_coda	,
										etoh_ufcm_data_lead	,	etoh_ufcm_data_coda	,
										etoh_ufcm_resp_tokn	,	etoh_ufcm_trdy_tokn	};	
/**********************************************************************************************************************/
	assign		etoh_user_alnk_reqs	=	etoh_dmau_txds_mfsm	==	ETOH_ACKS_PACK	;
//------------------------------------------------------------------------------	
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						etoh_user_alnk_data	<=	0	;
	else if( rora_acks_rv32_reqs)		etoh_user_alnk_data	<=	rora_acks_rv32_data	;
	else if( rora_acks_cube_reqs)		etoh_user_alnk_data	<=	rora_acks_cube_data	;
	else 								etoh_user_alnk_data	<=	0	;		
/**********************************************************************************************************************/
	reg			[19: 0]					cube_fram_rows_cnts	;

	assign		cube_fram_rows_maxi	=	cube_fram_rows_cnts	==	rora_gmsl_txln_rows	;

	assign		etoh_user_dlnk_reqs	=	etoh_dmau_txds_mfsm	==	ETOH_ROWS_PACK	;
	wire		etoh_user_dlnk_coda	=	etoh_dmau_txds_mfsm	==	ETOH_ROWS_CODA	;
//------------------------------------------------------------------------------
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_fram_rows_cnts	<=	0	;
	else if(~rora_gmsl_txln_enab)		cube_fram_rows_cnts	<=	0	;
	else if( etoh_user_dlnk_coda)		cube_fram_rows_cnts	<=	cube_fram_rows_cnts + etoh_ufcm_tlnk_done	;
/**********************************************************************************************************************/
	assign		rora_acks_txln_done	=	etoh_dmau_txds_mfsm	==	ETOH_ACKS_DONE	;
	assign		rora_resp_txln_done	=	etoh_dmau_txds_mfsm	==	ETOH_RESP_DONE	;
	assign		rora_trdy_txln_done	= 	etoh_dmau_txds_mfsm	==	ETOH_TRDY_DONE	;
	assign		rora_gmsl_txln_done	= 	etoh_dmau_txds_mfsm	==	ETOH_FRAM_DONE	;
/**********************************************************************************************************************/
endmodule
