module	edge_rxds_hubs_ufcm(
	input		[31: 0]					rora_rxln_ufcm_data	,
	input								rora_rxln_ufcm_drdy	,
	input								rora_rxln_ufcm_last	,
	
	output								rora_rxln_cmnd_lead	,
	output								rora_rxln_cmnd_coda	,
	output								rora_rxln_data_lead	,
	output								rora_rxln_data_coda	,

	input								rora_bclk			,
	input								rora_rstn			);
/**********************************************************************************************************************/
	reg			[31: 0]					rora_rxln_ufcm_buff	;
	wire								rora_rxln_ufcm_rxok	;
	wire		[63: 0]					rora_rxln_ufcm_tokn	;

	assign		rora_rxln_ufcm_tokn	= {	rora_rxln_ufcm_buff	,	rora_rxln_ufcm_data	};	
	assign		rora_rxln_ufcm_rxok	=&{	rora_rxln_ufcm_drdy	,	rora_rxln_ufcm_last	};

	always@(posedge rora_bclk or negedge rora_rstn)	
	if(~rora_rstn)						rora_rxln_ufcm_buff	<=	0	;
	else if(rora_rxln_ufcm_drdy)		rora_rxln_ufcm_buff	<={	rora_rxln_ufcm_buff[31: 0]	,	rora_rxln_ufcm_data	};

//	always@(posedge rora_bclk or negedge rora_rstn)	
//	if(~rora_rstn)						rora_rxln_ufcm_rxok	<=	0	;
//	else 								rora_rxln_ufcm_rxok	<=&{rora_rxln_ufcm_drdy	,	rora_rxln_ufcm_last	};
/**********************************************************************************************************************/
	assign		rora_rxln_cmnd_lead	= &{rora_rxln_ufcm_rxok	,	rora_rxln_ufcm_tokn	==	"CMNDLEAD"	};		
	assign		rora_rxln_cmnd_coda	= &{rora_rxln_ufcm_rxok	,	rora_rxln_ufcm_tokn	==	"CMNDCODA"	};		
	assign		rora_rxln_data_lead	= &{rora_rxln_ufcm_rxok	,	rora_rxln_ufcm_tokn	==	"DATALEAD"	};		
	assign		rora_rxln_data_coda	= &{rora_rxln_ufcm_rxok	,	rora_rxln_ufcm_tokn	==	"DATACODA"	};		
//------------------------------------------------------------------------------
//	always@(posedge rora_bclk or negedge rora_rstn)	
//	if(~rora_rstn)						begin
//		rora_rxln_cmnd_lead	<=			0	;		
//		rora_rxln_cmnd_coda	<=			0	;		
//		rora_rxln_data_lead	<=			0	;		
//		rora_rxln_data_coda	<=			0	;		
//	end else 							begin
//		rora_rxln_cmnd_lead	<=			rxln_cmnd_lead_meet	;		
//		rora_rxln_cmnd_coda	<=			rxln_cmnd_coda_meet	;		
//		rora_rxln_data_lead	<=			rxln_data_lead_meet	;		
//		rora_rxln_data_coda	<=			rxln_data_coda_meet	;		
//	end

endmodule
