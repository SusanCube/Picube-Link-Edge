/*----------------------------------------------------------------------------------------------------------------------
AUTHOR	: EDWARD YANG
history : 
        2026/09/03, edward, 
----------------------------------------------------------------------------------------------------------------------*/
module	edge_link_dvpx_pmau(
	input		[ 1: 0]					dvpx_pmau_port_enab	,
	output	reg							dvp0_pmau_vsyn_pado	,
	output	reg							dvp0_pmau_hsyn_pado	,
	output	reg	[15: 0]					dvp0_pmau_data_pado	,
	output	reg							dvp1_pmau_vsyn_pado	,
	output	reg							dvp1_pmau_hsyn_pado	,
	output	reg	[15: 0]					dvp1_pmau_data_pado	,

	output		[ 2: 0]					dvpx_clnk_memo_addr	,
	input		[31: 0]					dvpx_clnk_memo_data	,
	output								dvpx_dlnk_memo_rank	,
	output		[10: 0]					dvpx_dlnk_memo_addr	,
	input		[31: 0]					dvpx_dlnk_memo_data	,
	input								dvpx_bclk			,
	input								dvpx_rstn			,

	input		[19: 0]					rora_dvpx_dlnk_rows	,
	input		[19: 0]					rora_dvpx_dlnk_cols	,

	output								rora_dvpx_clnk_done	,
	input								rora_dvpx_clnk_natv	,	
	input								rora_dvpx_clnk_dmmy	,
	
	output								rora_dvpx_dlnk_done	,
	input								rora_dvpx_dlnk_enab	,
	input								rora_dvpx_dlnk_reqs	,
	output								rora_dvpx_dlnk_trdy	,
	input								rora_bclk			,
	input								rora_rstn			);
/**********************************************************************************************************************/
/**********************************************************************************************************************/
	wire								dvpx_pmau_dlnk_hsyn		;
	wire		[15: 0]					dvpx_pmau_dlnk_data		;

	wire								dvpx_pmau_clnk_vsyn		;
	wire								dvpx_pmau_clnk_hsyn		;
	wire		[15: 0]					dvpx_pmau_clnk_data		;
//------------------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						begin
		dvp0_pmau_vsyn_pado				<=	0	;
		dvp0_pmau_hsyn_pado				<=	0	;
		dvp0_pmau_data_pado				<=	0	;
	end else if(~dvpx_pmau_port_enab[0])begin
		dvp0_pmau_vsyn_pado				<=	0	;
		dvp0_pmau_hsyn_pado				<=	0	;
		dvp0_pmau_data_pado				<=	0	;
	end else							begin
		dvp0_pmau_vsyn_pado				<=	dvpx_pmau_clnk_vsyn	;
		dvp0_pmau_hsyn_pado				<=|{dvpx_pmau_clnk_hsyn	,	dvpx_pmau_dlnk_hsyn};
		dvp0_pmau_data_pado				<=	dvpx_pmau_clnk_data	|	dvpx_pmau_dlnk_data	;
	end
//------------------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						begin
		dvp1_pmau_vsyn_pado				<=	0	;
		dvp1_pmau_hsyn_pado				<=	0	;
		dvp1_pmau_data_pado				<=	0	;
	end else if(~dvpx_pmau_port_enab[1])begin
		dvp1_pmau_vsyn_pado				<=	0	;
		dvp1_pmau_hsyn_pado				<=	0	;
		dvp1_pmau_data_pado				<=	0	;
	end else							begin
		dvp1_pmau_vsyn_pado				<=	dvpx_pmau_clnk_vsyn	;
		dvp1_pmau_hsyn_pado				<=|{dvpx_pmau_clnk_hsyn	,	dvpx_pmau_dlnk_hsyn};
		dvp1_pmau_data_pado				<=	dvpx_pmau_clnk_data	|	dvpx_pmau_dlnk_data	;
	end
/**********************************************************************************************************************/
	edge_link_dvpx_cmnd				u_edge_link_dvpx_cmnd(
		.dvpx_pmau_clnk_vsyn			(dvpx_pmau_clnk_vsyn	),//output	reg			
		.dvpx_pmau_clnk_hsyn			(dvpx_pmau_clnk_hsyn	),//output	reg			
		.dvpx_pmau_clnk_data			(dvpx_pmau_clnk_data	),//output	reg	[15: 0]	

		.dvpx_clnk_memo_addr			(dvpx_clnk_memo_addr	),//output		[ 2: 0]	
		.dvpx_clnk_memo_data			(dvpx_clnk_memo_data	),//input		[15: 0]	
		.dvpx_bclk						(dvpx_bclk				),//input				
		.dvpx_rstn						(dvpx_rstn				),

		.rora_dvpx_clnk_done			(rora_dvpx_clnk_done	),//output	
		.rora_dvpx_clnk_natv			(rora_dvpx_clnk_natv	),//input	
		.rora_dvpx_clnk_dmmy			(rora_dvpx_clnk_dmmy	),//input	
		.rora_bclk						(rora_bclk				),//input	
		.rora_rstn						(rora_rstn				));//input	
/**********************************************************************************************************************/
	edge_link_dvpx_data				u_edge_link_dvpx_data(
		.dvpx_pmau_dlnk_hsyn			(dvpx_pmau_dlnk_hsyn	),//output	reg			
		.dvpx_pmau_dlnk_data			(dvpx_pmau_dlnk_data	),//output	reg	[15: 0]	

		.dvpx_dlnk_memo_rank			(dvpx_dlnk_memo_rank	),//output				
		.dvpx_dlnk_memo_addr			(dvpx_dlnk_memo_addr	),//output		[10: 0]	
		.dvpx_dlnk_memo_data			(dvpx_dlnk_memo_data	),//input		[31: 0]	
		.dvpx_bclk						(dvpx_bclk				),//input				
		.dvpx_rstn						(dvpx_rstn				),

		.rora_dvpx_dlnk_rows			(rora_dvpx_dlnk_rows	),//input		[19: 0]	
		.rora_dvpx_dlnk_cols			(rora_dvpx_dlnk_cols	),//input		[19: 0]			.rora_dvpx_dlnk_done			(rora_dvpx_dlnk_done	),//output				

		.rora_dvpx_dlnk_done			(rora_dvpx_dlnk_done	),//input				
		.rora_dvpx_dlnk_enab			(rora_dvpx_dlnk_enab	),//input				
		.rora_dvpx_dlnk_reqs			(rora_dvpx_dlnk_reqs	),//input				
		.rora_dvpx_dlnk_trdy			(rora_dvpx_dlnk_trdy	),//output				

		.rora_bclk						(rora_bclk				),//input				
		.rora_rstn						(rora_rstn				));//input				

endmodule

 
