/*----------------------------------------------------------------------------------------------------------------------
AUTHOR	: EDWARD YANG
version : 
        2026/09/03, edward, ver1.0
----------------------------------------------------------------------------------------------------------------------*/
/**********************************************************************************************************************/
//-----------------------------------------------------ICFG-------------------------------------------------------------------------------------
//HUBS	================================================================================|ETOH_ICFG_ACKS	|XXXXXXXXXXXXXXX

//EDGE	|GPIO_CUBE_REQS |---------------|DVPX_ICFG_CMND	|---------------|---------------|EDGE_CMND_DONE	|
//CUBE	|---------------|GPIO_CUBE_TRDY |---------------|GPIO_ICFG_ACKS	|GMSL_ICFG_LINK	|XXXXXXXXXXXXXXX|
/**********************************************************************************************************************/
/**********************************************************************************************************************/
//-----------------------------------------------------OCFG-------------------------------------------------------------------------------------
//HUBS	================================================|ETOH_OCFG_ACKS	|XXXXXXXXXXXXXXX|

//EDGE	|GPIO_CUBE_REQS |				|DVPX_OCFG_CMND	|				|EDGE_CMND_DONE	|
//CUBE	|				|GPIO_CUBE_TRDY |				|GPIO_OCFG_ACKS	|XXXXXXXXXXXXXXX|
/**********************************************************************************************************************/
/**********************************************************************************************************************/
//-----------------------------------------------------IDAT-------------------------------------------------------------------------------------
//HUBS	================================================|ETOH_IDAT_ACKS	|===============|ETOH_IDAT_RESP	|XXXXXXXXXXXXXXX|

//EDGE	|GPIO_CUBE_REQS |				|DVPX_IDAT_CMND	|				|				|				|EDGE_CMND_DONE	|
//CUBE	|				|GPIO_CUBE_TRDY |				|GPIO_IDAT_ACKS	|GMSL_IDAT_LINK	|GPIO_IDAT_RESP	|XXXXXXXXXXXXXXX|
/**********************************************************************************************************************/
/**********************************************************************************************************************/
//-----------------------------------------------------ODAT-------------------------------------------------------------------------------------
//HUBS	================================================|ETOH_ODAT_ACKS	|===============================|ETOH_IDAT_RESP	|XXXXXXXXXXXXXXX|

//EDGE	|GPIO_CUBE_REQS |				|DVPX_ODAT_CMND	|				|DVPX_DMMY_CMND	|DVPX_ODAT_LINK	|				|EDGE_CMND_DONE	|
//CUBE	|				|GPIO_CUBE_TRDY |				|GPIO_ODAT_ACKS	|				|				|GPIO_ODAT_RESP	|XXXXXXXXXXXXXXX|
/**********************************************************************************************************************/
//USER FLOW CONTROL MACHINE
module	edge_link_cube_ufcm(
    output	reg  	       				cube_ufcm_cmnd_port	,
    input   	[ 1: 0]    				cube_ufcm_stat_port	,
	
	output								cube_link_ufcm_done	,
	input								cube_link_ocfg_reqs	,
	input								cube_link_icfg_reqs	,
	input								cube_link_odat_reqs	,
	input								cube_link_idat_reqs	,

	input								rora_acks_txln_done	,
	output								rora_acks_cube_reqs	,
	output	reg	[31: 0]					rora_acks_cube_data	,
	
	input								rora_resp_txln_done	,
	output								rora_resp_cube_reqs	,

	input		[ 1: 0]					rora_dvpx_dlnk_port	,
	input								rora_dvpx_dlnk_done	,
	output								rora_dvpx_dlnk_enab	,

	input								rora_dvpx_clnk_done	,
	output								rora_dvpx_clnk_natv	,
	output								rora_dvpx_clnk_dmmy	,
	
	input		[31: 0]					rora_gmsl_alnk_data	,					
	input								rora_gmsl_alnk_done	,
	output								rora_gmsl_alnk_enab	,

	input								rora_gmsl_slnk_done	,
	output								rora_gmsl_slnk_enab	,
    input								rora_bclk           ,
    input								rora_rstn           ,
	
	output		[ 1: 0]					dvpx_pmau_port_enab	,
	input								dvpx_bclk			,
	input								dvpx_rstn			);
/**********************************************************************************************************************/	
/**********************************************************************************************************************/	
	reg			[3: 0]					cube_ufcm_link_mfsm	;

	wire    							cube_ufcm_misc_reqs ;	
    wire    							cube_ufcm_into_trdy ;	
    wire    							cube_ufcm_into_acks ;	
    wire    							cube_ufcm_into_resp ;	
//------------------------------------------------------------------------------
	parameter							EDGE_UFCM_CUBE_IDLE	=	4'H0	;
	parameter							EDGE_UFCM_CUBE_TRDY	=	4'H1	;
	parameter							EDGE_UFCM_CUBE_CMND	=	4'H2	;
	parameter							EDGE_UFCM_CUBE_ACKS	=	4'H3	;

	parameter							EDGE_UFCM_ODAT_HACK	=	4'H4	;
	parameter							EDGE_UFCM_ODAT_CDMY	=	4'H5	;
	parameter							EDGE_UFCM_ODAT_TXLN	=	4'H6	;
	parameter							EDGE_UFCM_ODAT_RESP	=	4'H7	;

	parameter							EDGE_UFCM_IDAT_HACK	=	4'H8	;
	parameter							EDGE_UFCM_IDAT_RXLN	=	4'H9	;
	parameter							EDGE_UFCM_IDAT_TXOK	=	4'HA	;
	
	parameter							EDGE_UFCM_ICFG_RXLN	=	4'HB	;
	parameter							EDGE_UFCM_ICFG_HACK	=	4'HC	;
	parameter							EDGE_UFCM_OCFG_HACK	=	4'HD	;

	parameter							EDGE_UFCM_HUBS_RESP	=	4'HE	;
	parameter							EDGE_UFCM_CUBE_DONE	=	4'HF	;

	assign		cube_ufcm_misc_reqs	= |{cube_link_ocfg_reqs	,	cube_link_icfg_reqs	,
										cube_link_odat_reqs	,	cube_link_idat_reqs	};	
//------------------------------------------------------------------------------
	always@(posedge rora_bclk or negedge rora_rstn)
    if(~rora_rstn)                  	cube_ufcm_link_mfsm	<=	EDGE_UFCM_CUBE_IDLE	;
    else 								begin
        case(cube_ufcm_link_mfsm)
			EDGE_UFCM_CUBE_IDLE	:		cube_ufcm_link_mfsm	<=	cube_ufcm_misc_reqs	? 	EDGE_UFCM_CUBE_TRDY	:	EDGE_UFCM_CUBE_IDLE	;	
        	EDGE_UFCM_CUBE_TRDY	:		cube_ufcm_link_mfsm	<=	cube_ufcm_into_trdy	?	EDGE_UFCM_CUBE_CMND	:	EDGE_UFCM_CUBE_TRDY	;
			EDGE_UFCM_CUBE_CMND	:		cube_ufcm_link_mfsm	<=	rora_dvpx_clnk_done	?	EDGE_UFCM_CUBE_ACKS	:	EDGE_UFCM_CUBE_CMND	;			
			EDGE_UFCM_CUBE_ACKS	:	
				if(cube_ufcm_into_acks)	cube_ufcm_link_mfsm	<=	cube_link_odat_reqs	?	EDGE_UFCM_ODAT_CDMY	:	
																cube_link_idat_reqs	?	EDGE_UFCM_IDAT_HACK	:	
																cube_link_icfg_reqs	?	EDGE_UFCM_ICFG_RXLN	:	EDGE_UFCM_OCFG_HACK	;

				else 					cube_ufcm_link_mfsm	<=													EDGE_UFCM_CUBE_ACKS	;	
//------------------------------------------------------------------------------		
			EDGE_UFCM_ODAT_CDMY	:		cube_ufcm_link_mfsm	<=	rora_dvpx_clnk_done	?	EDGE_UFCM_ODAT_HACK	:	EDGE_UFCM_ODAT_CDMY	;			
			EDGE_UFCM_ODAT_HACK	:		cube_ufcm_link_mfsm	<=	rora_acks_txln_done	?	EDGE_UFCM_ODAT_TXLN	:	EDGE_UFCM_ODAT_HACK	;			
			EDGE_UFCM_ODAT_TXLN	:		cube_ufcm_link_mfsm	<=	rora_dvpx_dlnk_done	?	EDGE_UFCM_ODAT_RESP	:	EDGE_UFCM_ODAT_TXLN	;			
			EDGE_UFCM_ODAT_RESP	:		cube_ufcm_link_mfsm	<=	cube_ufcm_into_resp	?	EDGE_UFCM_HUBS_RESP	:	EDGE_UFCM_ODAT_RESP	;			
//------------------------------------------------------------------------------
			EDGE_UFCM_IDAT_HACK	:		cube_ufcm_link_mfsm	<=	rora_acks_txln_done	?	EDGE_UFCM_IDAT_RXLN	:	EDGE_UFCM_IDAT_HACK	;			
			EDGE_UFCM_IDAT_RXLN	:		cube_ufcm_link_mfsm	<=	rora_gmsl_slnk_done	?	EDGE_UFCM_IDAT_TXOK	:	EDGE_UFCM_IDAT_RXLN	;			
			EDGE_UFCM_IDAT_TXOK	:		cube_ufcm_link_mfsm	<=	cube_ufcm_into_resp	?	EDGE_UFCM_HUBS_RESP	:	EDGE_UFCM_IDAT_TXOK	;		
//------------------------------------------------------------------------------		
			EDGE_UFCM_ICFG_RXLN	:		cube_ufcm_link_mfsm	<=	rora_gmsl_alnk_done	?	EDGE_UFCM_ICFG_HACK	:	EDGE_UFCM_ICFG_RXLN	;			
			EDGE_UFCM_ICFG_HACK	:		cube_ufcm_link_mfsm	<=	rora_acks_txln_done	?	EDGE_UFCM_CUBE_DONE	:	EDGE_UFCM_ICFG_HACK	;			
//------------------------------------------------------------------------------
			EDGE_UFCM_OCFG_HACK	:		cube_ufcm_link_mfsm	<=	rora_acks_txln_done	?	EDGE_UFCM_CUBE_DONE	:	EDGE_UFCM_OCFG_HACK	;			
//------------------------------------------------------------------------------
			EDGE_UFCM_HUBS_RESP	:		cube_ufcm_link_mfsm	<=	rora_resp_txln_done	?	EDGE_UFCM_CUBE_DONE	:	EDGE_UFCM_HUBS_RESP	;			
//------------------------------------------------------------------------------
			EDGE_UFCM_CUBE_DONE	:		cube_ufcm_link_mfsm	<=	cube_ufcm_misc_reqs	?	EDGE_UFCM_CUBE_DONE	:	EDGE_UFCM_CUBE_IDLE	;			
//------------------------------------------------------------------------------
		    default             :   	cube_ufcm_link_mfsm <=  												EDGE_UFCM_CUBE_IDLE ;
        endcase
	end
/**********************************************************************************************************************/	
/**********************************************************************************************************************/	
    edge_comm_cube_stat				u_edge_comm_cube_stat(
		.cube_ufcm_into_trdy 			(cube_ufcm_into_trdy	),//output
		.cube_ufcm_into_acks 			(cube_ufcm_into_acks	),//output
		.cube_ufcm_into_resp 			(cube_ufcm_into_resp	),//output

		.cube_ufcm_stat_port			(cube_ufcm_stat_port	),//input	[ 1: 0]	
		.rora_bclk						(rora_bclk				),//input			
		.rora_rstn						(rora_rstn				));//input			
/**********************************************************************************************************************/	
/**********************************************************************************************************************/	
	wire		etoc_ufcm_hits_idle	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_CUBE_IDLE	;
	wire		cube_link_ufcm_done	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_CUBE_DONE	;
	wire		etoc_ufcm_hits_trdy	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_CUBE_TRDY	;
	wire		etoc_ufcm_hits_acks	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_CUBE_ACKS	;


	assign		rora_dvpx_clnk_natv	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_CUBE_CMND	;
	assign		rora_dvpx_clnk_dmmy	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_ODAT_CDMY	;
	assign		rora_dvpx_dlnk_enab	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_ODAT_TXLN	;

	assign		rora_gmsl_alnk_enab	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_ICFG_RXLN	;
	assign		rora_gmsl_slnk_enab	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_IDAT_RXLN	;

	assign		rora_resp_cube_reqs	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_HUBS_RESP	;
/**********************************************************************************************************************/	
	wire		rora_acks_odat_reqs	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_ODAT_HACK	;
	wire		rora_acks_idat_reqs	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_IDAT_HACK	;
	wire		rora_acks_icfg_reqs	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_ICFG_HACK	;
	wire		rora_acks_ocfg_reqs	=	cube_ufcm_link_mfsm	==	EDGE_UFCM_OCFG_HACK	;

	assign		rora_acks_cube_reqs	= |{rora_acks_odat_reqs	,	rora_acks_idat_reqs	,
										rora_acks_icfg_reqs	,	rora_acks_ocfg_reqs};
//------------------------------------------------------------------------------
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_acks_cube_data	<=	0	;
	else if(rora_acks_odat_reqs)		rora_acks_cube_data	<=	"ODCA"	;
	else if(rora_acks_idat_reqs)		rora_acks_cube_data	<=	"IDCA"	;
	else if(rora_acks_ocfg_reqs)		rora_acks_cube_data	<=	"OCCA"	;
	else if(rora_acks_icfg_reqs)		rora_acks_cube_data	<=	rora_gmsl_alnk_data	;
	else								rora_acks_cube_data	<=	0	;	
/**********************************************************************************************************************/	
	wire		cube_ufcm_cmnd_issu	= &{etoc_ufcm_hits_idle	,	cube_ufcm_misc_reqs};

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_ufcm_cmnd_port	<=	0	;
	else if(cube_ufcm_into_trdy)		cube_ufcm_cmnd_port	<=	0	;
	else if(cube_ufcm_cmnd_issu)		cube_ufcm_cmnd_port	<=	1	;
/**********************************************************************************************************************/	
	reg			dvp0_issu_link_enab	;
	reg			dvp1_issu_link_enab	;

	wire		dvpx_data_fram_issu	=&{	etoc_ufcm_hits_acks	,	cube_ufcm_into_acks	,	cube_link_odat_reqs	}; 
	wire		dvpx_data_fram_stop	=&{	rora_dvpx_dlnk_enab	,	rora_dvpx_dlnk_done	}; 

	wire		dvp0_cmnd_natv_issu	=&{	etoc_ufcm_hits_trdy	,	cube_ufcm_into_trdy	};	
	wire		dvp0_cmnd_natv_stop	=&{	rora_dvpx_clnk_natv	,	rora_dvpx_clnk_done	};	
//------------------------------------------------------------------------------
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						dvp0_issu_link_enab	<=	0	;
	else if(dvp0_cmnd_natv_issu)		dvp0_issu_link_enab	<=	1	;
	else if(dvp0_cmnd_natv_stop)		dvp0_issu_link_enab	<=	0	;
	else if(dvpx_data_fram_issu)		dvp0_issu_link_enab	<=	rora_dvpx_dlnk_port[0]	;
	else if(dvpx_data_fram_stop)		dvp0_issu_link_enab	<=	0	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						dvp1_issu_link_enab	<=	0	;
	else if(dvpx_data_fram_issu)		dvp1_issu_link_enab	<=	rora_dvpx_dlnk_port[1]	;
	else if(dvpx_data_fram_stop)		dvp1_issu_link_enab	<=	0	;
//------------------------------------------------------------------------------
	gens_sync_mark					u_dvp0_dlnk_enab_mark(	
		.dtar_mark						(dvpx_pmau_port_enab[0]	),//output	
		.dtar_clki						(dvpx_bclk				),//input	
		.dtar_rstn						(dvpx_rstn				),//input	

		.dsrc_mark						(dvp0_issu_link_enab	),
		.dsrc_clki						(rora_bclk				),
		.dsrc_rstn						(rora_rstn				));
//------------------------------------------------------------------------------
	gens_sync_mark					u_dvp1_dlnk_enab_mark(	
		.dtar_mark						(dvpx_pmau_port_enab[1]	),//output	
		.dtar_clki						(dvpx_bclk				),//input	
		.dtar_rstn						(dvpx_rstn				),//input	

		.dsrc_mark						(dvp1_issu_link_enab	),
		.dsrc_clki						(rora_bclk				),
		.dsrc_rstn						(rora_rstn				));

endmodule	
/**********************************************************************************************************************/	
/**********************************************************************************************************************/	
module		edge_comm_cube_stat(
	output								cube_ufcm_into_trdy ,
	output								cube_ufcm_into_acks ,
	output	reg							cube_ufcm_into_resp ,

	input		[ 1: 0]					cube_ufcm_stat_port	,
	input								rora_bclk			,
	input								rora_rstn			);

   	reg     	[1:0]       			cube_link_stat_syn0	;
	reg     	[1:0]       			cube_link_stat_syn1	;
	reg			[1:0]					cube_link_comm_stat	;

    assign		cube_ufcm_into_trdy = &{cube_link_comm_stat	!= 2'H0	, cube_link_stat_syn1 == 2'H0	};	
    assign		cube_ufcm_into_acks = &{cube_link_comm_stat	!= 2'H1	, cube_link_stat_syn1 == 2'H1	};	
    wire		cube_ufcm_goto_resp = &{cube_link_comm_stat	!= 2'H2	, cube_link_stat_syn1 == 2'H2	};	
	
    always@(posedge rora_bclk or negedge rora_rstn)  
	if(~rora_rstn)						begin
		cube_link_stat_syn0	<=			0	;
        cube_link_stat_syn1	<=			0	;
        cube_link_comm_stat	<=			0	;
	end	else							begin
        cube_link_stat_syn0	<=			cube_ufcm_stat_port	;
		cube_link_stat_syn1	<=			cube_link_stat_syn0	;
	    cube_link_comm_stat	<=			cube_link_stat_syn1	;
    end

	always@(posedge rora_bclk or negedge rora_rstn)  
	if(~rora_rstn)						cube_ufcm_into_resp	<=	0	;
	else if(cube_ufcm_into_trdy)		cube_ufcm_into_resp	<=	0	;
	else if(cube_ufcm_into_acks)		cube_ufcm_into_resp	<=	0	;
	else if(cube_ufcm_goto_resp)		cube_ufcm_into_resp	<=	1	;
	
endmodule
/**********************************************************************************************************************/