/*----------------------------------------------------------------------------------------------------------------------
AUTHOR	: EDWARD YANG
history : 
        2026/09/03, edward, 
----------------------------------------------------------------------------------------------------------------------*/
module	edge_link_dvpx_data(
	output	reg							dvpx_pmau_dlnk_hsyn	,
	output		[15: 0]					dvpx_pmau_dlnk_data	,

	output	reg							dvpx_dlnk_memo_rank	,
	output		[10: 0]					dvpx_dlnk_memo_addr	,
	input		[31: 0]					dvpx_dlnk_memo_data	,
	input								dvpx_bclk			,
	input								dvpx_rstn			,

	input		[19: 0]					rora_dvpx_dlnk_rows	,
	input		[19: 0]					rora_dvpx_dlnk_cols	,

	output								rora_dvpx_dlnk_done	,
	input								rora_dvpx_dlnk_enab	,
	output								rora_dvpx_dlnk_trdy	,
	input								rora_dvpx_dlnk_reqs	,
	input								rora_bclk			,
	input								rora_rstn			);
/**********************************************************************************************************************/
//MGTE_CLOCK_DOMAIN
/**********************************************************************************************************************/
	wire								dvpx_dlnk_fram_enab	;
	wire								dvpx_dlnk_fram_done	;
	
	wire		[19: 0]					dvpx_dlnk_rows_size	;
	wire		[12: 0]					dvpx_dlnk_cols_size	;

	wire								dvpx_dlnk_rows_reqs	;
	wire								dvpx_dlnk_rows_half	;//When half of the data is sent, assert the TRDY signal
//------------------------------------------------------------------------------
	gens_sync_edge #( .EXTN(2))		u_dvpx_dlnk_rows_reqs(	
		.dtar_rise						(dvpx_dlnk_rows_reqs	),
		.dtar_fall						(						),
		.dtar_clki						(dvpx_bclk				),
		.dtar_rstn						(dvpx_rstn				),

		.dsrc_mark						(rora_dvpx_dlnk_reqs	),
		.dsrc_clki						(rora_bclk				),
		.dsrc_rstn						(rora_rstn				));
//------------------------------------------------------------------------------
	gens_sync_edge #( .EXTN(2))		u_dvpx_dlnk_rows_trdy(	
		.dtar_rise						(rora_dvpx_dlnk_trdy	),
		.dtar_fall						(						),
		.dtar_clki						(rora_bclk				),
		.dtar_rstn						(rora_rstn				),

		.dsrc_mark						(dvpx_dlnk_rows_half	),
		.dsrc_clki						(dvpx_bclk				),
		.dsrc_rstn						(dvpx_rstn				));
//------------------------------------------------------------------------------
	gens_sync_mark 					u_dvpx_dlnk_fram_enab(	
		.dtar_mark						(dvpx_dlnk_fram_enab	),
		.dtar_clki						(dvpx_bclk				),
		.dtar_rstn						(dvpx_rstn				),

		.dsrc_mark						(rora_dvpx_dlnk_enab	),
		.dsrc_clki						(rora_bclk				),
		.dsrc_rstn						(rora_rstn				));
//------------------------------------------------------------------------------
	gens_sync_edge #( .EXTN(2))		u_dvpx_dlnk_fram_done(	
		.dtar_rise						(rora_dvpx_dlnk_done	),
		.dtar_fall						(						),
		.dtar_clki						(rora_bclk				),
		.dtar_rstn						(rora_rstn				),

		.dsrc_mark						(dvpx_dlnk_fram_done	),
		.dsrc_clki						(dvpx_bclk				),
		.dsrc_rstn						(dvpx_rstn				));
//------------------------------------------------------------------------------
	gens_gray_code	#(.MSB(19))		u_dvpx_dlnk_rows_size(		
		.dtar_data						(dvpx_dlnk_rows_size	),
		.dtar_clki						(dvpx_bclk				),
		.dtar_rstn						(dvpx_rstn				),

		.dsrc_data						(rora_dvpx_dlnk_rows	),
		.dsrc_clki						(rora_bclk				));
//------------------------------------------------------------------------------
	gens_gray_code	#(.MSB(12))		u_dvpx_dlnk_cols_size(		
		.dtar_data						(dvpx_dlnk_cols_size	),
		.dtar_clki						(dvpx_bclk				),
		.dtar_rstn						(dvpx_rstn				),

		.dsrc_data						(rora_dvpx_dlnk_cols[12:0]	),
		.dsrc_clki						(rora_bclk				));
/**********************************************************************************************************************/
//DVPX_CLOCK_DOMAIN
/**********************************************************************************************************************/
	reg									dvpx_dlnk_rows_csen	;
	reg			[12: 0]					dvpx_dlnk_rows_pcnt	;
	wire		[12: 0]					dvpx_dlnk_rows_pnxt	;		
	wire								dvpx_dlnk_rows_tail	;

	wire		[11: 0]					dvpx_dlnk_cols_half	;
	assign		dvpx_dlnk_cols_half	=	dvpx_dlnk_cols_size[12:1]	;	

	assign		dvpx_dlnk_rows_pnxt	=	dvpx_dlnk_rows_pcnt + 1	;	
	assign 		dvpx_dlnk_rows_tail	= &{dvpx_dlnk_rows_csen	,dvpx_dlnk_rows_pcnt 		==	dvpx_dlnk_cols_size	};	
	assign 		dvpx_dlnk_rows_half	= &{dvpx_dlnk_rows_csen	,dvpx_dlnk_rows_pcnt[11: 0]	== 	dvpx_dlnk_cols_half	};	

	reg			[19: 0]					dvpx_dlnk_fram_rcnt	;
	wire		[19: 0]					dvpx_dlnk_fram_rnxt	;	

	assign		dvpx_dlnk_fram_rnxt	=	dvpx_dlnk_fram_rcnt + 1	;	
	assign 		dvpx_dlnk_fram_done	= &{dvpx_dlnk_rows_tail	,dvpx_dlnk_fram_rcnt ==			dvpx_dlnk_rows_size	};	
//----------------------------------------------------------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_dlnk_rows_csen	<=	0	;
	else if(~dvpx_dlnk_fram_enab)		dvpx_dlnk_rows_csen	<=	0	;
	else if( dvpx_dlnk_rows_tail)		dvpx_dlnk_rows_csen	<=  0	;
	else if( dvpx_dlnk_rows_reqs)		dvpx_dlnk_rows_csen	<=  1	;
//------------------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_dlnk_rows_pcnt	<=	0	;
	else if(~dvpx_dlnk_fram_enab)		dvpx_dlnk_rows_pcnt	<=	0	;
	else if( dvpx_dlnk_rows_tail)		dvpx_dlnk_rows_pcnt	<=  0	;
	else if( dvpx_dlnk_rows_csen)		dvpx_dlnk_rows_pcnt	<=  dvpx_dlnk_rows_pnxt	;
//------------------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_dlnk_fram_rcnt	<=	0	;
	else if(~dvpx_dlnk_fram_enab)		dvpx_dlnk_fram_rcnt	<=	0	;
	else if( dvpx_dlnk_rows_reqs)		dvpx_dlnk_fram_rcnt	<=  dvpx_dlnk_fram_rnxt	;
//----------------------------------------------------------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_pmau_dlnk_hsyn<=	0	;
	else if(~dvpx_dlnk_fram_enab)		dvpx_pmau_dlnk_hsyn<=	0	;
	else if( dvpx_dlnk_rows_tail)		dvpx_pmau_dlnk_hsyn<=  	0	;
	else if( dvpx_dlnk_rows_csen)		dvpx_pmau_dlnk_hsyn<=  	1	;
	else 								dvpx_pmau_dlnk_hsyn<=  	0	;
//----------------------------------------------------------------------------------------------------------------------
//	always@(posedge dvpx_bclk or negedge dvpx_rstn)
//	if(~dvpx_rstn)						dvpx_pmau_dlnk_data	<=	0	;
//	else if(~dvpx_dlnk_rows_csen)		dvpx_pmau_dlnk_data	<=	0	;
//	else 								dvpx_pmau_dlnk_data	<=	dvpx_dlnk_rows_pcnt[0]	?	dvpx_dlnk_memo_data[31:16]	:
//																							dvpx_dlnk_memo_data[15: 0]	;
	wire								dvpx_dlnk_mshw_vlid	= &{dvpx_pmau_dlnk_hsyn	, ~	dvpx_dlnk_rows_pcnt[0]	};
	wire								dvpx_dlnk_lshw_vlid	= &{dvpx_pmau_dlnk_hsyn	, 	dvpx_dlnk_rows_pcnt[0]	};

	assign		dvpx_pmau_dlnk_data	=	dvpx_dlnk_mshw_vlid	?	dvpx_dlnk_memo_data[31:16]	:
										dvpx_dlnk_lshw_vlid	?	dvpx_dlnk_memo_data[15: 0]	:	16'H0	;
//----------------------------------------------------------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_dlnk_memo_rank	<=	0	;
	else if(~dvpx_dlnk_fram_enab)		dvpx_dlnk_memo_rank	<=	0	;
	else if( dvpx_dlnk_rows_tail)		dvpx_dlnk_memo_rank	<= ~dvpx_dlnk_memo_rank	;
/**********************************************************************************************************************/
	assign		dvpx_dlnk_memo_addr	=	dvpx_dlnk_rows_pcnt[11: 1]	;	
/**********************************************************************************************************************/
endmodule
