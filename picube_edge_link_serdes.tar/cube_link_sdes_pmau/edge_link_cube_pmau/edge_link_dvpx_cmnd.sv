/*----------------------------------------------------------------------------------------------------------------------
AUTHOR	: EDWARD YANG
history : 
        2026/09/03, edward, 
----------------------------------------------------------------------------------------------------------------------*/
module	edge_link_dvpx_cmnd(
	output	reg							dvpx_pmau_clnk_vsyn	,
	output	reg							dvpx_pmau_clnk_hsyn	,
	output	reg	[15: 0]					dvpx_pmau_clnk_data	,

	output		[ 2: 0]					dvpx_clnk_memo_addr	,
	input		[31: 0]					dvpx_clnk_memo_data	,
	input								dvpx_bclk			,
	input								dvpx_rstn			,
	
	output								rora_dvpx_clnk_done	,
	input								rora_dvpx_clnk_natv	,	
	input								rora_dvpx_clnk_dmmy	,
	input								rora_bclk			,
	input								rora_rstn			);
/**********************************************************************************************************************/
//MGTE_CLOCK_DOMAIN
/**********************************************************************************************************************/
	wire								dvpx_cmnd_natv_enab	;
	wire								dvpx_cmnd_dmmy_enab	;
	wire								dvpx_pmau_clnk_enab	;
	wire								dvpx_pmau_clnk_done	;

	assign		dvpx_pmau_clnk_enab	= |{dvpx_cmnd_natv_enab	,	dvpx_cmnd_dmmy_enab	};
//------------------------------------------------------------------------------
	gens_sync_mark	 				u_dvpx_cmnd_natv_reqs(	
		.dtar_mark						(dvpx_cmnd_natv_enab	),//output	
		.dtar_clki						(dvpx_bclk				),//input	
		.dtar_rstn						(dvpx_rstn				),//input	

		.dsrc_mark						(rora_dvpx_clnk_natv	),//input   
		.dsrc_clki						(rora_bclk				),//input	
		.dsrc_rstn						(rora_rstn				));//input	
//------------------------------------------------------------------------------
	gens_sync_mark	 				u_dvpx_cmnd_dmmy_reqs(	
		.dtar_mark						(dvpx_cmnd_dmmy_enab	),//output	
		.dtar_clki						(dvpx_bclk				),//input	
		.dtar_rstn						(dvpx_rstn				),//input	

		.dsrc_mark						(rora_dvpx_clnk_dmmy	),//input   
		.dsrc_clki						(rora_bclk				),//input	
		.dsrc_rstn						(rora_rstn				));//input	
//------------------------------------------------------------------------------
	gens_sync_mark	 				u_dvpx_cmnd_link_done(	
		.dtar_mark						(rora_dvpx_clnk_done	),//output	
		.dtar_clki						(rora_bclk				),//input	
		.dtar_rstn						(rora_rstn				),//input	

		.dsrc_mark						(dvpx_pmau_clnk_done	),//input   
		.dsrc_clki						(dvpx_bclk				),//input	
		.dsrc_rstn						(dvpx_rstn				));//input	
/**********************************************************************************************************************/
//DVPX_CLOCK_DOMAIN
/**********************************************************************************************************************/
	reg			[ 2: 0]					dvpx_pmau_clnk_mfsm	;
	reg			[ 3: 0]					dvpx_pmau_clnk_time	;
	
	wire								dvpx_pmau_clnk_idle	;
	wire								dvpx_pmau_clnk_head	;
	wire								dvpx_pmau_clnk_blnk	;
	wire								dvpx_pmau_clnk_dmmy	;

	parameter							DVPX_CMND_LINK_IDLE	=	3'H0	;
	parameter							DVPX_CMND_LINK_HEAD	=	3'H1	;
	parameter							DVPX_CMND_LINK_BLNK	=	3'H2	;
	parameter							DVPX_CMND_LINK_DDMY	=	3'H3	;
	parameter							DVPX_CMND_LINK_DONE	=	3'H4	;

	assign	dvpx_pmau_clnk_idle		=	dvpx_pmau_clnk_mfsm	==	DVPX_CMND_LINK_IDLE	;
	assign	dvpx_pmau_clnk_head		=	dvpx_pmau_clnk_mfsm	==	DVPX_CMND_LINK_HEAD	;
	assign	dvpx_pmau_clnk_blnk		=	dvpx_pmau_clnk_mfsm	==	DVPX_CMND_LINK_BLNK	;
	assign	dvpx_pmau_clnk_dmmy		=	dvpx_pmau_clnk_mfsm	==	DVPX_CMND_LINK_DDMY	;
	assign	dvpx_pmau_clnk_done		=	dvpx_pmau_clnk_mfsm	==	DVPX_CMND_LINK_DONE	;

	wire	dvpx_cmnd_head_last		= &{dvpx_pmau_clnk_head	,	dvpx_pmau_clnk_time == 4'HF	};
	wire	dvpx_cmnd_blnk_last		= &{dvpx_pmau_clnk_blnk	,	dvpx_pmau_clnk_time == 4'HF	};
	wire	dvpx_cmnd_dmmy_last		= &{dvpx_pmau_clnk_dmmy	,	dvpx_pmau_clnk_time == 4'HF	};
//------------------------------------------------------------------------------
	always@(posedge	dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_pmau_clnk_mfsm	<=	DVPX_CMND_LINK_IDLE	;
	else begin
		case(dvpx_pmau_clnk_mfsm)
			DVPX_CMND_LINK_IDLE	:		dvpx_pmau_clnk_mfsm	<=	dvpx_pmau_clnk_enab	?	DVPX_CMND_LINK_HEAD	:	DVPX_CMND_LINK_IDLE	;
			DVPX_CMND_LINK_HEAD	:		dvpx_pmau_clnk_mfsm	<=	dvpx_cmnd_head_last	?	DVPX_CMND_LINK_BLNK	:	DVPX_CMND_LINK_HEAD	;	

			DVPX_CMND_LINK_BLNK	:	
			if(dvpx_cmnd_blnk_last)		dvpx_pmau_clnk_mfsm	<=	dvpx_cmnd_natv_enab	?	DVPX_CMND_LINK_DDMY	:	DVPX_CMND_LINK_DONE	;		
			else						dvpx_pmau_clnk_mfsm	<=													DVPX_CMND_LINK_BLNK	;
			
			DVPX_CMND_LINK_DDMY	:		dvpx_pmau_clnk_mfsm	<=	dvpx_cmnd_dmmy_last	?	DVPX_CMND_LINK_DONE	:	DVPX_CMND_LINK_DDMY	;		
			DVPX_CMND_LINK_DONE	:		dvpx_pmau_clnk_mfsm	<=	dvpx_pmau_clnk_enab	?	DVPX_CMND_LINK_DONE	:	DVPX_CMND_LINK_IDLE	;

			default				:		dvpx_pmau_clnk_mfsm	<=													DVPX_CMND_LINK_IDLE	;
		endcase	
	end
/**********************************************************************************************************************/
/**********************************************************************************************************************/
	wire								dvpx_cmnd_time_csen	;
	wire								dvpx_cmnd_time_last	;
	wire								dvpx_cmnd_time_flag	;

	assign		dvpx_cmnd_time_csen	= |{dvpx_pmau_clnk_head	,	dvpx_pmau_clnk_blnk	,	dvpx_pmau_clnk_dmmy	};
	assign		dvpx_cmnd_time_last	= |{dvpx_cmnd_head_last	,	dvpx_cmnd_blnk_last	,	dvpx_cmnd_dmmy_last	};
	assign		dvpx_cmnd_time_flag	=	dvpx_pmau_clnk_time[0]	;	
	assign		dvpx_clnk_memo_addr	=	dvpx_pmau_clnk_time[3:1];
//----------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_pmau_clnk_time	<=	0	;
	else if(~dvpx_cmnd_time_csen)		dvpx_pmau_clnk_time	<=	0	;
	else								dvpx_pmau_clnk_time	<=	dvpx_cmnd_time_last	?	4'H0	:	dvpx_pmau_clnk_time + 1	;		
//----------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn) 						dvpx_pmau_clnk_vsyn	<=	0	;
   	else								dvpx_pmau_clnk_vsyn	<=	dvpx_pmau_clnk_head	;
//----------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn) 						dvpx_pmau_clnk_hsyn	<=	0	;
   	else								dvpx_pmau_clnk_hsyn	<=	dvpx_pmau_clnk_dmmy	;
//----------------------------------------------------------------------
	always@(posedge dvpx_bclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_pmau_clnk_data	<=	0	;
	else if( dvpx_pmau_clnk_head)		dvpx_pmau_clnk_data	<=	dvpx_cmnd_time_flag	?	dvpx_clnk_memo_data[31:16]	: 
																						dvpx_clnk_memo_data[15: 0]	;
	else 								dvpx_pmau_clnk_data	<=	0	;																					
/**********************************************************************************************************************/
/**********************************************************************************************************************/
endmodule

 
