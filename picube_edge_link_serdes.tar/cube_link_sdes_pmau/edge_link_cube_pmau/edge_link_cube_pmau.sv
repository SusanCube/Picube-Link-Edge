/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
history : 
        2024/12/02, linsen, fix data CMND sequence 
        1. handshake with cube, waiting for re-cfig dvp ready
        2. dummy vsyn
----------------------------------------------------------------------*/
module	edge_link_cube_pmau(
	output	reg							dvp0_pmau_vsyn_pado	,			
	output	reg							dvp0_pmau_hsyn_pado	,
	output	reg	[15: 0]					dvp0_pmau_data_pado	,
	output	reg							dvp1_pmau_vsyn_pado	,			
	output	reg							dvp1_pmau_hsyn_pado	,
	output	reg	[15: 0]					dvp1_pmau_data_pado	,

	input								gmsl_pmau_vsyn_padi	,
	input								gmsl_pmau_hsyn_padi	,
	input		[15: 0]					gmsl_pmau_data_padi	,

	output								cube_ufcm_cmnd_port	,
	input		[ 1: 0]					cube_ufcm_stat_port	,

	output								cube_link_ufcm_done	,
	input								cube_link_ocfg_reqs	,
	input								cube_link_icfg_reqs	,
	input								cube_link_odat_reqs	,
	input								cube_link_idat_reqs	,

	input								rora_acks_txln_done	,
	output								rora_acks_cube_reqs	,
	output	reg	[31: 0]					rora_acks_cube_data	,
	
	input								rora_resp_txln_done	,
	output								rora_resp_cube_reqs	,

	input		[19: 0]					rora_data_link_rows	,
	input		[19: 0]					rora_data_link_cols	,
	
	output								rora_dvpx_dlnk_done	,
	output								rora_dvpx_dlnk_enab	,
	output								rora_dvpx_dlnk_trdy	,
	input		[ 1: 0]					rora_dvpx_dlnk_port	,
	input								rora_dvpx_dlnk_reqs	,

	input		[ 2: 0]					rora_gmsl_alnk_wsel	,
	input								rora_gmsl_slnk_done	,
	output								rora_gmsl_slnk_enab	,
	output								rora_gmsl_slnk_reqs	,
	input								rora_bclk			,
	input								rora_rstn			,		

	output		[ 2: 0]					dvpx_clnk_memo_addr	,
	input		[31: 0]					dvpx_clnk_memo_data	,
	output								dvpx_dlnk_memo_rank	,
	output		[10: 0]					dvpx_dlnk_memo_addr	,
	input		[31: 0]					dvpx_dlnk_memo_data	,
	input								dvpx_bclk			,
	input								dvpx_rstn			,

	output		[15: 0]					gmsl_slnk_rows_data	,//to hubs
	output								gmsl_slnk_rows_drdy	,//to hubs
	output								gmsl_slnk_rows_tail	,//to hubs
	input								gmsl_bclk			,
	input								gmsl_rstn			);
/***********************************************************************************************************/	
	wire		[ 1: 0]					dvpx_link_port_enab	;
	wire		[31: 0]					rora_gmsl_alnk_data	;

	edge_link_cube_ufcm				u_edge_link_cube_ufcm(
 		.cube_ufcm_stat_port			(cube_ufcm_stat_port	),//input   	[1:0]   
 		.cube_ufcm_cmnd_port			(cube_ufcm_cmnd_port	),//output	reg  	    
 		
		.cube_link_ufcm_done			(cube_link_ufcm_done	),//output				
		.cube_link_ocfg_reqs			(cube_link_ocfg_reqs	),//input				
		.cube_link_icfg_reqs			(cube_link_icfg_reqs	),//input				
		.cube_link_odat_reqs			(cube_link_odat_reqs	),//input				
		.cube_link_idat_reqs			(cube_link_idat_reqs	),//input				
	
		.rora_acks_txln_done			(rora_acks_txln_done	),//input				
		.rora_acks_cube_reqs			(rora_acks_cube_reqs	),//output				
		.rora_acks_cube_data			(rora_acks_cube_data	),//output	reg	[31: 0]	
	
		.rora_resp_txln_done			(rora_resp_txln_done	),//input
		.rora_resp_cube_reqs			(rora_resp_cube_reqs	),//output
		
		.rora_dvpx_clnk_done			(rora_dvpx_clnk_done	),//input				
 		.rora_dvpx_clnk_natv			(rora_dvpx_clnk_natv	),//output
		.rora_dvpx_clnk_dmmy			(rora_dvpx_clnk_dmmy	),//output				

		.rora_dvpx_dlnk_port			(rora_dvpx_dlnk_port	),//output	reg  	    
		.rora_dvpx_dlnk_enab			(rora_dvpx_dlnk_enab	),//output  
 		.rora_dvpx_dlnk_done			(rora_dvpx_dlnk_done	),//input  

		.rora_gmsl_alnk_data			(rora_gmsl_alnk_data	),//input		[31: 0]
		.rora_gmsl_alnk_enab			(rora_gmsl_alnk_enab	),//output  
 		.rora_gmsl_alnk_done			(rora_gmsl_alnk_done	),//input  
 
 		.rora_gmsl_slnk_enab			(rora_gmsl_slnk_enab	),//output  
 		.rora_gmsl_slnk_done			(rora_gmsl_slnk_done	),//input  
 		.rora_bclk						(rora_bclk				),//input				
 		.rora_rstn						(rora_rstn				),
		 
		.dvpx_pmau_port_enab			(dvpx_link_port_enab	),//input
		.dvpx_bclk						(dvpx_bclk				),//input
		.dvpx_rstn						(dvpx_rstn				));//input
/**********************************************************************************************************************/
	edge_link_gmsl_pmau				u_edge_link_gmsl_pmau(
		.gmsl_pmau_vsyn_padi			(gmsl_pmau_vsyn_padi	),//input				
		.gmsl_pmau_hsyn_padi			(gmsl_pmau_hsyn_padi	),//input				
		.gmsl_pmau_data_padi			(gmsl_pmau_data_padi	),//input		[15: 0]	
		
		.gmsl_slnk_rows_data			(gmsl_slnk_rows_data	),//output		[15: 0]	
		.gmsl_slnk_rows_drdy			(gmsl_slnk_rows_drdy	),//output				
		.gmsl_slnk_rows_tail			(gmsl_slnk_rows_tail	),//output				
		.gmsl_bclk						(gmsl_bclk				),//input				
		.gmsl_rstn						(gmsl_rstn				),//input				

		.rora_gmsl_alnk_wsel			(rora_gmsl_alnk_wsel	),//input		[ 2: 0]	
		.rora_gmsl_alnk_data			(rora_gmsl_alnk_data	),//output		[31: 0]	
    	.rora_gmsl_alnk_enab			(rora_gmsl_alnk_enab	),//input   
    	.rora_gmsl_alnk_done			(rora_gmsl_alnk_done	),//output	
    
		.rora_gmsl_slnk_enab			(rora_gmsl_slnk_enab	),//input   
    	.rora_gmsl_slnk_reqs			(rora_gmsl_slnk_reqs	),//output	

		.rora_bclk           			(rora_bclk          	),//input               
    	.rora_rstn           			(rora_rstn          	));//input               
/**********************************************************************************************************************/
	edge_link_dvpx_pmau				u_edge_link_dvpx_pmau(
		.dvpx_pmau_port_enab			(dvpx_link_port_enab	),//input		[ 1: 0]
		.dvp0_pmau_vsyn_pado			(dvp0_pmau_vsyn_pado	),//output	reg			
		.dvp0_pmau_hsyn_pado			(dvp0_pmau_hsyn_pado	),//output	reg			
		.dvp0_pmau_data_pado			(dvp0_pmau_data_pado	),//output	reg	[15: 0]	
		.dvp1_pmau_vsyn_pado			(dvp1_pmau_vsyn_pado	),//output	reg			
		.dvp1_pmau_hsyn_pado			(dvp1_pmau_hsyn_pado	),//output	reg			
		.dvp1_pmau_data_pado			(dvp1_pmau_data_pado	),//output	reg	[15: 0]	

		.dvpx_dlnk_memo_rank			(dvpx_dlnk_memo_rank	),//output				
		.dvpx_dlnk_memo_addr			(dvpx_dlnk_memo_addr	),//output		[11: 0]	
		.dvpx_dlnk_memo_data			(dvpx_dlnk_memo_data	),//input		[15: 0]	
		.dvpx_clnk_memo_addr			(dvpx_clnk_memo_addr	),//output		[ 2: 0]	
		.dvpx_clnk_memo_data			(dvpx_clnk_memo_data	),//input		[31: 0]	
		.dvpx_bclk						(dvpx_bclk				),//input				
		.dvpx_rstn						(dvpx_rstn				),//input				

		.rora_dvpx_dlnk_rows			(rora_data_link_rows	),//input		[19: 0]	
		.rora_dvpx_dlnk_cols			(rora_data_link_cols	),//input		[19: 0]	

		.rora_dvpx_clnk_done			(rora_dvpx_clnk_done	),//output				
		.rora_dvpx_clnk_natv			(rora_dvpx_clnk_natv	),//input				
		.rora_dvpx_clnk_dmmy			(rora_dvpx_clnk_dmmy	),//input				
		
		.rora_dvpx_dlnk_enab			(rora_dvpx_dlnk_enab	),//input				
		.rora_dvpx_dlnk_done			(rora_dvpx_dlnk_done	),//output				
		.rora_dvpx_dlnk_reqs			(rora_dvpx_dlnk_reqs	),//input				
		.rora_dvpx_dlnk_trdy			(rora_dvpx_dlnk_trdy	),//output				
		
		.rora_bclk						(rora_bclk				),//input				
		.rora_rstn						(rora_rstn				));//input				

endmodule

 
