/*----------------------------------------------------------------------------------------------------------------------
AUTHOR	: EDWARD YANG
version : 
        2026/09/03, edward, ver10
----------------------------------------------------------------------------------------------------------------------*/
module  edge_link_gmsl_pmau(
	input								gmsl_pmau_vsyn_padi	,
	input								gmsl_pmau_hsyn_padi	,
	input		[15: 0]					gmsl_pmau_data_padi	,

	output	reg	[15: 0]					gmsl_slnk_rows_data	,
	output	reg							gmsl_slnk_rows_drdy	,
	output								gmsl_slnk_rows_tail	,
	input								gmsl_bclk			,
	input								gmsl_rstn			,

	input		[ 2: 0]					rora_gmsl_alnk_wsel	,
	output		[31: 0]					rora_gmsl_alnk_data	,
    input                           	rora_gmsl_alnk_enab ,
	output								rora_gmsl_alnk_done ,

    input                           	rora_gmsl_slnk_enab ,
	output								rora_gmsl_slnk_reqs	,
    input                           	rora_bclk           ,
    input                           	rora_rstn           );
/**********************************************************************************************************************/
//	MGTE CLOCK DOMAIN
/**********************************************************************************************************************/
	wire								rora_gmsl_lead_tail	;
	wire								rora_gmsl_rows_tail	;

	assign		rora_gmsl_alnk_done	= &{rora_gmsl_alnk_enab	,	rora_gmsl_lead_tail	};
	assign		rora_gmsl_slnk_reqs	= &{rora_gmsl_slnk_enab	,	rora_gmsl_rows_tail	};	
/**********************************************************************************************************************/
//GMSL CLOCK DOMAIN  
/**********************************************************************************************************************/
	wire								gmsl_acks_enab	;	
	wire								gmsl_data_enab	;
	wire		[ 2: 0]					gmsl_acks_selx	;

	reg			[31: 0]					gmsl_acks_word	;
	reg			[15: 0]					gmsl_data_samp	;
	reg									gmsl_vsyn_samp	;
	reg									gmsl_hsyn_samp	;
//--ACKS_ENAB----------------------------------------------------------------------------	
	gens_sync_mark 					u_gens_gmsl_alnk_enab(	
		.dtar_mark						(gmsl_acks_enab			),//output	
		.dtar_clki						(gmsl_bclk				),//input	
		.dtar_rstn						(gmsl_rstn				),//input	

		.dsrc_mark  					(rora_gmsl_alnk_enab	),
		.dsrc_clki						(rora_bclk				),
		.dsrc_rstn						(rora_rstn				));
//--DATA_ENAB----------------------------------------------------------------------------	
	gens_sync_mark 					u_gens_gmsl_dlnk_enab(	
		.dtar_mark						(gmsl_data_enab			),//output	
		.dtar_clki						(gmsl_bclk				),//input	
		.dtar_rstn						(gmsl_rstn				),//input	

		.dsrc_mark  					(rora_gmsl_slnk_enab	),
		.dsrc_clki						(rora_bclk				),
		.dsrc_rstn						(rora_rstn				));
//--ROWS_REQS----------------------------------------------------------------------------
	gens_sync_edge #( .EXTN(2))		u_rora_gmsl_hsyn_edge(	
		.dtar_rise						(rora_gmsl_rows_tail	),//output	
		.dtar_fall						(						),//output	
		.dtar_clki						(rora_bclk				),//input	
		.dtar_rstn						(rora_rstn				),//input	

		.dsrc_mark						(gmsl_slnk_rows_tail	),//input   
		.dsrc_clki						(gmsl_bclk				),//input	
		.dsrc_rstn						(gmsl_rstn				));//input	
//--ROWS_TAIL----------------------------------------------------------------------------
	gens_sync_edge #( .EXTN(1))		u_gmsl_hsyn_fall_edge(	
		.dtar_rise						(						),//output	
		.dtar_fall						(gmsl_slnk_rows_tail	),//output	
		.dtar_clki						(gmsl_bclk				),//input	
		.dtar_rstn						(gmsl_rstn				),//input	

		.dsrc_mark						(gmsl_hsyn_samp			),//input   
		.dsrc_clki						(gmsl_bclk				),//input	
		.dsrc_rstn						(gmsl_rstn				));//input	
//--GRAY_ACKS_SELX----------------------------------------------------------------------------
	gens_gray_code	#(.MSB( 2))		u_gmsl_acks_word_indx(		
		.dtar_data						(gmsl_acks_selx			), 
		.dtar_clki						(gmsl_bclk				), 
		.dtar_rstn						(gmsl_rstn				),

		.dsrc_data						(rora_gmsl_alnk_wsel	), 
		.dsrc_clki						(rora_bclk				));
//--GRAY_ACKS_WORD----------------------------------------------------------------------------
	gens_gray_code	#(.MSB(31))		u_rora_gmsl_alnk_data(		
		.dtar_data						(rora_gmsl_alnk_data	), 
		.dtar_clki						(rora_bclk				), 
		.dtar_rstn						(rora_rstn				),

		.dsrc_data						(gmsl_acks_word			), 
		.dsrc_clki						(gmsl_bclk				));
//------------------------------------------------------------------------------
	always@(negedge gmsl_bclk or negedge gmsl_rstn)
    if(~gmsl_rstn)   					begin
		gmsl_vsyn_samp					<=	0	;
		gmsl_hsyn_samp					<=	0	;
		gmsl_data_samp					<=	0	;
	end else if(~gmsl_data_enab)		begin				
		gmsl_vsyn_samp					<=	0	;
		gmsl_hsyn_samp					<=	0	;
		gmsl_data_samp					<=	0	;
	end else begin				
		gmsl_vsyn_samp					<=	gmsl_pmau_vsyn_padi	;
		gmsl_hsyn_samp					<=	gmsl_pmau_hsyn_padi	;
		gmsl_data_samp					<=	gmsl_pmau_data_padi	;
	end
//------------------------------------------------------------------------------
	always@(posedge gmsl_bclk or negedge gmsl_rstn)
    if(~gmsl_rstn)   					begin
		gmsl_slnk_rows_drdy				<=	0	;
		gmsl_slnk_rows_data				<=	0	;
	end else if(~gmsl_data_enab)		begin	
		gmsl_slnk_rows_drdy				<=	0	;
		gmsl_slnk_rows_data				<=	0	;
	end else if(~gmsl_hsyn_samp)		begin	
		gmsl_slnk_rows_drdy				<=	0	;
		gmsl_slnk_rows_data				<=	0	;
	end else 							begin	
		gmsl_slnk_rows_drdy				<=	1	;
		gmsl_slnk_rows_data				<=	gmsl_data_samp	;
	end	
/**********************************************************************************************************************/
	reg			[ 2: 0]					gmsl_acks_cnts	;
	reg									gmsl_acks_taps	;

	wire		gmsl_acks_wmsb	= &{	gmsl_acks_enab	,	gmsl_vsyn_samp	,	gmsl_acks_taps	,	gmsl_acks_cnts	==	gmsl_acks_selx	}	;
	wire		gmsl_acks_wlsb	= &{	gmsl_acks_enab	,	gmsl_vsyn_samp	, ~	gmsl_acks_taps	,	gmsl_acks_cnts	==	gmsl_acks_selx	}	;

	always@(posedge gmsl_bclk or negedge gmsl_rstn)
	if(~gmsl_rstn)						gmsl_acks_taps	<=	0	;
	else if(~gmsl_acks_enab)			gmsl_acks_taps	<=	0	;
	else if(~gmsl_vsyn_samp)			gmsl_acks_taps	<=	0	;
	else 								gmsl_acks_taps	<= ~gmsl_acks_taps		;			

	always@(posedge gmsl_bclk or negedge gmsl_rstn)
	if(~gmsl_rstn)						gmsl_acks_cnts	<=	0	;
	else if(~gmsl_acks_enab)			gmsl_acks_cnts	<=	0	;
	else if(~gmsl_vsyn_samp)			gmsl_acks_cnts	<=	0	;
	else if( gmsl_acks_taps)			gmsl_acks_cnts	<=	gmsl_acks_cnts + 1	;			

	always@(posedge gmsl_bclk or negedge gmsl_rstn)
	if(~gmsl_rstn)						gmsl_acks_word	<=	0	;
	else if( gmsl_acks_wlsb)			gmsl_acks_word	<=	{ gmsl_acks_word[31:16]	,	gmsl_data_samp			};
	else if( gmsl_acks_wmsb)			gmsl_acks_word	<=	{ gmsl_data_samp		,	gmsl_acks_word[15:0]	};
/**********************************************************************************************************************/
//	
/**********************************************************************************************************************/
 
endmodule 