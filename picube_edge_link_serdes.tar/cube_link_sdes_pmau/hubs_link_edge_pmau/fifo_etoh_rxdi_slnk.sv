module	fifo_etoh_rxdi_slnk(	
	input								push_enab	,	
	input		[31: 0]					push_data	,
	input								push_drdy	,
	input								push_clki	,
	input								push_rstn	,

	input								pops_enab	,
	input								pops_trdy	,
	output		[63: 0]			 		pops_data	,
	output								pops_drdy	,
	input								pops_clki	,
	input								pops_rstn	);
/**********************************************************************************************************************/
	reg			[23: 0]					push_addr	;
	reg			[63: 0]					push_pack	;
	reg									push_wrcs	;

	wire		[22: 0]					push_msba	;
	wire		[ 6: 0]					push_dptr	;

	assign		push_msba	=			push_addr[23:1]	;
	assign		push_dptr	=			push_addr[ 7:1]	;

	always@(posedge push_clki or negedge push_rstn)
	if(~push_rstn)						push_addr	<=	0	;
	else if(~push_enab)					push_addr	<=	0	;
	else if( push_drdy)					push_addr	<=	push_addr + 1	;	

	always@(posedge push_clki or negedge push_rstn)
	if(~push_rstn)						push_pack	<=	0	;
	else if(~push_enab)					push_pack	<=	0	;
	else if( push_drdy)					push_pack	<= {push_data	,	push_pack[63:32]};	

	always@(posedge push_clki or negedge push_rstn)
	if(~push_rstn)						push_wrcs	<=	0	;
	else if(~push_enab)					push_wrcs	<=	0	;
	else 								push_wrcs	<=&{push_drdy	,	push_addr[0]	};	
//------------------------------------------------------------------------------
	(*ram_style="block"*) 
	reg 		[63: 0] 				push_memo[ 0:127]	;

	always@(posedge push_clki)			
	if(push_wrcs)						push_memo[push_dptr]	<=	push_pack	;
/**********************************************************************************************************************/
	wire		[22: 0]					gray_push	;

	gens_gray_code	#(.MSB(22))		sync_gray_push(		
		.dtar_data						(gray_push	), 
		.dtar_clki						(pops_clki	), 
		.dtar_rstn						(pops_rstn	),

		.dsrc_data						(push_msba	), 
		.dsrc_clki						(push_clki	));
/**********************************************************************************************************************/
	reg			[22: 0]					pops_addr	;
	wire		[22: 0]					pops_nxta	;
	wire		[ 5: 0]					pops_dptr	;	
	wire								pops_beok	;

	assign		pops_nxta	=			pops_addr + 1	;
	assign		pops_dptr	=			pops_trdy	?	pops_nxta[7:0]	:	pops_addr[7:0]	;
	assign		pops_drdy	=	&{		pops_enab	,	gray_push	>=	pops_nxta	};	
	assign		pops_beok	=	&{		pops_drdy	,	pops_trdy	};	
//------------------------------------------------------------------------------
	always@(posedge pops_clki or negedge pops_rstn)
	if(~pops_rstn)						pops_addr	<=	0	;
	else if(~pops_enab)					pops_addr	<=	0	;
	else if( pops_beok)					pops_addr	<= 	pops_nxta	;	
/**********************************************************************************************************************/
	always@(posedge pops_clki)			pops_data	<=	push_memo[pops_dptr]	;
/**********************************************************************************************************************/

endmodule