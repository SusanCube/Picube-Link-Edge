module	hubs_rxds_edge_ufcm(
	input		[31: 0]					mgte_etoh_ufcm_data	,
	input								mgte_etoh_ufcm_drdy	,
	input								mgte_etoh_ufcm_last	,
	
	output	reg							mgte_etoh_acks_lead	,
	output	reg							mgte_etoh_acks_coda	,
	output	reg							mgte_etoh_data_lead	,
	output	reg							mgte_etoh_data_coda	,
	output	reg							mgte_etoh_resp_tokn	,
//	output	reg							hubs_etoh_trdy_tokn	,
	input								mgte_bclk			,
	input								mgte_rstn			);
/**********************************************************************************************************************/
	reg			[63: 0]					mgte_etoh_ufcm_memo	;
	reg									mgte_etoh_ufcm_rxok	;

	always@(posedge mgte_bclk or negedge mgte_rstn)	
	if(~mgte_rstn)						mgte_etoh_ufcm_memo	<=	0	;
	else if(mgte_etoh_ufcm_drdy)		mgte_etoh_ufcm_memo	<={	mgte_etoh_ufcm_data	,	mgte_etoh_ufcm_memo[63:32]	};

	always@(posedge mgte_bclk or negedge mgte_rstn)	
	if(~mgte_rstn)						mgte_etoh_ufcm_rxok	<=	0	;
	else 								mgte_etoh_ufcm_rxok	<=&{mgte_etoh_ufcm_drdy	,	mgte_etoh_ufcm_last	};
/**********************************************************************************************************************/
	wire		etoh_acks_lead_meet	= &{mgte_etoh_ufcm_rxok	,	mgte_etoh_ufcm_memo	==	"ACKSLEAD"	};		
	wire		etoh_acks_coda_meet	= &{mgte_etoh_ufcm_rxok	,	mgte_etoh_ufcm_memo	==	"ACKSCODA"	};		
	wire		etoh_data_lead_meet	= &{mgte_etoh_ufcm_rxok	,	mgte_etoh_ufcm_memo	==	"DATALEAD"	};		
	wire		etoh_data_coda_meet	= &{mgte_etoh_ufcm_rxok	,	mgte_etoh_ufcm_memo	==	"DATACODA"	};		
	wire		etoh_resp_tokn_meet	= &{mgte_etoh_ufcm_rxok	,	mgte_etoh_ufcm_memo	==	"RESPONSE"	};		
//	wire		etoh_trdy_tokn_meet	= &{mgte_etoh_ufcm_rxok	,	mgte_etoh_ufcm_memo	==	"EDGETRDY"	};		
/**********************************************************************************************************************/
	always@(posedge mgte_bclk or negedge mgte_rstn)	
	if(~mgte_rstn)						begin
		mgte_etoh_acks_lead	<=			0	;		
		mgte_etoh_acks_coda	<=			0	;		
		mgte_etoh_data_lead	<=			0	;		
		mgte_etoh_data_coda	<=			0	;		
		mgte_etoh_resp_tokn	<=			0	;		
//		hubs_etoh_trdy_tokn	<=			0	;
	end else 							begin
		mgte_etoh_acks_lead	<=			etoh_acks_lead_meet	;
		mgte_etoh_acks_coda	<=			etoh_acks_coda_meet	;
		mgte_etoh_data_lead	<=			etoh_data_lead_meet	;
		mgte_etoh_data_coda	<=			etoh_data_coda_meet	;
		mgte_etoh_resp_tokn	<=			etoh_resp_tokn_meet	;
//		hubs_etoh_trdy_tokn	<=			etoh_trdy_tokn_meet	;
	end
/**********************************************************************************************************************/
/**********************************************************************************************************************/
/**********************************************************************************************************************/
endmodule


