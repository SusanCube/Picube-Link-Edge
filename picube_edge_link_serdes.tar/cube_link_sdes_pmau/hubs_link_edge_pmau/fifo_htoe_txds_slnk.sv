

module	fifo_htoe_txds_slnk(	
	input								push_init	,
	output								push_done	,
	input		[12: 0]					push_size	,
	input		[63: 0]					push_data	,
	input								push_drdy	,
	input								push_clki	,
	input								push_rstn	,

	output	reg							pops_enab	,
	output		[31: 0]			 		pops_data	,
	output								pops_drdy	,
	input								pops_trdy	,
	input								pops_clki	,
	input								pops_rstn	);
/**********************************************************************************************************************/
	wire		[12: 0]					pops_size	;

	gens_gray_code	#(.MSB(12))		u_dlnk_sync_gray_size(		
		.dtar_data						(pops_size	), 
		.dtar_clki						(pops_clki	), 
		.dtar_rstn						(pops_rstn	),

		.dsrc_data						(push_size	), 
		.dsrc_clki						(push_clki	)); 
/**********************************************************************************************************************/
	wire								pops_init	;
	wire								pops_done	;
//------------------------------------------------------------------------------
	gens_sync_edge #(.EXTN_MULT(1))	u_gens_pops_sync_init(	
		.dtar_rise						(pops_init	),//output
		.dtar_fall						(			),//output
		.dtar_clki						(pops_clki	),//input	
		.dtar_rstn						(pops_rstn	),//input	

		.dsrc_mark						(push_init	),//input
		.dsrc_clki						(push_clki	),//input
		.dsrc_rstn						(push_rstn	));//input
//------------------------------------------------------------------------------
	gens_sync_edge #(.EXTN_MULT(1))	u_gens_push_sync_done(	
		.dtar_rise						(push_done	),//output
		.dtar_fall						(			),//output
		.dtar_clki						(push_clki	),//input	
		.dtar_rstn						(push_rstn	),//input	

		.dsrc_mark						(pops_done	),//input
		.dsrc_clki						(pops_clki	),//input
		.dsrc_rstn						(pops_rstn	));//input
//------------------------------------------------------------------------------
	always@(posedge pops_clki or negedge pops_rstn)
	if(~pops_rstn)						pops_enab	<=	0	;
	else if( pops_init)					pops_enab	<=	1	;
	else if( pops_done)					pops_enab	<=	0	;
/**********************************************************************************************************************/
	reg			[11: 0]					push_indx	;
	wire		[11: 0]					push_gray	;
	wire		[11: 0]					push_nxta	;
	wire		[10: 0]					push_wptr	;

	assign		push_nxta	=			push_indx + 1	;
	assign		push_wptr	=			push_indx[10:0]	;

	always@(posedge push_clki or negedge push_rstn)
	if(~push_rstn)						push_indx	<=	0	;
	else if( push_init)					push_indx	<=	0	;
	else if( push_done)					push_indx	<=	0	;
	else if( push_drdy)					push_indx	<=	push_nxta	;	
//------------------------------------------------------------------------------
	(*ram_style="block"*) 
	reg 		[63: 0] 				push_memo[0:2047]	;//2K*4=08k

	always@(posedge push_clki)			
	if(push_drdy)						push_memo[push_wptr]	<=	push_data	;
//------------------------------------------------------------------------------
	gens_gray_code	#(.MSB(11))		u_sync_push_gray(		
		.SDI							(push_indx	), 
		.SCK							(push_clki	), 

		.GDO							(push_gray	), 
		.GCK							(pops_clki	), 
		.GRN							(pops_rstn	));
/**********************************************************************************************************************/
/**********************************************************************************************************************/
	reg			[12: 0]					pops_indx	;
	wire		[12: 0]					pops_nxta	;
	
	wire								pops_lsba	;
	wire								pops_beok	;

	wire		[31: 0]					pops_wrd0	;
	wire		[31: 0]					pops_wrd1	;
	wire		[10: 0]					pops_rptr	;

	assign		pops_nxta	=			pops_indx  + 1	;
	assign		pops_lsba	=			pops_indx[ 0 ]	;

	assign		pops_wrd0	=			push_memo[pops_rptr][ 31: 0]	;
	assign		pops_wrd1	=			push_memo[pops_rptr][ 63:32]	;

	assign		pops_beok	=	&{		pops_drdy	,	pops_trdy		};
	assign		pops_drdy	=	&{		pops_enab	,	push_gray		>=	pops_nxta[12:1]	};	
	assign		pops_done	= 	&{		pops_beok	,	pops_nxta[12:1]	==	pops_size		};
	assign		pops_rptr	=			pops_beok	?	pops_nxta[11:1]	:	pops_indx[11:1]	;
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
	always@(posedge pops_clki or negedge pops_rstn)
	if(~pops_rstn)						pops_indx	<=	0	;
	else if(~pops_enab)					pops_indx	<=	0	;
	else if( pops_trdy)					pops_indx	<= 	pops_nxta	;	
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
	always@(posedge pops_clki)			pops_data	<=	pops_lsba 	?	pops_wrd1	:	pops_wrd0	;
/**********************************************************************************************************************/

endmodule