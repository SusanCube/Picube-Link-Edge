module	hubs_rxds_edge_pmau(
	input		[31: 0]					mgte_etoh_axis_data	,
	input								mgte_etoh_axis_drdy	,
	input		[31: 0]					mgte_etoh_ufcm_data	,
	input								mgte_etoh_ufcm_drdy	,
	input								mgte_etoh_ufcm_last	,

	output								mgte_etoh_acks_lead	,
	output								mgte_etoh_acks_coda	,
	output								mgte_etoh_data_lead	,
	output								mgte_etoh_data_coda	,
	output								mgte_etoh_resp_tokn	,

	output		[31: 0]					mgte_etoh_acks_data	,
	output								mgte_etoh_acks_wrcs	,
	output		[31: 0]					mgte_etoh_maxi_rows	,
	output		[15: 0]					mgte_etoh_maxi_cols	,
	output		[15: 0]					mgte_etoh_maxi_data	,

	input								mgte_bclk			,
	input								mgte_rstn			,

	input								mgth_etoh_maxi_csen	,
	input								mgth_etoh_slnk_enab	,
	output		[63: 0]					mgth_etoh_slnk_data	,
	output								mgth_etoh_slnk_drdy	,
	input								mgth_etoh_slnk_trdy	,
	input								mgth_bclk			,
	input								mgth_rstn			,

	input								ddrs_etoh_wdma_bank	,
	input		[ 9: 0]					ddrs_etoh_wdma_addr	,
	output		[127:0]					ddrs_etoh_wdma_data	,
	input								ddrs_bclk			);
/**********************************************************************************************************************/
	hubs_rxds_edge_ufcm				u_hubs_rxds_edge_ufcm(
		.mgte_etoh_ufcm_data			(mgte_etoh_ufcm_data	),//input		[31: 0]	
		.mgte_etoh_ufcm_drdy			(mgte_etoh_ufcm_drdy	),//input				
		.mgte_etoh_ufcm_last			(mgte_etoh_ufcm_last	),//input				
		.mgte_etoh_acks_lead			(mgte_etoh_acks_lead	),//output	reg			
		.mgte_etoh_acks_coda			(mgte_etoh_acks_coda	),//output	reg			
		.mgte_etoh_data_lead			(mgte_etoh_data_lead	),//output	reg			
		.mgte_etoh_data_coda			(mgte_etoh_data_coda	),//output	reg			
		.mgte_etoh_resp_tokn			(mgte_etoh_resp_tokn	),//output	reg			
		.mgte_bclk						(mgte_bclk				),//input				
		.mgte_rstn						(mgte_rstn				));//input				
/**********************************************************************************************************************/
	hubs_rxds_edge_data				u_hubs_rxds_edge_data(
		.mgte_etoh_axis_data			(mgte_etoh_axis_data	),//input		[31: 0]	
		.mgte_etoh_axis_drdy			(mgte_etoh_axis_drdy	),//input				

		.mgte_etoh_acks_data			(mgte_etoh_acks_data	),//output	reg	[31: 0]	
		.mgte_etoh_acks_wrcs			(mgte_etoh_acks_wrcs	),//output	reg			
		.mgte_etoh_acks_lead			(mgte_etoh_acks_lead	),//input				
		.mgte_etoh_acks_coda			(mgte_etoh_acks_coda	),//input				
		.mgte_etoh_data_lead			(mgte_etoh_data_lead	),//input				
		.mgte_etoh_data_coda			(mgte_etoh_data_coda	),//input				
		.mgte_etoh_maxi_rows			(mgte_etoh_maxi_rows	),//output	reg	[31: 0]	
		.mgte_etoh_maxi_cols			(mgte_etoh_maxi_cols	),//output	reg	[31: 0]	
		.mgte_etoh_maxi_data			(mgte_etoh_maxi_data	),//output	reg	[15: 0]	
		.mgte_bclk						(mgte_bclk				),//input				
		.mgte_rstn						(mgte_rstn				),//input				

		.mgth_etoh_maxi_csen			(mgth_etoh_maxi_csen	),//input				
		.mgth_etoh_slnk_enab			(mgth_etoh_slnk_enab	),//input				
		.mgth_etoh_slnk_data			(mgth_etoh_slnk_data	),//output		[63: 0]	
		.mgth_etoh_slnk_drdy			(mgth_etoh_slnk_drdy	),//output				
		.mgth_etoh_slnk_trdy			(mgth_etoh_slnk_trdy	),//input				
		.mgth_bclk						(mgth_bclk				),//input				
		.mgth_rstn						(mgth_rstn				),//input				

		.ddrs_etoh_wdma_bank			(ddrs_etoh_wdma_bank	),//input				
		.ddrs_etoh_wdma_addr			(ddrs_etoh_wdma_addr	),//input		[ 9: 0]	
		.ddrs_etoh_wdma_data			(ddrs_etoh_wdma_data	),//output		[127:0]	
		.ddrs_bclk						(ddrs_bclk				));//input				
/**********************************************************************************************************************/
endmodule


