module	bram_ping_pang_etoh	#(
	ADDRW	=	12	,	
	DATAW 	=	256
)(	input								wport_rank	,
	input  				 				wport_csen	,
	input		[ADDRW-1:0]				wport_addr	,
	input		[DATAW-1:0]				wport_data	,
	input								wport_clki	,

	input								rport_rank	,
	input		[ADDRW-1:0]		 		rport_addr	,
	output	reg	[DATAW-1:0]		 		rport_data	,
	input								rport_clki	);
/**********************************************************************************************************************/
	parameter							DEPTH		=	1 << ADDRW;

	(*ram_style="block"*) 				reg [DATA_W-1: 0] 	memo[0:DEPTH-1]	;

	wire		[ADDRW:0]				page_wadd	= {	wport_rank,	wport_addr	};
	
	always@(posedge wport_clki)
	if(wport_csen)						memo[page_wadd]	<=	wport_data	;
/**********************************************************************************************************************/
	wire		[ADDRW:0]				page_radd	;
	assign								page_radd 	= {	rport_rank,	rport_addr	};

	always@(posedge rport_clki)			rport_data		<=	memo[page_radd]	;
/**********************************************************************************************************************/

endmodule