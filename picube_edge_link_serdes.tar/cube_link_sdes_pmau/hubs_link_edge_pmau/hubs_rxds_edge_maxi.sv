module	hubs_rxds_edge_maxi(
	input								edge_dlnk_maxi_sift	,
	output	reg	[31: 0]					edge_dlnk_maxi_rows	,
	output	reg	[15: 0]					edge_dlnk_maxi_cols	,
	output	reg	[15: 0]					edge_dlnk_maxi_data	,

	input								edge_dlnk_acks_coda	,
	input								edge_dlnk_data_coda	,
	input		[31: 0]					edge_dlnk_maxi_dsrc	,
	input								edge_dlnk_maxi_seek	,
	
	input								edge_bclk			,
	input								edge_rstn			);
/**********************************************************************************************************************/
	reg			[31: 0]					edge_dlnk_seek_rows	;
	reg			[15: 0]					edge_dlnk_seek_cols	;

	always@(posedge edge_bclk or negedge edge_rstn)
	if(~edge_rstn)						edge_dlnk_seek_rows	<=	0	;
	else if(~edge_dlnk_maxi_sift)		edge_dlnk_seek_rows	<=	0	;
	else if( edge_dlnk_acks_coda)		edge_dlnk_seek_rows	<=	0	;
	else if( edge_dlnk_data_coda)		edge_dlnk_seek_rows	<=	1 +	edge_dlnk_seek_rows	;

	always@(posedge edge_bclk or negedge edge_rstn)
	if(~edge_rstn)						edge_dlnk_seek_cols	<=	0	;
	else if(~edge_dlnk_maxi_sift)		edge_dlnk_seek_cols	<=	0	;
	else if( edge_dlnk_data_lead)		edge_dlnk_seek_cols	<=	0	;
	else if( edge_dlnk_maxi_seek)		edge_dlnk_seek_cols	<=	2 +	edge_dlnk_seek_cols	;
/**********************************************************************************************************************/
	wire		[15: 0]					maxi_seek_selx_vals	;
	wire								maxi_seek_selx_src0	;
	wire								maxi_seek_selx_src1	;
	wire								maxi_seek_selx_dsrc	;
	assign		maxi_seek_selx_dsrc	= |{maxi_seek_selx_src0	,	maxi_seek_selx_src1	};	
/**********************************************************************************************************************/
	maxi_spot_comp_cell				u_maxi_spot_comp_cell(
		.comp_base_data					(edge_dlnk_maxi_data		),//input		[15: 0]	
		.comp_src0_data					(edge_dlnk_maxi_dsrc[31:16]	),//input		[15: 0]	
		.comp_src1_data					(edge_dlnk_maxi_dsrc[15: 0]	),//input		[15: 0]	

		.comp_maxi_sel0					(maxi_seek_selx_src0		),//output	
		.comp_maxi_sel1					(maxi_seek_selx_src1		),
		.comp_maxi_vals					(maxi_seek_selx_vals		));//output	
/**********************************************************************************************************************/
	always@(posedge edge_bclk or negedge edge_rstn)
	if(~edge_rstn)						edge_dlnk_maxi_rows	<=	0	;
	else if(~edge_dlnk_maxi_sift)		edge_dlnk_maxi_rows	<=	0	;
	else if( edge_dlnk_maxi_seek)		edge_dlnk_maxi_rows	<=	maxi_seek_selx_dsrc	?	edge_dlnk_seek_rows	:	
																						edge_dlnk_maxi_rows	;

	always@(posedge edge_bclk or negedge edge_rstn)
	if(~edge_rstn)						edge_dlnk_maxi_cols	<=	0	;
	else if(~edge_dlnk_maxi_sift)		edge_dlnk_maxi_cols	<=	0	;
	else if( edge_dlnk_maxi_seek)		edge_dlnk_maxi_cols	<=	maxi_seek_selx_src0	?	edge_dlnk_seek_cols		:
																maxi_seek_selx_src1	?	edge_dlnk_seek_cols + 1	:
																						edge_dlnk_maxi_cols		;

	always@(posedge edge_bclk or negedge edge_rstn)
	if(~edge_rstn)						edge_dlnk_maxi_data	<=	0	;
	else if(~edge_dlnk_maxi_sift)		edge_dlnk_maxi_data	<=	0	;
	else if( edge_dlnk_maxi_seek)		edge_dlnk_maxi_data	<=	maxi_seek_selx_src0	?	edge_dlnk_maxi_dsrc[15: 0]	:	
																maxi_seek_selx_src1	?	edge_dlnk_maxi_dsrc[31:16]	:
																						edge_dlnk_maxi_data			;




endmodule

module	maxi_spot_comp_cell(
	input		[15: 0]					comp_base_data	,
	input		[15: 0]					comp_src0_data	,
	input		[15: 0]					comp_src1_data	,

	output								comp_maxi_sel0	,
	output								comp_maxi_sel1	);

	wire		[15:0]					comp_src0_norm	;
	wire		[15:0]					comp_src1_norm	;
	wire		[15:0]					comp_base_norm	;

	wire								base_gtcs_src0	;
	wire								base_gtcs_src1	;
	wire								src0_gtcs_src1	;

	assign		spot_src0_norm	=	{ ~	comp_src0_data[15]	,	comp_src0_data[14:0]	};
	assign		spot_src1_norm	=	{ ~	comp_src1_data[15]	,	comp_src1_data[14:0]	};
	assign		spot_base_norm	=	{ ~	comp_base_data[15]	,	comp_base_data[14:0]	};

	wire		base_ltcs_src0	=		spot_base_norm	>=	spot_src0_norm	;
	wire		base_ltcs_src1	=		spot_base_norm	>=	spot_src1_norm	;
	wire		src0_ltcs_src1	=		spot_src0_norm	>=	spot_src1_norm	;	

	wire		comp_maxi_base	=&{		base_ltcs_src0	,	base_ltcs_src1 	};
	
	assign		comp_maxi_sel0	=|{	&{~	base_ltcs_src0	,	base_ltcs_src1	},
									&{~	comp_maxi_base	,	src0_ltcs_src1	}};

	assign		comp_maxi_sel1	=|{	&{  base_ltcs_src0	, ~	base_ltcs_src1	},
									&{~	comp_maxi_base	, ~ src0_ltcs_src1	}};

endmodule	


