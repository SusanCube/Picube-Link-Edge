module	scut_htor_txds_edge(	
	input								fifo_enab	,

	input		[31: 0]					push_data	,
	input								push_drdy	,
	input								push_clki	,
	input								push_rstn	,

	output								pops_drdy	,
	output		[64: 0]			 		pops_data	,
	input								pops_trdy	,
	input								pops_clki	,
	input								pops_rstn	);
/**********************************************************************************************************************/
	wire								push_enab	;
	wire								pops_enab	;

	gens_sync_sign	sync_push_enab(		.ASDI(fifo_enab), .SSDO(push_enab), .SOCK(push_clki), .SORN(push_rstn));
	gens_sync_sign	sync_push_enab(		.ASDI(fifo_enab), .SSDO(pops_enab), .SOCK(pops_clki), .SORN(pops_rstn));
/**********************************************************************************************************************/
	reg			[23: 0]					push_addr	;
	reg			[63: 0]					push_pack	;
	reg									push_wrcs	;

	wire		[22: 0]					push_msba	;
	wire								push_lsba	;
	wire		[ 7: 0]					push_dptr	;

	assign		push_msba	=			push_addr[23:1]	;
	assign		push_lsba	=			push_addr[   0]	;
	assign		push_dptr	=			push_addr[ 8:1]	;

	always@(posedge push_clki or negedge push_rstn)
	if(~push_rstn)						push_addr	<=	0	;
	else if(~push_enab)					push_addr	<=	0	;
	else if( push_drdy)					push_addr	<=	push_addr + 1	;	

	always@(posedge push_clki or negedge push_rstn)
	if(~push_rstn)						push_pack	<=	0	;
	else if(~push_enab)					push_pack	<=	0	;
	else if( push_drdy)					push_pack	<= {push_data	,	push_pack[63:32]};	

	always@(posedge push_clki or negedge push_rstn)
	if(~push_rstn)						push_wrcs	<=	0	;
	else if(~push_enab)					push_wrcs	<=	0	;
	else 								push_wrcs	<=&{push_drdy	,	push_addr[0]	};	
//------------------------------------------------------------------------------
	(*ram_style="block"*) reg 	[63: 0] push_memo[0:255]	;

	always@(posedge push_clki)			
	if(push_wrcs)						push_memo[push_dptr]	<=	push_pack	;
/**********************************************************************************************************************/
	wire		[22: 0]					push_gray	;

	gens_gray_code	#(.MSB(22))		sync_gray_wptr(		
		.SDI							(push_msba	), 
		.SCK							(push_clki	), 
		.GDO							(push_gray	), 
		.GCK							(pops_clki	), 
		.GRN							(pops_rstn	));
/**********************************************************************************************************************/
	reg			[22: 0]					pops_addr	;
	wire		[22: 0]					pops_nxta	;
	wire		[ 7: 0]					pops_dptr	;	

	assign		pops_nxta	=			pops_addr + 1	;
	assign		pops_dptr	=			pops_addr[ 7: 0];
//------------------------------------------------------------------------------
	always@(posedge pops_clki or negedge pops_rstn)
	if(~pops_rstn)						pops_addr	<=	0	;
	else if(~pops_enab)					pops_addr	<=	0	;
	else if( pops_trdy)					pops_addr	<= 	pops_nxta	;	
/**********************************************************************************************************************/
	assign		pops_drdy	=			wptr_gray	>=	pops_nxta	;	

	always@(posedge pops_clki)			pops_data	<=	push_memo[pops_dptr]	;
/**********************************************************************************************************************/

endmodule