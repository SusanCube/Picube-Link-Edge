/******************************************************************************/
//max_rows_burst_leng :: 64K halfword~16K ddrs's data_pack when gather 1/4 Vocaburury

module	hubs_txds_edge_data(
	output	reg							mgte_htoe_axis_csen	,//CD:MGTE
	output		[31: 0]					mgte_htoe_axis_data	,//CD:MGTE
	output								mgte_htoe_axis_drdy	,//CD:MGTE
	output								mgte_htoe_axis_last	,//CD:MGTE
	input								mgte_htoe_axis_trdy	,//CD:MGTE
	
	input								mgth_htoe_clnk_reqs	,//CD:MGTH	
	output	reg							mgth_htoe_clnk_done	,//CD:MGTH	
	input		[ 3: 0]					mgth_htoe_clnk_size	,//CD:MGTH	COSL_DIMENSION BASE ON WORD
	output	reg	[ 3: 0]					mgte_htoe_clnk_addr	,//CD:MGTH	
	input		[31: 0]					mgte_htoe_clnk_data	,//CD:MGTH

	input								mgth_htoe_slnk_reqs	,//CD:MGTH
	output								mgth_htoe_slnk_done	,//CD:MGTH
	input		[12: 0]					mgth_htoe_slnk_size	,//CD:MGTH	COSL_DIMENSION BASE ON 2*DOTS
	input								mgth_htoe_slnk_drdy	,//CD:MGTH
	input		[63: 0]					mgth_htoe_slnk_data	,//CD:MGTH
	
	input								mgth_htoe_dlnk_reqs	,//CD:MGTH 
	output								mgth_htoe_dlnk_done	,//CD:MGTH
	input		[12: 0]					mgth_htoe_dlnk_size	,//CD:MGTH	COSL_DIMENSION BASE ON 2*DOTS
	
	output								ddrs_htoe_rdma_trdy	,//CD:DDRS	
	input		[127:0]					ddrs_htoe_rdma_dout	,//CD:DDRS	
	input								ddrs_htoe_rdma_drdy	,//CD:DDRS	
	
	input								mgte_bclk			,
	input								mgte_rstn			,
	input								mgth_bclk			,
	input								mgth_rstn			,
	input								ddrs_bclk			,
	input								ddrs_rstn			);
/**********************************************************************************************************************/
	reg									mgte_htoe_clnk_csen	;
	reg									mgte_htoe_slnk_csen	;
	reg									mgte_htoe_dlnk_csen	;
	wire								mgte_htoe_axis_csen	;

	wire								mgte_htoe_clnk_trdy	;
	wire								mgte_htoe_slnk_trdy	;
	wire								mgte_htoe_dlnk_trdy	;

	wire								mgte_htoe_clnk_drdy	=	1'B1	;
	wire								mgte_htoe_slnk_drdy	;
	wire								mgte_htoe_dlnk_drdy	;

	wire		[31: 0]					mgte_htoe_slnk_data	;
	wire		[31: 0]					mgte_htoe_dlnk_data	;
//------------------------------------------------------------------------------
	wire		mgte_htoe_axis_txok	= &{mgte_htoe_axis_csen	,	mgte_htoe_axis_drdy	,	mgte_htoe_axis_trdy	};
	assign		mgte_htoe_axis_csen	= |{mgte_htoe_clnk_csen	,	mgte_htoe_dlnk_csen	,	mgte_htoe_slnk_csen	};
	assign		mgte_htoe_clnk_trdy	= &{mgte_htoe_clnk_csen	,	mgte_htoe_axis_txok};
	assign		mgte_htoe_slnk_trdy	= &{mgte_htoe_slnk_csen	,	mgte_htoe_axis_txok};
	assign		mgte_htoe_dlnk_trdy	= &{mgte_htoe_dlnk_csen	,	mgte_htoe_axis_txok};
//------------------------------------------------------------------------------
	assign		mgte_htoe_axis_drdy	= 	mgte_htoe_clnk_csen	?	mgte_htoe_clnk_drdy	:
										mgte_htoe_dlnk_csen	?	mgte_htoe_dlnk_drdy	:
										mgte_htoe_slnk_csen	?	mgte_htoe_slnk_drdy	:	 1'B0	;
	
	assign		mgte_htoe_axis_data	=	mgte_htoe_clnk_csen	?	mgte_htoe_clnk_data	:
										mgte_htoe_dlnk_csen	?	mgte_htoe_dlnk_data	:	
										mgte_htoe_slnk_csen	?	mgte_htoe_slnk_data	:	31'H0	;

	assign		mgte_htoe_axis_last	=	mgte_htoe_clnk_csen	?	mgth_htoe_clnk_done	:
										mgte_htoe_dlnk_csen	?	mgth_htoe_dlnk_done	:	
										mgte_htoe_slnk_csen	?	hubs_htoe_slnk_done	:	 1'H0	;
/**********************************************************************************************************************/
//HUBS_TXDS_EDGE_CMND
/**********************************************************************************************************************/
	reg			[ 3: 0]					mgte_htoe_clnk_addr	;
	wire		[ 3: 0]					mgte_htoe_clnk_nxta	;
	wire								mgte_htoe_clnk_done	;
	wire								mgte_htoe_clnk_reqs	;

	assign		mgte_htoe_clnk_nxta	=	mgte_htoe_clnk_addr + 1	;
	assign		mgte_htoe_clnk_done	= &{mgte_htoe_clnk_trdy	,	mgte_htoe_clnk_nxta	==	mgth_htoe_clnk_size	};		

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_htoe_clnk_csen	<=	0	;
	else if(mgte_htoe_clnk_reqs)		mgte_htoe_clnk_csen	<=	1	;
	else if(mgte_htoe_clnk_done)		mgte_htoe_clnk_csen	<=	0	;

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_htoe_clnk_addr	<=	0	;
	else if(~mgte_htoe_clnk_csen)		mgte_htoe_clnk_addr	<=	0	;
	else if( mgte_htoe_clnk_trdy)		mgte_htoe_clnk_addr	<=	mgte_htoe_clnk_nxta	;
//------------------------------------------------------------------------------
	gens_sync_edge #( 
		.EXTN_MULT						( 0						),	
		.EDGE_TYPE						("RISE"					))	
	u_gens_sync_clnk_issu(	
		.dtar_edge						(mgte_htoe_clnk_reqs	),//output
		.dtar_clki						(mgte_bclk				),//input	
		.dtar_rstn						(mgte_rstn				),//input	

		.dsrc_mark						(mgth_htoe_clnk_reqs	),
		.dsrc_clki						(mgth_bclk				),
		.dsrc_rstn						(mgth_rstn				));
//------------------------------------------------------------------------------
	gens_sync_edge #(	
		.EXTN_MULT						( 0			),
		.EDGE_TYPE						( "RISE"	))
	u_gens_sync_clnk_done(	
		.dtar_edge						(mgth_htoe_clnk_done	),//output
		.dtar_clki						(mgth_bclk				),//input	
		.dtar_rstn						(mgth_rstn				),//input	

		.dsrc_mark						(mgte_htoe_clnk_done	),
		.dsrc_clki						(mgte_bclk				),
		.dsrc_rstn						(mgte_rstn				));
/**********************************************************************************************************************/
//HUBS_SCUT_EDGE_DATA
/**********************************************************************************************************************/
//u_slnk_sync_gray_size------------------------------------------------------------------------------
	fifo_htoe_txds_slnk				u_fifo_htoe_txds_slnk(	
		.push_init						(mgth_htoe_slnk_reqs	),//input				
		.push_done						(mgth_htoe_slnk_done	),//output				
		.push_size						(mgth_htoe_slnk_size	),//input		[12: 0]	
		.push_data						(mgth_htoe_slnk_data	),//input		[63: 0]	
		.push_drdy						(mgth_htoe_slnk_drdy	),//input				
		.push_clki						(mgth_bclk				),//input				
		.push_rstn						(mgth_rstn				),//input				

		.pops_enab						(mgte_htoe_slnk_csen	),//output	reg			
		.pops_data						(mgte_htoe_slnk_data	),//output		[31: 0]	
		.pops_drdy						(mgte_htoe_slnk_drdy	),//output				
		.pops_trdy						(mgte_htoe_slnk_trdy	),//input				
		.pops_clki						(mgte_bclk				),//input				
		.pops_rstn						(mgte_rstn				));//input				
/**********************************************************************************************************************/
//HUBS_TDMA_EDGE_DATA
/**********************************************************************************************************************/
	wire								mgte_htoe_dlnk_reqs	;
	wire								mgte_htoe_dlnk_done	;

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_htoe_dlnk_csen	<=	0	;
	else if(mgte_htoe_dlnk_reqs)		mgte_htoe_dlnk_csen	<=	1	;
	else if(mgte_htoe_dlnk_done)		mgte_htoe_dlnk_csen	<=	0	;
//u_dlnk_sync_tlnk_reqs------------------------------------------------------------------------------
	gens_sync_edge #(.EXTN(1))		u_gens_tlnk_reqs_edge(	
		.dtar_rise						(mgte_htoe_dlnk_reqs	),//output
		.dtar_fall						(						),//output
		.dtar_clki						(mgte_bclk				),//input	
		.dtar_rstn						(mgte_rstn				),//input	

		.dsrc_mark						(mgth_htoe_dlnk_reqs	),//input
		.dsrc_clki						(mgth_bclk				),//input
		.dsrc_rstn						(mgth_rstn				));//input
//u_tlnk_sync_dlnk_done------------------------------------------------------------------------------
	gens_sync_edge #(.EXTN(1))		u_gens_tlnk_reqs_edge(	
		.dtar_rise						(mgth_htoe_dlnk_done	),//output
		.dtar_fall						(						),//output
		.dtar_clki						(mgth_bclk				),//input	
		.dtar_rstn						(mgth_rstn				),//input	

		.dsrc_mark						(mgte_htoe_dlnk_done	),//input
		.dsrc_clki						(mgte_bclk				),//input
		.dsrc_rstn						(mgte_rstn				));//input
//------------------------------------------------------------------------------
	wire		[12: 0]					hubs_htoe_tlnk_size		;

	gens_gray_code	#(.MSB(12))		u_sync_gray_pops_size(		
		.dsrc_data						(mgth_htoe_dlnk_size	), 
		.dsrc_clki						(mgth_bclk				), 

		.dtar_data						(hubs_htoe_tlnk_size	), 
		.dtar_clki						(mgte_bclk				), 
		.dtar_rstn						(mgte_rstn				));

//u_htoe_txdo_fifo_data------------------------------------------------------------------------------
	fifo_host_txds_dlnk				u_fifo_htoe_txdo_dlnk#(
		.PAGE_WIDTH						(128					),
		.PACK_WIDTH						( 32					),
		.PACK_ADMSB						( 12					),
	)(	
		.push_data						(ddrs_htoe_rdma_data	), //input		[PAGE_WIDTH: 0]	
		.push_drdy						(ddrs_htoe_rdma_drdy	), //input						
		.push_trdy						(ddrs_htoe_rdma_trdy	), //output						
		.push_clki						(ddrs_bclk				), //input						
		.push_rstn						(ddrs_rstn				), //input						

		.pops_enab						(mgte_htoe_dlnk_csen	), //input						
		.pops_done						(mgte_htoe_dlnk_done	), //output						
		.pops_size						(hubs_htoe_tlnk_size  	), //input		[PACK_ADMSB: 0]	
		.pops_drdy						(mgte_htoe_dlnk_drdy	), //input						
		.pops_data						(mgte_htoe_dlnk_data	), //output	reg	[PACK_WIDTH: 0]	
		.pops_trdy						(mgte_htoe_dlnk_trdy	), //output						
		.pops_clki						(mgte_bclk				), //input						
		.pops_rstn						(mgte_rstn				));//input						
/**********************************************************************************************************************/




endmodule


