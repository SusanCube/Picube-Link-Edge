module	fifo_htoe_txds_dlnk(	
	input								push_init	,
	input		[127:0]					push_data	,
	input								push_drdy	,
	input								push_clki	,
	input								push_rstn	,

	input								pops_enab	,
	input		[12: 0]					pops_size	,
	input								pops_trdy	,
	output		[31: 0]			 		pops_data	,
	output								pops_drdy	,
	output								pops_last	,
	input								pops_clki	,
	input								pops_rstn	);
/**********************************************************************************************************************/
	reg			[10: 0]					push_wptr	;
	wire		[10: 0]					push_nxta	;
	wire								push_done	;
	wire		[ 9: 0]					memo_wadd	;

	assign		push_nxta	=			push_wptr + 1	;
	assign		memo_wadd	=			push_wptr[9:0]	;

	always@(posedge push_clki or negedge push_rstn)
	if(~push_rstn)						push_wptr	<=	0	;
	else if( push_init)					push_wptr	<=	0	;
	else if( push_done)					push_wptr	<=	0	;
	else if( push_drdy)					push_wptr	<=	push_nxta	;	
//------------------------------------------------------------------------------
	(*ram_style="block"*) 
	reg 		[127:0] 				push_memo[0:1023]	;//8*1=08k

	always@(posedge push_clki)			
	if(push_drdy)						push_memo[memo_wadd]	<=	push_data	;
/**********************************************************************************************************************/
	wire		[10: 0]					gray_wptr	;
//------------------------------------------------------------------------------
	gens_gray_code	#(.MSB(10))		u_sync_gray_wptr(		
		.dsrc_data						(push_wptr	), 
		.dsrc_clki						(push_clki	), 

		.dtar_data						(gray_wptr	), 
		.dtar_clki						(pops_clki	), 
		.dtar_rstn						(pops_rstn	));
//------------------------------------------------------------------------------
	gens_sync_edge #(	
		.EXTN_MULT						( 0			),
		.EDGE_TYPE						( "RISE"	))
	u_gens_sync_push_done(	
		.dtar_edge						(push_done	),//output
		.dtar_clki						(push_bclk	),//input	
		.dtar_rstn						(push_rstn	),//input	
		
		.dsrc_mark						(pops_last	),//input
		.dsrc_clki						(pops_bclk	),//input
		.dsrc_rstn						(pops_rstn	));//input
/**********************************************************************************************************************/
/**********************************************************************************************************************/
	reg			[127:0]					pops_page	;
	reg			[ 12:0]					pops_addr	;

	wire		[  1:0]					pops_lsba	;
	wire		[ 12:0]					pops_nxta	;

	wire		[ 9: 0]					pops_rptr	;
	wire								pops_beok	;

	wire		[31: 0]					pops_wrd0	;
	wire		[31: 0]					pops_wrd1	;
	wire		[31: 0]					pops_wrd2	;
	wire		[31: 0]					pops_wrd3	;

	assign		pops_nxta	=			pops_addr + 1	;
	assign		pops_lsba	=			pops_addr[1:0]	;

	assign		pops_wrd0	=			memo[pops_rptr][ 31: 0]	;
	assign		pops_wrd1	=			memo[pops_rptr][ 63:32]	;
	assign		pops_wrd2	=			memo[pops_rptr][ 95:64]	;
	assign		pops_wrd3	=			memo[pops_rptr][127:96]	;

	assign		pops_rptr	=			pops_trdy	?	pops_nxta[11:2]	:	pops_addr[11:2]	;
//------------------------------------------------------------------------------
	always@(posedge pops_clki or negedge pops_rstn)
	if(~pops_rstn)						pops_addr	<=	0	;
	else if(~pops_enab)					pops_addr	<=	0	;
	else if( pops_trdy)					pops_addr	<= 	pops_nxta	;	
//------------------------------------------------------------------------------
	always@(posedge pops_clki)			pops_data	<=	pops_lsba == 2'h0	?	pops_wrd0	:	
														pops_lsba == 2'h1	?	pops_wrd1	:	
														pops_lsba == 2'h2	?	pops_wrd2	:	
														pops_lsba == 2'h3	?	pops_wrd3	:	32'H0	;
//------------------------------------------------------------------------------
	assign		pops_beok	=	&{		pops_drdy	,	pops_trdy	};	
	assign		pops_drdy	=	&{		pops_enab	,	gray_wptr	>=	pops_nxta[12:2]	};	
	assign		pops_last	= 	&{		pops_beok	,	pops_nxta	==	pops_size		;
/**********************************************************************************************************************/

endmodule