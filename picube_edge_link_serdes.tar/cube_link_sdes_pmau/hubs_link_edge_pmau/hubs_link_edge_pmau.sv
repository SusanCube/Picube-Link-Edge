module	hubs_link_edge_ufcm(
	input		[31: 0]					mgte_rxln_axis_data	,
	input								mgte_rxln_axis_drdy	,
	input		[31: 0]					mgte_rxln_ufcm_data	,
	input								mgte_rxln_ufcm_drdy	,
	input								mgte_rxln_ufcm_last	,

	output		[31: 0]					mgte_txln_axis_data	,
	output								mgte_txln_axis_drdy	,
	output								mgte_txln_axis_last	,
	input								mgte_txln_axis_trdy	,
	output		[ 2: 0]					mgte_txln_ufcm_size	,
	output								mgte_txln_ufcm_drdy	,
	input								mgte_txln_ufcm_trdy	,
	
	output	reg							mgte_etoh_acks_lead	,
	output	reg							mgte_etoh_acks_coda	,
	output	reg							mgte_etoh_data_lead	,
	output	reg							mgte_etoh_data_coda	,
	output	reg							mgte_etoh_resp_tokn	,

	output		[31: 0]					mgte_etoh_acks_data	,
	output								mgte_etoh_acks_wrcs	,
	output		[31: 0]					mgte_etoh_maxi_rows	,
	output		[15: 0]					mgte_etoh_maxi_cols	,
	output		[15: 0]					mgte_etoh_maxi_data	,

	input								mgte_bclk			,
	input								mgte_rstn			,
	
	input								mgth_etoh_maxi_csen	,
	input								mgth_etoh_slnk_enab	,
	output		[63: 0]					mgth_etoh_slnk_data	,
	output								mgth_etoh_slnk_drdy	,
	input								mgth_etoh_slnk_trdy	,

	output								mgth_htoe_ufcm_idle	,	
	output								mgth_htoe_ufcm_done	,	
	input								mgth_htoe_ufcm_reqs	,
	input								mgth_cmnd_lead_issu	,
	input								mgth_cmnd_coda_issu	,
	input								mgth_data_lead_issu	,
	input								mgth_data_coda_issu	,

	input								mgth_htoe_clnk_reqs	,
	output	reg							mgth_htoe_clnk_done	,
	input		[ 3: 0]					mgth_htoe_clnk_size	,
	output	reg	[ 3: 0]					mgth_htoe_clnk_addr	,
	input		[31: 0]					mgth_htoe_clnk_data	,

	input								mgth_htoe_slnk_reqs	,
	output								mgth_htoe_slnk_done	,
	input		[12: 0]					mgth_htoe_slnk_size	,
	input								mgth_htoe_slnk_drdy	,
	input		[63: 0]					mgth_htoe_slnk_data	,
	
	input								mgth_htoe_dlnk_reqs	,
	output								mgth_htoe_dlnk_done	,
	input		[12: 0]					mgth_htoe_dlnk_size	,

	input								mgth_bclk			,
	input								mgth_rstn			,

	input								ddrs_etoh_wdma_bank	,
	input		[ 9: 0]					ddrs_etoh_wdma_addr	,
	output		[127:0]					ddrs_etoh_wdma_data	,
	output								ddrs_htoe_rdma_trdy	,
	input		[127:0]					ddrs_htoe_rdma_data	,
	input								ddrs_htoe_rdma_drdy	,
	input								ddrs_bclk			,
	input								ddrs_rstn			);
/**********************************************************************************************************************/
	hubs_rxds_edge_pmau				u_hubs_rxds_edge_pmau(
		.mgte_etoh_axis_data			(mgte_rxln_axis_data	),//input		[31: 0]	
		.mgte_etoh_axis_drdy			(mgte_rxln_axis_drdy	),//input				
		.mgte_etoh_ufcm_data			(mgte_rxln_ufcm_data	),//input		[31: 0]	
		.mgte_etoh_ufcm_drdy			(mgte_rxln_ufcm_drdy	),//input				
		.mgte_etoh_ufcm_last			(mgte_rxln_ufcm_last	),//input				

		.mgte_etoh_acks_lead			(mgte_etoh_acks_lead	),//output	
		.mgte_etoh_acks_coda			(mgte_etoh_acks_coda	),//output	
		.mgte_etoh_data_lead			(mgte_etoh_data_lead	),//output	
		.mgte_etoh_data_coda			(mgte_etoh_data_coda	),//output	
		.mgte_etoh_resp_tokn			(mgte_etoh_resp_tokn	),//output	

		.mgte_etoh_acks_data			(mgte_etoh_acks_data	),//output		[31: 0]	
		.mgte_etoh_acks_wrcs			(mgte_etoh_acks_wrcs	),//output				
		.mgte_etoh_maxi_rows			(mgte_etoh_maxi_rows	),//output		[31: 0]	
		.mgte_etoh_maxi_cols			(mgte_etoh_maxi_cols	),//output		[15: 0]	
		.mgte_etoh_maxi_data			(mgte_etoh_maxi_data	),//output		[15: 0]	

		.mgte_bclk						(mgte_bclk				),//input	
		.mgte_rstn						(mgte_rstn				),//input	

		.mgth_etoh_maxi_csen			(mgth_etoh_maxi_csen	),//input				
		.mgth_etoh_slnk_enab			(mgth_etoh_slnk_enab	),//input				
		.mgth_etoh_slnk_data			(mgth_etoh_slnk_data	),//output		[63: 0]	
		.mgth_etoh_slnk_drdy			(mgth_etoh_slnk_drdy	),//output				
		.mgth_etoh_slnk_trdy			(mgth_etoh_slnk_trdy	),//input				
		.mgth_bclk						(mgth_bclk				),//input				
		.mgth_rstn						(mgth_rstn				),//input				

		.ddrs_etoh_wdma_bank			(ddrs_etoh_wdma_bank	),//input	
		.ddrs_etoh_wdma_addr			(ddrs_etoh_wdma_addr	),//input	
		.ddrs_etoh_wdma_data			(ddrs_etoh_wdma_data	),//output	
		.ddrs_bclk						(ddrs_bclk				));//input	
/**********************************************************************************************************************/	
	hubs_txds_edge_pmau				u_hubs_txds_edge_pmau(
		.mgte_txln_axis_data			(mgte_txln_axis_data	),//output		[31: 0]	
		.mgte_txln_axis_drdy			(mgte_txln_axis_drdy	),//output				
		.mgte_txln_axis_last			(mgte_txln_axis_last	),//output				
		.mgte_txln_axis_trdy			(mgte_txln_axis_trdy	),//input				
		.mgte_txln_ufcm_size			(mgte_txln_ufcm_size	),//output		[ 2: 0]	
		.mgte_txln_ufcm_drdy			(mgte_txln_ufcm_drdy	),//output				
		.mgte_txln_ufcm_trdy			(mgte_txln_ufcm_trdy	),//input				
		.mgte_bclk						(mgte_bclk				),//input				
		.mgte_rstn						(mgte_rstn				),//input				

		.mgth_htoe_ufcm_idle			(mgth_htoe_ufcm_idle	),//output	
		.mgth_htoe_ufcm_done			(mgth_htoe_ufcm_done	),//output	
		.mgth_htoe_ufcm_reqs			(mgth_htoe_ufcm_reqs	),//input	
		.mgth_cmnd_lead_issu			(mgth_cmnd_lead_issu	),//input	
		.mgth_cmnd_coda_issu			(mgth_cmnd_coda_issu	),//input	
		.mgth_data_lead_issu			(mgth_data_lead_issu	),//input	
		.mgth_data_coda_issu			(mgth_data_coda_issu	),//input	

		.mgth_htoe_clnk_reqs			(mgth_htoe_clnk_reqs	),//input				
		.mgth_htoe_clnk_done			(mgth_htoe_clnk_done	),//output	reg			
		.mgth_htoe_clnk_size			(mgth_htoe_clnk_size	),//input		[ 3: 0]	
		.mgth_htoe_clnk_addr			(mgth_htoe_clnk_addr	),//output	reg	[ 3: 0]	
		.mgth_htoe_clnk_data			(mgth_htoe_clnk_data	),//input		[31: 0]	

		.mgth_htoe_slnk_reqs			(mgth_htoe_slnk_reqs	),//input				
		.mgth_htoe_slnk_done			(mgth_htoe_slnk_done	),//output				
		.mgth_htoe_slnk_size			(mgth_htoe_slnk_size	),//input		[12: 0]	
		.mgth_htoe_slnk_drdy			(mgth_htoe_slnk_drdy	),//input				
		.mgth_htoe_slnk_data			(mgth_htoe_slnk_data	),//input		[63: 0]	
		
		.mgth_htoe_dlnk_reqs			(mgth_htoe_dlnk_reqs	),//input				
		.mgth_htoe_dlnk_done			(mgth_htoe_dlnk_done	),//output				
		.mgth_htoe_dlnk_size			(mgth_htoe_dlnk_size	),//input		[12: 0]	
		.mgth_bclk						(mgth_bclk				),//input			
		.mgth_rstn						(mgth_rstn				),//input			

		.ddrs_htoe_rdma_trdy			(ddrs_htoe_rdma_trdy	),//output				
		.ddrs_htoe_rdma_data			(ddrs_htoe_rdma_data	),//input		[127:0]	
		.ddrs_htoe_rdma_drdy			(ddrs_htoe_rdma_drdy	),//input				
		.ddrs_bclk						(ddrs_bclk				),//input				
		.ddrs_rstn						(ddrs_rstn				));//input				
/**********************************************************************************************************************/	
endmodule


