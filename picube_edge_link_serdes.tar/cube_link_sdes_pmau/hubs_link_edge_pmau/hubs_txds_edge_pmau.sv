/******************************************************************************/
//max_rows_burst_leng :: 64K halfword~16K ddrs's data_pack when gather 1/4 Vocaburury
//	output		[ 2: 0]					mgte_txln_ufcm_size	,
module	hubs_txds_edge_pmau(
	output		[31: 0]					mgte_txln_axis_data	,
	output								mgte_txln_axis_drdy	,
	output								mgte_txln_axis_last	,
	input								mgte_txln_axis_trdy	,
	output								mgte_txln_ufcm_drdy	,
	input								mgte_txln_ufcm_trdy	,
	input								mgte_bclk			,
	input								mgte_rstn			,

	output								mgth_htoe_ufcm_idle	,
	output								mgth_htoe_ufcm_done	,
	input								mgth_htoe_ufcm_reqs	,
	input								mgth_htoe_cmnd_lead	,
	input								mgth_htoe_cmnd_coda	,
	input								mgth_htoe_data_lead	,
	input								mgth_htoe_data_coda	,

	input								mgth_htoe_clnk_reqs	,//CD:MGTH	
	output	reg							mgth_htoe_clnk_done	,//CD:MGTH	
	input		[ 3: 0]					mgth_htoe_clnk_size	,//CD:MGTH	COSL_DIMENSION BASE ON WORD
	output	reg	[ 3: 0]					mgth_htoe_clnk_addr	,//CD:MGTH	
	input		[31: 0]					mgth_htoe_clnk_data	,//CD:MGTH

	input								mgth_htoe_slnk_reqs	,//CD:MGTH
	output								mgth_htoe_slnk_done	,//CD:MGTH
	input		[12: 0]					mgth_htoe_slnk_size	,//CD:MGTH	COSL_DIMENSION BASE ON 2*DOTS
	input								mgth_htoe_slnk_drdy	,//CD:MGTH
	input		[63: 0]					mgth_htoe_slnk_data	,//CD:MGTH
	
	input								mgth_htoe_dlnk_reqs	,//CD:MGTH 
	output								mgth_htoe_dlnk_done	,//CD:MGTH
	input		[12: 0]					mgth_htoe_dlnk_size	,//CD:MGTH	COSL_DIMENSION BASE ON 2*DOTS
	input								mgth_bclk			,
	input								mgth_rstn			,

	output								ddrs_htoe_rdma_trdy	,//CD:DDRS	
	input		[127:0]					ddrs_htoe_rdma_data	,//CD:DDRS	
	input								ddrs_htoe_rdma_drdy	,//CD:DDRS	
	input								ddrs_bclk			,
	input								ddrs_rstn			);
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
	wire								mgte_htoe_ufcm_csen	;//CD:MGTE
	wire		[31: 0]					mgte_htoe_ufcm_data	;//CD:MGTE
	wire								mgte_htoe_ufcm_drdy	;//CD:MGTE

	wire								mgte_htoe_axis_csen	;//CD:MGTE
	wire		[31: 0]					mgte_htoe_axis_data	;//CD:MGTE
	wire								mgte_htoe_axis_drdy	;//CD:MGTE
	wire								mgte_htoe_axis_last	;//CD:MGTE
	wire								mgte_htoe_axis_trdy	;//CD:MGTE

	assign		mgte_txln_axis_data	=	mgte_htoe_ufcm_csen	?	mgte_htoe_ufcm_data	:
										mgte_htoe_axis_csen	?	mgte_htoe_axis_data	:	32'H0	;
	assign		mgte_txln_axis_drdy	=	mgte_htoe_axis_csen	?	mgte_htoe_axis_drdy	:	 1'H0	;
	assign		mgte_txln_axis_last	=	mgte_htoe_axis_csen	?	mgte_htoe_axis_last	:	 1'H0	;
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
	assign		mgte_txln_ufcm_size	= 	3'H3	;

	hubs_txds_edge_ufcm				u_hubs_txds_edge_ufcm(
		.mgte_htoe_ufcm_csen			(mgte_htoe_ufcm_csen	),//output
		.mgte_htoe_ufcm_data			(mgte_htoe_ufcm_data	),//output
		.mgte_htoe_ufcm_drdy			(mgte_txln_ufcm_drdy	),//output
		.mgte_htoe_ufcm_trdy			(mgte_txln_ufcm_trdy	),//output
		.mgte_bclk						(mgte_bclk				),//input
		.mgte_rstn						(mgte_rstn				),//input

		.mgth_htoe_ufcm_reqs			(mgth_htoe_ufcm_reqs	),//input
		.mgth_htoe_ufcm_idle			(mgth_htoe_ufcm_idle	),//output
		.mgth_htoe_ufcm_done			(mgth_htoe_ufcm_done	),//output
		.mgth_htoe_cmnd_lead			(mgth_htoe_cmnd_lead	),//input
		.mgth_htoe_cmnd_coda			(mgth_htoe_cmnd_coda	),//input
		.mgth_htoe_data_lead			(mgth_htoe_data_lead	),//input
		.mgth_htoe_data_coda			(mgth_htoe_data_coda	),//input//ROOT_TARGET_READY,ONLY USED IN ROOT_IMTX

		.mgth_bclk						(mgth_bclk				),//input
		.mgth_rstn						(mgth_rstn				));//input
//----------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------
	hubs_txds_edge_data				u_hubs_txds_edge_data(
		.mgte_htoe_axis_csen			(mgte_htoe_axis_csen	),//output	reg			 CD:MGTE
		.mgte_htoe_axis_data			(mgte_htoe_axis_data	),//output		[31: 0]	 CD:MGTE
		.mgte_htoe_axis_drdy			(mgte_htoe_axis_drdy	),//output				 CD:MGTE
		.mgte_htoe_axis_last			(mgte_htoe_axis_last	),//output				 CD:MGTE
		.mgte_htoe_axis_trdy			(mgte_txln_axis_trdy	),//input				 CD:MGTE
		.mgte_bclk						(mgte_bclk				),//input	
		.mgte_rstn						(mgte_rstn				),//input	

		.mgth_htoe_clnk_reqs			(mgth_htoe_clnk_reqs	),//input				CD:MGTH	
		.mgth_htoe_clnk_done			(mgth_htoe_clnk_done	),//output	reg			CD:MGTH	
		.mgth_htoe_clnk_size			(mgth_htoe_clnk_size	),//input		[ 3: 0]	CD:MGTH	COSL_DIMENSION BASE ON WORD
		.mgte_htoe_clnk_addr			(mgte_htoe_clnk_addr	),//output	reg	[ 3: 0]	CD:MGTH	
		.mgte_htoe_clnk_data			(mgte_htoe_clnk_data	),//input		[31: 0]	CD:MGTH

		.mgth_htoe_slnk_reqs			(mgth_htoe_slnk_reqs	),//input					CD:MGTH
		.mgth_htoe_slnk_done			(mgth_htoe_slnk_done	),//output					CD:MGTH
		.mgth_htoe_slnk_size			(mgth_htoe_slnk_size	),//input		[12: 0]		CD:MGTH	COSL_DIMENSION BASE ON 2*DOTS
		.mgth_htoe_slnk_drdy			(mgth_htoe_slnk_drdy	),//input					CD:MGTH
		.mgth_htoe_slnk_data			(mgth_htoe_slnk_data	),//input		[63: 0]		CD:MGTH
	
		.mgth_htoe_dlnk_reqs			(mgth_htoe_dlnk_reqs	),//CD:MGTH 
		.mgth_htoe_dlnk_done			(mgth_htoe_dlnk_done	),//CD:MGTH
		.mgth_htoe_dlnk_size			(mgth_htoe_dlnk_size	),//CD:MGTH	COSL_DIMENSION BASE ON 2*DOTS
		.mgth_bclk						(mgth_bclk				),//input	
		.mgth_rstn						(mgth_rstn				),//input	

		.ddrs_htoe_rdma_trdy			(ddrs_htoe_rdma_trdy	),//CD:DDRS	
		.ddrs_htoe_rdma_dout			(ddrs_htoe_rdma_data	),//CD:DDRS	
		.ddrs_htoe_rdma_drdy			(ddrs_htoe_rdma_drdy	),//CD:DDRS	
		.ddrs_bclk						(ddrs_bclk				),//input	
		.ddrs_rstn						(ddrs_rstn				));//input	
endmodule


