module	hubs_rxds_edge_data(
	input		[31: 0]					mgte_etoh_axis_data	,
	input								mgte_etoh_axis_drdy	,

	output	reg	[31: 0]					mgte_etoh_acks_data	,
	output	reg							mgte_etoh_acks_wrcs	,	
	input								mgte_etoh_acks_lead	,
	input								mgte_etoh_acks_coda	,
	input								mgte_etoh_data_lead	,
	input								mgte_etoh_data_coda	,

	output		[31: 0]					mgte_etoh_maxi_rows	,
	output		[15: 0]					mgte_etoh_maxi_cols	,
	output		[15: 0]					mgte_etoh_maxi_data	,
	input								mgte_bclk			,
	input								mgte_rstn			,

	input								mgth_etoh_dlnk_enab	,
	input								mgth_etoh_slnk_enab	,
	input								mgth_etoh_maxi_enab	,

	output		[63: 0]					mgth_etoh_slnk_data	,
	output								mgth_etoh_slnk_drdy	,
	input								mgth_etoh_slnk_trdy	,

	input								mgth_bclk			,
	input								mgth_rstn			,

	input								ddrs_etoh_wdma_bank	,
	input		[ 9: 0]					ddrs_etoh_wdma_addr	,
	output		[127:0]					ddrs_etoh_wdma_data	,	
	input								ddrs_bclk			);
/***EDGE_RXDS_CSEN*****************************************************************************************************/
	reg									mgte_etoh_acks_csen	;
	reg									mgte_etoh_data_csen	;

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_acks_csen	<=	0	;
	else if( mgte_etoh_acks_lead)		mgte_etoh_acks_csen	<=	1	;
	else if( mgte_etoh_acks_coda)		mgte_etoh_acks_csen	<= 	0	;

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_data_csen	<=	0	;
	else if( mgte_etoh_data_lead)		mgte_etoh_data_csen	<=	1	;
	else if( mgte_etoh_data_coda)		mgte_etoh_data_csen	<= 	0	;
//------------------------------------------------------------------------------
	wire		[ 2: 0]					mgth_etoh_misc_enab	;	
	wire		[ 2: 0]					mgte_etoh_misc_enab	;	

	assign		mgth_etoh_misc_enab	={	mgth_etoh_dlnk_enab	,	mgth_etoh_slnk_enab	,	mgth_etoh_maxi_enab	};
	assign		mgte_etoh_dlnk_enab	=	mgte_etoh_misc_enab[2]	;
	assign		mgte_etoh_slnk_enab	=	mgte_etoh_misc_enab[1]	;
	assign		mgte_etoh_maxi_enab	=	mgte_etoh_misc_enab[0]	;

	for(genvar i = 0 ; i < 3 ; i = i + 1)	begin:gens_edge_misc_enab

		gens_sync_mark 					u_mgte_etoh_misc_enab(	
			.dtar_mark						(mgte_etoh_misc_enab[i]	),//output	
			.dtar_clki						(mgte_bclk				),//input	
			.dtar_rstn						(mgte_rstn				),//input	

			.dsrc_mark 						(mgth_etoh_misc_enab[i]	),//input   
			.dsrc_clki						(mgth_bclk				),//input	
			.dsrc_rstn						(mgth_rstn				));//input	
	end
/***EDGE_RXDS_ACKS******************************************************************************************************/
	wire								mgte_etoh_acks_drdy	;
	assign		mgte_etoh_acks_drdy	= &{mgte_etoh_acks_csen	,	mgte_etoh_axis_drdy	};

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_acks_data	<=	0	;
	else if(mgte_etoh_acks_drdy)		mgte_etoh_acks_data	<=	mgte_etoh_axis_data	;

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_acks_wrcs	<=	0	;
	else 								mgte_etoh_acks_wrcs	<=	mgte_etoh_acks_drdy	;
/***EDGE_MAXI_SEEK*****************************************************************************************************/
	reg			[31: 0]					mgte_etoh_maxi_dsrc	;
	reg									mgte_etoh_maxi_seek	;

	wire								mgte_etoh_maxi_enab	;
	wire								mgte_etoh_maxi_sift	;	
	wire								mgte_etoh_maxi_drdy	;

	assign		mgte_etoh_maxi_sift	= &{mgte_etoh_maxi_enab	,	mgte_etoh_data_csen	};
	assign		mgte_etoh_maxi_drdy	= &{mgte_etoh_maxi_sift	,	mgte_etoh_axis_drdy	};
//------------------------------------------------------------------------------
	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_maxi_dsrc	<=	0	;
	else if(~mgte_etoh_maxi_sift)		mgte_etoh_maxi_dsrc	<=	0	;
	else if( mgte_etoh_maxi_drdy)		mgte_etoh_maxi_dsrc	<=	mgte_etoh_axis_data	;
	
	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_maxi_seek	<=	0	;
	else if(~mgte_etoh_maxi_sift)		mgte_etoh_maxi_seek	<=	0	;
	else 								mgte_etoh_maxi_seek	<=	mgte_etoh_maxi_drdy	;
//------------------------------------------------------------------------------
	hubs_rxds_edge_maxi				u_hubs_rxds_edge_maxi(
		.edge_dlnk_maxi_csen			(mgte_etoh_maxi_enab	),//input					
		.edge_dlnk_maxi_rows			(mgte_etoh_maxi_rows	),//output	reg	[31: 0]		
		.edge_dlnk_maxi_cols			(mgte_etoh_maxi_cols	),//output	reg	[15: 0]		
		.edge_dlnk_maxi_data			(mgte_etoh_maxi_data	),//output	reg	[15: 0]		
		
		.edge_dlnk_acks_coda			(mgte_etoh_acks_coda	),//input
		.edge_dlnk_data_coda			(mgte_etoh_data_coda	),//input
		.edge_dlnk_maxi_dsrc			(mgte_etoh_maxi_dsrc	),//input		[31: 0]	
		.edge_dlnk_maxi_seek			(mgte_etoh_maxi_seek	),//input				
		.edge_bclk						(mgte_bclk				),//input
		.edge_rstn						(mgte_rstn				));//input
/***EDGE_RXDS_PACK*****************************************************************************************************/
	reg									mgte_etoh_dlnk_bank	;
	reg			[  1:0]					mgte_etoh_dlnk_wcnt	;
	reg			[  9:0]					mgte_etoh_dlnk_addr	;//depth 1024 ,total 8K 
	reg			[127:0]					mgte_etoh_dlnk_data	;
	reg									mgte_etoh_dlnk_drdy	;

	wire								mgte_etoh_data_drdy	;
	assign		mgte_etoh_data_drdy	= &{mgte_etoh_data_csen	,	mgte_etoh_axis_drdy	};

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_dlnk_bank	<=	0	;
	else if(~mgte_etoh_dlnk_enab)		mgte_etoh_dlnk_bank	<=	0	;
	else if( mgte_etoh_acks_lead)		mgte_etoh_dlnk_bank	<=	0	;
	else if( mgte_etoh_data_coda)		mgte_etoh_dlnk_bank	<= ~mgte_etoh_dlnk_bank	;

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_dlnk_wcnt	<=	0	;
	else if(~mgte_etoh_dlnk_enab)		mgte_etoh_dlnk_wcnt	<=	0	;
	else if( mgte_etoh_data_lead)		mgte_etoh_dlnk_wcnt	<=	0	;
	else if( mgte_etoh_data_drdy)		mgte_etoh_dlnk_wcnt	<=	mgte_etoh_dlnk_wcnt + 1	;

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_dlnk_drdy	<=	0	;
	else if(~mgte_etoh_dlnk_enab)		mgte_etoh_dlnk_drdy	<=	0	;
	else if(~mgte_etoh_data_csen)		mgte_etoh_dlnk_drdy	<=	0	;	
	else 								mgte_etoh_dlnk_drdy	<=&{mgte_etoh_dlnk_wcnt	,	mgte_etoh_data_drdy	};

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_dlnk_addr	<=	0	;
	else if(~mgte_etoh_dlnk_enab)		mgte_etoh_dlnk_addr	<=	0	;
	else if( mgte_etoh_data_lead)		mgte_etoh_dlnk_addr	<=	0	;
	else if( mgte_etoh_dlnk_drdy)		mgte_etoh_dlnk_addr	<=	mgte_etoh_dlnk_addr + 1	;

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_etoh_dlnk_data	<=	0	;
	else if(~mgte_etoh_dlnk_enab)		mgte_etoh_dlnk_data	<=	0	;
	else if(~mgte_etoh_data_csen)		mgte_etoh_dlnk_data	<=	0	;	
	else if( mgte_etoh_data_drdy)		mgte_etoh_dlnk_data	<= {mgte_etoh_axis_data	,	mgte_etoh_dlnk_data[127: 32]};
//------------------------------------------------------------------------------
//one edge 160MBps	-> 16 edge 2.56GBps DDR4 BandWith 4.8GBps
//one edge 4KCols*2 -> 16 edge 64K*2 
	bram_ping_pang_etoh	#(
		.ADDRW							(10		),	
		.DATAW							(128	))
									u_hubs_edge_wdma_memo(	
		.wport_rank						(mgte_etoh_dlnk_bank	),//input					
		.wport_csen						(mgte_etoh_dlnk_drdy	),//input  				 	
		.wport_addr						(mgte_etoh_dlnk_addr	),//input		[ADDRW-1:0]	
		.wport_data						(mgte_etoh_dlnk_data	),//input		[DATAW-1:0]	
		.wport_clki						(mgte_bclk				),//input					

		.rport_rank						(ddrs_etoh_wdma_bank	),//input					
		.rport_addr						(ddrs_etoh_wdma_addr	),//input		[ADDRW-1:0]	
		.rport_data						(ddrs_etoh_wdma_data	),//output	reg	[DATAW-1:0]	
		.rport_clki						(ddrs_bclk				));//input					
/**********************************************************************************************************************/
/**********************************************************************************************************************/
	fifo_etoh_rxdi_slnk				u_etoh_rxdi_fifo_scut(		
		.push_enab						(mgte_etoh_slnk_enab	),//input		[31: 0]		
		.push_data						(mgte_etoh_axis_data	),//input		[31: 0]		
		.push_drdy						(mgte_etoh_data_drdy	),//input					
		.push_clki						(mgte_clki				),//input					
		.push_rstn						(mgte_rstn				),//input					

		.pops_enab						(mgth_etoh_slnk_enab	),//output		[64: 0]		
		.pops_data						(mgth_etoh_slnk_data	),//output		[64: 0]		
		.pops_drdy						(mgth_etoh_slnk_drdy	),//output					
		.pops_trdy						(mgth_etoh_slnk_trdy	),//input					
		.pops_clki						(mgth_clki				),//input					
		.pops_rstn						(mgth_rstn				));//input					
endmodule


