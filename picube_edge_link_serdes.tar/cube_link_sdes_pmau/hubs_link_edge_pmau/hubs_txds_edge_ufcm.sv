module	hubs_txds_edge_ufcm(
	output	reg							mgte_htoe_ufcm_csen	,//CD::MGTE_
	output	reg	[31: 0]					mgte_htoe_ufcm_data	,//CD::MGTE_
	output	reg							mgte_htoe_ufcm_drdy	,//CD::MGTE_
	input								mgte_htoe_ufcm_trdy	,//CD::MGTE_
	input								mgte_bclk			,
	input								mgte_rstn			,

	output								mgth_htoe_ufcm_idle	,//CD::MGTH
	output								mgth_htoe_ufcm_done	,//CD::MGTH
	input								mgth_htoe_ufcm_reqs	,//CD::MGTH
	input								mgth_htoe_cmnd_lead	,//CD::MGTH
	input								mgth_htoe_cmnd_coda	,//CD::MGTH
	input								mgth_htoe_data_lead	,//CD::MGTH
	input								mgth_htoe_data_coda	,//CD::MGTH
	input								mgth_bclk			,
	input								mgth_rstn			);
/**********************************************************************************************************************/
	wire		[ 4: 0]					mgth_htoe_ufcm_misc		;

	assign		mgth_htoe_ufcm_misc	= {	mgth_htoe_ufcm_reqs	,
										mgth_htoe_cmnd_lead	,	mgth_htoe_cmnd_coda	,
										mgth_htoe_data_lead	,	mgth_htoe_data_coda	};
//------------------------------------------------------------------------------
	wire		[ 4: 0]					mgte_htoe_ufcm_misc		;

	wire								mgte_htoe_ufcm_reqs		;
	wire								mgte_htoe_ufcm_idle		;
	wire								mgte_htoe_ufcm_done		;

	wire		mgte_htoe_cmnd_lead	=	mgte_htoe_ufcm_misc[3]	;
	wire		mgte_htoe_cmnd_coda	=	mgte_htoe_ufcm_misc[2]	;
	wire		mgte_htoe_data_lead	=	mgte_htoe_ufcm_misc[1]	;
	wire		mgte_htoe_data_coda	=	mgte_htoe_ufcm_misc[0]	;
//	wire		mgte_htoe_rrdy_tokn	=	mgte_htoe_ufcm_misc[0]	;
//------------------------------------------------------------------------------
	gens_gray_code	#(.MSB(4))		u_sync_ufcm_gray_misc(		
		.dtar_data						(mgte_htoe_ufcm_misc), 
		.dtar_clki						(mgte_bclk			), 
		.dtar_rstn						(mgte_rstn			),

		.dsrc_data						(mgth_htoe_ufcm_misc), 
		.dsrc_clki						(mgth_bclk			));
//------------------------------------------------------------------------------
	gens_sync_edge #(.EXTN(1))		u_gens_ufcm_reqs_edge(	
		.dtar_rise						(mgte_htoe_ufcm_reqs	),//output
		.dtar_fall						(						),//output
		.dtar_clki						(mgte_bclk				),//input	
		.dtar_rstn						(mgte_rstn				),//input	

		.dsrc_mark						(mgte_htoe_ufcm_misc[4]	),//input
		.dsrc_clki						(mgth_bclk				),//input
		.dsrc_rstn						(mgth_rstn				));//input
//------------------------------------------------------------------------------
	gens_sync_edge #(.EXTN(1))		u_gens_ufcm_done_edge(	
		.dtar_rise						(mgth_htoe_ufcm_done	),//output
		.dtar_fall						(						),//output
		.dtar_clki						(mgte_bclk				),//input	
		.dtar_rstn						(mgte_rstn				),//input	

		.dsrc_mark						(mgte_htoe_ufcm_done	),//input
		.dsrc_clki						(mgte_bclk				),//input
		.dsrc_rstn						(mgte_rstn				));//input
//------------------------------------------------------------------------------
	gens_sync_mark					u_gens_ufcm_idle_mark(	
		.dtar_mark						(mgth_htoe_ufcm_idle	),//output	
		.dtar_clki						(mgth_bclk				),//input	
		.dtar_rstn						(mgth_rstn				),//input	

	    .dsrc_mark						(mgte_htoe_ufcm_idle	),//input
		.dsrc_clki						(mgte_bclk				),//input
		.dsrc_rstn						(mgte_rstn				));//input
/**********************************************************************************************************************/
//	assign		mgte_htoe_ufcm_size	=	3'H3	;	//3@2+2 = 8 BYTES
/**********************************************************************************************************************/
	reg			[ 1: 0]					mgte_htoe_ufcm_mfsm	;

	parameter	MGTE_HTOE_UFCM_IDLE	=	2'H0	;
	parameter	MGTE_HTOE_UFCM_ACKS	=	2'H1	;
	parameter	MGTE_HTOE_UFCM_LEAD	=	2'H2	;
	parameter	MGTE_HTOE_UFCM_DONE	=	2'H3	;
//------------------------------------------------------------------------------
	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_htoe_ufcm_mfsm	<=	MGTE_HTOE_UFCM_IDLE	;
	else	begin
		case(mgte_htoe_ufcm_mfsm)	
			MGTE_HTOE_UFCM_IDLE	:		mgte_htoe_ufcm_mfsm	<=	mgte_htoe_ufcm_reqs	?	MGTE_HTOE_UFCM_REQS	:	MGTE_HTOE_UFCM_IDLE	;
			MGTE_HTOE_UFCM_ACKS	:		mgte_htoe_ufcm_mfsm	<=	mgte_htoe_ufcm_trdy	?	MGTE_HTOE_UFCM_LEAD	:	MGTE_HTOE_UFCM_ACKS	;
			MGTE_HTOE_UFCM_LEAD	:		mgte_htoe_ufcm_mfsm	<=													MGTE_HTOE_UFCM_CODA	;
			MGTE_HTOE_UFCM_DONE	:		mgte_htoe_ufcm_mfsm	<=													MGTE_HTOE_UFCM_IDLE	;
			default				:		mgte_htoe_ufcm_mfsm	<=													MGTE_HTOE_UFCM_IDLE	;	
		endcase
	end 
/**********************************************************************************************************************/
	assign		mgte_htoe_ufcm_idle	=	mgte_htoe_ufcm_mfsm	==	MGTE_HTOE_UFCM_IDLE	;
	assign		mgte_htoe_ufcm_done	=	mgte_htoe_ufcm_mfsm	==	MGTE_HTOE_UFCM_DONE	;
	wire		mgte_htoe_ufcm_acks	=	mgte_htoe_ufcm_mfsm	==	MGTE_HTOE_UFCM_ACKS	;
	wire		mgte_htoe_ufcm_lead	=	mgte_htoe_ufcm_mfsm	==	MGTE_HTOE_UFCM_LEAD	;

	wire		mgte_htoe_ufcm_txds	= &{mgte_htoe_ufcm_reqs	,	mgte_htoe_ufcm_idle	};
	wire		mgte_htoe_ufcm_txok	= &{mgte_htoe_ufcm_trdy	,	mgte_htoe_ufcm_acks	};
//------------------------------------------------------------------------------
	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_htoe_ufcm_csen	<=	0	;
	else if( mgte_htoe_ufcm_txds)		mgte_htoe_ufcm_csen	<=	1	;
	else if( mgte_htoe_ufcm_done)		mgte_htoe_ufcm_csen	<=	0	;
	
	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_htoe_ufcm_drdy	<=	0	;
	else if( mgte_htoe_ufcm_csen)		mgte_htoe_ufcm_drdy	<=	1	;
	else if( mgte_htoe_ufcm_txok)		mgte_htoe_ufcm_drdy	<=	0	;

	always@(posedge mgte_bclk or negedge mgte_rstn)
	if(~mgte_rstn)						mgte_htoe_ufcm_data	<=	0	;
	else if( mgte_htoe_ufcm_txok)		mgte_htoe_ufcm_data	<=	mgte_cmnd_lead_issu	?	"LEAD"	:
																mgte_cmnd_coda_issu	?	"CODA"	:	
																mgte_data_lead_issu	?	"LEAD"	:
																mgte_data_coda_issu	?	"CODA"	:	32'H0	;
	else if( mgte_htoe_ufcm_lead)		mgte_htoe_ufcm_data	<=	mgte_cmnd_lead_issu	?	"CMND"	:
																mgte_cmnd_coda_issu	?	"CMND"	:	
																mgte_data_lead_issu	?	"DATA"	:
																mgte_data_coda_issu	?	"DATA"	:	32'H0	;
	else								mgte_htoe_ufcm_data	<=	0	;



endmodule


