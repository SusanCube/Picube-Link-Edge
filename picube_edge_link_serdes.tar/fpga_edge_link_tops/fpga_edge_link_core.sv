
module  fpga_edge_link_core(
//------------------------------------------------------------------------------
	input		[31: 0]					rora_user_rxln_data	,
	input								rora_user_rxln_drdy	,
	input		[31: 0]					rora_ufcm_rxln_data	,
	input								rora_ufcm_rxln_drdy	,
	input								rora_ufcm_rxln_last	,

	output		[31: 0]					rora_user_txln_data	,
	output								rora_user_txln_drdy	,
	output								rora_user_txln_last	,
	input								rora_user_txln_trdy	,
	output								rora_ufcm_txln_reqs	,
	input								rora_ufcm_txln_acks	,

	input								rora_bclk			, //125MHZ
	input								rora_rstn			,
//------------------------------------------------------------------------------
	input								rv32_edge_dmem_csen	,
	input		[11: 0]					rv32_edge_dmem_addr	,
	input								rv32_edge_dmem_wrcs	,
	input		[31: 0]					rv32_edge_dmem_wdat	,
	output		[31: 0]					rv32_edge_dmem_rdat	,
//--------------------------------------
	output								cube_ispx_mode_port	,
	output								cube_ispx_rstn_port	,
	output								cube_chip_rstn_port	,
//--------------------------------------
	output								cube_ufcm_cmnd_port	,
	input		[ 1: 0]					cube_ufcm_stat_port	,
//--------------------------------------
	input								cube_uart_rxdi_port	,
	output								cube_uart_txdo_port	,
//--------------------------------------
	input     	                     	cube_bclk     		, //25MHZ
	input     	                     	cube_rstn     		,
//------------------------------------------------------------------------------
	output	reg							dvp0_pmau_vsyn_pado	,			
	output	reg							dvp0_pmau_hsyn_pado	,
	output	reg	[15: 0]					dvp0_pmau_data_pado	,
	output	reg							dvp1_pmau_vsyn_pado	,			
	output	reg							dvp1_pmau_hsyn_pado	,
	output	reg	[15: 0]					dvp1_pmau_data_pado	,
	input								dvpx_bclk			, //150~200MHZ
	input								dvpx_rstn			,
//--------------------------------------	
	input								gmsl_pmau_vsyn_padi	,
	input								gmsl_pmau_hsyn_padi	,
	input		[15: 0]					gmsl_pmau_data_padi	,
	input								gmsl_bclk			, //80~90MHZ
	input								gmsl_rstn			);
/**********************************************************************************************************************/
	wire	[ 2: 0]						rora_gmsl_alnk_wsel	;
	wire	[ 1: 0]						rora_dvpx_link_port	;

	wire	[19: 0]						rora_data_link_rows	;
	wire	[19: 0]						rora_data_link_cols	;

	wire	[ 0: 8]						rora_rxln_cmnd_mark	;
	wire	[ 3: 0]						rora_rxln_cmnd_addr	;
	wire	[31: 0]						rora_rxln_cmnd_data	;
	wire								rora_rxln_cmnd_drdy	;

	wire	[31: 0]						rora_acks_rv32_data	;

	wire	[ 2: 0]						dvpx_clnk_memo_addr	;
	wire	[31: 0]						dvpx_clnk_memo_data	;

	fpga_edge_rv32_ctrl				u_edge_rv32_link_core(
		.rv32_edge_ctrl_rdat			(rv32_edge_dmem_rdat	),//input		[ 31:0 ]	
		.rv32_edge_ctrl_csen			(rv32_edge_dmem_csen	),//output					
		.rv32_edge_ctrl_wrcs			(rv32_edge_dmem_wrcs	),//output					
		.rv32_edge_ctrl_addr			(rv32_edge_dmem_addr	),//output		[ 11:0 ]	
		.rv32_edge_ctrl_wdat			(rv32_edge_dmem_wdat	),//output		[ 31:0 ]	

		.cube_uart_rxdi_port			(cube_uart_rxdi_port	),//input					
		.cube_uart_txdo_port			(cube_uart_txdo_port	),//output					
		.cube_ispx_mode_port			(cube_ispx_mode_port	),//output	reg				
		.cube_ispx_rstn_port			(cube_ispx_rstn_port	),//output	reg				
		.cube_chip_rstn_port			(cube_chip_rstn_port	),//output	reg				
		.cube_acks_argu_selx			(rora_gmsl_alnk_wsel	),//output	reg	[ 2: 0]		

		.rora_rxln_cmnd_addr			(rora_rxln_cmnd_addr	),//input		[ 3: 0]	
		.rora_rxln_cmnd_data			(rora_rxln_cmnd_data	),//input		[31: 0]	
		.rora_rxln_cmnd_drdy			(rora_rxln_cmnd_drdy	),//input				
		.rora_rxln_cmnd_coda			(rora_rxln_cmnd_coda	),//input				

		.rora_acks_rv32_data			(rora_acks_rv32_data	),//output	reg	[31: 0]	
		.rora_acks_rv32_reqs			(rora_acks_rv32_reqs	),//output				
		.rora_acks_txln_done			(rora_acks_txln_done	),//input				

		.cube_link_icfg_reqs			(cube_link_icfg_reqs	),//output	
		.cube_link_ocfg_reqs			(cube_link_ocfg_reqs	),//output	
		.cube_link_idat_reqs			(cube_link_idat_reqs	),//output	
		.cube_link_odat_reqs			(cube_link_odat_reqs	),//output	
		.cube_link_ufcm_done			(cube_link_ufcm_done	),//input	

		.rora_data_link_rows			(rora_data_link_rows	),//output		[19: 0]	
		.rora_data_link_cols			(rora_data_link_cols	),//output		[19: 0]	
		.rora_dvpx_link_port			(rora_dvpx_link_port	),//output	reg	[ 1: 0]		
		
		.dvpx_clnk_memo_addr			(dvpx_clnk_memo_addr	),//input		[ 2: 0]		
		.dvpx_clnk_memo_data			(dvpx_clnk_memo_data	),//output		[31: 0]		

		.cube_bclk						(cube_bclk				),//input	
		.cube_rstn						(cube_rstn				),//input	
		.rora_bclk						(rora_bclk				),//input	
		.rora_rstn						(rora_rstn				));//input	
/**********************************************************************************************************************/
	wire		[31: 0]					rora_acks_cube_data	;
	wire		[10: 0]					dvpx_dlnk_memo_addr	;
	wire		[31: 0]					dvpx_dlnk_memo_data	;
	wire		[15: 0]					gmsl_slnk_rows_data	;

	edge_link_cube_pmau				u_edge_link_cube_pmau(
		.dvp0_pmau_vsyn_pado			(dvp0_pmau_vsyn_pado	),//output	reg			
		.dvp0_pmau_hsyn_pado			(dvp0_pmau_hsyn_pado	),//output	reg			
		.dvp0_pmau_data_pado			(dvp0_pmau_data_pado	),//output	reg	[15: 0]	
		.dvp1_pmau_vsyn_pado			(dvp1_pmau_vsyn_pado	),//output	reg			
		.dvp1_pmau_hsyn_pado			(dvp1_pmau_hsyn_pado	),//output	reg			
		.dvp1_pmau_data_pado			(dvp1_pmau_data_pado	),//output	reg	[15: 0]	

		.gmsl_pmau_vsyn_padi			(gmsl_pmau_vsyn_padi	),//input				
		.gmsl_pmau_hsyn_padi			(gmsl_pmau_hsyn_padi	),//input				
		.gmsl_pmau_data_padi			(gmsl_pmau_data_padi	),//input		[15: 0]	

		.cube_ufcm_stat_port			(cube_ufcm_stat_port	),//input		[ 1: 0]	
		.cube_ufcm_cmnd_port			(cube_ufcm_cmnd_port	),//output				

		.cube_link_ufcm_done			(cube_link_ufcm_done	),//output
		.cube_link_ocfg_reqs			(cube_link_ocfg_reqs	),//input
		.cube_link_icfg_reqs			(cube_link_icfg_reqs	),//input
		.cube_link_odat_reqs			(cube_link_odat_reqs	),//input
		.cube_link_idat_reqs			(cube_link_idat_reqs	),//input

		.rora_acks_txln_done			(rora_acks_txln_done	),//input					
		.rora_acks_cube_reqs			(rora_acks_cube_reqs	),//output					
		.rora_acks_cube_data			(rora_acks_cube_data	),//output	reg	[31: 0]		
	
		.rora_resp_txln_done			(rora_resp_txln_done	),//input	
		.rora_resp_cube_reqs			(rora_resp_cube_reqs	),//output	

		.rora_data_link_rows			(rora_data_link_rows	),//input		[19: 0]	
		.rora_data_link_cols			(rora_data_link_cols	),//input		[19: 0]	
		
		.rora_dvpx_dlnk_done			(rora_dvpx_dlnk_done	),//output	
		.rora_dvpx_dlnk_enab			(rora_dvpx_dlnk_enab	),//output	
		.rora_dvpx_dlnk_trdy			(rora_dvpx_dlnk_trdy	),//output	
		.rora_dvpx_dlnk_port			(rora_dvpx_link_port	),//input		[ 1: 0]
		.rora_dvpx_dlnk_reqs			(rora_dvpx_dlnk_reqs	),//input	
		
		.rora_gmsl_alnk_wsel			(rora_gmsl_alnk_wsel	),//input		[ 2: 0]	
		.rora_gmsl_slnk_done			(rora_gmsl_slnk_done	),//input
		.rora_gmsl_slnk_enab			(rora_gmsl_slnk_enab	),//output				
		.rora_gmsl_slnk_reqs			(rora_gmsl_slnk_reqs	),//output				
		.rora_bclk						(rora_bclk				),//input				
		.rora_rstn						(rora_rstn				),//input				

		.dvpx_clnk_memo_addr			(dvpx_clnk_memo_addr	),//output		[ 2: 0]	
		.dvpx_clnk_memo_data			(dvpx_clnk_memo_data	),//input		[31: 0]	
		.dvpx_dlnk_memo_rank			(dvpx_dlnk_memo_rank	),//output				
		.dvpx_dlnk_memo_addr			(dvpx_dlnk_memo_addr	),//output		[11: 0]	
		.dvpx_dlnk_memo_data			(dvpx_dlnk_memo_data	),//input		[15: 0]	
		.dvpx_bclk						(dvpx_bclk				),//input				
		.dvpx_rstn						(dvpx_rstn				),//input				

		.gmsl_slnk_rows_data			(gmsl_slnk_rows_data	),//output	
		.gmsl_slnk_rows_drdy			(gmsl_slnk_rows_drdy	),//output	
		.gmsl_slnk_rows_tail			(gmsl_slnk_rows_tail	),//output	
		.gmsl_bclk						(gmsl_bclk				),//input	
		.gmsl_rstn						(gmsl_rstn				));//input	
/**********************************************************************************************************************/
	edge_link_hubs_pmau				u_edge_link_hubs_pmau(
		.rora_user_rxln_data			(rora_user_rxln_data	),//input		[31: 0]	
		.rora_user_rxln_drdy			(rora_user_rxln_drdy	),//input				
		.rora_ufcm_rxln_data			(rora_ufcm_rxln_data	),//input		[31: 0]	
		.rora_ufcm_rxln_drdy			(rora_ufcm_rxln_drdy	),//input				
		.rora_ufcm_rxln_last			(rora_ufcm_rxln_last	),//input				
		.rora_user_txln_data			(rora_user_txln_data	),//output		[31: 0]	
		.rora_user_txln_drdy			(rora_user_txln_drdy	),//output				
		.rora_user_txln_last			(rora_user_txln_last	),//output				
		.rora_user_txln_trdy			(rora_user_txln_trdy	),//input				
		.rora_ufcm_txln_reqs			(rora_ufcm_txln_reqs	),//output				
		.rora_ufcm_txln_acks			(rora_ufcm_txln_acks	),//input				

		.rora_rxln_cmnd_addr			(rora_rxln_cmnd_addr	),//output		[ 3: 0]	
		.rora_rxln_cmnd_data			(rora_rxln_cmnd_data	),//output		[31: 0]	
		.rora_rxln_cmnd_drdy			(rora_rxln_cmnd_drdy	),//output				
		.rora_rxln_cmnd_coda			(rora_rxln_cmnd_coda	),//output				
		.rora_rxln_data_coda			(rora_dvpx_dlnk_reqs	),//output				
//------------------------------------------------------------------------------
		.rora_acks_txln_done			(rora_acks_txln_done	),//output					//to 	rv32_controller
		.rora_acks_rv32_reqs			(rora_acks_rv32_reqs	),//input					//from rv32_controller
		.rora_acks_rv32_data			(rora_acks_rv32_data	),//input		[31: 0]		//from rv32_controller

		.rora_acks_cube_reqs			(rora_acks_cube_reqs	),//input				//from cube(ufcm)_link_controller
		.rora_acks_cube_data			(rora_acks_cube_data	),//input		[31: 0]	//from cube(ufcm)_link_controller
	
		.rora_resp_txln_done			(rora_resp_txln_done	),//output	//to 	cube(ufcm)_link_controller
		.rora_resp_cube_reqs			(rora_resp_cube_reqs	),//input	//from cube(ufcm)_link_controller
		
		.rora_trdy_txln_done			(),//rora_trdy_cube_reqs	),//output	//to 	cube(dvpx)_link_controller
		.rora_trdy_cube_reqs			(rora_dvpx_dlnk_trdy	),//input	//from cube(dvpx)_link_controller
	
		.rora_gmsl_slnk_done			(rora_gmsl_slnk_done	),//output				//to 	cube(gmsl)_link_controller
		.rora_gmsl_slnk_enab			(rora_gmsl_slnk_enab	),//input				//from cube(gmsl)_link_controller
		.rora_gmsl_slnk_rows			(rora_data_link_rows	),//input		[19: 0]	
		.rora_gmsl_slnk_cols			(rora_data_link_cols	),//input		[19: 0]	
		.rora_gmsl_slnk_reqs			(rora_gmsl_slnk_reqs	),//input				//from cube(gmsl)_link_controller
		.rora_bclk						(rora_bclk				),//input				
		.rora_rstn						(rora_rstn				),//input				
//------------------------------------------------------------------------------
		.dvpx_dlnk_memo_rank			(dvpx_dlnk_memo_rank	),//input				
		.dvpx_dlnk_memo_addr			(dvpx_dlnk_memo_addr	),//input		[10: 0]	
		.dvpx_dlnk_memo_data			(dvpx_dlnk_memo_data	),//output		[31: 0]	
		.dvpx_bclk						(dvpx_bclk				),//input				
		
		.gmsl_slnk_rows_data			(gmsl_slnk_rows_data	),//input		[15: 0]	
		.gmsl_slnk_rows_drdy			(gmsl_slnk_rows_drdy	),//input				
		.gmsl_slnk_rows_tail			(gmsl_slnk_rows_tail	),//input				
		.gmsl_bclk						(gmsl_bclk				),//input				
		.gmsl_rstn						(gmsl_rstn				));//input				



endmodule
 