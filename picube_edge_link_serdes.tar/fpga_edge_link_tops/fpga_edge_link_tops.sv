//	GMSL	DAT0	:	
//
//
module  fpga_edge_link_tops(
    input								fpga_rstn_inpp		,//K5
    input								fpga_bclk_inpp		,//K5
	input								fpga_init_inpp		,//J5

	output								dvp0_vsyn_pado		,			
	output								dvp0_hsyn_pado		,
	output		[15: 0]					dvp0_data_pado		,
	output								dvp0_clko			,

	output								dvp1_vsyn_pado		,			
	output								dvp1_hsyn_pado		,
	output		[15: 0]					dvp1_data_pado		,
	output								dvp1_clko			,

	input		[15: 0]					gmsl_data_padi		,
	input								gmsl_vsyn_padi		,//F5
	input								gmsl_hsyn_padi		,//K4
	input								gmsl_clki			,//K3

	output								cube_ufcm_cmnd		,
	input		[ 1: 0]					cube_ufcm_stat		,
    
    output                         	 	cube_uart_txdo		,
    input                          	 	cube_uart_rxdi		,

    output                         		cube_ispx_mode		,
    output                         		cube_ispx_rstn		,
    output                         		cube_cold_rstn		,
	output                          	cube_clko	     	);//
/**********************************************************************************************************/
	fpga_edge_clks_gens				u_fpga_edge_clks_gens(
    	.dvpx_bclk_o					(dvpx_bclk			),//output	
		.dvpx_rstn_o					(dvpx_rstn			),//output	

		.init_lock_o					(init_lock			),//output
		.init_bclk_o					(init_bclk			),//output
		.init_rstn_o					(init_rstn			),//output

		.cube_bclk_o					(cube_bclk			),//output	
		.cube_rstn_o					(cube_rstn			),//output	

		.gmsl_bclk_i					(gmsl_bclk			),//input	
		.gmsl_rstn_o					(gmsl_rstn			),//output	

		.fpga_init_inpp					(fpga_init_inpp		),//input	
		.fpga_rstn_inpp					(fpga_rstn_inpp		),//input	
    	.fpga_bclk_inpp					(fpga_bclk_inpp		));	//input	
/**********************************************************************************************************/
	wire								rv32_edge_dmem_csen	;
	wire								rv32_edge_dmem_wrcs	;
	wire	[11: 0]						rv32_edge_dmem_addr	;
	wire	[31: 0]						rv32_edge_dmem_wdat	;
	wire	[31: 0]						rv32_edge_dmem_rdat	;

	fpga_edge_rv32_mcss				u_fpga_rv32(
		.rv32_dmem_csen					(rv32_edge_dmem_csen	),//input			
		.rv32_dmem_wrcs					(rv32_edge_dmem_wrcs	),//input			
		.rv32_dmem_addr					(rv32_edge_dmem_addr	),//input	[11: 0]	
		.rv32_dmem_wdat					(rv32_edge_dmem_wdat	),//input	[31: 0]	
		.rv32_dmem_rdat					(rv32_edge_dmem_rdat	),//output	[31: 0]	
		.rv32_bclk						(rora_bclk				),//input			
		.rv32_rstn						(rora_rstn				));//input			
/**********************************************************************************************************************/
	wire		[31: 0]					rora_rxln_axis_data	;
	wire								rora_rxln_axis_drdy	;
	wire		[31: 0]					rora_rxln_ufcm_data	;
	wire								rora_rxln_ufcm_drdy	;
	wire								rora_rxln_ufcm_last	;
	wire		[31: 0]					rora_txln_axis_data	;
	wire								rora_txln_axis_drdy	;
	wire								rora_txln_axis_last	;
	wire								rora_txln_axis_trdy	;
	wire		[ 2: 0]					rora_txln_ufcm_size	;
	wire								rora_txln_ufcm_reqs	;
	wire								rora_txln_ufcm_acks	;

 	fpga_edge_link_core				u_fpga_edge_link_core(
		.mgte_rxln_axis_data			(rora_rxln_user_data	),//input		[31: 0]	
		.mgte_rxln_axis_drdy			(rora_rxln_user_drdy	),//input				
		.mgte_rxln_ufcm_data			(rora_rxln_ufcm_data	),//input		[31: 0]	
		.mgte_rxln_ufcm_drdy			(rora_rxln_ufcm_drdy	),//input				
		.mgte_rxln_ufcm_last			(rora_rxln_ufcm_last	),//input				
//--------------------------------------
		.mgte_txln_axis_data			(rora_txln_user_data	),//output		[31: 0]	
		.mgte_txln_axis_drdy			(rora_txln_user_drdy	),//output				
		.mgte_txln_axis_last			(rora_txln_user_last	),//output				
		.mgte_txln_axis_trdy			(rora_txln_user_trdy	),//input				
		.mgte_txln_ufcm_size			(rora_txln_ufcm_size	),//output		[ 2: 0]	
		.mgte_txln_ufcm_reqs			(rora_txln_ufcm_reqs	),//output				
		.mgte_txln_ufcm_acks			(rora_txln_ufcm_acks	),//input				
		.mgte_bclk						(rora_bclk				), //125MHZ//input				
		.mgte_rstn						(rora_rstn				),//input		
//--------------------------------------
		.rv32_edge_dmem_csen			(rv32_edge_dmem_csen	),//input				
		.rv32_edge_dmem_wrcs			(rv32_edge_dmem_wrcs	),//input				
		.rv32_edge_dmem_addr			(rv32_edge_dmem_addr	),//input		[11: 0]		
		.rv32_edge_dmem_wdat			(rv32_edge_dmem_wdat	),//input		[31: 0]		
		.rv32_edge_dmem_rdat			(rv32_edge_dmem_rdat	),//output		[31: 0]		
//------------------------------------------------------------------------------
		.cube_ispx_mode_port			(cube_ispx_mode_port	),//output	
		.cube_ispx_rstn_port			(cube_ispx_rstn_port	),//output	
		.cube_chip_rstn_port			(cube_chip_rstn_port	),//output	
//--------------------------------------
		.cube_ufcm_cmnd_port			(cube_ufcm_cmnd_port	),//output				
		.cube_ufcm_stat_port			(cube_ufcm_stat_port	),//input		[ 1: 0]	
//--------------------------------------
		.cube_uart_rxdi_port			(cube_uart_rxdi_port	),//input	
		.cube_uart_txdo_port			(cube_uart_txdo_port	),//output	
//--------------------------------------
		.cube_bclk     					(cube_bclk     			),//input    //25MHZ
		.cube_rstn     					(cube_rstn     			),//input   
//------------------------------------------------------------------------------
		.dvp0_pmau_vsyn_pado			(dvp0_vsyn_pado			),//output	reg						
		.dvp0_pmau_hsyn_pado			(dvp0_hsyn_pado			),//output	reg			
		.dvp0_pmau_data_pado			(dvp0_data_pado			),//output	reg	[15: 0]	
		.dvp1_pmau_vsyn_pado			(dvp1_vsyn_pado			),//output	reg						
		.dvp1_pmau_hsyn_pado			(dvp1_hsyn_pado			),//output	reg			
		.dvp1_pmau_data_pado			(dvp1_data_pado			),//output	reg	[15: 0]	
		.dvpx_bclk						(dvpx_bclk				),//input				 //150~200MHZ
		.dvpx_rstn						(dvpx_rstn				),//input				
//--------------------------------------	
		.gmsl_pmau_vsyn_padi			(gmsl_vsyn_padi			),//input				
		.gmsl_pmau_hsyn_padi			(gmsl_hsyn_padi			),//input				
		.gmsl_pmau_data_padi			(gmsl_data_padi			),//input		[15: 0]	
		.gmsl_bclk						(gmsl_bclk				),//input				 //80~90MHZ
		.gmsl_rstn						(gmsl_rstn				));//input				
/**********************************************************************************************************/
    fpga_edge_rora_ctrl				u_fpga_edge_rora_ctrl(
		.rora_rxln_user_data			(rora_rxln_user_data	),//output		[31: 0]	
		.rora_rxln_user_drdy			(rora_rxln_user_drdy	),//output				
		.rora_rxln_ufcm_data			(rora_rxln_ufcm_data	),//output		[31: 0]	
		.rora_rxln_ufcm_drdy			(rora_rxln_ufcm_drdy	),//output				
		.rora_rxln_ufcm_last			(rora_rxln_ufcm_last	),//output				
		.rora_txln_user_data			(rora_txln_user_data	),//input		[31: 0]	
		.rora_txln_user_drdy			(rora_txln_user_drdy	),//input				
		.rora_txln_user_last			(rora_txln_user_last	),//input				
		.rora_txln_user_trdy			(rora_txln_user_trdy	),//output				
		.rora_txln_ufcm_reqs			(rora_txln_ufcm_reqs	),//input				
		.rora_txln_ufcm_acks			(rora_txln_ufcm_acks	),//output				
		.rora_bclk						(rora_bclk				),//output				 //125MHZ//input				
		.rora_rstn						(rora_rstn				),//output				 //input				
		.init_lock						(init_lock				),//input				
		.init_bclk						(init_bclk				),//input				
		.init_rstn						(init_rstn				)));//input				//

endmodule
 
   