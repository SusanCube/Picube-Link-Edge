//	GMSL	DAT0	:	
//
//
module  fpga_edge_clks_gens(
    input								fpga_rstn_inpp		,//K5
    input								fpga_bclk_inpp		,//K5

	output								dvpx_bclk_o			,
	output								dvpx_rstn_o			,

	output								init_bclk_o			,
	output								init_rstn_o			,

	output								cube_bclk_o			,
	output								cube_rstn_o			,

	input								gmsl_bclk_i			,
	output								gmsl_rstn_o			);
//------------------------------------------------------------------------------
	wire								init_lock_o		;
	wire								fpga_rstn_lpfs	;
	wire								fpga_mixs_rstn	;

	assign		fpga_mixs_rstn = &{		init_lock_o	,	fpga_rstn_lpfs	};

	lowp_filter		#(.BITW(7))		u_fpga_rstn_lpfs(
		.lpfs							(fpga_rstn_lpfs		),
		.inpt							(fpga_rstn_inpp		),
		.clki							(fpga_bclk_inpp		));

	lowp_filter		#(.BITW(7))		u_fpga_gmsl_rstn_lpfs(
		.lpfs							(gmsl_rstn_o		),
		.inpt							(fpga_mixs_rstn		),
		.clki							(gmsl_bclk_i		));				
	
	lowp_filter		#(.BITW(7))		u_fpga_cube_rstn_lpfs(
		.lpfs							(cube_rstn_o		),
		.inpt							(fpga_mixs_rstn		),
		.clki							(cube_bclk_o		));				

	lowp_filter		#(.BITW(7))		u_fpga_init_rstn_lpfs(
		.lpfs							(init_rstn_o		),
		.inpt							(fpga_mixs_rstn		),
		.clki							(init_bclk_o		));				

	lowp_filter		#(.BITW(7))		u_fpga_dvpx_rstn_lpfs(
		.lpfs							(dvpx_rstn_o		),
		.inpt							(fpga_mixs_rstn		),
		.clki							(dvpx_bclk_o		));				
//------------------------------------------------------------------------------
	gwip_mpll_i50m					u_fpga_edge_mpll_i50m(
		.lock							(init_lock_o		),
		.clkout0						(dvpx_bclk_o		),	//175MHz
		.clkout1						(init_bclk_o		),	// 50MHz
		.clkout2						(cube_bclk_o		),	// 25MHz	
		.clkin							( fpga_bclk_inpp	),	// 50MHz
		.mdclk							( fpga_bclk_inpp	),	// 50MHz
		.reset 							(~fpga_rstn_lpfs	));	// 

endmodule 
/**********************************************************************************************************/
/**********************************************************************************************************/


module	lowp_filter #( parameter BITW = 11	)	(
	output								lpfs	,
	output								inpt	,
	input								clki	);
//------------------------------------------------------------------------------
	reg			[BITW: 0]				lpfs_accu	= 0	;
	reg									lpfs_mark	= 0	;

	wire								accu_maxi	;
	wire								accu_gt08	;
	wire		[BITW: 0]				accu_inc1	;
	wire		[BITW: 0]				accu_dec8	;

	assign		accu_maxi	=		&	lpfs_accu	;
	assign		accu_gt08	=		| {	lpfs_accu[BITW:3]	};
	assign		accu_inc1	=			lpfs_accu +	1	;
	assign		accu_dec8	=			lpfs_accu -	8	;

	always@(posedge clki)
	if(inpt&(~accu_maxi))	lpfs_accu	<=	accu_inc1	;
	else if(~inpt)			lpfs_accu	<=	accu_gt08	?	accu_dec8	:	0		;
//------------------------------------------------------------------------------

	always@(posedge clki)	lpfs_mark	<=	accu_maxi	;
	assign					lpfs		=	lpfs_mark	;

endmodule	