// address mapping:
//  itcm    e000_0000~
//  dtcm    8000_0000
//  iowr    0000_0000


module  fpga_edge_rv32_mcss  (
    output                          rv32_dmem_csen      ,
    output                          rv32_dmem_wrcs      ,
    output  [11:0]                  rv32_dmem_addr      ,
    output  [31:0]                  rv32_dmem_wdat      ,
    input   [31:0]                  rv32_dmem_rdat      ,
    input                           rv32_mclk           ,
    input                           rv32_rstn           );

    wire    [31:0]                  serv_ibus_addr      ;
    wire    [31:0]                  serv_ibus_rdat      ;
    wire                            serv_ibus_cyc       ;
    reg                             serv_ibus_ack       ;
    wire    [31:0]                  serv_dbus_addr      ;
    wire    [31:0]                  serv_dbus_wdat      ;
    wire    [ 3:0]                  serv_dbus_wsel      ;
    wire                            serv_dbus_we        ;
    wire                            serv_dbus_cyc       ;
    wire    [31:0]                  serv_dbus_rdat      ;
    reg                             serv_dbus_ack       ;


serv_rf_top                     #(
    // ROM_START_ADDRESS of ecos:link(.ld)
    .RESET_PC                       (32'he000_0000      ),
    .COMPRESSED                     (0                  ),
    .MDU                            (0                  ),
    .PRE_REGISTER                   (0                  ),
    .RESET_STRATEGY                 ("MINI"             ),
    .DEBUG                          (0                  ),
    .WITH_CSR                       (0                  ),
    .W                              (4                  ))
u_ctop                          (
    .clk                            (rv32_mclk          ),
    .i_rst                          (~rv32_rstn         ),
    .i_timer_irq                    (1'b0               ),
    .o_ibus_adr                     (serv_ibus_addr     ),
    .o_ibus_cyc                     (serv_ibus_cyc      ),
    .i_ibus_rdt                     (serv_ibus_rdat     ),
    .i_ibus_ack                     (serv_ibus_ack      ),
    .o_dbus_adr                     (serv_dbus_addr     ),
    .o_dbus_dat                     (serv_dbus_wdat     ),
    .o_dbus_sel                     (serv_dbus_wsel     ),
    .o_dbus_we                      (serv_dbus_we       ),
    .o_dbus_cyc                     (serv_dbus_cyc      ),
    .i_dbus_rdt                     (serv_dbus_rdat     ),
    .i_dbus_ack                     (serv_dbus_ack      ),
    // Extension
    .o_ext_rs1                      (),
    .o_ext_rs2                      (),
    .o_ext_funct3                   (),
    .i_ext_rd                       (32'b0              ),
    .i_ext_ready                    (1'b0               ),
    .o_mdu_valid                    ());

//------------------------------------------------------------------------------
    wire                            irom_cs             ;
	gwip_irom_4kB                   u_irom  (
    .dout                           (serv_ibus_rdat     ), 
    .clk                            (rv32_mclk          ), 
    .oce                            (1'b1               ), 
    .ce                             (irom_cs            ), 
    .reset                          (~rv32_rstn         ), 
    .ad                             (serv_ibus_addr[11:2]));

    assign  irom_cs             =   serv_ibus_cyc &(!serv_ibus_ack);
    always @(posedge rv32_mclk)     
    if(rv32_rstn === 1'b0)          serv_ibus_ack   <= 1'b0;
    else                            serv_ibus_ack   <= irom_cs;

    wire    [31:0]                  dtcm_rdat       ;
    wire                            dtcm_cs         ;
    wire                            dtcm_wcs        ;
gwip_sp                         u_dtcm  (
    .dout                           (dtcm_rdat      ), 
    .clk                            (rv32_mclk      ), 
    .oce                            (1'b1           ), 
    .ce                             (dtcm_cs        ), 
    .reset                          (~rv32_rstn     ), 
    .wre                            (serv_dbus_we   ), 
    .ad                             (serv_dbus_addr[11:2]), 
    .din                            (serv_dbus_wdat     ));

    wire                            serv_dbus_cs    ;
    assign  serv_dbus_cs        =   serv_dbus_cyc   &~serv_dbus_ack;
    wire                            serv_dtcm_cs    ;
    assign  dtcm_cs             =   serv_dbus_cs    
                                &(  serv_dbus_addr[31:28]==4'h8);
    
    assign  rv32_dmem_csen      =&{ serv_dbus_cs	,  	serv_dbus_addr[31:28]==4'h0};
    assign  rv32_dmem_wrcs      =   rv32_dmem_csen	?	serv_dbus_we    		: 0	;
    assign  rv32_dmem_addr      =   rv32_dmem_csen	?	serv_dbus_addr[13:2]	: 0	;
    assign  rv32_dmem_wdat      =   rv32_dmem_csen	?	serv_dbus_wdat  		: 0	;

    always @(posedge rv32_mclk)
    if(rv32_rstn === 1'b0)          serv_dbus_ack   <=  1'b0;
    else                            serv_dbus_ack   <=  serv_dbus_cs;
    reg                             serv_dtcm_rvld  ;
    always @(posedge rv32_mclk)
    if(rv32_rstn === 1'b0)          serv_dtcm_rvld  <=  1'b0;
    else                            serv_dtcm_rvld  <=  dtcm_cs &!serv_dbus_we;
    assign  serv_dbus_rdat      =   serv_dtcm_rvld  ?   dtcm_rdat
                                :   rv32_dmem_rdat  ;
endmodule
