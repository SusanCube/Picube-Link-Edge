//	GMSL	DAT0	:	
//
//
module  fpga_edge_rora_link(
	output		[31: 0]					rora_user_rxln_data	,
	output								rora_user_rxln_drdy	,
	output		[31: 0]					rora_ufcm_rxln_data	,
	output								rora_ufcm_rxln_drdy	,
	output								rora_ufcm_rxln_last	,

	input		[31: 0]					rora_user_txln_data	,
	input								rora_user_txln_drdy	,
	input								rora_user_txln_last	,
	output								rora_user_txln_trdy	,
	input								rora_ufcm_txln_reqs	,
	output								rora_ufcm_txln_acks	,

	output								rora_bclk			, //125MHZ//input				
	output								rora_rstn			, //input				

	input								init_lock			,
	input								init_bclk			,
	input								init_rstn			);//
/**********************************************************************************************************/
	wire								rora_spll_lock		;
	wire								rora_mixs_lock		;

	assign		rora_mixs_lock	=	&{	init_lock	,	rora_spll_lock	}	;

	lowp_filter	#(.BITW(11))		u_rora_link_user_rstn(
		.lpfs							(rora_user_rstb	),
		.inpt							(rora_mixs_lock	),
		.clki							(rora_bclk		));


    rora_link   					u_fpga_edge_rora_link(
		.roralink_user_rx_data_o        (rora_user_rxln_data    ), //output [31:0]
		.roralink_user_rx_valid_o       (rora_user_rxln_drdy    ), //output
		.roralink_user_rx_last_o        (rora_user_rxln_last    ), //output
		.roralink_user_rx_strb_o        (					    ), //output [3:0]

		.roralink_user_ufc_rx_data_o    (rora_ufcm_rxln_data    ), //output [31:0]
		.roralink_user_ufc_rx_valid_o   (rora_ufcm_rxln_drdy    ), //output
		.roralink_user_ufc_rx_last_o    (rora_ufcm_rxln_last    ), //output
		.roralink_user_ufc_rx_strb_o    (						), //output [3:0]

		.roralink_user_tx_data_i        (rora_user_txln_data    ), //input [31:0]
		.roralink_user_tx_valid_i       (rora_user_txln_drdy    ), //input
		.roralink_user_tx_last_i        (rora_user_txln_last    ), //input
		.roralink_user_tx_strb_i        (4'HF					), //input [3:0]
		.roralink_user_tx_ready_o       (rora_user_txln_trdy    ), //output
		
		.roralink_user_ufc_tx_req_i     (rora_ufcm_txln_reqs 	), //input
		.roralink_user_ufc_tx_ack_o     (rora_ufcm_txln_acks    ), //output
		.roralink_user_ufc_tx_ms_i      (3'H3					), //input [2:0]=8BYTES=2WORDS

		.roralink_gt_pcs_tx_clk_o       ( rora_bclk				), 	//output
		.roralink_user_clk_i            ( rora_bclk				), 	//input

		.roralink_channel_up_o          (rora_link_chup         ), //output
		.roralink_lane_up_o             (rora_link_lnup         ), //output
		.roralink_link_reset_o          (	), //output
		.roralink_sys_reset_o           (	), //output
		.roralink_crc_pass_fail_n_o     (	), //output
		.roralink_crc_valid_o           (	), //output
		.roralink_hard_err_o            (	), //output
		.roralink_soft_err_o            (	), //output
		.roralink_frame_err_o           (	), //output
		.roralink_gt_rx_align_link_o    (	), //output
		.roralink_gt_rx_pma_lock_o      (	), //output
		.roralink_gt_rx_k_lock_o        (	), //output
		.roralink_gt_pcs_rx_clk_o       (	), //output

		.roralink_gt_pll_lock_o         (rora_spll_lock			), //output
		.roralink_user_pll_locked_i     (rora_spll_lock			), //input
		.roralink_reset_i               (rora_user_rstb			), //input
		
		.roralink_gt_reset_i            (~init_rstn          	), 	//input
		.roralink_gt_pcs_tx_reset_i     (~init_rstn          	), 	//input
		.roralink_gt_pcs_rx_reset_i     (~init_rstn          	),	//input
		.roralink_init_clk_i            ( init_bclk				), 	//input


		
		);//input

endmodule
 

