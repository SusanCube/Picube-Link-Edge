	
	initial		begin

		wait(dvpx_rstn & cube_rstn & gmsl_rstn & init_rstn);

		#1000;
		simu_tops_info	=	"Config_OUT GMSL_Acks_Word_Indx :: 2";
		$display("Config GMSL_Acks_Word_Indx :: 2");
		rora_ocfg_edge(3,32'H2);

		#1000;
		simu_tops_info	=	"Config_OUT CUBE_IPSX_MODE :: 1";
		$display("Config CUBE_IPSX_MODE :: 1");
		rora_ocfg_edge(4,32'H1);

		#1000;
		simu_tops_info	=	"Config_OUT CUBE_IPSX_RSTN :: 3";
		$display("Config CUBE_IPSX_RSTN :: 3");
		rora_ocfg_edge(5,32'H3);

		#1000;
		simu_tops_info	=	"Config_OUT UART_Baud_Rate :: 199";
		$display("Config UART_Baud_Rate :: 199");
		rora_ocfg_edge(7,32'D199);
		
		#1000;
		simu_tops_info	=	"Config_IN GMSL_Acks_Word_Indx :: (tobe)2";
		rora_icfg_edge(3);

		#1000;
		simu_tops_info	=	"Config_IN CUBE_IPSX_MODE :: (tobe)1";
		rora_icfg_edge(4);

		#1000;
		simu_tops_info	=	"Config_IN CUBE_IPSX_RSTN :: (tobe)3";
		rora_icfg_edge(5);

		#1000;
		simu_tops_info	=	"Config_IN UART_Baud_Rate :: (tobe)199";
		rora_icfg_edge(7);
//------------------------------------------------------------------------------
		#1000;
		simu_tops_info	=	"VECT_OUT CUBE_DVP0_DDRS::@A_8000::@ROW_64::@COL_512";
		rora_odat_cube(3,32'h8000,2,64);
//------------------------------------------------------------------------------
		#1000;
		simu_tops_info	=	"VECT_OUT CUBE_DVP0_DDRS::@A_8000::@ROW_64::@COL_512";
		rora_odat_cube(3,32'h8000,32,4096);
//------------------------------------------------------------------------------
		#1000;
		simu_tops_info	=	"VECT_IN CUBE_GMSL_DDRS::@A_8000::@ROW_4::@COL_32";
		rora_idat_cube(6,32'h8000,4,32);
//------------------------------------------------------------------------------
		#1000;
		simu_tops_info	=	"VECT_IN CUBE_GMSL_DDRS::@A_8000::@ROW_17::@COL_1024";
		rora_idat_cube(6,32'h8000,17,1024);
//------------------------------------------------------------------------------
		#1000;
		simu_tops_info	=	"VECT_IN CUBE_GMSL_DDRS::@A_8000::@ROW_69::@COL_2048";
		rora_idat_cube(6,32'h8000,69,2048);
