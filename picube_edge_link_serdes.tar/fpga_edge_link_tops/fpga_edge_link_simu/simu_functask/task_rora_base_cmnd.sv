//------------------------------------------------------------------------------
	task automatic	rora_init_cmnd	;
	begin
		@(posedge rora_bclk)	begin
			link_cmnd_code	=	0;
			link_edge_dest	=	0;
			link_cube_dest	=	0;
			link_slav_addr	=	0;
			link_meta_rows	=	0;
			link_meta_cols	=	0;
			link_auxi_dat0	=	0;
			link_auxi_dat1	=	0;
			link_auxi_dat2	=	0;
			link_auxi_dat3	=	0;
		end
	end
	endtask
//------------------------------------------------------------------------------
	task automatic	rora_rx_cmnd_acks	;
	begin
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	0	;
		wait( rora_cmnd_acks_mark)	;
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	0	;
		wait(~rora_cmnd_acks_mark)	;
		
	end
	endtask
//------------------------------------------------------------------------------
	task automatic	rora_rx_cmnd_resp	;
	begin
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	0	;
		wait( rora_cmnd_resp_mark)	;
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	0	;
		wait(~rora_cmnd_resp_mark)	;
		
	end
	endtask
//------------------------------------------------------------------------------
	task automatic	rora_rx_cmnd_trdy	;
	begin
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	0	;
		wait(rora_cmnd_trdy_mark)	;
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(posedge rora_bclk)	rora_cmnd_stat_clrs	=	0	;
	end
	endtask
//------------------------------------------------------------------------------
	task automatic	rora_ocfg_edge	;
	input		[31: 0]					ocfg_addr	;
	input		[31: 0]					ocfg_data	;
	begin
		rora_init_cmnd();
		link_cmnd_code	=	"OCFG"	;
		link_edge_dest	=	"EDGE"	;
		link_auxi_dat0	=	ocfg_addr	;
		link_auxi_dat1	=	ocfg_data	;
		
		$display({`BOLD,`COFY,`BOFB,"%0t RORA_OCFG_EDGE_CMND,CFIG_DATA:%8H@%8H",`NORM},$time,ocfg_addr,ocfg_data);
		u_rora.rora_tx_cmnd_pack();
		rora_rx_cmnd_acks();
	
	end
	endtask
//------------------------------------------------------------------------------
	task automatic	rora_icfg_edge	;
	input		[31: 0]					icfg_addr	;
	begin
		rora_init_cmnd();
		link_cmnd_code	=	"ICFG"	;
		link_edge_dest	=	"EDGE"	;
		link_auxi_dat0	=	icfg_addr	;
		$display({`BOLD,`COFY,`BOFB,"%0t RORA_ICFG_EDGE_CMND,@%8H",`NORM},$time,icfg_addr);
		u_rora.rora_tx_cmnd_pack();
		rora_rx_cmnd_acks();
	end
	endtask	
//------------------------------------------------------------------------------
	task automatic	rora_odat_cube	;
		input		[31: 0]				dvpx_port	;
		input		[31: 0]				ddrs_addr	;	
		input		[31: 0]				odat_rows	;
		input		[31: 0]				odat_cols	;

		integer							i	;
		reg			[31:0]				rora_word ;
	begin
		rora_init_cmnd();

		rora_word		= {	1'B0,odat_cols[31:1]};
		$display("ODAT_WORD_SIZE::%4H",rora_word);

		link_cmnd_code	=	"OVCT"		;
		link_edge_dest	=	0			;
		link_cube_dest	=	dvpx_port	;
		link_slav_addr	=	ddrs_addr	;
		link_meta_rows	=	odat_rows	;
		link_meta_cols	=	odat_cols	;

		$display({`BOLD,`COFY,`BOFB,"%0t RORA_ODAT_CUBE_DDRS,PORT:%8H,ADDR:%8H,ROW::%4H,COL::%4H",`NORM},$time,dvpx_port,ddrs_addr,odat_rows,odat_cols);
		u_rora.rora_tx_cmnd_pack();
		rora_rx_cmnd_acks();

		for (i = 0; i < odat_rows ; i = i + 1) begin
			u_rora.rora_tx_data_pack(i,rora_word);
			rora_rx_cmnd_trdy();
		end

		rora_rx_cmnd_resp();
		
	end
	endtask	
//------------------------------------------------------------------------------
	task automatic	rora_idat_cube	;
		input		[31: 0]				gmsl_port	;
		input		[31: 0]				ddrs_addr	;	
		input		[31: 0]				idat_rows	;
		input		[31: 0]				idat_cols	;

		integer							i	;
		reg			[31:0]				rora_word ;
	begin
		rora_init_cmnd();

		rora_word		= {	1'B0,idat_cols[31:1]};
		$display("IDAT_WORD_SIZE::%4H",rora_word);

		link_cmnd_code	=	"IVCT"		;
		link_edge_dest	=	0			;
		link_cube_dest	=	gmsl_port	;
		link_slav_addr	=	ddrs_addr	;
		link_meta_rows	=	idat_rows	;
		link_meta_cols	=	idat_cols	;

		$display({`BOLD,`COFY,`BOFB,"%0t RORA_IDAT_CUBE_DDRS,PORT:%8H,ADDR:%8H,ROW::%4H,COL::%4H",`NORM},$time,gmsl_port,ddrs_addr,idat_rows,idat_cols);
		u_rora.rora_tx_cmnd_pack();
		rora_rx_cmnd_acks();

//		for (i = 0; i < odat_rows ; i = i + 1) begin
//			u_rora.rora_tx_data_pack(i,rora_word);
//			rora_rx_cmnd_trdy();
//		end

		rora_rx_cmnd_resp();
		
	end
	endtask	