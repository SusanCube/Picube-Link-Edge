`include "defs_disp_color.vh"

`timescale	1ns/1ps
module  fpga_edge_simu_tops();
	reg									fpga_rstn		;
    reg									fpga_bclk		;
	reg									gmsl_bclk		;
	reg									rora_bclk		;
	reg									rora_rstn		;
//------------------------------------------------------------------------------
	reg		[31: 0]						link_cmnd_code	;
	reg		[31: 0]						link_edge_dest	;
	reg		[31: 0]						link_cube_dest	;
	reg		[31: 0]						link_slav_addr	;
	reg		[31: 0]						link_meta_rows	;
	reg		[31: 0]						link_meta_cols	;
	reg		[31: 0]						link_auxi_dat0	;
	reg		[31: 0]						link_auxi_dat1	;
	reg		[31: 0]						link_auxi_dat2	;
	reg		[31: 0]						link_auxi_dat3	;
	
	wire	[ 0: 9][31: 0]				link_cmnd_argu	;
	assign	link_cmnd_argu[ 0]	=		link_cmnd_code	;
	assign	link_cmnd_argu[ 1]	=		link_edge_dest	;
	assign	link_cmnd_argu[ 2]	=		link_cube_dest	;
	assign	link_cmnd_argu[ 3]	=		link_slav_addr	;
	assign	link_cmnd_argu[ 4]	=		link_meta_rows	;
	assign	link_cmnd_argu[ 5]	=		link_meta_cols	;
	assign	link_cmnd_argu[ 6]	=		link_auxi_dat0	;
	assign	link_cmnd_argu[ 7]	=		link_auxi_dat1	;
	assign	link_cmnd_argu[ 8]	=		link_auxi_dat2	;
	assign	link_cmnd_argu[ 9]	=		link_auxi_dat3	;
	
	reg									rora_cmnd_stat_clrs	;
	tri0								rora_cmnd_acks_mark	;
	tri0								rora_cmnd_resp_mark	;
	tri0								rora_cmnd_trdy_mark	;
//------------------------------------------------------------------------------
	initial	begin
		rora_cmnd_stat_clrs	=	0	;

		link_cmnd_code	=	0	;
		link_edge_dest	=	0	;
		link_cube_dest	=	0	;
		link_slav_addr	=	0	;
		link_meta_rows	=	0	;
		link_meta_cols	=	0	;
		link_auxi_dat0	=	0	;
		link_auxi_dat1	=	0	;
		link_auxi_dat2	=	0	;
		link_auxi_dat3	=	0	;
	
		fpga_rstn	=	0	;
    	fpga_bclk	=	0	;
		gmsl_bclk	=	0	;
		rora_bclk	=	0	;
		rora_rstn	=	0	;
	
		#120	;
		fpga_rstn	=	1	;
		rora_rstn	=	1	;

	end

	always #10	fpga_bclk	= ~ fpga_bclk		;//125MHz
	always #4	rora_bclk	= ~ rora_bclk		;//125MHz
	always #5	gmsl_bclk	= ~ gmsl_bclk		;//100MHz
/**********************************************************************************************************************/	
	initial begin
		$display("======Begin * Dump * WaveForm====== ");
		$fsdbDumpfile("fpga_edge_simu_tops.fsdb");
		$fsdbDumpvars(0,fpga_edge_simu_tops);
		$fsdbDumpMDA();
	end
//------------------------------------------------------------------------------
	fpga_edge_clks_gens				u_fpga_clks(
    	.fpga_rstn_inpp					(fpga_rstn				),//input	
    	.fpga_bclk_inpp					(fpga_bclk				),//input	
		.dvpx_bclk_o					(dvpx_bclk				),//output	
		.dvpx_rstn_o					(dvpx_rstn				),//output	
		.cube_bclk_o					(cube_bclk				),//output	
		.cube_rstn_o					(cube_rstn				),//output	
		.gmsl_bclk_i					(gmsl_bclk				),//input	
		.gmsl_rstn_o					(gmsl_rstn				),//output	
		.init_bclk_o					(init_bclk				),//output	
		.init_rstn_o					(init_rstn				));//output	
//------------------------------------------------------------------------------
	GSR 	GSR (.GSRI (1'b1));

	
	wire								rv32_edge_dmem_csen	;
	wire								rv32_edge_dmem_wrcs	;
	wire	[11: 0]						rv32_edge_dmem_addr	;
	wire	[31: 0]						rv32_edge_dmem_wdat	;
	wire	[31: 0]						rv32_edge_dmem_rdat	;

	fpga_edge_rv32_mcss				u_fpga_rv32(
		.rv32_dmem_csen					(rv32_edge_dmem_csen	),//input			
		.rv32_dmem_wrcs					(rv32_edge_dmem_wrcs	),//input			
		.rv32_dmem_addr					(rv32_edge_dmem_addr	),//input	[11: 0]	
		.rv32_dmem_wdat					(rv32_edge_dmem_wdat	),//input	[31: 0]	
		.rv32_dmem_rdat					(rv32_edge_dmem_rdat	),//output	[31: 0]	
		.rv32_mclk						(rora_bclk				),//input			
		.rv32_rstn						(rora_rstn				));//input			
//------------------------------------------------------------------------------
	wire		[ 1: 0]					cube_ufcm_stat_port	;
	wire		[15: 0]					dvp0_pmau_data_pado	;
	wire		[15: 0]					dvp1_pmau_data_pado	;
	wire		[15: 0]					gmsl_pmau_data_padi	;
	
	behv_cube_2805					u_cube_2805(
		.cube_cmnd_reqs					(cube_ufcm_cmnd_port	),//input				
		.cube_stat_gpio					(cube_ufcm_stat_port	),//output		[1:0]	

		.dvp0_vsyn_padi					(dvp0_pmau_vsyn_pado	),//input				
		.dvp0_hsyn_padi					(dvp0_pmau_hsyn_pado	),//input				
		.dvp0_data_padi					(dvp0_pmau_data_pado	),//input		[15:0]	
		.dvp0_clki						(dvpx_bclk				),//input				//175MHZ
		.dvp0_rstn						(dvpx_rstn				),//input				

		.dvp1_vsyn_padi					(dvp1_pmau_vsyn_pado	),//input				
		.dvp1_hsyn_padi					(dvp1_pmau_hsyn_pado	),//input				
		.dvp1_data_padi					(dvp1_pmau_data_pado	),//input		[15:0]	
		.dvp1_clki						(dvpx_bclk				),//input				//175MHZ
		.dvp1_rstn						(dvpx_rstn				),//input				

		.gmsl_vsyn_pado					(gmsl_pmau_vsyn_padi	),//output				
		.gmsl_hsyn_pado					(gmsl_pmau_hsyn_padi	),//output				
		.gmsl_data_pado					(gmsl_pmau_data_padi	),//output		[15:0]	
		.gmsl_clko						(gmsl_clko				),//output				

		.cube_clki						(cube_bclk				),//input	
		.cube_rstn						(cube_rstn				));//input	
//------------------------------------------------------------------------------
	wire		[31: 0]					behv_user_rxln_data	;
	wire		[31: 0]					behv_user_txln_data	;
	wire		[31: 0]					behv_ufcm_txln_data	;

	behv_rora_txrx					u_rora(
		.rora_user_txln_data			(behv_user_txln_data	),//output		[31: 0]	
		.rora_user_txln_drdy			(behv_user_txln_drdy	),//output				
		.rora_ufcm_txln_data			(behv_ufcm_txln_data	),//output		[31: 0]	
		.rora_ufcm_txln_drdy			(behv_ufcm_txln_drdy	),//output				
		.rora_ufcm_txln_last			(behv_ufcm_txln_last	),//output				

		.rora_ufcm_rxln_reqs			(behv_ufcm_rxln_reqs	),//input				
		.rora_ufcm_rxln_acks			(behv_ufcm_rxln_acks	),//output	reg			
		.rora_user_rxln_data			(behv_user_rxln_data	),//input		[31: 0]	
		.rora_user_rxln_drdy			(behv_user_rxln_drdy	),//input				
		.rora_user_rxln_last			(behv_user_rxln_last	),//input				
		.rora_user_rxln_trdy			(behv_user_rxln_trdy	),//output	reg			

		.rora_cmnd_acks_mark			(rora_cmnd_acks_mark	),//output	reg	
		.rora_cmnd_resp_mark			(rora_cmnd_resp_mark	),//output	reg	
		.rora_cmnd_trdy_mark			(rora_cmnd_trdy_mark	),//output	reg	
		.rora_cmnd_stat_clrs			(rora_cmnd_stat_clrs	),//input		

		.rora_bclk						(rora_bclk				),//input				
		.rora_rstn						(rora_rstn				));//input				
//------------------------------------------------------------------------------
	behv_uart_txrx					u_uart(
		.uart_txdo_pado					(cube_uart_rxdi_port	),//output	reg	
		.uart_rxdi_padi					(cube_uart_txdo_port	));//input		
//------------------------------------------------------------------------------
	fpga_edge_link_core				u_fpga_edge(
		.rora_user_rxln_data			(behv_user_txln_data	),//input		[31: 0]	
		.rora_user_rxln_drdy			(behv_user_txln_drdy	),//input				
		.rora_ufcm_rxln_data			(behv_ufcm_txln_data	),//input		[31: 0]	
		.rora_ufcm_rxln_drdy			(behv_ufcm_txln_drdy	),//input				
		.rora_ufcm_rxln_last			(behv_ufcm_txln_last	),//input				

		.rora_user_txln_data			(behv_user_rxln_data	),//output		[31: 0]	
		.rora_user_txln_drdy			(behv_user_rxln_drdy	),//output				
		.rora_user_txln_last			(behv_user_rxln_last	),//output				
		.rora_user_txln_trdy			(behv_user_rxln_trdy	),//input				
		.rora_ufcm_txln_reqs			(behv_ufcm_rxln_reqs	),//output				
		.rora_ufcm_txln_acks			(behv_ufcm_rxln_acks	),//input				

		.rora_bclk						(rora_bclk				),//input //125MHZ
		.rora_rstn						(rora_rstn				),//input
//--------------------------------------
		.rv32_edge_dmem_csen			(rv32_edge_dmem_csen	),//input				
		.rv32_edge_dmem_wrcs			(rv32_edge_dmem_wrcs	),//input				
		.rv32_edge_dmem_addr			(rv32_edge_dmem_addr	),//input		[11: 0]		
		.rv32_edge_dmem_wdat			(rv32_edge_dmem_wdat	),//input		[31: 0]		
		.rv32_edge_dmem_rdat			(rv32_edge_dmem_rdat	),//output		[31: 0]		

		.cube_ispx_mode_port			(cube_ispx_mode_port	),//output	
		.cube_ispx_rstn_port			(cube_ispx_rstn_port	),//output	
		.cube_chip_rstn_port			(cube_chip_rstn_port	),//output	

		.cube_ufcm_cmnd_port			(cube_ufcm_cmnd_port	),//output				
		.cube_ufcm_stat_port			(cube_ufcm_stat_port	),//input		[ 1: 0]	

		.cube_uart_rxdi_port			(cube_uart_rxdi_port	),//input	
		.cube_uart_txdo_port			(cube_uart_txdo_port	),//output	

		.cube_bclk						(cube_bclk				),//input   //25MHZ
		.cube_rstn						(cube_rstn				),//input  
//--------------------------------------
		.dvp0_pmau_vsyn_pado			(dvp0_pmau_vsyn_pado	),			
		.dvp0_pmau_hsyn_pado			(dvp0_pmau_hsyn_pado	),
		.dvp0_pmau_data_pado			(dvp0_pmau_data_pado	),

		.dvp1_pmau_vsyn_pado			(dvp1_pmau_vsyn_pado	),			
		.dvp1_pmau_hsyn_pado			(dvp1_pmau_hsyn_pado	),
		.dvp1_pmau_data_pado			(dvp1_pmau_data_pado	),
		.dvpx_bclk						(dvpx_bclk				), //150~200MHZ
		.dvpx_rstn						(dvpx_rstn				),

		.gmsl_pmau_vsyn_padi			(gmsl_pmau_vsyn_padi	),//input				
		.gmsl_pmau_hsyn_padi			(gmsl_pmau_hsyn_padi	),//input				
		.gmsl_pmau_data_padi			(gmsl_pmau_data_padi	),//input		[15: 0]	
		.gmsl_bclk						(gmsl_bclk				),//input				 //80~90MHZ
		.gmsl_rstn						(gmsl_rstn				));//input				

/******************************************************************************/
//BEGIN	DECLARE SIMU_PATTERN

//------------------------------------------------------------------------------
	task	rora_rx_cmnd_acks	;
	begin
		@(rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(rora_bclk)	rora_cmnd_stat_clrs	=	0	;
		wait(rora_cmnd_acks_mark)	;
		@(rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(rora_bclk)	rora_cmnd_stat_clrs	=	0	;
	end
	endtask
//------------------------------------------------------------------------------
	task	rora_rx_cmnd_resp	;
	begin
		@(rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(rora_bclk)	rora_cmnd_stat_clrs	=	0	;
		wait(rora_cmnd_resp_mark)	;
		@(rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(rora_bclk)	rora_cmnd_stat_clrs	=	0	;
	end
	endtask
//------------------------------------------------------------------------------
	task	rora_rx_cmnd_trdy	;
	begin
		@(rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(rora_bclk)	rora_cmnd_stat_clrs	=	0	;
		wait(rora_cmnd_trdy_mark)	;
		@(rora_bclk)	rora_cmnd_stat_clrs	=	1	;
		@(rora_bclk)	rora_cmnd_stat_clrs	=	0	;
	end
	endtask
//------------------------------------------------------------------------------
	task	rora_ocfg_edge_cmnd	;
	input	[31: 0]		ocfg_addr	;
	input	[31: 0]		ocfg_data	;
	begin
		link_cmnd_code	=	"OCFG"	;
		link_edge_dest	=	"EDGE"	;
		link_auxi_dat0	=	ocfg_addr	;
		link_auxi_dat0	=	ocfg_data	;
		
		$display({`BOLD,`COFY,`BOFB,"%0t RORA_OCFG_EDGE_CMND,CFIG_DATA:%8H@%8H",`NORM},$time,ocfg_addr,ocfg_data);
		u_rora.rora_tx_cmnd_pack(link_cmnd_argu);
		rora_rx_cmnd_acks();
	
	end
	endtask

//------------------------------------------------------------------------------
	task	rora_icfg_edge_cmnd	;
	input	[31: 0]		icfg_addr	;
	begin
		link_cmnd_code	=	"ICFG"	;
		link_edge_dest	=	"EDGE"	;
		link_auxi_dat0	=	icfg_addr	;
		$display({`BOLD,`COFY,`BOFB,"%0t RORA_ICFG_EDGE_CMND,@%8H",`NORM},$time,icfg_addr);
		u_rora.rora_tx_cmnd_pack(link_cmnd_argu);
		rora_rx_cmnd_acks();
	
	end
	endtask	

	
	initial		begin
		#1000;
		rora_ocfg_edge_cmnd(4,333);
		#1000;
		rora_icfg_edge_cmnd(4);
	



	$display({`BOLD,`COFR,"%0t	***************Simuation Done ********************",`NORM},$time);
	end //STIM_PATTERN END


endmodule	