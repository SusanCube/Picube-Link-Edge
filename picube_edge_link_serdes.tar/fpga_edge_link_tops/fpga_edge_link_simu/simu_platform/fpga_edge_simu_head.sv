`include "defs_disp_color.vh"

`timescale	1ns/1ps
module  fpga_edge_simu_tops();
	reg									run_ustclk	;
	reg 	[31:0] 						run_ustime	;
	reg 	[31:0] 						run_ustset	;

	wire		run_ustmax	=	run_ustime	==	run_ustset	;						
	integer		param_ok	;

initial begin
    run_ustset = 32'd1000;

    $display("[DEBUG] test PARAM = %0d", $test$plusargs("PARAM"));

    param_ok = $value$plusargs("PARAM=%d", run_ustset);

    $display("[DEBUG] value PARAM status = %0d, run_ustset = %0d",
             param_ok, run_ustset);

    run_ustclk = 0;
    run_ustime = 0;

    #10;
    wait(run_ustmax);
    $display({`BOLD,`COFY,`BOFR,
              "[TOP] Forcefully Stop_simulation By_Timer_limit %0d_us",`NORM},
             run_ustset);
    $finish();
	
end

	always #500	run_ustclk	= ~ run_ustclk		;//1MHz
	always@(posedge run_ustclk)			run_ustime	<=	run_ustime + 1	;

//------------------------------------------------------------------------------
	reg		[511:0]						simu_tops_info	;
//------------------------------------------------------------------------------
	reg									fpga_rstn		;
    reg									fpga_bclk		;
	reg									rora_bclk		;
	reg									rora_rstn		;
//------------------------------------------------------------------------------
	reg		[31: 0]						link_cmnd_code	;
	reg		[31: 0]						link_edge_dest	;
	reg		[31: 0]						link_cube_dest	;
	reg		[31: 0]						link_slav_addr	;
	reg		[31: 0]						link_meta_rows	;
	reg		[31: 0]						link_meta_cols	;
	reg		[31: 0]						link_auxi_dat0	;
	reg		[31: 0]						link_auxi_dat1	;
	reg		[31: 0]						link_auxi_dat2	;
	reg		[31: 0]						link_auxi_dat3	;

	wire	[ 0: 9][31: 0]				rora_link_cmnd_argu	;
	assign	rora_link_cmnd_argu[ 0]	=	link_cmnd_code	;
	assign	rora_link_cmnd_argu[ 1]	=	link_edge_dest	;
	assign	rora_link_cmnd_argu[ 2]	=	link_cube_dest	;
	assign	rora_link_cmnd_argu[ 3]	=	link_slav_addr	;
	assign	rora_link_cmnd_argu[ 4]	=	link_meta_rows	;
	assign	rora_link_cmnd_argu[ 5]	=	link_meta_cols	;
	assign	rora_link_cmnd_argu[ 6]	=	link_auxi_dat0	;
	assign	rora_link_cmnd_argu[ 7]	=	link_auxi_dat1	;
	assign	rora_link_cmnd_argu[ 8]	=	link_auxi_dat2	;
	assign	rora_link_cmnd_argu[ 9]	=	link_auxi_dat3	;
	
	reg									rora_cmnd_stat_clrs	;
	tri0								rora_cmnd_acks_mark	;
	tri0								rora_cmnd_resp_mark	;
	tri0								rora_cmnd_trdy_mark	;
//------------------------------------------------------------------------------
	initial	begin
		simu_tops_info		=	"INIT SIMULATION"	;
		rora_cmnd_stat_clrs	=	0	;

		link_cmnd_code	=	0	;
		link_edge_dest	=	0	;
		link_cube_dest	=	0	;
		link_slav_addr	=	0	;
		link_meta_rows	=	0	;
		link_meta_cols	=	0	;
		link_auxi_dat0	=	0	;
		link_auxi_dat1	=	0	;
		link_auxi_dat2	=	0	;
		link_auxi_dat3	=	0	;
	
		fpga_rstn	=	0	;
    	fpga_bclk	=	0	;
		rora_bclk	=	0	;
		rora_rstn	=	0	;
	
		#120	;
		fpga_rstn	=	1	;
		rora_rstn	=	1	;

	end

	always #10	fpga_bclk	= ~ fpga_bclk		;// 50MHz
	always #4	rora_bclk	= ~ rora_bclk		;//125MHz
/**********************************************************************************************************************/	
	initial begin
		$display("======Begin * Dump * WaveForm====== ");
		$fsdbDumpfile("fpga_edge_simu_tops.fsdb");
		$fsdbDumpvars(0,fpga_edge_simu_tops);
		$fsdbDumpMDA();
	end
//------------------------------------------------------------------------------
	wire								gmsl_bclk	;

	fpga_edge_clks_gens				u_fpga_clks(
    	.fpga_rstn_inpp					(fpga_rstn				),//input	
    	.fpga_bclk_inpp					(fpga_bclk				),//input	
		.dvpx_bclk_o					(dvpx_bclk				),//output	
		.dvpx_rstn_o					(dvpx_rstn				),//output	
		.cube_bclk_o					(cube_bclk				),//output	
		.cube_rstn_o					(cube_rstn				),//output	
		.gmsl_bclk_i					(gmsl_bclk				),//input	
		.gmsl_rstn_o					(gmsl_rstn				),//output	
		.init_bclk_o					(init_bclk				),//output	
		.init_rstn_o					(init_rstn				));//output	
//------------------------------------------------------------------------------
	GSR 	GSR (.GSRI (1'b1));

	
	wire								rv32_edge_dmem_csen	;
	wire								rv32_edge_dmem_wrcs	;
	wire	[11: 0]						rv32_edge_dmem_addr	;
	wire	[31: 0]						rv32_edge_dmem_wdat	;
	wire	[31: 0]						rv32_edge_dmem_rdat	;

	fpga_edge_rv32_mcss				u_fpga_rv32(
		.rv32_dmem_csen					(rv32_edge_dmem_csen	),//input			
		.rv32_dmem_wrcs					(rv32_edge_dmem_wrcs	),//input			
		.rv32_dmem_addr					(rv32_edge_dmem_addr	),//input	[11: 0]	
		.rv32_dmem_wdat					(rv32_edge_dmem_wdat	),//input	[31: 0]	
		.rv32_dmem_rdat					(rv32_edge_dmem_rdat	),//output	[31: 0]	
		.rv32_mclk						(rora_bclk				),//input			
		.rv32_rstn						(rora_rstn				));//input			
    defparam                        fpga_edge_simu_tops.u_fpga_rv32.u_ctop.DEBUG = 1;
    reg     [31:0]                      tmem[0:8192];
    initial begin
        $readmemh("code.hex",tmem);
        for(int i=0; i<1024; i=i+1) begin
            u_fpga_rv32.u_irom.prom_inst_0.ram_MEM[i*16 +:16] = tmem[i][15:0 ];
            u_fpga_rv32.u_irom.prom_inst_1.ram_MEM[i*16 +:16] = tmem[i][31:16];
        end
    end
//------------------------------------------------------------------------------
	wire		[ 1: 0]					cube_ufcm_stat_port	;
	wire		[15: 0]					dvp0_pmau_data_pado	;
	wire		[15: 0]					dvp1_pmau_data_pado	;
	wire		[15: 0]					gmsl_pmau_data_padi	;
	
	behv_cube_2805					u_cube_2805(
		.cube_cmnd_reqs					(cube_ufcm_cmnd_port	),//input				
		.cube_stat_gpio					(cube_ufcm_stat_port	),//output		[1:0]	

		.dvp0_vsyn_padi					(dvp0_pmau_vsyn_pado	),//input				
		.dvp0_hsyn_padi					(dvp0_pmau_hsyn_pado	),//input				
		.dvp0_data_padi					(dvp0_pmau_data_pado	),//input		[15:0]	
		.dvp0_clki						(dvpx_bclk				),//input				//175MHZ
		.dvp0_rstn						(dvpx_rstn				),//input				

		.dvp1_vsyn_padi					(dvp1_pmau_vsyn_pado	),//input				
		.dvp1_hsyn_padi					(dvp1_pmau_hsyn_pado	),//input				
		.dvp1_data_padi					(dvp1_pmau_data_pado	),//input		[15:0]	
		.dvp1_clki						(dvpx_bclk				),//input				//175MHZ
		.dvp1_rstn						(dvpx_rstn				),//input				

		.gmsl_vsyn_pado					(gmsl_pmau_vsyn_padi	),//output				
		.gmsl_hsyn_pado					(gmsl_pmau_hsyn_padi	),//output				
		.gmsl_data_pado					(gmsl_pmau_data_padi	),//output		[15:0]	
		.gmsl_clko						(gmsl_bclk				),//output				

		.cube_clki						(dvpx_bclk				),//input	
		.cube_rstn						(dvpx_rstn				));//input	
//------------------------------------------------------------------------------
	wire		[31: 0]					behv_user_rxln_data	;
	wire		[31: 0]					behv_ufcm_rxln_data	;
	wire		[31: 0]					behv_user_txln_data	;

	behv_rora_txrx					u_rora(
		.behv_user_rxln_data			(behv_user_rxln_data	),//output		[31: 0]	
		.behv_user_rxln_drdy			(behv_user_rxln_drdy	),//output				
		.behv_ufcm_rxln_data			(behv_ufcm_rxln_data	),//output		[31: 0]	
		.behv_ufcm_rxln_drdy			(behv_ufcm_rxln_drdy	),//output				
		.behv_ufcm_rxln_last			(behv_ufcm_rxln_last	),//output				

		.behv_ufcm_txln_reqs			(behv_ufcm_txln_reqs	),//input				
		.behv_ufcm_txln_acks			(behv_ufcm_txln_acks	),//output	reg			
		.behv_user_txln_data			(behv_user_txln_data	),//input		[31: 0]	
		.behv_user_txln_drdy			(behv_user_txln_drdy	),//input				
		.behv_user_txln_last			(behv_user_txln_last	),//input				
		.behv_user_txln_trdy			(behv_user_txln_trdy	),//output	reg			

		.rora_cmnd_acks_mark			(rora_cmnd_acks_mark	),//output	reg	
		.rora_cmnd_resp_mark			(rora_cmnd_resp_mark	),//output	reg	
		.rora_cmnd_trdy_mark			(rora_cmnd_trdy_mark	),//output	reg	
		.rora_cmnd_stat_clrs			(rora_cmnd_stat_clrs	),//input		

		.rora_link_cmnd_argu			(rora_link_cmnd_argu			),

		.rora_bclk						(rora_bclk				),//input				
		.rora_rstn						(rora_rstn				));//input				
//------------------------------------------------------------------------------
	behv_uart_txrx					u_uart(
		.uart_txdo_pado					(cube_uart_rxdi_port	),//output	reg	
		.uart_rxdi_padi					(cube_uart_txdo_port	));//input		
//------------------------------------------------------------------------------
	fpga_edge_link_core				u_fpga_edge(
		.rora_user_rxln_data			(behv_user_rxln_data	),//input		[31: 0]	
		.rora_user_rxln_drdy			(behv_user_rxln_drdy	),//input				
		.rora_ufcm_rxln_data			(behv_ufcm_rxln_data	),//input		[31: 0]	
		.rora_ufcm_rxln_drdy			(behv_ufcm_rxln_drdy	),//input				
		.rora_ufcm_rxln_last			(behv_ufcm_rxln_last	),//input				

		.rora_ufcm_txln_reqs			(behv_ufcm_txln_reqs	),//output				
		.rora_ufcm_txln_acks			(behv_ufcm_txln_acks	),//input				
		.rora_user_txln_data			(behv_user_txln_data	),//output		[31: 0]	
		.rora_user_txln_drdy			(behv_user_txln_drdy	),//output				
		.rora_user_txln_last			(behv_user_txln_last	),//output				
		.rora_user_txln_trdy			(behv_user_txln_trdy	),//input				

		.rora_bclk						(rora_bclk				),//input //125MHZ
		.rora_rstn						(rora_rstn				),//input
//--------------------------------------
		.rv32_edge_dmem_csen			(rv32_edge_dmem_csen	),//input				
		.rv32_edge_dmem_wrcs			(rv32_edge_dmem_wrcs	),//input				
		.rv32_edge_dmem_addr			(rv32_edge_dmem_addr	),//input		[11: 0]		
		.rv32_edge_dmem_wdat			(rv32_edge_dmem_wdat	),//input		[31: 0]		
		.rv32_edge_dmem_rdat			(rv32_edge_dmem_rdat	),//output		[31: 0]		

		.cube_ispx_mode_port			(cube_ispx_mode_port	),//output	
		.cube_ispx_rstn_port			(cube_ispx_rstn_port	),//output	
		.cube_chip_rstn_port			(cube_chip_rstn_port	),//output	

		.cube_ufcm_cmnd_port			(cube_ufcm_cmnd_port	),//output				
		.cube_ufcm_stat_port			(cube_ufcm_stat_port	),//input		[ 1: 0]	

		.cube_uart_rxdi_port			(cube_uart_rxdi_port	),//input	
		.cube_uart_txdo_port			(cube_uart_txdo_port	),//output	

		.cube_bclk						(cube_bclk				),//input   //25MHZ
		.cube_rstn						(cube_rstn				),//input  
//--------------------------------------
		.dvp0_pmau_vsyn_pado			(dvp0_pmau_vsyn_pado	),			
		.dvp0_pmau_hsyn_pado			(dvp0_pmau_hsyn_pado	),
		.dvp0_pmau_data_pado			(dvp0_pmau_data_pado	),

		.dvp1_pmau_vsyn_pado			(dvp1_pmau_vsyn_pado	),			
		.dvp1_pmau_hsyn_pado			(dvp1_pmau_hsyn_pado	),
		.dvp1_pmau_data_pado			(dvp1_pmau_data_pado	),
		.dvpx_bclk						(dvpx_bclk				), //150~200MHZ
		.dvpx_rstn						(dvpx_rstn				),

		.gmsl_pmau_vsyn_padi			(gmsl_pmau_vsyn_padi	),//input				
		.gmsl_pmau_hsyn_padi			(gmsl_pmau_hsyn_padi	),//input				
		.gmsl_pmau_data_padi			(gmsl_pmau_data_padi	),//input		[15: 0]	
		.gmsl_bclk						(gmsl_bclk				),//input				 //80~90MHZ
		.gmsl_rstn						(gmsl_rstn				));//input				

/******************************************************************************/
//BEGIN	DECLARE SIMU_PATTERN

