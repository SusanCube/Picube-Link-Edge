#!/bin/csh
clear

if ($#argv >= 1) then
    set SIM_PARAM = $1
else
    set SIM_PARAM = 1000
endif
echo "Simulation parameter = $SIM_PARAM"


echo "\e[34m__________________________________________________________________________"
echo "Please Enter the parameters in the following Order:: 				"
echo "--1 PATN_NAME -> Specify Simulation Pattern Nme"
echo "__________________________________________________________________________\e[0m"
echo

setenv		PROJ_HOME		/home/home1/yangxg/X88/FPGA_GAPU_LINK_TOPS
setenv		RSRC_HOME		$PROJ_HOME/rsrc

setenv		FMWR_HOME		$RSRC_HOME/fpga_edge_link_tops/fpga_edge_link_ecos/ecos_edge
setenv		BEHV_HOME		$RSRC_HOME/fpga_edge_link_tops/fpga_edge_link_simu/simu_behavior
setenv		PLAT_HOME		$RSRC_HOME/fpga_edge_link_tops/fpga_edge_link_simu/simu_platform
setenv		TASK_HOME		$RSRC_HOME/fpga_edge_link_tops/fpga_edge_link_simu/simu_functask
setenv		STIM_HOME		$RSRC_HOME/fpga_edge_link_tops/fpga_edge_link_simu/simu_stimulus


cp -f	$FMWR_HOME/code.hex 	./

#cp -f	$FMWR_HOME/tpuc_bios/code.hex 	./init_file/tpgs_rv32_crom.hex

cat $PLAT_HOME/fpga_edge_simu_head.sv	\
	$TASK_HOME/task_rora_base_cmnd.sv	\
	$STIM_HOME/stim_rora_base_cmnd.sv	\
	$PLAT_HOME/fpga_edge_simu_tail.sv	>	./fpga_edge_simu_tops.sv

echo  	"\n========================================================================================================"
echo  	"\e[36m Do You Want Remove PreCompiled Database? \e[0m"
echo  	"\e[36m ---------------------------------------y(remove) or n(Keep) \e[0m"
echo  	"========================================================================================================"

set		choice=$<
if( "$choice" == "y") then
  	rm -rf ./csrc *.log  ./simv* ./AN.DB  *.fsdb*  novas.* u* v* w*
else 
endif 

echo  	"\n========================================================================================================"
echo  	"\e[33m Run Verilog Compiler or Waveform load  ? \e[0m"
echo  	"\e[33m ---------------------------------------w(WaveForm LOAD) or c(compile) \e[0m"
echo  	"========================================================================================================"


set		choice=$<
if( "$choice" == "w") then
  	make VERDI
else 
	make FULL SIM_PARAM=$SIM_PARAM
endif 



