
    #10000ns;
	$display({`BOLD,`COFR,"%0t	***************Simuation Done ********************",`NORM},$time);

	$finish;
	end //STIM_PATTERN END



endmodule	
