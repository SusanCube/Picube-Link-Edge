`timescale	1ns/1ps
module	behv_dvpx_rxdi(
	input							dvpx_intf_indx		,
	input							dvpx_vsyn_padi		,
	input							dvpx_hsyn_padi		,
	input		[15:0]				dvpx_data_padi		,
	
	input							dvpx_port_enab		,
	input							dvpx_odat_disa		,	
	input							dvpx_odat_reqs		,
	output							dvpx_odat_done		,
	
	input		[31:0]				dvpx_odat_rows		,
	input		[31:0]				dvpx_odat_cols		,
	
	input							dvpx_clki			,
	input							dvpx_rstn			);
/**********************************************************************/
	reg								dvpx_hsyn_sync		;
	wire	dvpx_hsyn_rise	=	&{	dvpx_hsyn_padi	, ~dvpx_hsyn_sync}	;
	wire	dvpx_hsyn_fall	=	&{ ~dvpx_hsyn_padi	,  dvpx_hsyn_sync}	;
	
	always@(posedge dvpx_clki or negedge dvpx_rstn)	
	if(~dvpx_rstn)					dvpx_hsyn_sync	<=	0	;
	else							dvpx_hsyn_sync	<=	dvpx_hsyn_padi	;
//----------------------------------------------------------------------
	reg								odat_real_csen	;

	wire	odat_real_reqs	= &{dvpx_port_enab	,	dvpx_odat_reqs	}	; 	
	
	always@(posedge dvpx_clki or negedge dvpx_rstn)	
	if(~dvpx_rstn)					odat_real_csen	<=	0	;
	else if( dvpx_odat_disa)		odat_real_csen	<=	0	;
	else if( odat_real_reqs)		odat_real_csen	<=	1	;
	else if( dvpx_odat_done)		odat_real_csen	<=	0	;
//----------------------------------
	reg			[31:0]				odat_rows_cnts	;
	reg			[31:0]				odat_cols_cnts	;
	
	always@(posedge dvpx_clki or negedge dvpx_rstn)	
	if(~dvpx_rstn)					odat_rows_cnts	<=	0	;
	else if(~odat_real_csen)		odat_rows_cnts	<=	0	;
	else if( dvpx_hsyn_fall)		odat_rows_cnts	<=	1 +	odat_rows_cnts	;
	
	always@(posedge dvpx_clki or negedge dvpx_rstn)	
	if(~dvpx_rstn)					odat_cols_cnts	<=	0	;
	else if(~odat_real_csen)		odat_cols_cnts	<=	0	;
	else if(~dvpx_hsyn_padi)		odat_cols_cnts	<=	0	;
	else 							odat_cols_cnts	<=	1 + odat_cols_cnts	;
//----------------------------------
	assign	dvpx_odat_done	= &{	odat_real_csen	,	
									odat_rows_cnts+1==	dvpx_odat_rows	,
									odat_cols_cnts+1==	dvpx_odat_cols	};	
/**********************************************************************/
	wire	dvpx_recv_time	=	odat_real_csen&dvpx_hsyn_padi	;
	always@(posedge dvpx_clki )	
	if(dvpx_recv_time&dvpx_intf_indx)
		$display("\t\t\t\t\t----DVP1 DI::%H,R%H_C%H",dvpx_data_padi,odat_rows_cnts,odat_cols_cnts)	;
	else if(dvpx_recv_time)
		$display("--DVP0 DI::%H,R%H_C%H",dvpx_data_padi,odat_rows_cnts,odat_cols_cnts)	;


/**********************************************************************/
endmodule

	


