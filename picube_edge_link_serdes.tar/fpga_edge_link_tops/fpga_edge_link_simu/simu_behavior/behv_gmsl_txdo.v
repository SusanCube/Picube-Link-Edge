`timescale	1ns/1ps
/**********************************************************************/
module	behv_gmsl_txdo(
	output	reg							gmsl_vsyn_pado		,
	output	reg							gmsl_hsyn_pado		,
	output	reg	[15:0]					gmsl_data_pado		,
	output	reg							gmsl_clko			,
		
	input								gmsl_port_enab		,
	input								gmsl_idat_disa		,	
	input								gmsl_icfg_reqs		,
	output								gmsl_icfg_done		,
	input								gmsl_idat_reqs		,
	output								gmsl_idat_done		,
		
	input		[31:0]					gmsl_idat_rows		,
	input		[31:0]					gmsl_idat_cols		,
	
	input								dvpx_clki			,
	input								gmsl_rstn			);
/**********************************************************************/
	always@(posedge dvpx_clki or negedge gmsl_rstn)	
	if(~gmsl_rstn)					gmsl_clko	<=	0	;
	else							gmsl_clko	<= ~gmsl_clko	;
/**********************************************************************/
	reg			[ 3: 0]				gmsl_link_mfsm	;

	parameter	GMSL_LINK_IDLE	=	4'H0	;
	parameter	GMSL_ICFG_VSYN	=	4'H1	;
	parameter	GMSL_ICFG_VMUT	=	4'H2	;
	parameter	GMSL_ICFG_HSYN	=	4'H3	;
	parameter	GMSL_ICFG_DONE	=	4'H4	;
	parameter	GMSL_IDAT_VSYN	=	4'H5	;
	parameter	GMSL_IDAT_VMUT	=	4'H6	;
	parameter	GMSL_IDAT_HSYN	=	4'H7	;
	parameter	GMSL_IDAT_HMUT	=	4'H8	;
	parameter	GMSL_IDAT_NEXT	=	4'H9	;
	parameter	GMSL_IDAT_DONE	=	4'HA	;

	wire		gmsl_link_idle	=	gmsl_link_mfsm	==	GMSL_LINK_IDLE	;
	wire		gmsl_icfg_vsyn	=	gmsl_link_mfsm	==	GMSL_ICFG_VSYN	;
	wire		gmsl_icfg_vmut	=	gmsl_link_mfsm	==	GMSL_ICFG_VMUT	;
	wire		gmsl_icfg_hsyn	=	gmsl_link_mfsm	==	GMSL_ICFG_HSYN	;
	assign		gmsl_icfg_done	=	gmsl_link_mfsm	==	GMSL_ICFG_DONE	;

	wire		gmsl_idat_vsyn	=	gmsl_link_mfsm	==	GMSL_IDAT_VSYN	;
	wire		gmsl_idat_vmut	=	gmsl_link_mfsm	==	GMSL_IDAT_VMUT	;
	wire		gmsl_idat_hsyn	=	gmsl_link_mfsm	==	GMSL_IDAT_HSYN	;
	wire		gmsl_idat_hmut	=	gmsl_link_mfsm	==	GMSL_IDAT_HMUT	;
	wire		gmsl_idat_next	=	gmsl_link_mfsm	==	GMSL_IDAT_NEXT	;
	assign		gmsl_idat_done	=	gmsl_link_mfsm	==	GMSL_IDAT_DONE	;
/**********************************************************************************************************/
	reg			[ 5: 0]				gmsl_mute_cnts	;
	reg			[31: 0]				gmsl_vsyn_cnts	;
	reg			[31: 0]				gmsl_hsyn_cnts	;
	reg			[31: 0]				gmsl_rows_cnts	;
	
	wire		[31: 0]				gmsl_hsyn_numb	=	gmsl_icfg_hsyn	?	32'D07	:	gmsl_idat_cols	;			

	wire	gmsl_mute_last		=	gmsl_mute_cnts	==	 6'D15			;
	wire	gmsl_vsyn_last		=	gmsl_vsyn_cnts	==	32'D16			;
	wire	gmsl_hsyn_last		=	gmsl_hsyn_cnts	==	gmsl_hsyn_numb-1;
	wire	gmsl_rows_last		=	gmsl_rows_cnts	==	gmsl_idat_rows	;
//----------------------------------------------------------------------
	always@(posedge gmsl_clko or negedge gmsl_rstn)	
	if(~gmsl_rstn)					gmsl_mute_cnts	<=	0	;
	else if( gmsl_icfg_vmut)		gmsl_mute_cnts	<=	1 + gmsl_mute_cnts	;
	else if( gmsl_idat_vmut)		gmsl_mute_cnts	<=	1 + gmsl_mute_cnts	;
	else if( gmsl_idat_hmut)		gmsl_mute_cnts	<=	1 + gmsl_mute_cnts	;
	else							gmsl_mute_cnts	<=	0	;
	
	always@(posedge gmsl_clko or negedge gmsl_rstn)	
	if(~gmsl_rstn)					gmsl_vsyn_cnts	<=	0	;
	else if( gmsl_vsyn_pado)		gmsl_vsyn_cnts	<=	1 + gmsl_vsyn_cnts	;
	else							gmsl_vsyn_cnts	<=	0	;

	always@(posedge gmsl_clko or negedge gmsl_rstn)	
	if(~gmsl_rstn)					gmsl_hsyn_cnts	<=	0	;
	else if( gmsl_icfg_hsyn)		gmsl_hsyn_cnts	<=	1 + gmsl_hsyn_cnts	;
	else if( gmsl_idat_hsyn)		gmsl_hsyn_cnts	<=	1 + gmsl_hsyn_cnts	;
	else							gmsl_hsyn_cnts	<=	0	;

	always@(posedge gmsl_clko or negedge gmsl_rstn)	
	if(~gmsl_rstn)					gmsl_rows_cnts	<=	0	;
	else if( gmsl_link_idle)		gmsl_rows_cnts	<=	0	;
	else if( gmsl_idat_hmut)		gmsl_rows_cnts	<=	gmsl_mute_last + gmsl_rows_cnts	;
/**********************************************************************************************************/
	assign	gmsl_vsyn_pado		= |{gmsl_icfg_vsyn	,	gmsl_idat_vsyn	};
	assign	gmsl_hsyn_pado		= |{gmsl_icfg_hsyn	,	gmsl_idat_hsyn	};
	assign	gmsl_data_pado		=	gmsl_icfg_vsyn	?	16'H5A5A	:
									gmsl_idat_vsyn	?	16'HA5A5	:
									gmsl_icfg_hsyn	?	16'H9696	:
									gmsl_idat_hsyn	?	gmsl_hsyn_cnts	:	16'H0	;
									
	wire	cube_icfg_reqs		=&{	gmsl_port_enab	,	gmsl_icfg_reqs	};
	wire	cube_idat_reqs		=&{	gmsl_port_enab	,	gmsl_idat_reqs	};
/***********************************************************************************************************/
	always@(posedge gmsl_clko or negedge gmsl_rstn)	
	if(~gmsl_rstn)					gmsl_link_mfsm	<=	GMSL_LINK_IDLE	;
	else if(gmsl_idat_disa)			gmsl_link_mfsm	<=	GMSL_LINK_IDLE	;
	else	begin
		case(gmsl_link_mfsm)
			GMSL_LINK_IDLE	:	gmsl_link_mfsm	<=	cube_icfg_reqs	?	GMSL_ICFG_VSYN	:
													cube_idat_reqs	?	GMSL_IDAT_VSYN	:	GMSL_LINK_IDLE	;

			GMSL_ICFG_VSYN	:	gmsl_link_mfsm	<=	gmsl_vsyn_last	?	GMSL_ICFG_VMUT	:	GMSL_ICFG_VSYN	;
			GMSL_ICFG_VMUT	:	gmsl_link_mfsm	<=	gmsl_mute_last	?	GMSL_ICFG_HSYN	:	GMSL_ICFG_VMUT	;
			GMSL_ICFG_HSYN	:	gmsl_link_mfsm	<=	gmsl_hsyn_last	?	GMSL_ICFG_DONE	:	GMSL_ICFG_HSYN	;
			GMSL_ICFG_DONE	:	gmsl_link_mfsm	<=											GMSL_LINK_IDLE	;

			GMSL_IDAT_VSYN	:	gmsl_link_mfsm	<=	gmsl_vsyn_last	?	GMSL_IDAT_VMUT	:	GMSL_IDAT_VSYN	;
			GMSL_IDAT_VMUT	:	gmsl_link_mfsm	<=	gmsl_mute_last	?	GMSL_IDAT_HSYN	:	GMSL_IDAT_VMUT	;
			GMSL_IDAT_HSYN	:	gmsl_link_mfsm	<=	gmsl_hsyn_last	?	GMSL_IDAT_HMUT	:	GMSL_IDAT_HSYN	;
			GMSL_IDAT_HMUT	:	gmsl_link_mfsm	<=	gmsl_mute_last	?	GMSL_IDAT_NEXT	:	GMSL_IDAT_HMUT	;
			GMSL_IDAT_NEXT	:	gmsl_link_mfsm	<=	gmsl_rows_last	?	GMSL_IDAT_DONE	:	GMSL_IDAT_HSYN	;
			GMSL_IDAT_DONE	:	gmsl_link_mfsm	<=											GMSL_LINK_IDLE	;
			default			:	gmsl_link_mfsm	<=											GMSL_LINK_IDLE	;
		endcase
	end

/***********************************************************************************************************/

endmodule




