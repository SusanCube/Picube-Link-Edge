//**********************************************************************************************************
//**********************************************************************************************************
`include	"agile_card_vars.vh"

`timescale 1ns/100fs
module	tpem_simu_top();

	reg			[0:8][31:0]			cmnd_memo		;
	reg			[31:0]				simu_step		;

	reg								tpem_fclk		;
	reg								tpem_mclk		;
	reg								tpem_sclk		;
	reg								tpem_rstn		;
	reg			[3:0]				fclk_shft		;
	wire		tpem_strb	=		fclk_shft[0]	;
	
	always #1.5625	tpem_fclk	= ~ tpem_fclk		;
	
	always@(posedge tpem_fclk)		tpem_mclk	<= ~	tpem_mclk	;
	always@(posedge tpem_mclk)		tpem_sclk	<= ~	tpem_sclk	;
	
	
	always@(posedge tpem_fclk or negedge tpem_rstn)
	if(~tpem_rstn)					fclk_shft	<=	4'H8	;
	else							fclk_shft	<={	fclk_shft[0],fclk_shft[3:1]	};

	initial		begin
		cmnd_memo[0]	=	0	;
		cmnd_memo[1]	=	0	;
		cmnd_memo[2]	=	0	;
		cmnd_memo[3]	=	0	;
		cmnd_memo[4]	=	0	;
		cmnd_memo[5]	=	0	;
		cmnd_memo[6]	=	0	;
		cmnd_memo[7]	=	0	;
		cmnd_memo[8]	=	0	;

		simu_step		=	0	;	

		tpem_fclk	=	0	;
		tpem_mclk	=	0	;
		tpem_sclk	=	0	;
		tpem_rstn	=	0	;
		fclk_shft	=	0	;
	#17	;
		tpem_rstn	=	1	;
	end

	parameter	CUBE_IDLE	=	0	;
	parameter	CUBE_ACKS	=	1	;
	parameter	CUBE_RESP	=	2	;
	parameter	CUBE_BUSY	=	3	;

/**********************************************************************************************************/	

	initial begin
		$display("======Begin * Dump * WaveForm====== ");
		$fsdbDumpfile("tpem_simu_top.fsdb");
		$fsdbDumpvars(0,tpem_simu_top);
		$fsdbDumpMDA();
	end

/***********************************************************************************************************/
	wire							rv32_dmem_csen	;
	wire							rv32_dmem_wrcs	;
	wire		[ 7: 0]				rv32_dmem_addr	;
	wire		[31: 0]				rv32_dmem_wout	;
	wire		[31: 0]				rv32_dmem_rdin	;

	rv32_core_behv				u_tpem_rv32(
		.rv32_dmem_csen				(rv32_dmem_csen			),//output				
		.rv32_dmem_wrcs				(rv32_dmem_wrcs			),//output				
		.rv32_dmem_addr				(rv32_dmem_addr			),//output		[ 7: 0]	
		.rv32_dmem_wout				(rv32_dmem_wout			),//output		[31: 0]	
		.rv32_dmem_rdin				(rv32_dmem_rdin			),//input		[31: 0]	
		.tpem_sclk					(tpem_sclk				),//input				
		.tpem_rstn					(tpem_rstn				));//input				
/**********************************************************************************************************/
	tpem_behv_simu_esse			u_behv_tpem_esse(
		.rv32_tpem_ctrl_csen		(rv32_dmem_csen			),//input					
		.rv32_tpem_ctrl_wrcs		(rv32_dmem_wrcs			),//input					
		.rv32_tpem_ctrl_addr		(rv32_dmem_addr			),//input		[ 7: 0 ]	
		.rv32_tpem_ctrl_wdin		(rv32_dmem_wout			),//input		[ 31:0 ]	
		.rv32_tpem_ctrl_rout		(rv32_dmem_rdin			),//output		[ 31:0 ]	
	
		.tpem_link_tune_txdo		(tpem_tune_txdo			),//output		
		.tpem_link_tune_rxdi		(tpem_tune_rxdi			),//output		
		.tpem_link_rstn_outp		(tpem_rstn_outp			),//output		
		.tpem_link_rstn_outn		(tpem_rstn_outn			),//output		
		.tpem_link_fclk_outp		(tpem_fclk_outp			),//output		
		.tpem_link_fclk_outn		(tpem_fclk_outn			),//output		
		.tpem_link_fram_outp		(tpem_fram_outp			),//output		
		.tpem_link_fram_outn		(tpem_fram_outn			),//output		
		.tpem_link_dat0_outp		(tpem_dat0_outp			),//output		
		.tpem_link_dat0_outn		(tpem_dat0_outn			),//output		
		.tpem_link_dat1_outp		(tpem_dat1_outp			),//output		
		.tpem_link_dat1_outn		(tpem_dat1_outn			),//output		
		.tpem_link_dat2_outp		(tpem_dat2_outp			),//output		
		.tpem_link_dat2_outn		(tpem_dat2_outn			),//output		
		.tpem_link_dat3_outp		(tpem_dat3_outp			),//output		
		.tpem_link_dat3_outn		(tpem_dat3_outn			),//output	

		.tpes_link_fclk_inpp		(tpes_fclk_inpn			),//input		
		.tpes_link_fclk_inpn		(tpes_fclk_inpp			),//input		
		.tpes_link_fram_inpp		(tpes_fram_inpp			),//input		
		.tpes_link_fram_inpn		(tpes_fram_inpn			),//input		
		.tpes_link_dat0_inpp		(tpes_dat0_inpp			),//input		
		.tpes_link_dat0_inpn		(tpes_dat0_inpn			),//input		
		.tpes_link_dat1_inpp		(tpes_dat1_inpp			),//input		
		.tpes_link_dat1_inpn		(tpes_dat1_inpn			),//input		
		.tpes_link_dat2_inpp		(tpes_dat2_inpp			),//input		
		.tpes_link_dat2_inpn		(tpes_dat2_inpn			),//input		
		.tpes_link_dat3_inpp		(tpes_dat3_inpn			),//input		
		.tpes_link_dat3_inpn		(tpes_dat3_inpp			),//input		
		.tpem_fclk					(tpem_fclk				),//input		
		.tpem_sclk					(tpem_sclk				),//input		
		.tpem_strb					(tpem_strb				),//input		
		.tpem_rstn					(tpem_rstn				));//input		
/**********************************************************************************************************/
		wire	[15: 0]				dvp0_data_pado		;
		wire	[15: 0]				dvp1_data_pado		;
		wire	[15: 0]				gmsl_data_padi		;
		wire	[ 1: 0]				cube_stat_gpio		;

	fpga_slx9_tops				u_fpga_slx9_tops(
		.tpes_fclk_outp				(tpes_fclk_inpp			),//output
		.tpes_fclk_outn				(tpes_fclk_inpn			),//output
		.tpes_fram_outp				(tpes_fram_inpp			),//output
		.tpes_fram_outn				(tpes_fram_inpn			),//output
		.tpes_dat0_outp				(tpes_dat0_inpp			),//output
		.tpes_dat0_outn				(tpes_dat0_inpn			),//output
		.tpes_dat1_outp				(tpes_dat1_inpp			),//output
		.tpes_dat1_outn				(tpes_dat1_inpn			),//output
		.tpes_dat2_outp				(tpes_dat2_inpp			),//output
		.tpes_dat2_outn				(tpes_dat2_inpn			),//output
		.tpes_dat3_outp				(tpes_dat3_inpp			),//output
		.tpes_dat3_outn				(tpes_dat3_inpn			),//output

		.tpem_fclk_inpp				(tpem_fclk_outp			),//input 
		.tpem_fclk_inpn				(tpem_fclk_outn			),//input 
		.tpem_fram_inpp				(tpem_fram_outp			),//input 
		.tpem_fram_inpn				(tpem_fram_outn			),//input 
		.tpem_dat0_inpp				(tpem_dat0_outp			),//input 
		.tpem_dat0_inpn				(tpem_dat0_outn			),//input 
		.tpem_dat1_inpp				(tpem_dat1_outp			),//input 
		.tpem_dat1_inpn				(tpem_dat1_outn			),//input 
		.tpem_dat2_inpp				(tpem_dat2_outp			),//input 
		.tpem_dat2_inpn				(tpem_dat2_outn			),//input 
		.tpem_dat3_inpp				(tpem_dat3_outp			),//input 
		.tpem_dat3_inpn				(tpem_dat3_outn			),//input 

		.tpem_tune_txdo  			(tpem_tune_txdo  		),//input
		.tpem_tune_rxdi  			(tpem_tune_rxdi  		),//input
		.tpem_rstn_inpp  			(tpem_rstn_outp  		),//input
    	.tpem_rstn_inpn  			(tpem_rstn_outn  		),//input
		
		.dvp0_vsyn_pado				(dvp0_vsyn_pado			),//output	reg			
		.dvp0_hsyn_pado				(dvp0_hsyn_pado			),//output	reg			
		.dvp0_data_pado				(dvp0_data_pado			),//output	reg	[15: 0]	
		.dvp0_clko					(dvp0_clko				),//output				
		
		.dvp1_vsyn_pado				(dvp1_vsyn_pado			),//output	reg			
		.dvp1_hsyn_pado				(dvp1_hsyn_pado			),//output	reg			
		.dvp1_data_pado				(dvp1_data_pado			),//output	reg	[15: 0]	
		.dvp1_clko					(dvp1_clko				),//output				

		.gmsl_vsyn_padi				(gmsl_vsyn_padi			),//input				
		.gmsl_hsyn_padi				(gmsl_hsyn_padi			),//input				
		.gmsl_data_padi				(gmsl_data_padi			),//input		[15: 0]	
		.gmsl_clki					(gmsl_clki				),//input				
		
		.cube_stat_gpio				(cube_stat_gpio			),//input		[ 1: 0]	
		.cube_comm_gpio				(cube_comm_gpio			),//output				
		.cube_uart_txdo				(cube_uart_txdo			),//output               
		.cube_uart_rxdi				(cube_uart_rxdi			),//input                
		.cube_ispx_mode				(cube_ispx_mode			),//output               
		.cube_ispx_rstn				(cube_ispx_rstn			),//output               
		.cube_chip_rstn				(cube_chip_rstn			),//output               
		.cube_clko     				(cube_clko				));//output               

/**********************************************************************************************************/
	behv_uart_txrx				u_uart(
		.uart_txdo_pado				(cube_uart_rxdi			),//output	reg	
		.uart_rxdi_padi				(cube_uart_txdo			));//input		
/**********************************************************************************************************/
	behv_cube_2805				u_2805(
		.cube_link_reqs				(cube_comm_gpio			),//input				
		.cube_stat_gpio				(cube_stat_gpio			),//output		[1:0]	

		.dvp0_vsyn_padi				(dvp0_vsyn_pado			),//input				
		.dvp0_hsyn_padi				(dvp0_hsyn_pado			),//input				
		.dvp0_data_padi				(dvp0_data_pado			),//input		[15:0]	
		.dvp0_clki					(dvp0_clki				),//input				
		.dvp0_rstn					(cube_rstn				),//input				

		.dvp1_vsyn_padi				(dvp1_vsyn_pado			),//input				
		.dvp1_hsyn_padi				(dvp1_hsyn_pado			),//input				
		.dvp1_data_padi				(dvp1_data_pado			),//input		[15:0]	
		.dvp1_clki					(dvp1_clki				),//input				
		.dvp1_rstn					(cube_rstn				),//input				
		
		.gmsl_vsyn_pado				(gmsl_vsyn_padi			),//output				
		.gmsl_hsyn_pado				(gmsl_hsyn_padi			),//output				
		.gmsl_data_pado				(gmsl_data_padi			),//output		[15:0]	
		.gmsl_clko					(gmsl_clki				),//output				
		
		.cube_clki					(dvp0_clko				),//input				
		.cube_rstn					(tpem_rstn				));//input				


/***********************************************************************************************************
	behv_dvpx_rxdi				u_dvp0(
		.dvpx_intf_indx				(1'B0					),//input				
		.dvpx_vsyn_padi				(dvp0_vsyn_pado			),//input				
		.dvpx_hsyn_padi				(dvp0_hsyn_pado			),//input				
		.dvpx_data_padi				(dvp0_data_pado			),//input		[15:0]	
		.dvpx_clki					(dvp0_clko				),//input				
		.dvpx_rstn					(tpem_rstn				));//input				

	behv_dvpx_rxdi				u_dvp1(
		.dvpx_intf_indx				(1'B1					),//input				
		.dvpx_vsyn_padi				(dvp1_vsyn_pado			),//input				
		.dvpx_hsyn_padi				(dvp1_hsyn_pado			),//input				
		.dvpx_data_padi				(dvp1_data_pado			),//input		[15:0]	
		.dvpx_clki					(dvp1_clko				),//input				
		.dvpx_rstn					(tpem_rstn				));//input				

	behv_gmsl_txdo				u_gmsl(
		.gmsl_vsyn_pado				(gmsl_vsyn_padi			),//input				
		.gmsl_hsyn_pado				(gmsl_hsyn_padi			),//input				
		.gmsl_data_pado				(gmsl_data_padi			),//input		[15:0]	
		.gmsl_clko					(gmsl_clki				));//input				
***********************************************************************************************************/
//----------------------------------------------------------------------TPEM	TASK
task	tpem_rstn_tpes;
	input	[31: 0]		pulz	;
	begin
		u_tpem_rv32.rv32_iowr(8'H04,pulz);//ACTIVE TPES RESET
		u_tpem_rv32.rv32_wait(8'H04,32'H0000_0000);//wait TPES RESET end
	end	
endtask
//--------------
task	tpem_init_cmnd;
	begin
		u_tpem_rv32.rv32_iowr(8'H30	, cmnd_memo[0]	);
		u_tpem_rv32.rv32_iowr(8'H31	, cmnd_memo[1]	);
		u_tpem_rv32.rv32_iowr(8'H32	, cmnd_memo[2]	);
		u_tpem_rv32.rv32_iowr(8'H33	, cmnd_memo[3]	);
		u_tpem_rv32.rv32_iowr(8'H34	, cmnd_memo[4]	);
		u_tpem_rv32.rv32_iowr(8'H35	, cmnd_memo[5]	);
		u_tpem_rv32.rv32_iowr(8'H36	, cmnd_memo[6]	);
		u_tpem_rv32.rv32_iowr(8'H37	, cmnd_memo[7]	);
		u_tpem_rv32.rv32_iowr(8'H38	, cmnd_memo[8]	);
	end	
endtask
//--------------
task	tpem_issu_cmnd;
	input		[7:0]	cmnd	;
	input		[31:0]	mask	;
	
	begin
		u_tpem_rv32.rv32_iowr(8'H00	, cmnd	);
		u_tpem_rv32.rv32_wait(8'H00 , mask	);
		u_tpem_rv32.rv32_iowr(8'H00	, 8'H00	);
		
	end
endtask
//--------------
task	tpem_tune_idly;
	reg			[7: 0]		cnts	;	

	begin

		u_tpem_rv32.rv32_iowr(8'H01	, 8'H99	);
				
		for(cnts=1;cnts<33;cnts=cnts+1)	begin
			$display("\t\t\t\t\t\tTPEM Tune Input_Delays:%h",8*cnts);
			u_tpem_rv32.rv32_iowr(8'H70	, 8*cnts	);
			#1000	;
		end

		u_tpem_rv32.rv32_iowr(8'H01	, 8'H00	);
		#1000	;
	end
endtask

//--------------
task	tpem_tune_odly;
	
	reg			flag	;
	
	begin
		flag	=	1	;	
		u_tpem_rv32.rv32_iowr(8'H01	, 8'H88);

		while(flag)	begin
			u_tpem_rv32.rv32_wait(8'H40	, 32'H41434b53	);	
			$display("\t\t\t\t\t\tTPEM Tune Output_Delays Success!!");
			flag	=	0	;
		end
		u_tpem_rv32.rv32_iowr(8'H01	, 8'H00	);
		#1000	;

	end

endtask
//----------------------------------------------------------------------UART	TASK
//----------------------------------------------------------------------UART	TASK
//----------------------------------------------------------------------UART	TASK
//----------------------------------------------------------------------UART	TASK
task	cube_uart_send	;
	input	[7:0]	data	;
	begin
		u_uart.uart_txdo_data(data)	;
	end
endtask

//--------------
task	cube_uart_tx4	;
	input		[7:0]	dat0	;
	input		[7:0]	dat1	;
	input		[7:0]	dat2	;
	input		[7:0]	dat3	;
	
	begin
		u_uart.uart_txdo_data(dat0)	;
		u_uart.uart_txdo_data(dat1)	;
		u_uart.uart_txdo_data(dat2)	;
		u_uart.uart_txdo_data(dat3)	;
	end
endtask

//--------------
task	cube_uart_tx6	;
	input		[7:0]	dat0	;
	input		[7:0]	dat1	;
	input		[7:0]	dat2	;
	input		[7:0]	dat3	;
	input		[7:0]	dat4	;
	input		[7:0]	dat5	;
	
	begin
		u_uart.uart_txdo_data(dat0)	;
		u_uart.uart_txdo_data(dat1)	;
		u_uart.uart_txdo_data(dat2)	;
		u_uart.uart_txdo_data(dat3)	;
		u_uart.uart_txdo_data(dat4)	;
		u_uart.uart_txdo_data(dat5)	;
	end
endtask

//--------------
task	cube_uart_tx7	;
	input		[7:0]	dat0	;
	input		[7:0]	dat1	;
	input		[7:0]	dat2	;
	input		[7:0]	dat3	;
	input		[7:0]	dat4	;
	input		[7:0]	dat5	;
	input		[7:0]	dat6	;
	
	
	begin
		u_uart.uart_txdo_data(dat0)	;
		u_uart.uart_txdo_data(dat1)	;
		u_uart.uart_txdo_data(dat2)	;
		u_uart.uart_txdo_data(dat3)	;
		u_uart.uart_txdo_data(dat4)	;
		u_uart.uart_txdo_data(dat5)	;
		u_uart.uart_txdo_data(dat6)	;
	end
endtask




	parameter	CUBE_TRIM_CMND	=	8'H88	;
	parameter	CUBE_BOOT_CMND	=	8'H53	;
	parameter	CUBE_DNLD_CMND	=	8'H52	;
	parameter	CUBE_ASET_CMND	=	8'H51	;
	parameter	CUBE_OMTX_CMND	=	8'H24	;
	parameter	CUBE_IMTX_CMND	=	8'H23	;
	parameter	CUBE_OVCT_CMND	=	8'H22	;
	parameter	CUBE_IVCT_CMND	=	8'H21	;
	parameter	CUBE_NNEX_CMND	=	8'H13	;
	parameter	CUBE_OCFG_CMND	=	8'H12	;
	parameter	CUBE_ICFG_CMND	=	8'H11	;

	parameter	CUBE_TRIM_MASK	=	32'H2000	;
	parameter	CUBE_BOOT_MASK	=	32'H0200	;
	parameter	CUBE_DNLD_MASK	=	32'H0100	;
	parameter	CUBE_ASET_MASK	=	32'H0080	;
	parameter	CUBE_OMTX_MASK	=	32'H0040	;
	parameter	CUBE_IMTX_MASK	=	32'H0020	;
	parameter	CUBE_OVCT_MASK	=	32'H0010	;
	parameter	CUBE_IVCT_MASK	=	32'H0008	;
	parameter	CUBE_NNEX_MASK	=	32'H0004	;
	parameter	CUBE_OCFG_MASK	=	32'H0002	;
	parameter	CUBE_ICFG_MASK	=	32'H0001	;
	


initial			begin
	#10000	;	simu_step =	1	;
	$display("1---TPEM Reset Tpes")	;
	tpem_rstn_tpes(100);												
	
	#10000	;	simu_step =	2	;
	$display("2---TPEM Calibration LVDS Input Channel")	;				
	tpem_tune_idly();													
	
	#10000	;	simu_step =	3	;
	$display("3---TPEM Calibration LVDS Output Channel")	;
	tpem_tune_odly();													
//----------------------------------------------------------------------	
//----------------------------------------------------------------------	
	#10000	;	simu_step =	4	;
	$display("4---TPEM OCFG TPES ENABLE UART_PARAMETER")	;
	$display(" ---4.1 Config UART_BaudRate : ")	;

	cmnd_memo[0]	=	32'H2	;	//TPES CONFIG
	cmnd_memo[1]	=	32'H0	;	//CUBE SHORTCUT
	cmnd_memo[2]	=	32'H0	;	//SLAVE ADDR
	cmnd_memo[3]	=	32'H0	;	//ROWS
	cmnd_memo[4]	=	32'H0	;	//COLS
	cmnd_memo[5]	=	32'Hc018	;	//-->UART_BAUD_RATE
	cmnd_memo[6]	=	32'D32	;	//-->346~115200
	cmnd_memo[7]	=	32'H0	;	//
	cmnd_memo[8]	=	32'H0	;	//
	
	tpem_init_cmnd();
	tpem_issu_cmnd(CUBE_OCFG_CMND,CUBE_OCFG_MASK);						
	
	$display(" ---4.2 Config UART_ISP_MODE : ")	;
	cmnd_memo[5]	=	32'Hc00C	;	//-->UART_isp_mode
	cmnd_memo[6]	=	32'H0000	;	//

	tpem_init_cmnd();
	tpem_issu_cmnd(CUBE_OCFG_CMND,CUBE_OCFG_MASK);						
	
	$display(" ---4.3 Config UART_ISP_RSTN : ")	;
	cmnd_memo[5]	=	32'Hc010	;	//-->UART_isp_mode
	cmnd_memo[6]	=	32'H0003	;	//

	tpem_init_cmnd();
	tpem_issu_cmnd(CUBE_OCFG_CMND,CUBE_OCFG_MASK);						
//----------------------------------------------------------------------	
//----------------------------------------------------------------------
	#10000	;	simu_step =	5	;
	$display("5---TPEM OCFG ENABLE UART_TXDO ")	;
	$display(" ---5.1 Config UART_ISPM_ENAB : ")	;

	tpem_issu_cmnd(CUBE_ASET_CMND,CUBE_ASET_MASK);						
	
	$display(" ---5.2 Config UART_TXDO_BUFF : ")	;
	cmnd_memo[0]	=	32'H00000000	;	//TPES CONFIG
	cmnd_memo[1]	=	32'H11223344	;	//CUBE SHORTCUT
	cmnd_memo[2]	=	32'H55667788	;	//SLAVE ADDR
	cmnd_memo[3]	=	32'H99AABBCC	;	//ROWS
	cmnd_memo[4]	=	32'HDDEEFF00	;	//COLS
	cmnd_memo[5]	=	32'HFFEEDDCC	;	//-->UART_BAUD_RATE
	cmnd_memo[6]	=	32'HBBAA9988	;	//-->346~115200
	cmnd_memo[7]	=	32'H77665544	;	//
	cmnd_memo[8]	=	32'H33221100	;	//
	tpem_init_cmnd();
	tpem_issu_cmnd(CUBE_DNLD_CMND,CUBE_DNLD_MASK);						
	
	
	$display(" ---5.3 Config CUBE BOOT ")	;
	tpem_issu_cmnd(CUBE_BOOT_CMND,CUBE_BOOT_MASK);						
//----------------------------------------------------------------------	
//----------------------------------------------------------------------
	#10000	;	simu_step =	6	;
	$display("6---TPEM OCFG TPES ENABLE UART_QUIZ")	;
	$display(" ---6.1 Config UART_UIQZ : ")	;

	cmnd_memo[0]	=	32'H2	;	//TPES CONFIG
	cmnd_memo[5]	=	32'Hc024	;	//-->UART_BAUD_RATE
	cmnd_memo[6]	=	32'HFF	;	//-->346~115200
	
	tpem_init_cmnd();
	tpem_issu_cmnd(CUBE_OCFG_CMND,CUBE_OCFG_MASK);						
	
	$display(" ---6.1 CUBE UART_UIQZ SEQUENCE : ")	;
	cube_uart_tx4(8'H57,8'H5f,8'H4F,8'H4B);				#100;//"W_OK"
	cube_uart_tx6(8'H32,8'H6E,8'H64,8'H20,8'H4F,8'H4B);	#100;//"2nd OK"
	cube_uart_tx6(8'H33,8'H72,8'H64,8'H20,8'H4F,8'H4B);	#100;//"3rd OK"
	cube_uart_tx6(8'H44,8'H44,8'H52,8'H49,8'H4F,8'H4B);	#100;//"DDRIOK"
	cube_uart_tx6(8'H44,8'H44,8'H52,8'H53,8'H4F,8'H4B);	#100;//"DDRSOK"
	cube_uart_tx6(8'H49,8'H53,8'H50,8'H20,8'H4F,8'H4B);	#100;//"ISP OK"
	cube_uart_tx4(8'H47,8'H5f,8'H4F,8'H4B);				#100;//"G_OK"
	
	cube_uart_tx7(8'H44,8'H44,8'H52,8'H46,8'H41,8'H49,8'H4C);	#100;//"DDRFAIL"
//----------------------------------------------------------------------	
//----------------------------------------------------------------------
	#10000	;	simu_step =	7	;
	$display("7---TPEM OCFG CUBE")	;
	$display(" ---7.1 fake OCfg CUBE  : ")	;

	cmnd_memo[0]	=	32'H0	;	//TPES CONFIG
	cmnd_memo[1]	=	32'H3	;	//TPES CONFIG DVP0
	cmnd_memo[8]	=	32'H2	;	//TPES CONFIG conmmand OCFG
	
	tpem_init_cmnd();
	tpem_issu_cmnd(CUBE_OCFG_CMND,CUBE_OCFG_MASK);						

	#10000	;	simu_step =	8	;
	$display(" ---7.2 fake ICfg CUBE  : ")	;
	cmnd_memo[0]	=	32'H0	;	//TPES CONFIG
	cmnd_memo[1]	=	32'H6	;	//TPES CONFIG GMSL 
	cmnd_memo[8]	=	32'H1	;	//TPES CONFIG conmmand ICFG
	
	tpem_init_cmnd();
	tpem_issu_cmnd(CUBE_ICFG_CMND,CUBE_ICFG_MASK);						

	#10000	;	simu_step =	9	;
	$display(" ---7.2 fake IDAT CUBE  : ")	;
	cmnd_memo[0]	=	32'H0	;	//TPES CONFIG
	cmnd_memo[1]	=	32'H6	;	//TPES CONFIG GMSL 
	cmnd_memo[2]	=	32'H84000000	;	//TPES CONFIG SLAVE ADDRESS
	cmnd_memo[3]	=	32'H9	;	//TPES CONFIG ROWS
	cmnd_memo[4]	=	32'H100	;	//TPES CONFIG COLS
	cmnd_memo[8]	=	32'H3	;	//TPES CONFIG conmmand ODAT
	
	tpem_init_cmnd();
	tpem_issu_cmnd(CUBE_IVCT_CMND,CUBE_IVCT_MASK);						
	
	#10000	;	simu_step =	10	;
	$display(" ---7.3 fake ODAT CUBE  : ")	;
	cmnd_memo[0]	=	32'H0	;	//TPES CONFIG
	cmnd_memo[1]	=	32'H5	;	//TPES CONFIG DUAL DVP 
	cmnd_memo[2]	=	32'H84000000	;	//TPES CONFIG SLAVE ADDRESS
	cmnd_memo[3]	=	32'H4	;	//TPES CONFIG ROWS
	cmnd_memo[4]	=	32'H100	;	//TPES CONFIG COLS
	cmnd_memo[8]	=	32'H4	;	//TPES CONFIG conmmand ODAT
	
	tpem_init_cmnd();
	tpem_issu_cmnd(CUBE_OVCT_CMND,CUBE_OVCT_MASK);						
	

	#10000	;	simu_step =	11	;
	$display(" ---7.4 fake ODAT CUBE  : ")	;
	cmnd_memo[0]	=	32'H0	;	//TPES CONFIG
	cmnd_memo[1]	=	32'H4	;	//TPES CONFIG  DVP 1
	cmnd_memo[2]	=	32'H84000000	;	//TPES CONFIG SLAVE ADDRESS
	cmnd_memo[3]	=	32'H4	;	//TPES CONFIG ROWS
	cmnd_memo[4]	=	32'H100	;	//TPES CONFIG COLS
	cmnd_memo[8]	=	32'H4	;	//TPES CONFIG conmmand ODAT
	
	tpem_init_cmnd();
	tpem_issu_cmnd(CUBE_OVCT_CMND,CUBE_OVCT_MASK);						
	
	


	


	

				


	
	

	


	#1000	;
	$system("date") ;
	$finish();

	$display($time,"****************\t\t END TPEM_SLX9 SIMULATION ");
end	


endmodule


