`timescale	1ns/1ps

module	behv_uart_txrx(
	output	reg						uart_txdo_pado		,
	input							uart_rxdi_padi		);
/**********************************************************************/
	reg								uart_bclk			;
	reg								uart_rstn			;
	
	always	#12.5	uart_bclk	= ~	uart_bclk	;

	initial	begin
		uart_rstn	=	0	;
		uart_bclk	=	0	;
		#37	;
		uart_rstn	=	1	;
	end
/**********************************************************************/
`ifdef	FAST_SIMU
	parameter	FULL_BAUD_RATE	=	12'h1F	;
	parameter	HALF_BAUD_RATE	=	12'h0F	;
`else
	parameter	FULL_BAUD_RATE	=	12'h15A	;
	parameter	HALF_BAUD_RATE	=	12'h0AD	;
`endif
//----------------------------------------------------------------------
	initial	begin
		uart_txdo_pado	=	1'b1	;
	end

	reg	[11:0]			txdo_baud_rate	;
	
	wire		txdo_full_baud	=	txdo_baud_rate	==	FULL_BAUD_RATE	;
	
	always@(posedge uart_bclk or negedge uart_rstn)
	if(~uart_rstn)					txdo_baud_rate	<=	0	;
	else if(txdo_full_baud)			txdo_baud_rate	<=	0	;
	else							txdo_baud_rate	<=	1 +	txdo_baud_rate	;			

	task	uart_txdo_data	;
	input	[ 7: 0]		tx_data	;
		begin
			@(posedge txdo_full_baud)	uart_txdo_pado	<=	1'b1	;
			@(posedge txdo_full_baud)	uart_txdo_pado	<=	1'b0	;
			@(posedge txdo_full_baud)	uart_txdo_pado	<=	tx_data[0]	;
			@(posedge txdo_full_baud)	uart_txdo_pado	<=	tx_data[1]	;
			@(posedge txdo_full_baud)	uart_txdo_pado	<=	tx_data[2]	;
			@(posedge txdo_full_baud)	uart_txdo_pado	<=	tx_data[3]	;
			@(posedge txdo_full_baud)	uart_txdo_pado	<=	tx_data[4]	;	;
			@(posedge txdo_full_baud)	uart_txdo_pado	<=	tx_data[5]	;
			@(posedge txdo_full_baud)	uart_txdo_pado	<=	tx_data[6]	;
			@(posedge txdo_full_baud)	uart_txdo_pado	<=	tx_data[7]	;
			@(posedge txdo_full_baud)	begin
									$display($time,"UART_TX_DATA:%H DONE",tx_data);
									uart_txdo_pado	<=	1'b1	;
			end
		end
	endtask
/***********************************************************************/
//	UART	TXDI	
/***********************************************************************/
	reg			[ 2: 0]				rxdi_padi_samp	;

	wire	uart_rxdi_sbit	=	rxdi_padi_samp[0]	;

	always@(posedge uart_bclk or negedge uart_rstn)
	if(~uart_rstn)					rxdi_padi_samp	<=	0	;
	else							rxdi_padi_samp	<={	uart_rxdi_padi	,	rxdi_padi_samp[2:1]};




	wire		rxdi_data_rise	= 	rxdi_padi_samp[1:0]	==	2'B10	;	
	wire		rxdi_data_fall	= 	rxdi_padi_samp[1:0]	==	2'B01	;	
	wire		rxdi_data_xchg	= 	rxdi_data_rise		|	rxdi_data_fall	;	

	
//----------------------------------------------------------------------
	reg			[ 1: 0]				uart_rxdi_mfsm	;
	reg			[11: 0]				rxdi_baud_rate	;
	reg			[ 7: 0]				uart_rxdi_data	;
	reg			[ 7: 0]				uart_rxdi_cnts	;

	parameter	RXDI_MFSM_IDLE	=	0	;
	parameter	RXDI_MFSM_LEAD	=	1	;
	parameter	RXDI_MFSM_DATA	=	2	;

	wire		rxdi_half_baud	=	rxdi_baud_rate	==	HALF_BAUD_RATE	;
	wire		rxdi_full_baud	=	rxdi_baud_rate	==	FULL_BAUD_RATE	;
	wire		rxdi_sbit_bmax	= &	uart_rxdi_cnts	;

	wire		rxdi_hits_idle	=	uart_rxdi_mfsm	==	RXDI_MFSM_IDLE	;
	wire		rxdi_hits_lead	=	uart_rxdi_mfsm	==	RXDI_MFSM_LEAD	;
	wire		rxdi_hits_data	=	uart_rxdi_mfsm	==	RXDI_MFSM_DATA	;
	
	wire		uart_rxdi_done	= &{rxdi_hits_data	,	rxdi_full_baud	,	uart_rxdi_cnts == 8	};
	
	always@(posedge uart_bclk or negedge uart_rstn)
	if(~uart_rstn)							rxdi_baud_rate	<=	0	;
	else if(rxdi_hits_idle )				rxdi_baud_rate	<=	0	;
	else if(rxdi_full_baud)					rxdi_baud_rate	<=	0	;
	else									rxdi_baud_rate	<=	1 +	rxdi_baud_rate	;			
	
	always@(posedge uart_bclk or negedge uart_rstn)
	if(~uart_rstn)							uart_rxdi_data	<=	0	;
	else if(rxdi_hits_idle)					uart_rxdi_data	<=	0	;
	else if(rxdi_hits_data&rxdi_half_baud)	uart_rxdi_data	<={ uart_rxdi_sbit	,	uart_rxdi_data[7:1]}	;	

	always@(posedge uart_bclk or negedge uart_rstn)
	if(~uart_rstn)							uart_rxdi_cnts	<=	0	;
	else if(rxdi_hits_idle)					uart_rxdi_cnts	<=	0	;
	else if(rxdi_hits_data&rxdi_half_baud)	uart_rxdi_cnts	<=	1 +	uart_rxdi_cnts 	;	


	always@(posedge uart_bclk or negedge uart_rstn)
	if(~uart_rstn)					uart_rxdi_mfsm	<=	0	;
	else	begin
		case(uart_rxdi_mfsm)	
			RXDI_MFSM_IDLE	:	uart_rxdi_mfsm	<=	rxdi_data_fall	?	RXDI_MFSM_LEAD	:	RXDI_MFSM_IDLE	;
			RXDI_MFSM_LEAD	:	uart_rxdi_mfsm	<=	rxdi_full_baud	?	RXDI_MFSM_DATA	:	RXDI_MFSM_LEAD	;
			RXDI_MFSM_DATA	:	uart_rxdi_mfsm	<=	uart_rxdi_done	?	RXDI_MFSM_IDLE	:	RXDI_MFSM_DATA	;
			default			:	uart_rxdi_mfsm	<=											RXDI_MFSM_IDLE	;	
		endcase
	end

/***********************************************************************/
	wire	[ 7: 0]					uart_rxdi_shft	;
	assign	uart_rxdi_shft	=	{	uart_rxdi_shft	,	uart_rxdi_shft[7:1]	};


	always@(posedge uart_bclk )
	if(uart_rxdi_done)				$display($time,"UART_RX_DATA:%H DONE",uart_rxdi_data);
	
	


	


endmodule




