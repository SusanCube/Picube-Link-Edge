`include "defs_disp_color.vh"

module	behv_rora_txrx(
	output	reg	[31: 0]					behv_user_rxln_data	,
	output	reg							behv_user_rxln_drdy	,
	output	reg	[31: 0]					behv_ufcm_rxln_data	,
	output	reg							behv_ufcm_rxln_drdy	,
	output	reg							behv_ufcm_rxln_last	,

	input								behv_ufcm_txln_reqs	,
	output	reg							behv_ufcm_txln_acks	,
	input		[31: 0]					behv_user_txln_data	,
	input								behv_user_txln_drdy	,
	input								behv_user_txln_last	,
	output	reg							behv_user_txln_trdy	,


	input		[0:9][31:0]				rora_link_cmnd_argu	,

	output	reg							rora_cmnd_acks_mark	,
	output	reg							rora_cmnd_resp_mark	,
	output	reg							rora_cmnd_trdy_mark	,
	input								rora_cmnd_stat_clrs	,
	input								rora_bclk			,
	input								rora_rstn			);
/**********************************************************************************************************************/
	reg		[255:0]						simu_rora_info	;
	
	initial	begin
		simu_rora_info		=	"INIT RORA SIMULATION"	;
	end	
/**********************************************************************************************************************/
	reg		[ 2: 0]						rora_ufcm_rxln_mfsm	;

	parameter	RORA_UFCM_RXLN_IDLE	=	3'h0	;
	parameter	RORA_UFCM_RXLN_ACKS	=	3'h1	;
	parameter	RORA_UFCM_RXLN_WRD0	=	3'h2	;
	parameter	RORA_UFCM_RXLN_WRD1	=	3'h3	;
	parameter	RORA_UFCM_RXLN_DONE	=	3'h4	;	

	wire		rora_ufcm_rx_idle	=	rora_ufcm_rxln_mfsm	==	RORA_UFCM_RXLN_IDLE	;
	wire		rora_ufcm_rx_acks	=	rora_ufcm_rxln_mfsm	==	RORA_UFCM_RXLN_ACKS	;
	wire		rora_ufcm_rx_wrd0	=	rora_ufcm_rxln_mfsm	==	RORA_UFCM_RXLN_WRD0	;
	wire		rora_ufcm_rx_wrd1	=	rora_ufcm_rxln_mfsm	==	RORA_UFCM_RXLN_WRD1	;
	wire		rora_ufcm_rx_done	=	rora_ufcm_rxln_mfsm	==	RORA_UFCM_RXLN_DONE	;
	wire		rora_ufcm_rx_vlid	= &{rora_ufcm_rx_idle	,	behv_ufcm_txln_reqs	}	;

	
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_ufcm_rxln_mfsm	<=	RORA_UFCM_RXLN_IDLE	;
	else	begin
		case(rora_ufcm_rxln_mfsm)		
			RORA_UFCM_RXLN_IDLE	:		rora_ufcm_rxln_mfsm	<=	behv_ufcm_txln_reqs	?	RORA_UFCM_RXLN_ACKS	:	RORA_UFCM_RXLN_IDLE	;
			RORA_UFCM_RXLN_ACKS	:		rora_ufcm_rxln_mfsm	<=													RORA_UFCM_RXLN_WRD0	;
			RORA_UFCM_RXLN_WRD0	:		rora_ufcm_rxln_mfsm	<=													RORA_UFCM_RXLN_WRD1	;
			RORA_UFCM_RXLN_WRD1	:		rora_ufcm_rxln_mfsm	<=													RORA_UFCM_RXLN_DONE	;
			RORA_UFCM_RXLN_DONE	:		rora_ufcm_rxln_mfsm	<=													RORA_UFCM_RXLN_IDLE	;
		endcase
	end
//------------------------------------------------------------------------------	
	reg			[63: 0]					rora_ufcm_rxdi_dwrd	;
	string								rora_ufcm_rxdi_strs	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_ufcm_rxdi_dwrd	<=	0	;
	else if(rora_ufcm_rx_vlid)			rora_ufcm_rxdi_dwrd	<=	0	;
	else if(rora_ufcm_rx_wrd0)			rora_ufcm_rxdi_dwrd	<=	{behv_user_txln_data	,	rora_ufcm_rxdi_dwrd[31: 0]	};
	else if(rora_ufcm_rx_wrd1)			rora_ufcm_rxdi_dwrd	<=	{rora_ufcm_rxdi_dwrd[63:32]	,	behv_user_txln_data		};

	always@(posedge rora_bclk )
//	if(rora_ufcm_rx_vlid)				$display({`BOLD,`COFR,"\t%0t RORA_RX_UFCM_REQS",`NORM},$time);
//	else if(rora_ufcm_rx_acks)			$display({`BOLD,`COFR,"\t%0t RORA_RX_UFCM_ACKS",`NORM},$time);
	if(rora_ufcm_rx_done)		begin	rora_ufcm_rxdi_strs = $sformatf("%c%c%c%c%c%c%c%c",
        																rora_ufcm_rxdi_dwrd[63:56],
        																rora_ufcm_rxdi_dwrd[55:48],
        																rora_ufcm_rxdi_dwrd[47:40],
        																rora_ufcm_rxdi_dwrd[39:32],
        																rora_ufcm_rxdi_dwrd[31:24],
        																rora_ufcm_rxdi_dwrd[23:16],
        																rora_ufcm_rxdi_dwrd[15: 8],
        																rora_ufcm_rxdi_dwrd[ 7: 0]);
    								//	$display("[%0t ns] ASCII string = %s", $time, str_ascii);
										$display({`BOLD,`COFR,"\t%0t RORA_RX_UFCM:%s",`NORM},$time,rora_ufcm_rxdi_strs);
	end
//------------------------------------------------------------------------------

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						behv_ufcm_txln_acks	<=	0	;
	else 								behv_ufcm_txln_acks	<=	rora_ufcm_rx_vlid	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						behv_user_txln_trdy	<=	1	;
	else if(rora_ufcm_rx_vlid)			behv_user_txln_trdy	<=	0	;
	else if(rora_ufcm_rx_wrd1)			behv_user_txln_trdy	<=	1	;
/**********************************************************************************************************************/
	reg									rora_ufcm_rxcs_alnk	;
	reg									rora_ufcm_rxcs_dlnk	;
	reg		[11: 0]						rora_ufcm_rxcs_wcnt	;

	wire	rora_ufcm_rx_data_lead	= &{rora_ufcm_rx_done	,	rora_ufcm_rxdi_dwrd	==	"DATALEAD"	};
	wire	rora_ufcm_rx_data_coda	= &{rora_ufcm_rx_done	,	rora_ufcm_rxdi_dwrd	==	"DATACODA"	};	
	wire	rora_ufcm_rx_acks_lead	= &{rora_ufcm_rx_done	,	rora_ufcm_rxdi_dwrd	==	"ACKSLEAD"	};	
	wire	rora_ufcm_rx_acks_coda	= &{rora_ufcm_rx_done	,	rora_ufcm_rxdi_dwrd	==	"ACKSCODA"	};	
	wire	rora_ufcm_rx_resp_tokn	= &{rora_ufcm_rx_done	,	rora_ufcm_rxdi_dwrd	==	"RESPONSE"	};	
	wire	rora_ufcm_rx_trdy_tokn	= &{rora_ufcm_rx_done	,	rora_ufcm_rxdi_dwrd	==	"DATATRDY"	};	


	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_ufcm_rxcs_alnk	<=	0	;
	else if(rora_ufcm_rx_acks_lead)		rora_ufcm_rxcs_alnk	<=	1	;
	else if(rora_ufcm_rx_acks_coda)		rora_ufcm_rxcs_alnk	<=	0	;


	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_ufcm_rxcs_dlnk	<=	0	;
	else if(rora_ufcm_rx_data_lead)		rora_ufcm_rxcs_dlnk	<=	1	;
	else if(rora_ufcm_rx_data_coda)		rora_ufcm_rxcs_dlnk	<=	0	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_ufcm_rxcs_wcnt	<=	0	;
	else if(~rora_ufcm_rxcs_alnk)		rora_ufcm_rxcs_wcnt	<=	0	;
	else if(~rora_ufcm_rxcs_dlnk)		rora_ufcm_rxcs_wcnt	<=	0	;
	else if( behv_user_txln_drdy)		rora_ufcm_rxcs_wcnt	<=	rora_ufcm_rxcs_wcnt + 1	;


	always@(posedge rora_bclk )
	if(rora_ufcm_rxcs_alnk&behv_user_txln_drdy&behv_user_txln_trdy)				
										$display({`BOLD,`COFC,"\t%0t RORA_RX_ACKS:%8H@%3H",`NORM},$time,behv_user_txln_data,rora_ufcm_rxcs_wcnt);
	else if(rora_ufcm_rxcs_dlnk&behv_user_txln_drdy&behv_user_txln_trdy)				
										$display({`NORM,`COFW,"%\t\t0t RORA_RXUSR_DATA	%8H@%3H",`NORM},$time,behv_user_txln_data,rora_ufcm_rxcs_wcnt);
/**********************************************************************************************************************/
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_cmnd_acks_mark	<=	0	;
	else if(rora_ufcm_rx_acks_coda)		rora_cmnd_acks_mark	<=	1	;
	else if(rora_cmnd_stat_clrs)		rora_cmnd_acks_mark	<=	0	;
//--------------------------------------
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_cmnd_resp_mark	<=	0	;
	else if(rora_ufcm_rx_resp_tokn)		rora_cmnd_resp_mark	<=	1	;
	else if(rora_cmnd_stat_clrs)		rora_cmnd_resp_mark	<=	0	;
//--------------------------------------
	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_cmnd_trdy_mark	<=	0	;
	else if(rora_ufcm_rx_trdy_tokn)		rora_cmnd_trdy_mark	<=	1	;
	else if(rora_cmnd_stat_clrs)		rora_cmnd_trdy_mark	<=	0	;
/**********************************************************************************************************************/
/**********************************************************************************************************************/
	initial		begin
			behv_ufcm_rxln_data	=	0	;
			behv_ufcm_rxln_drdy	=	0	;
			behv_ufcm_rxln_last	=	0	;
			behv_user_rxln_data	=	0	;
			behv_user_rxln_drdy	=	0	;
	end
//------------------------------------------------------------------------------
	task automatic	rora_ufcm_txln_word	;
	input	[31: 0]						txln_ufcm_tokn_word	;
	input								txln_ufcm_tokn_last	;
	begin
		@(posedge rora_bclk)	begin
			behv_ufcm_rxln_data			<=	txln_ufcm_tokn_word	;
			behv_ufcm_rxln_drdy			<=	1	;
			behv_ufcm_rxln_last			<=	txln_ufcm_tokn_last	;
		end
	end
	endtask
//------------------------------------------------------------------------------
	task automatic	rora_ufcm_txln_stop	;
	begin
		@(posedge rora_bclk)	begin
			behv_ufcm_rxln_data			<=	0	;
			behv_ufcm_rxln_drdy			<=	0	;
			behv_ufcm_rxln_last			<=	0	;
		end
	end
	endtask
//------------------------------------------------------------------------------
	task automatic	rora_ufcm_txln_tokn	;
	input	[63: 0]						txln_ufcm_tokn_dwrd	;
	begin
		rora_ufcm_txln_word(txln_ufcm_tokn_dwrd[63:32],0)	;
		rora_ufcm_txln_word(txln_ufcm_tokn_dwrd[31: 0],1)	;
		rora_ufcm_txln_stop()	;
	end
	endtask
//------------------------------------------------------------------------------
	task automatic	rora_user_txln_word	;
	input	[31: 0]						txln_user_data_word	;
	begin
		@(posedge rora_bclk)	begin
			behv_user_rxln_data			<=	txln_user_data_word	;
			behv_user_rxln_drdy			<=	1	;
		end
	end
	endtask
//------------------------------------------------------------------------------
	task automatic	rora_user_txln_stop	;
	begin
		@(posedge rora_bclk)	begin
			behv_user_rxln_drdy			<=	0	;
		end
	end
	endtask	
//------------------------------------------------------------------------------
	task automatic 	rora_tx_cmnd_pack	;
//	input	[0:9][31:0]					txln_cmnd_memo	;
	integer								i	;
	reg		[31: 0]						txln_cmnd_argu	;
	begin
		simu_rora_info	=	"ISSU_CMND_LEAD";
		rora_ufcm_txln_tokn("CMNDLEAD");
		
		simu_rora_info	=	"ISSU_CMND_ARGU";
		for (i = 0; i < 10; i = i + 1) begin
			txln_cmnd_argu	=	rora_link_cmnd_argu[i][31:0 ]	;
			$display("\t\t\tTX_USER_DATA_%4D::%8H",i,txln_cmnd_argu);
			rora_user_txln_word(txln_cmnd_argu);
		end
		rora_user_txln_stop()	;

		simu_rora_info	=	"ISSU_CMND_CODA";
		rora_ufcm_txln_tokn("CMNDCODA");
		simu_rora_info	=	"ISSU_CMND_DONE";
		
	end
	endtask
//------------------------------------------------------------------------------
	task automatic	rora_tx_data_pack	;
	input	[15: 0]						txln_data_rows	;
	input	[15: 0]						txln_data_cols	;
	
	integer								i	;
	reg		[31: 0]						txln_data_word	;	
	reg		[15: 0]						txln_rows_inc1	;
	reg		[15: 0]						txln_cols_inc1	;
	
	begin
		$display("ODAT~~ROW::%4H  COL::%4H",txln_data_rows,txln_data_cols);

		rora_ufcm_txln_tokn("DATALEAD");
		for (i = 0; i < txln_data_cols; i = i + 1) begin
			txln_rows_inc1	=	txln_data_rows + 1	;
			txln_cols_inc1	=	i + 1	;
			
			txln_data_word	= { txln_rows_inc1 , txln_cols_inc1	};
		//	$display("%8H",txln_data_word);
			rora_user_txln_word(txln_data_word);
		end
		rora_user_txln_stop();
		rora_ufcm_txln_tokn("DATACODA");
	end
	endtask
//------------------------------------------------------------------------------
endmodule




