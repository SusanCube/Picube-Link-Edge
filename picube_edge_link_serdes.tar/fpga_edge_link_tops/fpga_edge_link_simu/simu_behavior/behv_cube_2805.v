`timescale	1ns/1ps
module	behv_cube_2805(
	input								cube_cmnd_reqs		,
	output		[1:0]					cube_stat_gpio		,

	input								dvp0_vsyn_padi		,
	input								dvp0_hsyn_padi		,
	input		[15:0]					dvp0_data_padi		,
	input								dvp0_clki			,//175MHZ
	input								dvp0_rstn			,

	input								dvp1_vsyn_padi		,
	input								dvp1_hsyn_padi		,
	input		[15:0]					dvp1_data_padi		,
	input								dvp1_clki			,//175MHZ
	input								dvp1_rstn			,

	output								gmsl_vsyn_pado		,
	output								gmsl_hsyn_pado		,
	output		[15:0]					gmsl_data_pado		,
	output								gmsl_clko			,

	input								cube_clki			,
	input								cube_rstn			);
/**********************************************************************************************************************/
	reg									dvp0_vsyn_padr	;
	reg									dvp0_hsyn_padr	;
	reg			[15: 0]					dvp0_data_padr	;

	reg									dvp1_vsyn_padr	;
	reg									dvp1_hsyn_padr	;
	reg			[15: 0]					dvp1_data_padr	;
	
	always@(posedge cube_clki)	begin
		dvp0_vsyn_padr		<=	dvp0_vsyn_padi	;
		dvp0_hsyn_padr		<=	dvp0_hsyn_padi	;
		dvp0_data_padr		<=	dvp0_data_padi	;
		dvp1_vsyn_padr		<=	dvp1_vsyn_padi	;
		dvp1_hsyn_padr		<=	dvp1_hsyn_padi	;
		dvp1_data_padr		<=	dvp1_data_padi	;
	end
/**********************************************************************************************************************/
	wire		[31:0]				cube_gmsl_rows	;
	wire		[31:0]				cube_xdat_rows	;
	wire		[31:0]				cube_xdat_cols	;

	behv_2805_flow					u_cube_flow(
		.cube_link_misc_reqs			(cube_cmnd_reqs			),//input				
		.cube_link_stat_gpio			(cube_stat_gpio			),//output		[ 1: 0]	

		.dvp0_vsyn_padi					(dvp0_vsyn_padr			),//input				
		.dvp0_hsyn_padi					(dvp0_hsyn_padr			),//input				
		.dvp0_data_padi					(dvp0_data_padr			),//input		[15: 0]	

		.cube_link_dest_gmsl			(gmsl_port_enab			),//output				
		.cube_link_dest_dvp0			(dvp0_port_enab			),//output				
		.cube_link_dest_dvp1			(dvp1_port_enab			),//output				

		.cube_link_hits_seek			(cube_link_disa			),//output				
		.cube_gmsl_icfg_reqs			(gmsl_icfg_reqs			),//output				
		.cube_gmsl_idat_reqs			(gmsl_idat_reqs			),//output				
		.cube_dvpx_odat_reqs			(dvpx_odat_reqs			),//output				
		.cube_gmsl_icfg_done			(gmsl_icfg_done			),//input				
		.cube_gmsl_idat_done			(gmsl_idat_done			),//input				
		.cube_dvp0_odat_done			(dvp0_odat_done			),//input				
		.cube_dvp1_odat_done			(dvp1_odat_done			),//input				

		.cube_link_gmsl_rows			(cube_gmsl_rows			),//output		[31: 0]	
		.cube_link_xdat_rows			(cube_xdat_rows			),//output		[31: 0]	
		.cube_link_xdat_cols			(cube_xdat_cols			),//output		[31: 0]	
		.cube_clki						(cube_clki				),//input				
		.cube_rstn						(cube_rstn				));//input				
/**********************************************************************************************************/
	behv_dvpx_rxdi					u_dvp0(
		.dvpx_intf_indx					(1'B0					),//input				
		.dvpx_vsyn_padi					(dvp0_vsyn_padr			),//input				
		.dvpx_hsyn_padi					(dvp0_hsyn_padr			),//input				
		.dvpx_data_padi					(dvp0_data_padr			),//input		[15:0]	

		.dvpx_port_enab					(dvp0_port_enab			),//input				
		.dvpx_odat_disa					(cube_link_disa			),//input				
		.dvpx_odat_reqs					(dvpx_odat_reqs			),//input				
		.dvpx_odat_done					(dvp0_odat_done			),//output				

		.dvpx_odat_rows					(cube_xdat_rows			),//input		[31:0]	
		.dvpx_odat_cols					(cube_xdat_cols			),//input		[31:0]	
		.dvpx_clki						(cube_clki				),//input				
		.dvpx_rstn						(cube_rstn				));//input				
/**********************************************************************************************************/
	behv_dvpx_rxdi					u_dvp1(
		.dvpx_intf_indx					(1'B1					),//input				
		.dvpx_vsyn_padi					(dvp1_vsyn_padr			),//input				
		.dvpx_hsyn_padi					(dvp1_hsyn_padr			),//input				
		.dvpx_data_padi					(dvp1_data_padr			),//input		[15:0]	

		.dvpx_port_enab					(dvp1_port_enab			),//input				
		.dvpx_odat_disa					(cube_link_disa			),//input				
		.dvpx_odat_reqs					(dvpx_odat_reqs			),//input				
		.dvpx_odat_done					(dvp1_odat_done			),//output				

		.dvpx_odat_rows					(cube_xdat_rows			),//input		[31:0]	
		.dvpx_odat_cols					(cube_xdat_cols			),//input		[31:0]	
		.dvpx_clki						(cube_clki				),//input				
		.dvpx_rstn						(cube_rstn				));//input				
/**********************************************************************************************************/
	behv_gmsl_txdo					u_gmsl(
		.gmsl_vsyn_pado					(gmsl_vsyn_pado			),//input				
		.gmsl_hsyn_pado					(gmsl_hsyn_pado			),//input				
		.gmsl_data_pado					(gmsl_data_pado			),//input		[15:0]	
		.gmsl_clko						(gmsl_clko				),

		.gmsl_port_enab					(gmsl_port_enab			),//input				
		.gmsl_idat_disa					(cube_link_disa			),//input				
		.gmsl_icfg_reqs					(gmsl_icfg_reqs			),//input				
		.gmsl_icfg_done					(gmsl_icfg_done			),//output				
		.gmsl_idat_reqs					(gmsl_idat_reqs			),//input				
		.gmsl_idat_done					(gmsl_idat_done			),//output				

		.gmsl_idat_rows					(cube_gmsl_rows			),//input		[31:0]	
		.gmsl_idat_cols					(cube_xdat_cols			),//input		[31:0]	
		.dvpx_clki						(cube_clki				),//input				
		.gmsl_rstn						(cube_rstn				));//input				
/**********************************************************************************************************/


endmodule




