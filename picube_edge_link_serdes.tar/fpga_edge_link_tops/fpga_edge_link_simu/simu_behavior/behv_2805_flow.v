`timescale	1ns/1ps
module	behv_2805_flow(
	input								cube_link_misc_reqs	,
	output	reg	[1:0]					cube_link_stat_gpio	,
		
	input								dvp0_vsyn_padi		,
	input								dvp0_hsyn_padi		,
	input		[15:0]					dvp0_data_padi		,
		
	output		[31: 0]					cube_link_gmsl_rows	,
	output		[31: 0]					cube_link_xdat_rows	,
	output		[31: 0]					cube_link_xdat_cols	,
	
	output								cube_link_dest_gmsl	,
	output								cube_link_dest_dvp0	,
	output								cube_link_dest_dvp1	,
	
	output								cube_link_hits_seek	,	
	output	reg							cube_gmsl_icfg_reqs	,
	output	reg							cube_gmsl_idat_reqs	,
	output	reg							cube_dvpx_odat_reqs	,
	
	input								cube_gmsl_icfg_done	,
	input								cube_gmsl_idat_done	,
	input								cube_dvp0_odat_done	,
	input								cube_dvp1_odat_done	,
		
	input								cube_clki			,
	input								cube_rstn			);
/**********************************************************************************************************/
	reg			[3:0]				cube_flow_mfsm	;

	parameter	CUBE_LINK_SEEK	=	4'H0	;
	parameter	CUBE_LINK_IDLE	=	4'H1	;
	parameter	CUBE_RECV_CMDD	=	4'H2	;
	parameter	CUBE_RECV_DMYD	=	4'H3	;
	parameter	CUBE_LINK_PROC	=	4'H4	;
	parameter	CUBE_OCFG_ACKS	=	4'H5	;
	parameter	CUBE_GMSL_ICFG	=	4'H6	;
	parameter	CUBE_ICFG_ACKS	=	4'H7	;

//	parameter	CUBE_IDAT_ACKS	=	4'H8	;
//	parameter	CUBE_GMSL_IDAT	=	4'H9	;
//	parameter	CUBE_IDAT_RESP	=	4'HA	;


	parameter	CUBE_IDAT_ACKS	=	4'H8	;
	parameter	CUBE_GMSL_REQS	=	4'H9	;
	parameter	CUBE_GMSL_IDAT	=	4'HA	;
	parameter	CUBE_GMSL_BLKS	=	4'HB	;
	parameter	CUBE_IDAT_RESP	=	4'HC	;

	parameter	CUBE_ODAT_ACKS	=	4'HD	;
	parameter	CUBE_DVPX_ODAT	=	4'HE	;
	parameter	CUBE_ODAT_RESP	=	4'HF	;


	assign	cube_link_hits_seek	=	cube_flow_mfsm	==	CUBE_LINK_SEEK	;
	wire	cube_link_hits_idle	=	cube_flow_mfsm	==	CUBE_LINK_IDLE	;
	wire	cube_link_recv_cmnd	=	cube_flow_mfsm	==	CUBE_RECV_CMDD	;
	wire	cube_link_recv_dmyd	=	cube_flow_mfsm	==	CUBE_RECV_DMYD	;
	wire	cube_link_hits_proc	=	cube_flow_mfsm	==	CUBE_LINK_PROC	;
	wire	cube_link_ocfg_acks	=	cube_flow_mfsm	==	CUBE_OCFG_ACKS	;
	wire	cube_link_gmsl_icfg	=	cube_flow_mfsm	==	CUBE_GMSL_ICFG	;
	wire	cube_link_icfg_acks	=	cube_flow_mfsm	==	CUBE_ICFG_ACKS	;

	wire	cube_link_idat_acks	=	cube_flow_mfsm	==	CUBE_IDAT_ACKS	;
	wire	cube_link_gmsl_reqs	=	cube_flow_mfsm	==	CUBE_GMSL_REQS	;
	wire	cube_link_gmsl_idat	=	cube_flow_mfsm	==	CUBE_GMSL_IDAT	;
	wire	cube_link_gmsl_blks	=	cube_flow_mfsm	==	CUBE_GMSL_BLKS	;
	wire	cube_link_idat_resp	=	cube_flow_mfsm	==	CUBE_IDAT_RESP	;

	wire	cube_link_odat_acks	=	cube_flow_mfsm	==	CUBE_ODAT_ACKS	;
	wire	cube_link_dvpx_odat	=	cube_flow_mfsm	==	CUBE_DVPX_ODAT	;
	wire	cube_link_odat_resp	=	cube_flow_mfsm	==	CUBE_ODAT_RESP	;

	wire	cube_rxdi_cmnd_crdy		;
	wire	cube_rxdi_cmnd_drdy		;
/**********************************************************************************************************/
	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn)					cube_link_stat_gpio	<=	3	;
	else if(cube_link_hits_idle)	cube_link_stat_gpio	<=	0	;
	else if(cube_link_ocfg_acks)	cube_link_stat_gpio	<=	1	;
	else if(cube_link_icfg_acks)	cube_link_stat_gpio	<=	1	;
	else if(cube_link_odat_acks)	cube_link_stat_gpio	<=	1	;
	else if(cube_link_idat_acks)	cube_link_stat_gpio	<=	1	;
	else if(cube_link_odat_resp)	cube_link_stat_gpio	<=	2	;
	else if(cube_link_idat_resp)	cube_link_stat_gpio	<=	2	;
/**********************************************************************************************************/
	reg			[ 3:0]				cube_dvp0_cmnd_cnts	;
	reg			[ 3:0]				cube_dvp0_dmyd_cnts	;

	assign	cube_rxdi_cmnd_crdy	= 	cube_dvp0_cmnd_cnts	==	4'HF	;
	assign	cube_rxdi_cmnd_drdy	= 	cube_dvp0_dmyd_cnts	==	4'HF	;
	
	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn)					cube_dvp0_cmnd_cnts	<=	0	;
	else if(cube_link_hits_seek)	cube_dvp0_cmnd_cnts	<=	0	;
	else if(     dvp0_vsyn_padi)	cube_dvp0_cmnd_cnts	<=	cube_dvp0_cmnd_cnts + cube_link_recv_cmnd	;

	always@(posedge cube_clki or negedge cube_rstn)
	if(~cube_rstn)					cube_dvp0_dmyd_cnts	<=	0	;
	else if(cube_link_hits_seek)	cube_dvp0_dmyd_cnts	<=	0	;
	else if(     dvp0_hsyn_padi)	cube_dvp0_dmyd_cnts	<=	cube_dvp0_dmyd_cnts + cube_link_recv_dmyd	;
	
	reg			[15:0]				cube_cmnd_memo[0:15]	;
	wire		[0:15]				cube_cmnd_wrcs			;
	wire		[31:0]				cube_cmnd_argu[0: 7]	;

	genvar	i	;
	generate
	for( i = 0; i < 16 ; i = i +1)begin
		assign	cube_cmnd_wrcs[i]	=&{	cube_link_recv_cmnd	,	cube_dvp0_cmnd_cnts == i	}	;

		always@(posedge cube_clki or negedge cube_rstn)
		if(~cube_rstn)					cube_cmnd_memo[i]	<=	0	;
		else if(cube_link_hits_seek)	cube_cmnd_memo[i]	<=	0	;
		else if(cube_cmnd_wrcs[i])		cube_cmnd_memo[i]	<=	dvp0_data_padi	;
	end
	endgenerate	

	genvar	j	;
	generate
	for( j = 0; j < 8 ; j = j +1)begin
		assign	cube_cmnd_argu[j][31:16]	=	cube_cmnd_memo[j*2+1]	;
		assign	cube_cmnd_argu[j][15: 0]	=	cube_cmnd_memo[j*2+0]	;	
	end
	endgenerate	
/**********************************************************************************************************/
	wire		[31:0]				cube_link_misc_dest	=	cube_cmnd_argu[0];
	wire		[31:0]				cube_link_misc_addr	=	cube_cmnd_argu[1];
	
	assign							cube_link_xdat_rows	=	cube_cmnd_argu[2];
	assign							cube_link_xdat_cols	=	cube_cmnd_argu[3];

//	wire		[31:0]				cube_link_misc_aux0	=	cube_cmnd_argu[4];
//	wire		[31:0]				cube_link_misc_aux1	=	cube_cmnd_argu[5];
//	wire		[31:0]				cube_link_misc_aux2	=	cube_cmnd_argu[6];
//	wire		[31:0]				cube_link_misc_aux3	=	cube_cmnd_argu[7];
	
	assign	cube_link_dest_dvp0	=	cube_link_misc_dest	==	32'H3	|	cube_link_misc_dest	==	32'H5	;
	assign	cube_link_dest_dvp1	=	cube_link_misc_dest	==	32'H4	|	cube_link_misc_dest	==	32'H5	;
	assign	cube_link_dest_gmsl	=	cube_link_misc_dest	==	32'H6	|	cube_link_misc_dest	==	32'H7	;

	wire	cube_link_icfg_cmnd	=	cube_link_misc_dest	==	1	;//cube_link_misc_cmnd	==	32'H1	;
	wire	cube_link_ocfg_cmnd	=	cube_link_misc_dest	==	2	;//cube_link_misc_cmnd	==	32'H2	;
	wire	cube_link_idat_cmnd	=	cube_link_dest_gmsl	;//cube_link_misc_cmnd	==	32'H3	;
	wire	cube_link_odat_cmnd	=	cube_link_dest_dvp0	|	cube_link_dest_dvp1	;//cube_link_misc_cmnd	==	32'H4	;
//----------------------------------------------------------------------
	wire	cube_dvpx_odat_done	= ( cube_link_dest_dvp0	?	cube_dvp0_odat_done	:	1'b1	)	&
								  ( cube_link_dest_dvp1	?	cube_dvp1_odat_done	:	1'b1	)	;

	wire	gmsl_icfg_reqs_issu	= &{cube_link_hits_proc	,	cube_link_icfg_cmnd	}	;
	wire	gmsl_idat_reqs_issu	= &{cube_link_idat_acks	,	cube_link_idat_cmnd	}	;
	wire	dvpx_odat_reqs_issu	= &{cube_link_odat_acks	,	cube_link_odat_cmnd	}	; 

	always@(posedge cube_clki or negedge cube_rstn)			
	if(~cube_rstn)					cube_gmsl_icfg_reqs	<=	0	;
	else if(gmsl_icfg_reqs_issu)	cube_gmsl_icfg_reqs	<=	1	;
	else if(cube_gmsl_icfg_done)	cube_gmsl_icfg_reqs	<=	0	;	

	always@(posedge cube_clki or negedge cube_rstn)			
	if(~cube_rstn)					cube_gmsl_idat_reqs	<=	0	;
//	else if(gmsl_idat_reqs_issu)	cube_gmsl_idat_reqs	<=	1	;
	else if(cube_link_gmsl_reqs)	cube_gmsl_idat_reqs	<=	1	;
	else if(cube_gmsl_idat_done)	cube_gmsl_idat_reqs	<=	0	;	
	
	always@(posedge cube_clki or negedge cube_rstn)			
	if(~cube_rstn)					cube_dvpx_odat_reqs	<=	0	;
	else if(dvpx_odat_reqs_issu)	cube_dvpx_odat_reqs	<=	1	;
	else if(cube_dvpx_odat_done)	cube_dvpx_odat_reqs	<=	0	;	
/**********************************************************************************************************/
//	reg			[19: 0]				cube_gmsl_blks_rows	;

//	wire							cube_gmsl_blks_last	;
//	wire							cube_gmsl_blks_done	;
//	wire							cube_gmsl_blks_next	;

//	assign	cube_gmsl_blks_last	=	cube_gmsl_blks_rows + 4 >= cube_link_xdat_rows	;
//	assign	cube_gmsl_blks_done	=	cube_gmsl_blks_rows 	>= cube_link_xdat_rows	;
	assign	cube_link_gmsl_rows	=	cube_link_xdat_rows	;//cube_gmsl_blks_last	?	cube_link_xdat_rows - cube_gmsl_blks_rows	:	4	;
//	assign	cube_gmsl_blks_next	= &{cube_gmsl_idat_done	,	cube_link_gmsl_idat	};


//	always@(posedge cube_clki or negedge cube_rstn)			
//	if(~cube_rstn)					cube_gmsl_blks_rows	<=	0	;
//	else if(cube_link_hits_idle)	cube_gmsl_blks_rows	<=	0	;
//	else if(cube_gmsl_blks_next)	cube_gmsl_blks_rows	<=	cube_gmsl_blks_rows + 4	;	

/**********************************************************************************************************/
	always@(posedge cube_clki or negedge cube_rstn)			
	if(~cube_rstn)				cube_flow_mfsm	<=	CUBE_LINK_SEEK	;
	else begin
		case(cube_flow_mfsm)
			CUBE_LINK_SEEK	:		cube_flow_mfsm	<=	cube_link_misc_reqs	?	CUBE_LINK_IDLE	:	CUBE_LINK_SEEK	;	
			CUBE_LINK_IDLE	:		cube_flow_mfsm	<= ~cube_link_misc_reqs	?	CUBE_RECV_CMDD	:	CUBE_LINK_IDLE	;	
			CUBE_RECV_CMDD	:		cube_flow_mfsm	<=	cube_rxdi_cmnd_crdy	?	CUBE_RECV_DMYD	:	CUBE_RECV_CMDD	;
			CUBE_RECV_DMYD	:		cube_flow_mfsm	<=	cube_rxdi_cmnd_drdy	?	CUBE_LINK_PROC	:	CUBE_RECV_DMYD	;	

			CUBE_LINK_PROC	:		cube_flow_mfsm	<=	cube_link_ocfg_cmnd	?	CUBE_OCFG_ACKS	:	
														cube_link_icfg_cmnd	?	CUBE_GMSL_ICFG	:	
														cube_link_odat_cmnd	?	CUBE_ODAT_ACKS	:	
														cube_link_idat_cmnd	?	CUBE_IDAT_ACKS	:	CUBE_LINK_SEEK	;
			CUBE_OCFG_ACKS	:		cube_flow_mfsm	<=												CUBE_LINK_SEEK	;											

			CUBE_GMSL_ICFG	:		cube_flow_mfsm	<=	cube_gmsl_icfg_done	?	CUBE_ICFG_ACKS	:	CUBE_GMSL_ICFG	;
			CUBE_ICFG_ACKS	:		cube_flow_mfsm	<=												CUBE_LINK_SEEK	;

			CUBE_IDAT_ACKS	:		cube_flow_mfsm	<=												CUBE_GMSL_REQS	;
			CUBE_GMSL_REQS	:		cube_flow_mfsm	<=												CUBE_GMSL_IDAT	;
			CUBE_GMSL_IDAT	:		cube_flow_mfsm	<=	cube_gmsl_idat_done	?	CUBE_IDAT_RESP	:	CUBE_GMSL_IDAT	;
//			CUBE_GMSL_BLKS	:		cube_flow_mfsm	<=	cube_gmsl_blks_done	?	CUBE_IDAT_RESP	:	CUBE_GMSL_REQS	;
			CUBE_IDAT_RESP	:		cube_flow_mfsm	<=												CUBE_LINK_SEEK	;

//			CUBE_IDAT_ACKS	:		cube_flow_mfsm	<=												CUBE_GMSL_IDAT	;
//			CUBE_GMSL_IDAT	:		cube_flow_mfsm	<=	cube_gmsl_idat_done	?	CUBE_IDAT_RESP	:	CUBE_GMSL_IDAT	;
//			CUBE_IDAT_RESP	:		cube_flow_mfsm	<=												CUBE_LINK_SEEK	;

			CUBE_ODAT_ACKS	:		cube_flow_mfsm	<=												CUBE_DVPX_ODAT	;
			CUBE_DVPX_ODAT	:		cube_flow_mfsm	<=	cube_dvpx_odat_done	?	CUBE_ODAT_RESP	:	CUBE_DVPX_ODAT	;
			CUBE_ODAT_RESP	:		cube_flow_mfsm	<=												CUBE_LINK_SEEK	;

			default			:		cube_flow_mfsm	<=												CUBE_LINK_SEEK	;
		endcase
	end
/**********************************************************************************************************/


endmodule




