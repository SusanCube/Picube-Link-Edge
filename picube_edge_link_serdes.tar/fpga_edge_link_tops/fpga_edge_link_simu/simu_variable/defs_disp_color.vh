`ifndef COLOR_DEFINES_VH
`define COLOR_DEFINES_VH

`define NORM							"\033[0m"
`define BOLD							"\033[1m"
`define COFR							"\033[31m"
`define COFG							"\033[32m"
`define COFY		   					"\033[33m"
`define COFC		   					"\033[35m"
`define COFW		   					"\033[37m"
`define BOFB		   					"\033[40m"
`define BOFR		   					"\033[41m"

`endif