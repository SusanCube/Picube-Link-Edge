/***********************************************************************************************************
VERSION	:	1.0
DATE	:  	2026-09-22
AUTHOR	:	EDWARD YANG 
***********************************************************************************************************/

module	fpga_edge_rv32_cmnd(
	output		[31:0 ]					rv32_edge_cmnd_rout	,
	input								rv32_edge_cmnd_csen	,
	input		[ 3: 0]					rv32_edge_cmnd_addr	,
//------------------------------------------------------------------------------
	input		[ 3: 0]					rora_rxln_cmnd_addr	,
	input								rora_rxln_cmnd_drdy	,
	input		[31: 0]					rora_rxln_cmnd_data	,
	input								rora_rxln_cmnd_coda	,

	output reg	[ 10:0]					rora_rxln_cmnd_mark	,
	input								rora_rxln_cmnd_clrs	,	
//------------------------------------------------------------------------------
	output		[19: 0]					rora_data_link_rows	,
	output		[19: 0]					rora_data_link_cols	,
	output		[ 1: 0]					rora_dvpx_link_port	,
//------------------------------------------------------------------------------
	input		[ 2: 0]					dvpx_clnk_memo_addr	,
	output		[31: 0]					dvpx_clnk_memo_data	,
//------------------------------------------------------------------------------
	input								rora_bclk			,
	input								rora_rstn			);
/**********************************************************************************************************************/
	reg			[31: 0]					rora_rxln_cmnd_memo[0: 9]	;
	wire		[63: 0]					rora_rxln_cmnd_dwrd			;

	wire		[0 : 9]					edge_cmnd_memo_wrid			;	
	wire		[0 : 8]					rv32_cmnd_memo_rdid			;	
//------------------------------------------------------------------------------
	for(genvar i = 0 ; i < 10 ; i = i + 1) begin	:	edge_cmnd_memo_rwcs
		assign	edge_cmnd_memo_wrid[i]	= &{	rora_rxln_cmnd_addr	==	i	,	rora_rxln_cmnd_drdy	};
	
		always@(posedge rora_bclk or negedge rora_rstn)
		if(~rora_rstn)					rora_rxln_cmnd_memo[i]	<=	0	;
		else if(edge_cmnd_memo_wrid[i])	rora_rxln_cmnd_memo[i]	<=	rora_rxln_cmnd_data	;
	end
/**********************************************************************************************************************/
	wire		[63: 0]					rora_rxln_cmnd_code[0:10]	;

	assign		rora_rxln_cmnd_code[0 ]	=	"ICFG"	;
	assign		rora_rxln_cmnd_code[1 ]	=	"OCFG"	;
	assign		rora_rxln_cmnd_code[2 ]	=	"IVCT"	;
	assign		rora_rxln_cmnd_code[3 ]	=	"OVCT"	;
	assign		rora_rxln_cmnd_code[4 ]	=	"IMTX"	;
	assign		rora_rxln_cmnd_code[5 ]	=	"OMTX"	;
	assign		rora_rxln_cmnd_code[6 ]	=	"ASET"	;
	assign		rora_rxln_cmnd_code[7 ]	=	"DNLD"	;
	assign		rora_rxln_cmnd_code[8 ]	=	"BOOT"	;
	assign		rora_rxln_cmnd_code[9 ]	=	"NNEX"	;
	assign		rora_rxln_cmnd_code[10]	=	"TASK"	;

	for(genvar j = 0 ; j <  11 ; j = j + 1) begin	:	rora_link_cmnd_mark
		always@(posedge rora_bclk or negedge rora_rstn)
		if(~rora_rstn)					rora_rxln_cmnd_mark[j]	<=	0	;
		else if(rora_rxln_cmnd_clrs	)	rora_rxln_cmnd_mark[j]	<=	0	;
		else if(rora_rxln_cmnd_coda	)	rora_rxln_cmnd_mark[j]	<=	rora_rxln_cmnd_memo[0] == rora_rxln_cmnd_code[j] 	;
	end
/**********************************************************************************************************/
	for(genvar k = 0 ; k < 9 ; k = k + 1) begin	:	rv32_cmnd_memo_rdcs
		assign	rv32_cmnd_memo_rdid[k]	= &{	rv32_edge_cmnd_addr	==	k	,	rv32_edge_cmnd_csen	};
	end

	assign		rv32_edge_cmnd_rout	=	rv32_cmnd_memo_rdid[ 0]	?	rora_rxln_cmnd_memo[ 1]	://EDGE_DEST
										rv32_cmnd_memo_rdid[ 1]	?	rora_rxln_cmnd_memo[ 2]	://GNPU_DEST
										rv32_cmnd_memo_rdid[ 2]	?	rora_rxln_cmnd_memo[ 3]	://SLAV_ADDR
										rv32_cmnd_memo_rdid[ 3]	?	rora_rxln_cmnd_memo[ 4]	://XDAT_ROWS
										rv32_cmnd_memo_rdid[ 4]	?	rora_rxln_cmnd_memo[ 5]	://XDAT_COLS
										rv32_cmnd_memo_rdid[ 5]	?	rora_rxln_cmnd_memo[ 6]	://AUXI_WRD0
										rv32_cmnd_memo_rdid[ 6]	?	rora_rxln_cmnd_memo[ 7]	://AUXI_WRD1
										rv32_cmnd_memo_rdid[ 7]	?	rora_rxln_cmnd_memo[ 8]	://AUXI_WRD2
										rv32_cmnd_memo_rdid[ 8]	?	rora_rxln_cmnd_memo[ 9]	://AUXI_WRD3
																	32'H0	;
/**********************************************************************************************************/
	wire		[0 : 7]					dvpx_clnk_memo_rdid			;	

	for(genvar m = 0 ; m <  8 ; m = m + 1) begin	:	dvpx_cmnd_memo_rdcs
		assign	dvpx_clnk_memo_rdid[m]	= &{	dvpx_clnk_memo_addr	==	m	};
	end

	assign		dvpx_clnk_memo_data	=	dvpx_clnk_memo_rdid[0]	?	rora_rxln_cmnd_memo[ 2]	:
										dvpx_clnk_memo_rdid[1]	?	rora_rxln_cmnd_memo[ 3]	:
										dvpx_clnk_memo_rdid[2]	?	rora_rxln_cmnd_memo[ 4]	:
										dvpx_clnk_memo_rdid[3]	?	rora_rxln_cmnd_memo[ 5]	:
										dvpx_clnk_memo_rdid[4]	?	rora_rxln_cmnd_memo[ 6]	:
										dvpx_clnk_memo_rdid[5]	?	rora_rxln_cmnd_memo[ 7]	:
										dvpx_clnk_memo_rdid[6]	?	rora_rxln_cmnd_memo[ 8]	:
										dvpx_clnk_memo_rdid[7]	?	rora_rxln_cmnd_memo[ 9]	:	32'H0	;
/**********************************************************************************************************/
	assign		rora_data_link_rows	=	rora_rxln_cmnd_memo[4][19:0]	;
	assign		rora_data_link_cols	=	rora_rxln_cmnd_memo[5][19:0]	;
	assign		rora_dvpx_link_port[0]=(rora_rxln_cmnd_memo[2]==32'H3)	|	(rora_rxln_cmnd_memo[2]==32'H5)	;
	assign		rora_dvpx_link_port[1]=(rora_rxln_cmnd_memo[2]==32'H4)	|	(rora_rxln_cmnd_memo[2]==32'H5)	;



endmodule

 