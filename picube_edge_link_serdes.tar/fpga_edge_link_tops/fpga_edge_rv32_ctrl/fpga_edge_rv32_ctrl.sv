/***********************************************************************************************************
VERSION	:	1.0
DATE	:  	2026-10-01
AUTHOR	:	EDWARD YANG 
***********************************************************************************************************/
module	fpga_edge_rv32_ctrl(
	output	reg	[ 31:0 ]				rv32_edge_ctrl_rdat	,
	input								rv32_edge_ctrl_csen	,
	input								rv32_edge_ctrl_wrcs	,
	input		[ 11:0 ]				rv32_edge_ctrl_addr	,
	input		[ 31:0 ]				rv32_edge_ctrl_wdat	,

	input								cube_uart_rxdi_port	,
	output								cube_uart_txdo_port	,
	output	reg							cube_ispx_mode_port	,
	output	reg							cube_ispx_rstn_port	,
	output	reg							cube_chip_rstn_port	,
	output		[ 2: 0]					cube_acks_argu_selx	,

	input		[ 3: 0]					rora_rxln_cmnd_addr	,
	input		[31: 0]					rora_rxln_cmnd_data	,
	input								rora_rxln_cmnd_drdy	,
	input								rora_rxln_cmnd_coda	,

	output	reg	[31: 0]					rora_acks_rv32_data	,
	output								rora_acks_rv32_reqs	,
	input								rora_acks_txln_done	,

	input								cube_link_ufcm_done	,
	output								cube_link_icfg_reqs	,
	output								cube_link_ocfg_reqs	,
	output								cube_link_idat_reqs	,
	output								cube_link_odat_reqs	,

	output		[19: 0]					rora_data_link_rows	,
	output		[19: 0]					rora_data_link_cols	,
	output		[ 1: 0]					rora_dvpx_link_port	,

	input		[ 2: 0]					dvpx_clnk_memo_addr	,
	output		[31: 0]					dvpx_clnk_memo_data	,

	input								cube_bclk			,	
	input								cube_rstn			,
	input								rora_bclk			,	
	input								rora_rstn			);	
/**********************************************************************************************************************/
	wire								rv32_edge_misc_csen	;
	wire								rv32_edge_cmnd_csen	;

	wire		[ 3: 0]					rv32_edge_ctrl_lsba	;
	wire		[31: 0]					rv32_edge_ctrl_rout	;
	wire		[31: 0]					rv32_edge_misc_rout	;
	wire		[31: 0]					rv32_edge_cmnd_rout	;


	assign		rv32_edge_ctrl_lsba	=	rv32_edge_ctrl_addr[ 3: 0]	;	
	assign		rv32_edge_misc_csen	= &{rv32_edge_ctrl_csen	,	rv32_edge_ctrl_addr[11:4] == 8'H0};
	assign		rv32_edge_cmnd_csen	= &{rv32_edge_ctrl_csen	,	rv32_edge_ctrl_addr[11:4] == 8'H1};
	assign		rv32_edge_ctrl_rout	=	rv32_edge_misc_csen	?	rv32_edge_misc_rout	:
										rv32_edge_cmnd_csen	?	rv32_edge_cmnd_rout	:	32'H0		;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rv32_edge_ctrl_rdat	<=	0	;
	else 								rv32_edge_ctrl_rdat	<=	rv32_edge_ctrl_rout	;	

/**********************************************************************************************************************/
	wire		[10: 0]					rora_rxln_cmnd_mark	;
	wire		[11: 0]					cube_uart_baud_rate	;
	wire		[31: 0]					cube_uart_txdo_data	;
	wire		[ 7: 0]					cube_uart_quiz_enab	;
	wire		[ 7: 0]					cube_uart_quiz_stat	;

	fpga_edge_rv32_misc				u_edge_rv32_link_misc(
		.rv32_edge_misc_rout			(rv32_edge_misc_rout	),//output		[ 31:0 ]	rv32_edge_ctrl_rout
		.rv32_edge_misc_csen			(rv32_edge_misc_csen	),//input					rv32_edge_ctrl_csen
		.rv32_edge_misc_addr			(rv32_edge_ctrl_lsba	),//input		[  3:0 ]	rv32_edge_ctrl_addr
		.rv32_edge_misc_wrcs			(rv32_edge_ctrl_wrcs	),//input					rv32_edge_ctrl_wrcs
		.rv32_edge_misc_wdin			(rv32_edge_ctrl_wdat	),//input		[ 31:0 ]	rv32_edge_ctrl_wdin

		.rora_rxln_cmnd_mark			(rora_rxln_cmnd_mark	),//input		[10: 0]	
		.rora_rxln_cmnd_coda			(rora_rxln_cmnd_coda	),//input				
		.rora_rxln_cmnd_clrs			(rora_rxln_cmnd_clrs	),//output				

		.rora_acks_rv32_data			(rora_acks_rv32_data	),//output	reg	[31: 0]	
		.rora_acks_rv32_reqs			(rora_acks_rv32_reqs	),//output				
		.rora_acks_txln_done			(rora_acks_txln_done	),//input				

		.cube_acks_argu_selx			(cube_acks_argu_selx	),//output		[ 2: 0]	
		.cube_ispx_mode_port			(cube_ispx_mode_port	),//output	reg			
		.cube_ispx_rstn_port			(cube_ispx_rstn_port	),//output	reg			
		.cube_chip_rstn_port			(cube_chip_rstn_port	),//output	reg			

		.cube_uart_txdo_done			(cube_uart_txdo_done	),//input				
		.cube_uart_txdo_enab			(cube_uart_txdo_enab	),//output	reg			
		.cube_uart_txdo_drdy			(cube_uart_txdo_drdy	),//output	reg			
		.cube_uart_txdo_data			(cube_uart_txdo_data	),//output	reg	[31: 0]	
		.cube_uart_baud_rate			(cube_uart_baud_rate	),//output		[11: 0]	
		.cube_uart_rxdi_enab			(cube_uart_rxdi_enab	),//output	reg			
		.cube_uart_quiz_enab			(cube_uart_quiz_enab	),//output	reg	[ 7: 0]	
		.cube_uart_quiz_stat			(cube_uart_quiz_stat	),//input		[ 7: 0]	

		.cube_link_icfg_reqs			(cube_link_icfg_reqs	),//output	
		.cube_link_ocfg_reqs			(cube_link_ocfg_reqs	),//output	
		.cube_link_idat_reqs			(cube_link_idat_reqs	),//output	
		.cube_link_odat_reqs			(cube_link_odat_reqs	),//output	
		.cube_link_ufcm_done			(cube_link_ufcm_done	),//input	

		.rora_bclk						(rora_bclk				),//input
		.rora_rstn						(rora_rstn				),//input
		.cube_bclk						(cube_bclk				),//input
		.cube_rstn						(cube_rstn				));//input
/**********************************************************************************************************************/
	fpga_edge_rv32_cmnd				u_fpga_edge_rv32_cmnd(
		.rv32_edge_cmnd_rout			(rv32_edge_cmnd_rout	),//output		[ 31:0 ]
		.rv32_edge_cmnd_csen			(rv32_edge_cmnd_csen	),//input				
		.rv32_edge_cmnd_addr			(rv32_edge_ctrl_lsba	),//input		[  3:0 ]

		.rora_rxln_cmnd_addr			(rora_rxln_cmnd_addr	),//input		[ 3: 0]	
		.rora_rxln_cmnd_drdy			(rora_rxln_cmnd_drdy	),//input				
		.rora_rxln_cmnd_data			(rora_rxln_cmnd_data	),//input		[31: 0]	
		.rora_rxln_cmnd_coda			(rora_rxln_cmnd_coda	),//input				

		.rora_rxln_cmnd_mark			(rora_rxln_cmnd_mark	),//output reg	[10: 0]	
		.rora_rxln_cmnd_clrs			(rora_rxln_cmnd_clrs	),//input				

		.rora_data_link_rows			(rora_data_link_rows	),//output		[19: 0]	
		.rora_data_link_cols			(rora_data_link_cols	),//output		[19: 0]	
		.rora_dvpx_link_port			(rora_dvpx_link_port	),//output		[19: 0]	

		.dvpx_clnk_memo_addr			(dvpx_clnk_memo_addr	),//input		[ 2: 0]
		.dvpx_clnk_memo_data			(dvpx_clnk_memo_data	),//output		[31: 0]

		.rora_bclk						(rora_bclk				),//input	
		.rora_rstn						(rora_rstn				));//input	
/**********************************************************************************************************************/
	edge_link_uart_pmau				u_edge_link_uart_pmau(
		.cube_uart_txdo_port			(cube_uart_txdo_port	),//output				
		.cube_uart_rxdi_port			(cube_uart_rxdi_port	),//input				
		.cube_uart_baud_rate			(cube_uart_baud_rate	),//input		[11: 0]	
		.cube_bclk						(cube_bclk				),//input				
		.cube_rstn						(cube_rstn				),//input				

		.rv32_uart_rxdi_enab			(cube_uart_rxdi_enab	),//input				
		.rv32_uart_quiz_enab			(cube_uart_quiz_enab	),//input		[ 7: 0]	
		.rv32_uart_quiz_stat			(cube_uart_quiz_stat	),//output		[ 7: 0]	
		.rv32_uart_txdo_done			(cube_uart_txdo_done	),//output				
		.rv32_uart_txdo_enab			(cube_uart_txdo_enab	),//input				
		.rv32_uart_tbuf_wrcs			(cube_uart_txdo_drdy	),//input				
		.rv32_uart_tbuf_wdin			(cube_uart_txdo_data	),//input		[31: 0]	
		.rv32_bclk						(rora_bclk				),//input				
		.rv32_rstn						(rora_rstn				));//input				

endmodule		