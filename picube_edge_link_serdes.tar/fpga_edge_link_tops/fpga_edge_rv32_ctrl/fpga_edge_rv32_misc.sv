/***********************************************************************************************************
VERSION	:	1.0
DATE	:  	2026-09-01
AUTHOR	:	EDWARD YANG 
***********************************************************************************************************/
module	fpga_edge_rv32_misc(
	output		[31: 0]					rv32_edge_misc_rout	,
	input								rv32_edge_misc_csen	,
	input								rv32_edge_misc_wrcs	,
	input		[ 3: 0]					rv32_edge_misc_addr	,
	input		[31: 0]					rv32_edge_misc_wdin	,
//-------------------------------------------------------
	input		[10: 0]					rora_rxln_cmnd_mark	,
	input								rora_rxln_cmnd_coda	,
	output								rora_rxln_cmnd_clrs	,
//-------------------------------------------------------
	output	reg	[31: 0]					rora_acks_rv32_data	,
	output	reg							rora_acks_rv32_reqs	,
	input								rora_acks_txln_done	,
//-------------------------------------------------------
	output	reg	[ 2: 0]					cube_acks_argu_selx	,	
	output	reg							cube_ispx_mode_port	,
	output	reg							cube_ispx_rstn_port	,
	output	reg							cube_chip_rstn_port	,
//-------------------------------------------------------
	input								cube_uart_txdo_done	,	
	output	reg							cube_uart_txdo_enab	,	
	output	reg							cube_uart_txdo_drdy	,
	output	reg	[31: 0]					cube_uart_txdo_data	,
	output		[11: 0]					cube_uart_baud_rate	,
	output	reg							cube_uart_rxdi_enab	,
	output	reg	[ 7: 0]					cube_uart_quiz_enab	,
	input		[ 7: 0]					cube_uart_quiz_stat	,
//-------------------------------------------------------
	output								cube_link_icfg_reqs	,
	output								cube_link_ocfg_reqs	,
	output								cube_link_idat_reqs	,
	output								cube_link_odat_reqs	,
	input								cube_link_ufcm_done	,
//-------------------------------------------------------
	input								rora_bclk			,
	input								rora_rstn			,
	input								cube_bclk			,
	input								cube_rstn			);
/**********************************************************************************************************************/
	wire		[ 0:15]					rv32_edge_misc_csid	;
	wire		[ 0:15]					rv32_edge_misc_wrid	;

	wire		[31: 0]					edge_link_misc_wrd0	;//		31'H0 ,	rora_rxln_cmnd_stat
	wire		[31: 0]					edge_link_misc_wrd1	;//		21'H0 ,	rora_rxln_cmnd_mark
	wire		[31: 0]					edge_link_misc_wrd2	;//				rora_acks_rv32_data	
	wire		[31: 0]					edge_link_misc_wrd3	;//		29'H0 , rora_acks_cube_wsel
	wire		[31: 0]					edge_link_misc_wrd4	;//		31'H0 ,	cube_ispx_mode_port
	wire		[31: 0]					edge_link_misc_wrd5	;//		30'H0 ,	cube_ispx_rstn_port	,	cube_chip_rstn_port		
	wire		[31: 0]					edge_link_misc_wrd6	;//		29'H0 ,	cube_ufcm_cmnd_ctrl
	wire		[31: 0]					edge_link_misc_wrd7	;//		20'H0	cube_uart_baud_rate		
	wire		[31: 0]					edge_link_misc_wrd8	;//				cube_uart_txdo_data
	wire		[31: 0]					edge_link_misc_wrd9	;//		30'H0 ,	cube_uart_rxdi_enab ,	cube_uart_txdo_enab	
	wire		[31: 0]					edge_link_misc_wrda	;//		24'H0 ,	cube_uart_quiz_stat		
	wire		[31: 0]					edge_link_misc_wrdb	;//				cube_usec_time_sets		
	wire		[31: 0]					edge_link_misc_wrdc	;//				edge_link_ecos_var0
	wire		[31: 0]					edge_link_misc_wrdd	;//				edge_link_ecos_var1
	wire		[31: 0]					edge_link_misc_wrde	;//				edge_link_ecos_var2
	wire		[31: 0]					edge_link_misc_wrdf	;//				edge_link_ecos_var3

	assign	rv32_edge_misc_rout	=		rv32_edge_misc_csid[ 0]	?	edge_link_misc_wrd0	:
										rv32_edge_misc_csid[ 1]	?	edge_link_misc_wrd1	:
										rv32_edge_misc_csid[ 2]	?	edge_link_misc_wrd2	:
										rv32_edge_misc_csid[ 3]	?	edge_link_misc_wrd3	:
										rv32_edge_misc_csid[ 4]	?	edge_link_misc_wrd4	:
										rv32_edge_misc_csid[ 5]	?	edge_link_misc_wrd5	:
										rv32_edge_misc_csid[ 6]	?	edge_link_misc_wrd6	:
										rv32_edge_misc_csid[ 7]	?	edge_link_misc_wrd7	:
										rv32_edge_misc_csid[ 8]	?	edge_link_misc_wrd8	:
										rv32_edge_misc_csid[ 9]	?	edge_link_misc_wrd9	:	
										rv32_edge_misc_csid[10]	?	edge_link_misc_wrda	:	
										rv32_edge_misc_csid[11]	?	edge_link_misc_wrdb	:
										rv32_edge_misc_csid[12]	?	edge_link_misc_wrdc	:
										rv32_edge_misc_csid[13]	?	edge_link_misc_wrdd	:	
										rv32_edge_misc_csid[14]	?	edge_link_misc_wrde	:	
										rv32_edge_misc_csid[15]	?	edge_link_misc_wrdf	:	32'H0	;

genvar m	;
generate
	for(m = 0 ; m <16 ; m = m + 1) begin	:	gens_tpes_rwcs_ctrl
		assign	rv32_edge_misc_csid[m]	= &{rv32_edge_misc_csen	,	rv32_edge_misc_addr==m	};
		assign	rv32_edge_misc_wrid[m]	= &{rv32_edge_misc_wrcs	,	rv32_edge_misc_csid[m]	};
	end
endgenerate	
/**********************************************************************************************************************/
//WORD_00:	rora_rxln_cmnd_stat 
//WORD_01:	rora_rxln_cmnd_mark
	reg									rora_rxln_cmnd_stat		;	
	assign		rora_rxln_cmnd_clrs	=	rv32_edge_misc_wrid[0]	;
	assign		edge_link_misc_wrd0	= {	31'H0 ,	rora_rxln_cmnd_stat	};	
	assign		edge_link_misc_wrd1	= {	21'H0 ,	rora_rxln_cmnd_mark	};	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_rxln_cmnd_stat	<=	0	;
	else if(rora_rxln_cmnd_coda)		rora_rxln_cmnd_stat	<=	1	;	
	else if(rora_rxln_cmnd_clrs)		rora_rxln_cmnd_stat	<=	0	;	
/**********************************************************************************************************************/
//WORD_02:	edge_link_acks_argu
//	reg									rora_acks_rv32_reqs	;
	assign		edge_link_misc_wrd2	= {	31'H0 ,	rora_acks_rv32_reqs	};	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_acks_rv32_reqs	<=	0	;
	else if(rv32_edge_misc_wrid[2])		rora_acks_rv32_reqs	<=	1	;	
	else if(rora_acks_txln_done)		rora_acks_rv32_reqs	<=	0	;		

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rora_acks_rv32_data	<=	0	;
	else if(rv32_edge_misc_wrid[2])		rora_acks_rv32_data	<=	rv32_edge_misc_wdin	;	
/**********************************************************************************************************************/
//WORD_03:	cube_acks_selx_word  
	assign		edge_link_misc_wrd3	= {	29'H0 ,	cube_acks_argu_selx	};	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_acks_argu_selx	<=	0	;
	else if(rv32_edge_misc_wrid[3])		cube_acks_argu_selx	<=	rv32_edge_misc_wdin[ 2: 0]	;	
/**********************************************************************************************************************/
//WORD_04:	CUBE ISP MODE CTRL	
	assign		edge_link_misc_wrd4	= {	31'H0 , cube_ispx_mode_port	};

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_ispx_mode_port	<=	0	;
	else if(rv32_edge_misc_wrid[4])		cube_ispx_mode_port	<=	rv32_edge_misc_wdin[0]	;//	rv32_edge_misc_wdin[0]	;
/**********************************************************************************************************************/
//WORD_05:	CUBE RESET_N CTRL
	assign		edge_link_misc_wrd5	= {	30'H0	,	cube_ispx_rstn_port	,	cube_chip_rstn_port	};	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_ispx_rstn_port	<=	0	;
	else if(rv32_edge_misc_wrid[5])		cube_ispx_rstn_port	<=	rv32_edge_misc_wdin[1]	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_chip_rstn_port	<=	0	;
	else if(rv32_edge_misc_wrid[5])		cube_chip_rstn_port	<=	rv32_edge_misc_wdin[0]	;
/**********************************************************************************************************************/
//WORD_06:	CUBE MISC LINK CTRL
	reg			[ 2: 0]					cube_ufcm_cmnd_ctrl	;
	reg									cube_ufcm_cmnd_stat	;
	
	assign		cube_link_icfg_reqs	=	cube_ufcm_cmnd_ctrl	== 3'H1	;
	assign		cube_link_ocfg_reqs	=	cube_ufcm_cmnd_ctrl	== 3'H2	;
	assign		cube_link_idat_reqs	=	cube_ufcm_cmnd_ctrl	== 3'H3	;
	assign		cube_link_odat_reqs	=	cube_ufcm_cmnd_ctrl	== 3'H4	;
	
	assign		edge_link_misc_wrd6	= {	31'H0 ,cube_ufcm_cmnd_stat };	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_ufcm_cmnd_ctrl	<=	0	;
	else if(rv32_edge_misc_wrid[6])		cube_ufcm_cmnd_ctrl	<=	rv32_edge_misc_wdin[2:0];
	else if(cube_link_ufcm_done	)		cube_ufcm_cmnd_ctrl	<=	0	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_ufcm_cmnd_stat	<=	0	;
	else if(rv32_edge_misc_wrid[6])		cube_ufcm_cmnd_stat	<=	0	;
	else if(cube_link_ufcm_done	)		cube_ufcm_cmnd_stat	<=	1	;
/**********************************************************************************************************************/
//WORD_07:	CUBE  UART BAUD RATE
	reg			[11: 0]					rv32_uart_link_baud	;
	assign		edge_link_misc_wrd7	= {	20'H0 ,	rv32_uart_link_baud	};	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						rv32_uart_link_baud	<=	12'D217	;//
	else if(rv32_edge_misc_wrid[7])		rv32_uart_link_baud	<=	rv32_edge_misc_wdin[11:0]	;

	gens_gray_code #( .MSB	(11))	u_cube_uart_baud_rate(	
		.dtar_data						(cube_uart_baud_rate	),//output	reg [MSB: 0]
		.dtar_clki						(cube_bclk				),//input				
		.dtar_rstn						(cube_rstn				),//input				

		.dsrc_data						(rv32_uart_link_baud	),//input		[MSB: 0]
		.dsrc_clki						(rora_bclk				));//input				
/**********************************************************************************************************************/
//WORD_08:	CUBE  UART TXDO DATA
//	reg									cube_uart_txdo_drdy	;
	assign		edge_link_misc_wrd8	= 	cube_uart_txdo_data	;	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_uart_txdo_data	<=	0	;
	else if(rv32_edge_misc_wrid[8])		cube_uart_txdo_data	<=	rv32_edge_misc_wdin	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_uart_txdo_drdy	<=	0	;
	else								cube_uart_txdo_drdy	<=	rv32_edge_misc_wrid[7]	;
/**********************************************************************************************************************/
//WORD_09:	CUBE UART TXRX ENAB
	assign		edge_link_misc_wrd9	= {	30'H0	,	cube_uart_rxdi_enab	,	cube_uart_txdo_enab	};	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_uart_txdo_enab	<=	0	;
	else if(rv32_edge_misc_wrid[9])		cube_uart_txdo_enab	<=	rv32_edge_misc_wdin[0];
	else if(cube_uart_txdo_done)		cube_uart_txdo_enab	<=	0	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_uart_rxdi_enab	<=	0	;
	else if(rv32_edge_misc_wrid[9])		cube_uart_rxdi_enab	<=	rv32_edge_misc_wdin[1];
/**********************************************************************************************************************/
//WORD_10:	CUBE UART QUIZ STAT
	assign		edge_link_misc_wrda	= {	16'H0	,	cube_uart_quiz_enab ,	cube_uart_quiz_stat	};	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_uart_quiz_enab	<=	8'H00	;
	else if(rv32_edge_misc_wrid[10])	cube_uart_quiz_enab	<=	rv32_edge_misc_wdin[7:0];
/**********************************************************************************************************************/
//WORD_11:	CUBE USEC TIME CTRL
	reg			[31: 0]					cube_ecos_time_cnts	;
	reg			[ 9: 0]					cube_usec_time_cnts	;

	wire		cube_usec_time_flag	=	cube_usec_time_cnts	==	10'H7D;//125 CLOCKS
	wire		cube_time_cnts_zero	=	cube_ecos_time_cnts	==	32'H0	;
	
	assign		edge_link_misc_wrdb	= 	cube_ecos_time_cnts	;	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_usec_time_cnts	<=	0	;
	else if(rv32_edge_misc_wrid[11])	cube_usec_time_cnts	<=	0	;	
	else if(cube_usec_time_flag)		cube_usec_time_cnts	<=	0	;
	else 								cube_usec_time_cnts	<=	cube_usec_time_cnts + 1	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						cube_ecos_time_cnts	<=	0	;
	else if(rv32_edge_misc_wrid[11])	cube_ecos_time_cnts	<=	rv32_edge_misc_wdin	;
	else if(~cube_time_cnts_zero)		cube_ecos_time_cnts	<=	cube_ecos_time_cnts - cube_usec_time_flag	;
/**********************************************************************************************************************/
//WORD_12:	EDGE LINK ECOS VAR0
//WORD_13:	EDGE LINK ECOS VAR1
//WORD_14:	EDGE LINK ECOS VAR2
//WORD_15:	EDGE LINK ECOS VAR3
	reg			[31: 0]					edge_link_ecos_var0	;
	reg			[31: 0]					edge_link_ecos_var1	;
	reg			[31: 0]					edge_link_ecos_var2	;
	reg			[31: 0]					edge_link_ecos_var3	;

	assign		edge_link_misc_wrdc	= 	edge_link_ecos_var0	;	
	assign		edge_link_misc_wrdd	= 	edge_link_ecos_var1	;	
	assign		edge_link_misc_wrde	= 	edge_link_ecos_var2	;	
	assign		edge_link_misc_wrdf	= 	edge_link_ecos_var3	;	

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						edge_link_ecos_var0	<=	0	;
	else if(rv32_edge_misc_wrid[12])	edge_link_ecos_var0	<=	rv32_edge_misc_wdin	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						edge_link_ecos_var1	<=	0	;
	else if(rv32_edge_misc_wrid[13])	edge_link_ecos_var1	<=	rv32_edge_misc_wdin	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						edge_link_ecos_var2	<=	0	;
	else if(rv32_edge_misc_wrid[14])	edge_link_ecos_var2	<=	rv32_edge_misc_wdin	;

	always@(posedge rora_bclk or negedge rora_rstn)
	if(~rora_rstn)						edge_link_ecos_var3	<=	0	;
	else if(rv32_edge_misc_wrid[15])	edge_link_ecos_var3	<=	rv32_edge_misc_wdin	;
/**********************************************************************************************************************/


endmodule
