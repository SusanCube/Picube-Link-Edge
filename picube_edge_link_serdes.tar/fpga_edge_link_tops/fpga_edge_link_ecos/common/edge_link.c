
#include  "edge_link.h"
/******************************************************************************/
/******************************************************************************/
void	edge_boot_init(){
	CTRL->UART_ENAB	=	2	;//always open recv
	CTRL->CUBE_ACKS	=	2	;
}
//--------------------------------------
void  	edge_time_sets(uint32_t time){
	CTRL->USEC_TIME	=	time	;
	while(CTRL->USEC_TIME != 0)	;
}
//--------------------------------------
void	edge_soft_acks(uint32_t stat){
	CTRL->SOFT_ACKS	=	stat	;
	while(CTRL->SOFT_ACKS)	;
}
/******************************************************************************/
/******************************************************************************/
void  edge_icfg_parse(){

	uint32_t  ACKS_ARGU ;
	
	if(CMND_EDGE_DEST == EDGE_DEST_BYPS)
	{
		CTRL->CUBE_UFCM	=	1	;
		while((CTRL->CUBE_UFCM ) != 1)	;
	} else {
		ACKS_ARGU	=	*(uint32_t *)(CMND_AUXI_VAR0<<2)	;
		edge_soft_acks(ACKS_ARGU);
    }
}
//--------------------------------------
void  edge_ocfg_parse(){
	
	if(CMND_EDGE_DEST == EDGE_DEST_BYPS)
	{	
		CTRL->CUBE_UFCM	=	2	;
		while((CTRL->CUBE_UFCM ) != 1)	;
	} else {
		*(uint32_t *)(CMND_AUXI_VAR0<<2)	=	CMND_AUXI_VAR1	;
		edge_soft_acks(0x4F434647);		//"OCFG"
	}
}
/******************************************************************************/
/******************************************************************************/
void  edge_idat_parse(){
	CTRL->CUBE_UFCM	=	3	;
	while((CTRL->CUBE_UFCM ) != 1)	;
}
//--------------------------------------
void  edge_odat_parse(){
	CTRL->CUBE_UFCM	=	4	;
	while((CTRL->CUBE_UFCM ) != 1)	;
}
/******************************************************************************/
/******************************************************************************/
void  edge_aset_parse( ){
//make ISP enter active mode
    
	CTRL->ISPS_MODE	=	0		;
	CTRL->ISPS_RSTN	=	0		;
	edge_time_sets(5000000)		;

	CTRL->ISPS_RSTN	=	3		;
	edge_time_sets(5000000)		;
	edge_soft_acks(0x444f4e45)	;//"ASET"		
}
//--------------------------------------
void  edge_dnld_parse(){

    uint32_t  i;

	CTRL->UART_ENAB	=	3	;//always open recv

    for (i = 1; i < 9; i++) {
       CTRL->UART_TXDD = CMND->CMND_MEMO[i];
    }

	while((CTRL->UART_ENAB & 0x80000000) != 0x80000000)	;

	CTRL->UART_ENAB	=	2	;//disable TXDO
	edge_soft_acks(0x444E4C44)	;//"DNLD"		
}
//--------------------------------------
void  edge_boot_parse(){
    CTRL->UART_ENAB	=	3	;//always open recv

    // send ISP "G" command
    CTRL->UART_TXDD = 0x36322047;
    CTRL->UART_TXDD = 0x35333438;
    CTRL->UART_TXDD = 0x0d363534;

	while((CTRL->UART_ENAB & 0x80000000) != 0x80000000)	;
	CTRL->UART_ENAB	=	2	;//disable TXDO
	edge_soft_acks(0x424F4F54)	;//"BOOT"	
}
/******************************************************************************/
/******************************************************************************/
void  edge_nnex_parse(){
	CTRL->CUBE_UFCM	=	1	;
	while((CTRL->CUBE_UFCM ) != 1)	;
}
//--------------------------------------
void  edge_task_parse(){
	CTRL->CUBE_UFCM	=	1	;
	while((CTRL->CUBE_UFCM ) != 1)	;
}
