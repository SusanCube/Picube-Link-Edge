
#ifndef EDGE_LINK_H_
#define EDGE_LINK_H_

#include  "edge_ctrl.h"

	void	edge_time_sets(uint32_t time);
	void	edge_soft_acks(uint32_t stat);

	void	edge_task_parse();
	void	edge_nnex_parse();

	void	edge_aset_parse();
	void	edge_dnld_parse();
	void	edge_boot_parse();

	void	edge_idat_parse();
	void	edge_odat_parse();

	void	edge_icfg_parse();
	void	edge_ocfg_parse();

#endif  /*TPES_LINK_H_*/
