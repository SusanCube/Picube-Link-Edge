
#ifndef EDGE_CTRL_H_
#define EDGE_CTRL_H_

#include <stdint.h>
/******************************************************************************/
	#define	CMND_TASK_MARK 				0x00000400	//BIT08
	#define	CMND_NNEX_MARK 				0x00000200	//BIT07
	#define	CMND_BOOT_MARK 				0x00000100	//BIT06
	#define	CMND_DNLD_MARK 				0x00000080	//BIT05
	#define	CMND_ASET_MARK 				0x00000040	//BIT04
	#define	CMND_OMTX_MARK 				0x00000020	//BIT03
	#define	CMND_IMTX_MARK 				0x00000010	//BIT02
	#define	CMND_OVCT_MARK 				0x00000008	//BIT03
	#define	CMND_IVCT_MARK 				0x00000004	//BIT02
	#define	CMND_OCFG_MARK 				0x00000002	//BIT01
	#define	CMND_ICFG_MARK 				0x00000001	//BIT00

/******************************************************************************/
	typedef struct _EDGE_CTRL_ {
		volatile uint32_t LINK_STAT		; // 00_00
		volatile uint32_t LINK_CMND		; // 01_04
		volatile uint32_t SOFT_ACKS		; // 02_08	SOFT ACKS
		volatile uint32_t CUBE_ACKS		; // 03_0C	CUBE ACKS WORD SELECT

		volatile uint32_t ISPS_MODE		; // 04_10
		volatile uint32_t ISPS_RSTN		; // 05_14
		volatile uint32_t CUBE_UFCM		; // 06_18
		volatile uint32_t UART_BAUD		; // 07_1C

		volatile uint32_t UART_TXDD		; // 08_20
	    volatile uint32_t UART_ENAB		; // 09_24
		volatile uint32_t UART_QUIZ		; // 0A_28
		volatile uint32_t USEC_TIME		; // 0B_2C

		volatile uint32_t ECOS_VAR0		; // 0C_30
		volatile uint32_t ECOS_VAR1		; // 0D_34
		volatile uint32_t ECOS_VAR2		; // 0E_38
		volatile uint32_t ECOS_VAR3		; // 0F_3C
	}	EDGE_CTRL	;					
//--------------------------------------
	#define CTRL_BASE 	0x00000000
	#define CTRL			((EDGE_CTRL *)CTRL_BASE)
	
/******************************************************************************/
	typedef struct _CMND_ARGU_ {
		volatile uint32_t CMND_MEMO[16]		; // 40 ~ 7C
	} 	CMND_ARGU	;
//----------------------------------------------------------------------
	#define CMND_ARGU_BASE 				(0x40 + CTRL_BASE)
	#define CMND				     	((CMND_ARGU *)CMND_ARGU_BASE)
//----------------------------------------------------------------------
	#define	CMND_EDGE_DEST				CMND->CMND_MEMO[0 ]	
	#define	CMND_CUBE_DEST				CMND->CMND_MEMO[1 ]	
	#define	CMND_SLAV_ADDR				CMND->CMND_MEMO[2 ]	
	#define	CMND_META_ROWS				CMND->CMND_MEMO[3 ]	
	#define	CMND_META_COLS				CMND->CMND_MEMO[4 ]	
	#define	CMND_AUXI_VAR0				CMND->CMND_MEMO[5 ]	
	#define	CMND_AUXI_VAR1				CMND->CMND_MEMO[6 ]	
	#define	CMND_AUXI_VAR2				CMND->CMND_MEMO[7 ]	
	#define	CMND_AUXI_VAR3				CMND->CMND_MEMO[8 ]	


	#define EDGE_DEST_BYPS   			0x00
//  	#define TPEL_DEST_CRAM   0x01
//  	#define TPEL_DEST_CFIG   0x02
  


 
#endif /*EDGE_CTRL_H_*/

