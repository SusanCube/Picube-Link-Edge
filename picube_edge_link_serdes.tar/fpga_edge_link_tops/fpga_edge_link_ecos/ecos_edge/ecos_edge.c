
#include  "../common/edge_ctrl.h"
#include  "../common/edge_link.h"

void    main()  {
  
  	while (1) {
    	if(CTRL->LINK_STAT==0X0)			{	continue	;	}
		else{
    		     if(CTRL->LINK_CMND & CMND_ICFG_MARK) { CTRL->LINK_STAT = 0x49434647	;	edge_icfg_parse();	continue	;}
    		else if(CTRL->LINK_CMND & CMND_OCFG_MARK) { CTRL->LINK_STAT = 0x4F434647	;	edge_ocfg_parse();	continue	;}
    		else if(CTRL->LINK_CMND & CMND_IVCT_MARK) { CTRL->LINK_STAT = 0x49564354	;	edge_idat_parse();	continue	;}
			else if(CTRL->LINK_CMND & CMND_OVCT_MARK) { CTRL->LINK_STAT = 0x4F564354	;	edge_odat_parse();	continue	;}
    		else if(CTRL->LINK_CMND & CMND_IMTX_MARK) { CTRL->LINK_STAT = 0x494D5458	;	edge_idat_parse();	continue	;}
			else if(CTRL->LINK_CMND & CMND_OMTX_MARK) { CTRL->LINK_STAT = 0x4F4D5458	;	edge_odat_parse();	continue	;}
    		else if(CTRL->LINK_CMND & CMND_ASET_MARK) { CTRL->LINK_STAT = 0x41534554	;	edge_aset_parse();	continue	;}
    		else if(CTRL->LINK_CMND & CMND_DNLD_MARK) { CTRL->LINK_STAT = 0x444E4C44	;	edge_dnld_parse();	continue	;}
    		else if(CTRL->LINK_CMND & CMND_BOOT_MARK) { CTRL->LINK_STAT = 0x424F4F54	;	edge_boot_parse();	continue	;}
			else if(CTRL->LINK_CMND & CMND_NNEX_MARK) { CTRL->LINK_STAT = 0x4E4E4558	;	edge_nnex_parse();	continue	;}
    		else if(CTRL->LINK_CMND & CMND_TASK_MARK) { CTRL->LINK_STAT = 0x5441534B	;	edge_task_parse();	continue	;}
		}	
  	}
}
