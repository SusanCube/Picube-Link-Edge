
module	gens_gray_code #(	
	parameter MSB =	22 
)(	output	reg [MSB: 0]				dtar_data	,
	input								dtar_clki	,
	input								dtar_rstn	,

	input		[MSB: 0]				dsrc_data	,
	input								dsrc_clki	);

	reg			[MSB: 0]				dsrc_gray_code	;
	wire		[MSB: 0]				dsrc_gray_sync	;

	assign		dsrc_gray_sync	= {		dsrc_data[MSB] , dsrc_data[MSB:1] ^ dsrc_data[MSB-1:0]	};

	always@(posedge dsrc_clki)			dsrc_gray_code	<=	dsrc_gray_sync	;
/**********************************************************************************************************************/
	reg			[MSB: 0]				dtar_gray_syn0	;
	reg			[MSB: 0]				dtar_gray_syn1	;
	wire		[MSB: 0]				dtar_gray_code	;
	
	always@(posedge dtar_clki or negedge dtar_rstn)
	if(~dtar_rstn)	begin				dtar_gray_syn0	<=	0	;
										dtar_gray_syn1	<=	0	;
	end else	begin					dtar_gray_syn0	<=	dsrc_gray_code	;
										dtar_gray_syn1	<=	dtar_gray_syn0	;
	end

	assign	dtar_gray_code[MSB]=dtar_gray_syn1[MSB]	;

	for(genvar i=MSB-1 ; i>=0 ; i =i-1) begin
		assign	dtar_gray_code[i] = dtar_gray_code[i+1] ^ dtar_gray_syn1[i];
	end
/**********************************************************************************************************************/

	always@(posedge dtar_clki or negedge dtar_rstn)
	if(~dtar_rstn)						dtar_data	<=	0	;
	else								dtar_data	<=	dtar_gray_code	;
									


//	assign	dtar_data	=	dtar_data_gray_decd	;

endmodule
  