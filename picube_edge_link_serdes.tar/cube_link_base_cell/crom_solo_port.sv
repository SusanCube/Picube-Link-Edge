// 
// FPGA version, by template
//
//  run vivado/ku35_0/getrsrc.sh, 
//    to copy rsim/init_file/tpgs_rv32_crom.hex to <ip_root>/rv32_rom.hex
//    copy this file to vivado/ku35_0/rsrc

module  solo_port_crom #(
	parameter	FILE = "defaulr.hex"
)(
	output  reg [31: 0]       			DO	,
	input       [11: 0]       			AD	,
	input                     			EN	,
	input                     			CK	);
/******************************************************************************/
(* rom_style="{block}" *)
  	reg    		[31: 0]           		mem[0:4095]  ;

	initial 	begin
		fid =	$fopen(FILE, "r");
		if (fid == 0)	begin
            $display("==========================================");
            $display("  [ERROR] [%m] File not found or no permission:");
            $display("          \"%0s\"", FILE);
            $display("  >>> Memory is NOT initialized! <<<");
            $display("==========================================");
            $finish;   
        end else begin
            $fclose(fid);
            $readmemh(FILE, mem);
            $display("[%m] OK: loaded %0d x %0d bits from \"%0s\"",FILE);
        end
	end

  	always  @(posedge CK)   	 	DO	<= 	EN	?	mem[AD] : DO;

endmodule
