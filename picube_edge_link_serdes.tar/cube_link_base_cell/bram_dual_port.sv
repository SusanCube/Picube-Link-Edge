module	bram_dual_port	#(
  parameter ADDR_BITS = 4	,
  parameter DATA_BITS = 256	
)  (
	input  				 				wport_csen	,
	input		[ADDR_BITS-1:0]			wport_addr	,
	input		[DATA_BITS-1:0]			wport_data	,
	input								wport_clki	,

	input		[ADDR_BITS-1:0] 		rport_addr	,
	output	reg	[DATA_BITS-1:0] 		rport_data	,
	input								rport_clki	);

(* ram_style="block" *) reg [DATA_BITS-1:0] memo[(1<<ADDR_BITS)-1:0];

	always@(posedge wport_clki)
	if(wport_csen)
		memo[wport_addr]	<=	wport_data		;

	always@(posedge rport_clki)
		rport_data			<=	memo[rport_addr];
		


endmodule