module	sole_port_bram	#(
	parameter ADDR_BITS = 10	,
	parameter DATA_BITS = 32	
)  (
	input  				 			bram_csen	,
	input  				 			bram_wrcs	,
	input		[ADDR_BITS-1:0]		bram_addr	,
	input		[DATA_BITS-1:0]		bram_wdata	,
	output	reg	[DATA_BITS-1:0]		bram_rdata	,
	input							bram_clki	);

(* ram_style="block" *) reg [DATA_BITS-1:0] memo[(1<<ADDR_BITS)-1:0];

	always@(posedge bram_clki)
	if(bram_csen & bram_wrcs)		memo[bram_addr]	<=	bram_wdata		;

	always@(posedge bram_clki)
									bram_rdata		<=	memo[bram_addr]	;
endmodule