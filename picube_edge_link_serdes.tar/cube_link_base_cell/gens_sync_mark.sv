
module  gens_sync_mark (	
	output								dtar_mark	,
	input								dtar_clki	,
	input								dtar_rstn	,

	input                   	        dsrc_mark   ,
	input								dsrc_clki	,
	input								dsrc_rstn	);
//----------------------------------------------------------------------
	reg									dsrc_mark_samp	;

	always@(posedge dsrc_clki or negedge dsrc_rstn)
    if(~dsrc_rstn)      				dsrc_mark_samp	<= 	1'B0     	;
	else								dsrc_mark_samp	<=	dsrc_mark	;
//----------------------------------------------------------------------
	reg		[1:0]						dtar_mark_samp	;
		
	always@(posedge dtar_clki or negedge dtar_rstn)
    if(~dtar_rstn)      		    	dtar_mark_samp  <= 2'B0     ;
	else 								dtar_mark_samp 	<={dsrc_mark_samp	, dtar_mark_samp[1]	};

	assign	dtar_mark	=	dtar_mark_samp[0]	;
	
endmodule