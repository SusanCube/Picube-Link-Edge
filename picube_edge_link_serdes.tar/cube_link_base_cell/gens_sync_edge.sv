
module  gens_sync_edge #(	parameter EXTN = 2	)
(	
	output								dtar_rise	,
	output								dtar_fall	,
	input								dtar_clki	,
	input								dtar_rstn	,

	input                   	        dsrc_mark   ,
	input								dsrc_clki	,
	input								dsrc_rstn	);
//----------------------------------------------------------------------
	reg		[EXTN:0]					dsrc_extn_regs	;
	reg									dsrc_extn_mark	;

	always@(posedge dsrc_clki or negedge dsrc_rstn)
    if(~dsrc_rstn)      				dsrc_extn_regs	<= 	0	;
	else								dsrc_extn_regs	<= {dsrc_mark ,	dsrc_extn_regs[EXTN:1]	};

	always@(posedge dsrc_clki or negedge dsrc_rstn)
    if(~dsrc_rstn)      				dsrc_extn_mark	<=	1'B0	;
	else								dsrc_extn_mark	<=|{dsrc_mark , dsrc_extn_regs	};
//----------------------------------------------------------------------
	reg		[2:0]						dtar_mark_samp	;
		
	always@(posedge dtar_clki or negedge dtar_rstn)
    if(~dtar_rstn)      		    	dtar_mark_samp  <= 3'B0     ;
	else 								dtar_mark_samp 	<={dsrc_extn_mark	, dtar_mark_samp[2:1]	};


	assign	dtar_rise	=	dtar_mark_samp[1:0]	==	2'B10	;
	assign	dtar_fall	=	dtar_mark_samp[1:0]	==	2'B01	;

endmodule