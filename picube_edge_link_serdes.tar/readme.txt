本次开源工程，是基于高云FPGA实现的EDGE算力互联的示例。
EDGE与HUB之间通过1路serdes互联，与MPU核之间通过DVP核GMSL接口互联。
我做了典型应用的仿真环境，实现了基于serdes互联对EDGE的配置，以及双向的数据读写。
本开源工程的使用：
（1）请你创建自己的工作目录
（2）进入工作目录，link fpga_edge_link_tops\fpga_edge_link_simu\simu_platform\runsim.sh 到当前目录
（3）修改runsim.sh的“setenv		PROJ_HOME		？？”，将PROJ_HOME指向你的开源工程存放目录
（4）在当前目录用 runsim.sh 1200的命令启动仿真，最高限时1200us

