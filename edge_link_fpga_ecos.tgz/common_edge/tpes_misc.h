
#ifndef TPES_MISC_H_
#define TPES_MISC_H_

#include <stdint.h>
/**********************************************************************/
	typedef struct _TPEL_CTRL_ {
		volatile uint32_t TPES_LINK		; // 00_00
		volatile uint32_t TPES_ACKS		; // 01_04
		volatile uint32_t RESP_SELX		; // 02_08
		volatile uint32_t ISPS_MDOE		; // 03_0C
		volatile uint32_t TPES_RSTN		; // 04_10
		volatile uint32_t DVPX_ENAB		; // 05_14
		volatile uint32_t UART_BAUD		; // 06_18
		volatile uint32_t UART_TXDD		; // 07_1C

	    volatile uint32_t UART_ENAB		; // 08_20
		volatile uint32_t UART_QUIZ		; // 09_24
		volatile uint32_t CUBE_LINK		; // 0A_28

		volatile uint32_t LINK_CMND		; // 0B_2C
		volatile uint32_t USEC_TIME		; // 0C_30
		volatile uint32_t ECOS_VAR0		; // 0D_34
		volatile uint32_t ECOS_VAR1		; // 0E_38
		volatile uint32_t ECOS_VAR2		; // 0F_3C
	}	TPEL_CTRL	;					
//----------------------------------------------------------------------
	#define TPEL_BASE 	0x0000c000
	#define TPEL			((TPEL_CTRL *)TPEL_BASE)

	#define	TPEL_LINK_CMND			TPEL->LINK_CMND
	#define	TPEL_LINK_ACKS			TPEL->TPES_ACKS
	#define	TPEL_RESP_SELX			TPEL->RESP_SELX

	#define	TPEL_USEC_TIME			TPEL->USEC_TIME


	#define	TPEL_ISPS_MODE			TPEL->ISPS_MDOE
	#define	TPEL_ISPS_RSTN			TPEL->TPES_RSTN
	
	#define	TPEL_UART_TXDD			TPEL->UART_TXDD
	#define	TPEL_UART_ENAB			TPEL->UART_ENAB
	
	#define	TPEL_CUBE_LINK			TPEL->CUBE_LINK

	#define	TPEL_ECOS_VAR2			TPEL->ECOS_VAR2
	
	#define TPEL_BOOT_MASK 			0x00000200	//BIT09	
	#define TPEL_DNLD_MASK 			0x00000100	//BIT08
	#define TPEL_ASET_MASK 			0x00000080	//BIT07
	#define TPEL_OMTX_MASK 			0x00000040	//BIT06
	#define TPEL_IMTX_MASK 			0x00000020	//BIT05
	#define TPEL_OVCT_MASK 			0x00000010	//BIT04
	#define TPEL_IVCT_MASK 			0x00000008	//BIT03
	#define TPEL_NNEX_MASK 			0x00000004	//BIT02
	#define TPEL_OCFG_MASK 			0x00000002	//BIT01
	#define TPEL_ICFG_MASK 			0x00000001	//BIT00
/**********************************************************************/
	typedef struct _TPEL_CMND_ {
		volatile uint32_t CMND_MEMO[16]		; // 40 ~ 7C
	} 	TPEL_CMND	;
//----------------------------------------------------------------------
	#define TPEL_CMND_BASE 	0x0000c040
	#define TPES_CMND     	((TPEL_CMND *)TPEL_CMND_BASE)
//----------------------------------------------------------------------
	#define	TPEL_TPES_DEST			TPES_CMND->CMND_MEMO[0 ]	
	#define	TPEL_CUBE_DEST			TPES_CMND->CMND_MEMO[1 ]	
	#define	TPEL_SLAV_ADDR			TPES_CMND->CMND_MEMO[2 ]	
	#define	TPEL_META_ROWS			TPES_CMND->CMND_MEMO[3 ]	
	#define	TPEL_META_COLS			TPES_CMND->CMND_MEMO[4 ]	
	#define	TPEL_AUXI_VAR0			TPES_CMND->CMND_MEMO[5 ]	
	#define	TPEL_AUXI_VAR1			TPES_CMND->CMND_MEMO[6 ]	
	#define	TPEL_AUXI_VAR2			TPES_CMND->CMND_MEMO[7 ]	
	#define	TPEL_AUXI_VAR3			TPES_CMND->CMND_MEMO[8 ]	


	#define TPEL_DEST_BYPS   0x00
//  	#define TPEL_DEST_CRAM   0x01
//  	#define TPEL_DEST_CFIG   0x02
  


/**********************************************************************/
	typedef struct _CUBE_RESP_ {
		volatile uint32_t RESP_MEMO[16]		; // 80 ~ BC
	} 	CUBE_RESP	;
//----------------------------------------------------------------------
	#define CUBE_RESP_BASE 	0x0000c080
	#define CUBE_RESP     	((CUBE_RESP *)CUBE_RESP_BASE)
//----------------------------------------------------------------------
	#define	CUBE_RESP_DAT0			CUBE_RESP->RESP_MEMO[0 ]	
	#define	CUBE_RESP_DAT1			CUBE_RESP->RESP_MEMO[1 ]	
	#define	CUBE_RESP_DAT2			CUBE_RESP->RESP_MEMO[2 ]	
	#define	CUBE_RESP_DAT3			CUBE_RESP->RESP_MEMO[3 ]	
	#define	CUBE_RESP_DAT4			CUBE_RESP->RESP_MEMO[4 ]	
	#define	CUBE_RESP_DAT5			CUBE_RESP->RESP_MEMO[5 ]	
	#define	CUBE_RESP_DAT6			CUBE_RESP->RESP_MEMO[6 ]	
	#define	CUBE_RESP_DAT7			CUBE_RESP->RESP_MEMO[7 ]	
/**********************************************************************/
 
#endif /*TPUC_MISC_H_*/

