
#ifndef TPES_LINK_H_
#define TPES_LINK_H_

#include  "tpes_misc.h"

	void		tpes_time_sets(uint32_t time);

	void		tpes_aset_parse();
	void		tpes_dnld_parse();
	void		tpes_boot_parse();


	void		tpes_icfg_parse();
	void		tpes_ocfg_parse();
	void		tpes_nnex_parse();
	void		tpes_idat_parse();
	void		tpes_odat_parse();
	void		tpes_idat_parse();
	void		tpes_odat_parse();


	void  		tpes_icfg_cube();
	void  		tpes_ocfg_cube();

	void 		tpes_icfg_self();
	void  		tpes_ocfg_self();

#endif  /*TPES_LINK_H_*/
