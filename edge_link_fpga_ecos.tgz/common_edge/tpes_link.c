
#include  "tpes_link.h"
/**********************************************************************/
void	tpes_boot_init(){
	TPEL_UART_ENAB	=	2	;//always open recv
	TPEL_RESP_SELX	=	2	;
}
/**********************************************************************/
void  tpes_time_sets(uint32_t time){
	TPEL_USEC_TIME	=	time	;
	while(TPEL_USEC_TIME != 0)	;
}
/**********************************************************************/
void  tpes_aset_parse( ){
//make ISP enter active mode
    
	TPEL_ISPS_MODE	=	0		;
	TPEL_ISPS_RSTN	=	0		;
	tpes_time_sets(5000000)		;
	
	TPEL_ISPS_RSTN	=	3		;
	tpes_time_sets(1000000)		;
	TPEL_LINK_ACKS	=0x41534554	;
}
/**********************************************************************/
void  tpes_dnld_parse(){

    uint32_t  i;

	TPEL_UART_ENAB	=	3	;//always open recv


    for (i = 1; i < 9; i++) {
       TPEL_UART_TXDD = TPES_CMND->CMND_MEMO[i];
    }

	while((TPEL_UART_ENAB & 0x80000000) != 0x80000000)	;

	TPEL_UART_ENAB	=	2	;//disable TXDO

	TPEL_LINK_ACKS	=	0x444E4C44	;
}
/**********************************************************************/
void  tpes_boot_parse(){
    TPEL_UART_ENAB	=	3	;//always open recv

    // send ISP "G" command
    TPEL_UART_TXDD = 0x36322047;
    TPEL_UART_TXDD = 0x35333438;
    TPEL_UART_TXDD = 0x0d363534;

	while((TPEL_UART_ENAB & 0x80000000) != 0x80000000)	;
	TPEL_UART_ENAB	=	2	;//disable TXDO

	TPEL_LINK_ACKS	=	0x424F4F54	;
}
/**********************************************************************/
void  tpes_odat_parse(){
	TPEL_CUBE_LINK	=	2	;
	while((TPEL_CUBE_LINK ) != 1)	;
}
/**********************************************************************/
void  tpes_idat_parse(){
	TPEL_CUBE_LINK	=	3	;
	while((TPEL_CUBE_LINK ) != 1)	;
}
/**********************************************************************/
void  tpes_nnex_parse(){
	TPEL_CUBE_LINK	=	1	;
	while((TPEL_CUBE_LINK ) != 1)	;
}
/**********************************************************************/
void  tpes_ocfg_parse(){
	
	
	if(TPEL_TPES_DEST == TPEL_DEST_BYPS)
	{	
		TPEL_CUBE_LINK	=	1	;
		while((TPEL_CUBE_LINK ) != 1)	;
	} else {
		*(uint32_t *)TPEL_AUXI_VAR0	=	TPEL_AUXI_VAR1	;
	
		TPEL_LINK_ACKS	=	0x12345678	;
	}
}
/**********************************************************************/
void  tpes_icfg_parse(){

	uint32_t  ICFG_ADDR ;

	
	if(TPEL_TPES_DEST == TPEL_DEST_BYPS)
	{
		TPEL_CUBE_LINK	=	1	;
		while((TPEL_CUBE_LINK ) != 1)	;
	} else {
		ICFG_ADDR		=	TPEL_AUXI_VAR0	;
		TPEL_LINK_ACKS	=	*(uint32_t *)ICFG_ADDR	;

    }
}
