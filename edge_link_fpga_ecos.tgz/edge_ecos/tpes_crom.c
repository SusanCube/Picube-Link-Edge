
#include  "../common_tpes/tpes_misc.h"
#include  "../common_tpes/tpes_link.h"

void    main()  {
  TPEL->ECOS_VAR0	=	0x1234	;
  
  tpes_boot_init();
  
  while (1) {
    TPEL_LINK_CMND = TPEL->TPES_LINK ;

    if(TPEL_LINK_CMND & TPEL_ICFG_MASK) { TPEL->ECOS_VAR0 =	0x0000	;	TPEL->TPES_LINK = 0	;	tpes_icfg_parse();	}
    if(TPEL_LINK_CMND & TPEL_OCFG_MASK) { TPEL->ECOS_VAR0 =	0x1111	;	TPEL->TPES_LINK = 0	;	tpes_ocfg_parse();	}
    if(TPEL_LINK_CMND & TPEL_NNEX_MASK) { TPEL->ECOS_VAR0 =	0x2222	;	TPEL->TPES_LINK = 0	;	tpes_nnex_parse();	}
    if(TPEL_LINK_CMND & TPEL_IVCT_MASK) { TPEL->ECOS_VAR0 =	0x3333	;	TPEL->TPES_LINK = 0	;	tpes_idat_parse();	}
	if(TPEL_LINK_CMND & TPEL_OVCT_MASK) { TPEL->ECOS_VAR0 =	0x4444	;	TPEL->TPES_LINK = 0	;	tpes_odat_parse();	}
    if(TPEL_LINK_CMND & TPEL_IMTX_MASK) { TPEL->ECOS_VAR0 =	0x5555	;	TPEL->TPES_LINK = 0	;	tpes_idat_parse();	}
	if(TPEL_LINK_CMND & TPEL_OMTX_MASK) { TPEL->ECOS_VAR0 =	0x6666	;	TPEL->TPES_LINK = 0	;	tpes_odat_parse();	}
    if(TPEL_LINK_CMND & TPEL_ASET_MASK) { TPEL->ECOS_VAR0 =	0x7777	;	TPEL->TPES_LINK = 0	;	tpes_aset_parse();	}
    if(TPEL_LINK_CMND & TPEL_DNLD_MASK) { TPEL->ECOS_VAR0 =	0x8888	;	TPEL->TPES_LINK = 0	;	tpes_dnld_parse();	}
    if(TPEL_LINK_CMND & TPEL_BOOT_MASK) { TPEL->ECOS_VAR0 =	0x9999	;	TPEL->TPES_LINK = 0	;	tpes_boot_parse();	}
  }
}

 
 
 
 
