module  asyn_slow_sync_fast(
	input							slow_mark	,
	input							slow_clrs	,
	input							slow_clki	,
	input							slow_rstn	,
	
	output	reg						fast_mark  	,
	input							fast_csen   ,
	input							fast_clki	,
	input							fast_rstn	);
//----------------------------------------------------------------------
	reg								slow_extn_regs	;
	reg								slow_extn_mark	;

	always@(posedge slow_clki or negedge slow_rstn)
	if(!slow_rstn)      			slow_extn_regs	<= 0    ;
	else if(slow_clrs)				slow_extn_regs	<= 0    ;
	else							slow_extn_regs	<=slow_mark 	;

	always@(posedge slow_clki or negedge slow_rstn)
	if(!slow_rstn)      			slow_extn_mark	<= 1'B0     ;
    else if(slow_clrs)     			slow_extn_mark	<= 1'B0     ;
    else							slow_extn_mark	<=	slow_extn_regs	|	slow_mark	;
//----------------------------------------------------------------------
	reg			[ 1: 0]				fast_mark_samp	;
	
	always@(posedge fast_clki or negedge slow_rstn)
	if(!slow_rstn)         			fast_mark_samp	<= 0    ;  	
	else if(slow_clrs)     			fast_mark_samp	<= 0    ;
	else							fast_mark_samp	<={slow_mark,	fast_mark_samp[1]	};
 
	assign	fast_mark	=	fast_mark_samp[0]	;

endmodule