
module  asyn_fast_sync_slow #(	parameter EXTN_MULT = 2	)
(	
	output							slow_mark	,
	input							slow_clrs	,
	input							slow_clki	,
	input							slow_rstn	,    

	input                           fast_mark   ,
	input							fast_clki	,
	input							fast_rstn	);
//----------------------------------------------------------------------
	reg		[EXTN_MULT:0]			fast_extn_regs	;
	reg								fast_extn_mark	;

	always@(posedge fast_clki or negedge fast_rstn)
    if(~fast_rstn)      			fast_extn_regs	<= 0     ;
	else if(slow_clrs)				fast_extn_regs	<= 0     ;
    else							fast_extn_regs	<={fast_mark ,	fast_extn_regs[EXTN_MULT:1]	};

	always@(posedge fast_clki or negedge fast_rstn)
    if(~fast_rstn)      			fast_extn_mark	<= 1'B0     ;
	else if(slow_clrs)				fast_extn_mark	<= 1'B0     ;
    else							fast_extn_mark	<=|fast_extn_regs	;
//----------------------------------------------------------------------
	reg		[1:0]					slow_mark_samp	;
	
//	wire	slow_mark_rise		=	slow_mark_samp[1:0]	==	2'B10	;
//	wire	slow_mark_fall		=	slow_mark_samp[1:0]	==	2'B01	;
	
	always@(posedge slow_clki or negedge slow_rstn)
    if(~slow_rstn)      		    slow_mark_samp  <= 3'B0     ;
	else if(slow_clrs)				slow_mark_samp  <= 3'B0     ;
    else 							slow_mark_samp 	<={fast_extn_mark	, slow_mark_samp[1]	};

	assign	slow_mark	=	slow_mark_samp[0]	;

//	always@(posedge slow_clki)
//    if(!slow_rstn)  			    slow_mark		 <= 1'B0     ;
//   	else if(slow_mark_rise)			slow_mark		 <= 1'B1     ;
//	else if(slow_mark_fall)			slow_mark		 <= 1'B0     ;

endmodule