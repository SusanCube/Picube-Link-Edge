
module	slx9_clks_gens	(
		output						tpes_fclk	,//100MHZ,125MHz,150Mhz,160MHZ
		output						tpes_strb	,//fast vs slow 1/4
		output						tpes_sclk	,//25MHZ,31.25MHZ,37.5MHZ,//40MHZ
        output                      cube_clko    ,//25MHZ
		
		output	reg					isde_prst	,//High Active
		output	reg					tpes_rstn	,//Low Active
		output	reg					tpem_rstn	,

		input						tpem_fclk	,//200MHZ,250MHZ,300MHZ,320MHZ
		input						tpem_sclk	,//62.5MHZ,75MHZ,80MHZ
		input						auxi_rstn	,//FROM SOFTWARE
		input						extn_rstn	);//FROM PAD
/**********************************************************************/
	wire							pllx_lock	;
	wire	mixs_rstn		=   &{	auxi_rstn, extn_rstn , pllx_lock };

	reg		[15: 0]					tpes_rstn_cnts = 0	;
	wire	[15: 0]					tpes_rstn_tnxt	;

	assign	tpes_rstn_tnxt	=		tpes_rstn_cnts + 1	;
	
	always@(posedge tpes_sclk or negedge mixs_rstn)
    if(~mixs_rstn)      tpes_rstn   <=  0;
	else                tpes_rstn	<=  tpes_rstn_cnts	>=	16'H7D	;

	always@(posedge tpes_sclk  or negedge mixs_rstn )
	if(~mixs_rstn)					tpes_rstn_cnts	<=	0	;
	else if(~tpes_rstn)				tpes_rstn_cnts	<=	tpes_rstn_tnxt	;
//---------------------------------------------------------------------
	reg		[ 5: 0]					extn_rstn_time = 0 ;
	wire	[ 5: 0]					extn_rstn_tnxt	;
	
	assign	extn_rstn_tnxt	=		extn_rstn_time + 1	;
  always@(posedge tpem_sclk)  begin
		tpem_rstn		<=		extn_rstn_time	>=	 6'H3D		;
		isde_prst		<=	~	(extn_rstn_time >=   6'H3D);
  end

	always@(posedge tpem_sclk  or negedge extn_rstn )
	if(~extn_rstn)					extn_rstn_time	<=	0	;
	else if(~tpem_rstn)				extn_rstn_time	<=	extn_rstn_tnxt	;

/**********************************************************************/
	reg		[ 3: 0]					tpes_strb_posi	;
	wire							tpes_strb_m8bd	;
	assign	tpes_strb		=		tpes_strb_posi[3]	;

	always@(posedge tpes_fclk or negedge tpes_rstn)
	if(!tpes_rstn) 					tpes_strb_posi	<=	4'H1	;
	else							tpes_strb_posi	<= {tpes_strb_posi[2:0],tpes_strb_posi[3]};
//------------------------------------------------------------
	wire								cube_cclk	;

	ODDR2 #(
    	.DDR_ALIGNMENT        ("C0"       ),
    	.INIT                 (1'b0       ),
    	.SRTYPE               ("ASYNC"    ))
	u_cube_clko (
		.Q							(cube_clko			),	// 1-bit output: Data output to IOB
		.D0							(1'B0				),	// 1-bit input: Parallel data input 1
		.D1							(1'B1				),	// 1-bit input: Parallel data input 2
		.C0							( cube_cclk		),	// 1-bit input: High-speed clock input
		.C1							(~cube_cclk		),	// 1-bit input: High-speed clock input
    	.CE             			(1'b1     			),
    	.S              			(1'b0     			),
		.R 							(1'B0				)); // 1-bit input: Active-High Async Reset
/**********************************************************************/
	
    PLL_200M		          	  	u_dlls(
        .CLK_IN1              	      	(tpem_fclk	),//input         
	
        .CLK_OUT1             	      	(tpes_fclk	),
        .CLK_OUT2             	      	(tpes_sclk	),
        .CLK_OUT3             	      	(cube_cclk	),
	
        .RESET                	      	(isde_prst	),
        .LOCKED               	      	(pllx_lock	));
/**********************************************************************/



endmodule

	 
