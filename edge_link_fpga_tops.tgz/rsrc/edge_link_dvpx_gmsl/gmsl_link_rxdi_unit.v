
module  gmsl_link_rxdi_unit(
	output  reg [ 7: 0]             	cube_gmsl_fram_mbdo ,
    output  reg [ 7: 0]             	cube_gmsl_dat0_mbdo ,
    output  reg [ 7: 0]             	cube_gmsl_dat1_mbdo ,
    output  reg [ 7: 0]             	cube_gmsl_dat2_mbdo ,
    output  reg [ 7: 0]             	cube_gmsl_dat3_mbdo ,

    input                           	gmsl_link_data_enab ,
	input                           	gmsl_link_data_reqs ,
	output  reg                     	gmsl_link_data_done ,

    input       [19: 0]             	cube_link_xdat_rows ,
    input       [19: 0]             	cube_link_xdat_cols ,

    input       [ 3: 0]             	cube_gmsl_resp_indx ,
    output      [31: 0]             	cube_gmsl_resp_word ,
	input       [ 3: 0]             	cube_gmsl_argu_selx ,
    output		[31: 0]					cube_gmsl_argu_word ,	
	
	input                           	osde_sclk           ,
    input                           	osde_rstn           ,

	input								gmsl_vsyn_padi		,
	input								gmsl_hsyn_padi		,
	input		[15: 0]					gmsl_data_padi		,
	input								gmsl_clki			);
/**********************************************************************************************************************/
	reg									gmsl_vsyn_pdin			;
	reg									gmsl_hsyn_pdin			;
	reg			[15: 0]					gmsl_data_pdin			;

	always@(posedge gmsl_clki)		begin
		gmsl_vsyn_pdin		<=	gmsl_vsyn_padi	;
		gmsl_hsyn_pdin		<=	gmsl_hsyn_padi	;
		gmsl_data_pdin		<=	gmsl_data_padi	;
	end 
/**********************************************************************************************************************/
	reg			[15:0]					gmsl_data_samp	;
	reg									gmsl_vsyn_samp	;
	reg									gmsl_vsyn_sync	;
	reg									gmsl_hsyn_samp	;
	reg									gmsl_hsyn_sync	;

	wire	gmsl_hsyn_fall	=   &{~		gmsl_hsyn_samp	,	gmsl_hsyn_sync	};
	wire	gmsl_vsyn_fall	=   &{~		gmsl_vsyn_samp	,	gmsl_vsyn_sync	};
	
	always@(posedge gmsl_clki or negedge gmsl_rstn)
    if(~osde_rstn)   begin
		gmsl_vsyn_samp	<=	0	;
		gmsl_vsyn_sync	<=	0	;
		gmsl_hsyn_samp	<=	0	;
		gmsl_hsyn_sync	<=	0	;
		gmsl_data_samp	<=	0	;
	end else begin
		gmsl_vsyn_samp	<=	gmsl_vsyn_pdin	;
		gmsl_vsyn_sync	<=	gmsl_vsyn_samp	;
		gmsl_hsyn_samp	<=	gmsl_hsyn_pdin	;
		gmsl_hsyn_sync	<=	gmsl_hsyn_samp	;
		gmsl_data_samp	<=	gmsl_data_pdin	;
	end
//------------------------------------------------------------------------------	
	reg									gmsl_resp_taps	;
	reg			[ 3: 0]					gmsl_resp_cnts	;
	reg			[31: 0]					gmsl_resp_memo[ 0: 7]	;
	
	wire		[ 0: 7]					gmsl_resp_wmsb	;
	wire		[ 0: 7]					gmsl_resp_wlsb	;

	always@(posedge gmsl_clki or negedge gmsl_rstn)
	if(~osde_rstn)						gmsl_resp_taps	<=	0	;
	else if(~gmsl_vsyn_samp)			gmsl_resp_taps	<=	0	;
	else 								gmsl_resp_taps	<= ~gmsl_resp_taps		;			

	always@(posedge gmsl_clki or negedge gmsl_rstn)
	if(~osde_rstn)						gmsl_resp_cnts	<=	0	;
	else if(~gmsl_vsyn_samp)			gmsl_resp_cnts	<=	0	;
	else if( gmsl_resp_taps)			gmsl_resp_cnts	<=	gmsl_resp_cnts + 1	;			

	genvar i;

generate
for(i = 0 ; i < 7 ; i=i+1 )	begin
	assign	gmsl_resp_wmsb[i]	= &{	gmsl_vsyn_samp	,	gmsl_resp_taps	,	gmsl_resp_cnts	==	i	}	;
	assign	gmsl_resp_wlsb[i]	= &{	gmsl_vsyn_samp	, ~	gmsl_resp_taps	,	gmsl_resp_cnts	==	i	}	;

	always@(posedge gmsl_clki or negedge gmsl_rstn)
	if(~osde_rstn)						gmsl_resp_memo[i]	<=	0	;
	else if(gmsl_resp_wlsb[i])			gmsl_resp_memo[i]	<=	{ gmsl_resp_memo[i][31:16]	,	gmsl_data_samp			};
	else if(gmsl_resp_wmsb[i])			gmsl_resp_memo[i]	<=	{ gmsl_data_samp			,	gmsl_resp_memo[i][15:0]	};
end
endgenerate
//------------------------------------------------------------------------------
	assign	cube_gmsl_argu_word	=		cube_gmsl_argu_selx	==	0	?	gmsl_resp_memo[0]	:
										cube_gmsl_argu_selx	==	1	?	gmsl_resp_memo[1]	:
										cube_gmsl_argu_selx	==	2	?	gmsl_resp_memo[2]	:
										cube_gmsl_argu_selx	==	3	?	gmsl_resp_memo[3]	:
										cube_gmsl_argu_selx	==	4	?	gmsl_resp_memo[4]	:
										cube_gmsl_argu_selx	==	5	?	gmsl_resp_memo[5]	:
										cube_gmsl_argu_selx	==	6	?	gmsl_resp_memo[6]	:
										cube_gmsl_argu_selx	==	7	?	gmsl_resp_memo[7]	:	32'H0	;

	assign	cube_gmsl_resp_word	=		cube_gmsl_resp_indx	==	0	?	gmsl_resp_memo[0]	:
										cube_gmsl_resp_indx	==	1	?	gmsl_resp_memo[1]	:
										cube_gmsl_resp_indx	==	2	?	gmsl_resp_memo[2]	:
										cube_gmsl_resp_indx	==	3	?	gmsl_resp_memo[3]	:
										cube_gmsl_resp_indx	==	4	?	gmsl_resp_memo[4]	:
										cube_gmsl_resp_indx	==	5	?	gmsl_resp_memo[5]	:
										cube_gmsl_resp_indx	==	6	?	gmsl_resp_memo[6]	:
										cube_gmsl_resp_indx	==	7	?	gmsl_resp_memo[7]	:	32'H0	;
/**********************************************************************************************************************/
/**********************************************************************************************************************/
	reg			[ 2: 0]					gmsl_rxen_samp	;
	reg									gmsl_rxdi_enab	;
	reg			[31:0]					gmsl_rxdi_word	;
	reg			[ 9:0]					gmsl_rxdi_wptr	;
	reg									gmsl_rxdi_wrcs	;	
	reg									gmsl_rxdi_taps	;	
	reg									gmsl_rxdi_vlid	;	
	reg									gmsl_rxdi_bank	;	
//------------------------------------------------------------------------------
	wire		gmsl_rxdi_reqs	=		gmsl_rxen_samp[1:0] == 2'B01	;		
	wire		gmsl_rxdi_done	=		gmsl_rxen_samp[1:0] == 2'B10	;		

	always@(posedge gmsl_clki or negedge gmsl_rstn)
    if(~osde_rstn)   					gmsl_rxen_samp	<=	0	;
	else 								gmsl_rxen_samp	<={	gmsl_link_data_reqs	,	gmsl_rxen_samp	};

	always@(posedge gmsl_clki or negedge gmsl_rstn)
    if(~osde_rstn)   					gmsl_rxdi_enab	<=	0	;
	else if(gmsl_rxdi_reqs)				gmsl_rxdi_enab	<=	1	;
	else if(gmsl_rxdi_done)				gmsl_rxdi_enab	<=	0	;
//------------------------------------------------------------------------------
	always@(posedge gmsl_clki or negedge gmsl_rstn)
	if(~osde_rstn)						gmsl_rxdi_bank	<=	0	;
	else if(~gmsl_rxdi_enab)			gmsl_rxdi_bank	<=	0	;
	else if( gmsl_hsyn_fall)			gmsl_rxdi_bank	<= ~gmsl_rxdi_bank	;
//------------------------------------------------------------------------------	
	always@(posedge gmsl_clki or negedge gmsl_rstn)
	if(~osde_rstn)						gmsl_rxdi_taps	<=	0	;
	else if(~gmsl_rxdi_enab)			gmsl_rxdi_taps	<=	0	;
	else if(~gmsl_hsyn_samp)			gmsl_rxdi_taps	<=	0	;
	else 								gmsl_rxdi_taps	<= ~gmsl_rxdi_taps		;
//------------------------------------------------------------------------------
	always@(posedge gmsl_clki or negedge gmsl_rstn)
	if(~osde_rstn)						gmsl_rxdi_wrcs	<=	0	;
	else if(~gmsl_rxdi_enab)			gmsl_rxdi_wrcs	<=	0	;
	else 								gmsl_rxdi_wrcs	<=  gmsl_rxdi_taps		;
//------------------------------------------------------------------------------
	always@(posedge gmsl_clki or negedge gmsl_rstn)
	if(~osde_rstn)						gmsl_rxdi_vlid	<=	0	;
	else if(~gmsl_rxdi_enab)			gmsl_rxdi_vlid	<=	0	;
	else 								gmsl_rxdi_vlid	<=  gmsl_hsyn_samp		;
//------------------------------------------------------------------------------
	always@(posedge gmsl_clki or negedge gmsl_rstn)
	if(~osde_rstn)						gmsl_rxdi_word	<=	0	;
	else if(~gmsl_hsyn_samp)			gmsl_rxdi_word	<=	0	;
	else if( gmsl_rxdi_taps)			gmsl_rxdi_word	<=	{ gmsl_data_samp		,	gmsl_rxdi_word[15:0]	};		
	else								gmsl_rxdi_word	<=	{ gmsl_rxdi_word[31:16]	,	gmsl_data_samp			};	
//------------------------------------------------------------------------------
	always@(posedge gmsl_clki or negedge gmsl_rstn)
	if(~osde_rstn)						gmsl_rxdi_wptr	<=	0	;
	else if(~gmsl_rxdi_vlid)			gmsl_rxdi_wptr	<=	0	;
	else 								gmsl_rxdi_wptr	<=	gmsl_rxdi_wptr + gmsl_rxdi_wrcs	;
//------------------------------------------------------------------------------
	wire								gmsl_rxdi_wcs0	= &{gmsl_rxdi_wrcs , ~	gmsl_rxdi_bank	};
	wire								gmsl_rxdi_wcs1	= &{gmsl_rxdi_wrcs , 	gmsl_rxdi_bank	};
/**********************************************************************************************************************/
	wire								dlnk_fram_reqs	;
	wire								dlnk_rows_reqs	;

	gens_edge_slow_fast 			u_gens_dlnk_fram_reqs(	
		.fast_edge   					(dlnk_fram_reqs		),//output	
		.fast_clki						(osde_sclk			),//input	
		.fast_rstn						(osde_rstn			),//input	

		.slow_sign						(gmsl_vsyn_fall		),//input	
		.slow_clki						(gmsl_clki			),//input	
		.slow_rstn						(gmsl_rstn			));//input	

	gens_edge_slow_fast 			u_gens_dlnk_rows_reqs(	
		.fast_edge   					(dlnk_rows_reqs		),//output	
		.fast_clki						(osde_sclk			),//input	
		.fast_rstn						(osde_rstn			),//input	

		.slow_sign						(gmsl_hsyn_fall		),//input	
		.slow_clki						(gmsl_clki			),//input	
		.slow_rstn						(gmsl_rstn			));//input	
/**********************************************************************************************************************/
	reg									dlnk_rows_csen	;
	reg			[19:0]					dlnk_rows_tcnt	;
	reg									gmsl_txdo_bank	;
	reg			[ 9:0]					dlnk_txdo_rptr	;
//------------------------------------------------------------------------------
	wire	dlnk_rows_tail		=	&{	dlnk_rows_csen	,	dlnk_txdo_rptr 	==	cube_link_xdat_cols[10:1] 	};
	wire	dlnk_data_done		=	&{	dlnk_rows_tail	,	dlnk_rows_tcnt 	==	cube_link_xdat_rows 		};
//------------------------------------------------------------------------------
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						gmsl_txdo_bank	<=	0	;
	else if(~gmsl_link_data_enab)		gmsl_txdo_bank	<=	0	;
	else if( dlnk_rows_tail)			gmsl_txdo_bank	<= ~gmsl_txdo_bank	;
//------------------------------------------------------------------------------
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						dlnk_rows_csen	<=	0	;
	else if(~gmsl_link_data_enab)		dlnk_rows_csen	<=	0	;
	else if(dlnk_fram_reqs)				dlnk_rows_csen	<=	0	;	
	else if(dlnk_rows_reqs)				dlnk_rows_csen	<=	1	;	
	else if(dlnk_rows_tail)				dlnk_rows_csen	<=	0	;
//------------------------------------------------------------------------------
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						dlnk_rows_tcnt	<=	1	;
	else if(~gmsl_link_data_enab)		dlnk_rows_tcnt	<=	1	;
	else if(dlnk_data_done)				dlnk_rows_tcnt	<=	1	;	
	else if(dlnk_rows_tail)				dlnk_rows_tcnt	<=	dlnk_rows_tcnt+1;	
//------------------------------------------------------------------------------
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						dlnk_txdo_rptr	<=	0	;
	else if(~gmsl_link_data_enab)		dlnk_txdo_rptr	<=	0	;
	else if(dlnk_fram_reqs)				dlnk_txdo_rptr	<=	0	;
	else if(dlnk_rows_reqs)				dlnk_txdo_rptr	<=	1	;
	else if(dlnk_rows_csen)				dlnk_txdo_rptr	<=	dlnk_txdo_rptr+1;
	else								dlnk_txdo_rptr	<=	0	;
//------------------------------------------------------------------------------
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						gmsl_link_data_done	<=	0	;
	else 								gmsl_link_data_done	<=	dlnk_data_done	;
/**********************************************************************************************************************/
	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 32 ))	
	u_gmsl_ping_memo (
		.wport_csen						(gmsl_rxdi_wcs0			),//input  				 		
		.wport_data						(gmsl_rxdi_word			),//input		[DATA_BITS-1:0]
		.wport_addr						(gmsl_rxdi_wptr			),//input		[ADDR_BITS-1:0]
		.wport_clki						(gmsl_clki				),//input						

		.rport_addr						(dlnk_txdo_rptr			),//input		[ADDR_BITS-1:0]
		.rport_data						(dlnk_txdo_dat0			),//output	reg	[DATA_BITS-1:0]
		.rport_clki						(osde_sclk				));//input						
//------------------------------------------------------------------------------
	dual_port_bram	#(	
		.ADDR_BITS	( 9 ),	.DATA_BITS	( 32 ))	
	u_gmsl_pang_memo (
		.wport_csen						(gmsl_rxdi_wcs1			),//input  				 		
		.wport_data						(gmsl_rxdi_word			),//input		[DATA_BITS-1:0]
		.wport_addr						(gmsl_rxdi_wptr			),//input		[ADDR_BITS-1:0]
		.wport_clki						(gmsl_clki				),//input						

		.rport_addr						(dlnk_txdo_rptr			),//input		[ADDR_BITS-1:0]
		.rport_data						(dlnk_txdo_dat1			),//output	reg	[DATA_BITS-1:0]
		.rport_clki						(osde_sclk				));//input						
/**********************************************************************************************************************/
	wire		[31:0]				gmsl_dlnk_rout	;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					cube_gmsl_fram_mbdo	<=	0		;
	else if(dlnk_rows_reqs)			cube_gmsl_fram_mbdo	<=	8'HFF	;
	else							cube_gmsl_fram_mbdo	<={8{dlnk_rows_csen}}	;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					cube_gmsl_dat3_mbdo	<=	0		;
	else if(dlnk_rows_reqs)			cube_gmsl_dat3_mbdo	<=	8'H44	;
	else if(dlnk_rows_csen)			cube_gmsl_dat3_mbdo	<=	dlnk_txdo_bank	?	dlnk_txdo_dat1[31:24]	:	dlnk_txdo_dat0[31:24]	;
	else 							cube_gmsl_dat3_mbdo	<=	0		;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					cube_gmsl_dat2_mbdo	<=	0		;
	else if(dlnk_rows_reqs)			cube_gmsl_dat2_mbdo	<=	8'H41	;
	else if(dlnk_rows_csen)			cube_gmsl_dat3_mbdo	<=	dlnk_txdo_bank	?	dlnk_txdo_dat1[23:16]	:	dlnk_txdo_dat0[23:16]	;
	else 							cube_gmsl_dat2_mbdo	<=	0		;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					cube_gmsl_dat1_mbdo	<=	0		;
	else if(dlnk_rows_reqs)			cube_gmsl_dat1_mbdo	<=	8'H54	;
	else if(dlnk_rows_csen)			cube_gmsl_dat3_mbdo	<=	dlnk_txdo_bank	?	dlnk_txdo_dat1[15: 8]	:	dlnk_txdo_dat0[15: 8]	;
	else 							cube_gmsl_dat1_mbdo	<=	0		;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					cube_gmsl_dat0_mbdo	<=	0		;
	else if(dlnk_rows_reqs)			cube_gmsl_dat0_mbdo	<=	8'H41	;
	else if(dlnk_rows_csen)			cube_gmsl_dat3_mbdo	<=	dlnk_txdo_bank	?	dlnk_txdo_dat1[ 7: 0]	:	dlnk_txdo_dat0[ 7: 0]	;
	else 							cube_gmsl_dat0_mbdo	<=	0		;


endmodule