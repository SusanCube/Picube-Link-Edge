module	edge_link_flow_ctrl(
	input		[6:0]					edge_link_misc_cmnd	,
    input   	[1:0]      				edge_link_stat_gpio	,
    output	reg  	       				edge_link_comm_gpio	,
	output	reg	[1:0]					edge_link_comm_stat	,					

	input								edge_link_cfig_reqs	,
	input								edge_link_odat_reqs	,
	input								edge_link_idat_reqs	,
	output	reg							edge_link_cfig_done	,
	output	reg							edge_link_odat_done	,
	output								edge_link_idat_done	,

	output	reg							dvpx_link_cmnd_enab	,
	input								dvpx_link_cmnd_done	,
	output	reg							dvpx_link_dmmy_enab	,
	input								dvpx_link_dmmy_done	,
	output	reg							dvpx_link_odat_enab	,
	input								dvpx_link_odat_done	,

	output	reg							gmsl_link_idat_enab	,
	output								gmsl_link_idat_reqs	,
	input								gmsl_link_idat_done	,
	input		[31:0]					gmsl_link_resp_word	,
	
    output		[7:0]					flow_resp_fram_mbdo	,
    output		[7:0]					flow_resp_dat3_mbdo	,
    output		[7:0]					flow_resp_dat2_mbdo	,
    output		[7:0]					flow_resp_dat1_mbdo	,
    output		[7:0]					flow_resp_dat0_mbdo	,
    
    input								osde_sclk           ,
    input								osde_rstn           );
/***********************************************************************************************************/	
    reg     	[1:0]       			edge_link_stat_syn0	;
	reg     	[1:0]       			edge_link_stat_syn1	;

    wire    edge_link_real_idle = &{	edge_link_comm_stat	== 2'H0	, edge_link_stat_syn1 == 2'H0	};	
    wire    edge_link_into_idle = &{	edge_link_comm_stat	!= 2'H0	, edge_link_stat_syn1 == 2'H0	};	
    wire    edge_link_into_acks = &{	edge_link_comm_stat	!= 2'H1	, edge_link_stat_syn1 == 2'H1	};	
    wire    edge_link_into_resp = &{	edge_link_comm_stat	!= 2'H2	, edge_link_stat_syn1 == 2'H2	};	
	
    always@(posedge osde_sclk or negedge osde_rstn)  
	if(~osde_rstn)					begin
		edge_link_stat_syn0	<=	0	;
        edge_link_stat_syn1	<=	0	;
        edge_link_comm_stat	<=	0	;
	end 		else 				begin
        edge_link_stat_syn0	<=	edge_link_stat_gpio	;
		edge_link_stat_syn1	<=	edge_link_stat_syn0	;
	    edge_link_comm_stat	<=	edge_link_stat_syn1	;
    end
	
	assign	gmsl_link_idat_reqs	= &{	edge_link_real_idle	,	edge_link_idat_reqs	};
/***********************************************************************************************************/	
	reg    		[ 3: 0]					edge_link_comm_mfsm	;

    parameter   EDGE_MFSM_COMM_SEEK	=   0   ;
    parameter   EDGE_MFSM_COMM_IDLE	=   1   ;
    parameter   EDGE_MFSM_COMM_CMND	=   2   ;
    parameter   EDGE_MFSM_COMM_ACKS	=   3   ;
    parameter   EDGE_MFSM_DMMY_CMND	=   4   ;
    parameter   EDGE_MFSM_DMMY_ACKS	=   5   ;
    parameter   EDGE_MFSM_COMM_RESP	=   6   ;

	parameter   EDGE_MFSM_CFIG_DONE	=   7   ;
	parameter   EDGE_MFSM_RESP_DONE	=   8   ;


	wire	edge_link_misc_reqs	= |{	edge_link_cfig_reqs	,	edge_link_idat_reqs	,	edge_link_odat_reqs	};

    wire	edge_hits_comm_seek =		edge_link_comm_mfsm == EDGE_MFSM_COMM_SEEK	;
    wire	edge_hits_comm_idle =		edge_link_comm_mfsm == EDGE_MFSM_COMM_IDLE	;
    wire	edge_hits_comm_cmnd =		edge_link_comm_mfsm == EDGE_MFSM_COMM_CMND	;
    wire	edge_hits_comm_acks =		edge_link_comm_mfsm == EDGE_MFSM_COMM_ACKS	;
    wire	edge_hits_dmmy_cmnd =		edge_link_comm_mfsm == EDGE_MFSM_DMMY_CMND	;
	wire	edge_hits_dmmy_acks =		edge_link_comm_mfsm == EDGE_MFSM_DMMY_ACKS	;
    wire	edge_hits_comm_resp =		edge_link_comm_mfsm == EDGE_MFSM_COMM_RESP	;
//----------------------------------------------------------------------------------------------------------
	always@(posedge osde_sclk or negedge osde_rstn)
    if(~osde_rstn)                  	edge_link_comm_mfsm	<=	EDGE_MFSM_COMM_SEEK	;
    else begin
        case(edge_link_comm_mfsm)
        	EDGE_MFSM_COMM_SEEK	:		edge_link_comm_mfsm	<=	edge_link_misc_reqs	? 	EDGE_MFSM_COMM_IDLE	:	EDGE_MFSM_COMM_SEEK	;	
        	EDGE_MFSM_COMM_IDLE	:		edge_link_comm_mfsm	<=	edge_link_into_idle	?	EDGE_MFSM_COMM_CMND	:	EDGE_MFSM_COMM_IDLE	;
			EDGE_MFSM_COMM_CMND	:		edge_link_comm_mfsm	<=	dvpx_link_cmnd_done	?	EDGE_MFSM_COMM_ACKS	:	EDGE_MFSM_COMM_CMND	;			
			EDGE_MFSM_COMM_ACKS	:	
			if(edge_link_into_acks)		edge_link_comm_mfsm	<=	edge_link_odat_reqs	?	EDGE_MFSM_DMMY_CMND	:	
																edge_link_idat_reqs	?	EDGE_MFSM_COMM_RESP	:	EDGE_MFSM_CFIG_DONE	;
			else						edge_link_comm_mfsm	<=													EDGE_MFSM_COMM_ACKS	;

			EDGE_MFSM_CFIG_DONE	:		edge_link_comm_mfsm	<=	edge_link_misc_reqs	?	EDGE_MFSM_CFIG_DONE	:	EDGE_MFSM_COMM_SEEK	;
			
			EDGE_MFSM_DMMY_CMND	:		edge_link_comm_mfsm	<=	dvpx_link_dmmy_done	?	EDGE_MFSM_DMMY_ACKS	:	EDGE_MFSM_DMMY_CMND	;
			EDGE_MFSM_DMMY_ACKS	:		edge_link_comm_mfsm	<=													EDGE_MFSM_COMM_RESP	;
			EDGE_MFSM_COMM_RESP	:		edge_link_comm_mfsm	<=	edge_link_into_resp	?	EDGE_MFSM_RESP_DONE	:	EDGE_MFSM_COMM_RESP	;

			EDGE_MFSM_RESP_DONE	:		edge_link_comm_mfsm	<=	edge_link_misc_reqs	?	EDGE_MFSM_RESP_DONE	:	EDGE_MFSM_COMM_SEEK	;

            default             :   	edge_link_comm_mfsm <=  												EDGE_MFSM_COMM_SEEK ;
        endcase
    end
//---------------------------------------------------------------------
    wire	edge_link_comm_issu	= &{	edge_hits_comm_seek	,   edge_link_misc_reqs };	//weit 2805 comm-ready
	wire    edge_link_cmnd_issu	= &{	edge_hits_comm_idle	,   edge_link_into_idle };	//send comm-command 

	wire	edge_norm_acks_issu	= &{	edge_hits_comm_acks	,   edge_link_into_acks	};
    wire	edge_dmmy_cmnd_issu	= &{	edge_norm_acks_issu	,	edge_link_odat_reqs	};

	wire	edge_idat_acks_issu	= &{	edge_norm_acks_issu	,	edge_link_idat_reqs	};
	wire    edge_odat_acks_issu	= &{	edge_hits_dmmy_acks	};//,  	dvpx_link_dmmy_done };	

	wire    edge_link_resp_issu	= &{	edge_hits_comm_resp	,   edge_link_into_resp };	
//----------------------------------    
	always@(posedge osde_sclk or negedge osde_rstn)
    if(~osde_rstn)                  	edge_link_comm_gpio	<=  0   ;
    else if(edge_link_into_idle)    	edge_link_comm_gpio	<=  0   ;
    else if(edge_link_comm_issu)    	edge_link_comm_gpio	<=  1   ;
//----------------------------------
    always@(posedge osde_sclk or negedge osde_rstn)
    if(~osde_rstn)                  	dvpx_link_cmnd_enab <=  0   ;
    else if(dvpx_link_cmnd_done)    	dvpx_link_cmnd_enab <=  0   ;
    else if(edge_link_cmnd_issu)    	dvpx_link_cmnd_enab <=  1   ;
//----------------------------------
    always@(posedge osde_sclk or negedge osde_rstn)
    if(~osde_rstn)                  	dvpx_link_dmmy_enab <=  0   ;
    else if(dvpx_link_dmmy_done)    	dvpx_link_dmmy_enab <=  0   ;
    else if(edge_dmmy_cmnd_issu)    	dvpx_link_dmmy_enab <=  1   ;
//----------------------------------
    always@(posedge osde_sclk or negedge osde_rstn)
    if(~osde_rstn)                  	dvpx_link_odat_enab <=  0   ;
    else if(dvpx_link_odat_done)    	dvpx_link_odat_enab <=  0   ;
    else if(edge_odat_acks_issu)    	dvpx_link_odat_enab <=  1   ;
//----------------------------------
    always@(posedge osde_sclk or negedge osde_rstn)
    if(~osde_rstn)                  	gmsl_link_idat_enab <=  0   ;
    else if(gmsl_link_idat_done)    	gmsl_link_idat_enab <=  0   ;
    else if(edge_norm_acks_issu)    	gmsl_link_idat_enab <=  edge_link_idat_reqs   ;
/**********************************************************************************************************/
	wire	edge_scut_acks_issu	=		edge_link_odat_reqs	?	edge_odat_acks_issu	:	edge_norm_acks_issu	;
//----------------------------------
	reg									edge_scut_acks_argu	;
	reg									edge_scut_resp_argu	;
//----------------------------------
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)                  	edge_scut_acks_argu <=  0   ;
	else 								edge_scut_acks_argu <=  edge_scut_acks_issu  ;
//----------------------------------
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)              	    edge_scut_resp_argu <=  0   ;
	else 								edge_scut_resp_argu <=  edge_link_resp_issu  ;
/**********************************************************************************************************/
	reg			[31:0]					edge_acks_resp_data	;
	reg									edge_acks_resp_fram	;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_acks_resp_fram	<=	0		;
	else if(edge_scut_acks_issu)		edge_acks_resp_fram	<=	8'HFF	;
	else if(edge_link_resp_issu)		edge_acks_resp_fram	<=	8'HFF	;
	else if(edge_scut_acks_argu)		edge_acks_resp_fram	<=	8'HFF	;
	else if(edge_scut_resp_argu)		edge_acks_resp_fram	<=	8'HFF	;
	else								edge_acks_resp_fram	<=	0		;
//-------------------------------------------------------------------
	wire	tpem_icfg_link_cmnd	=		edge_link_misc_cmnd[0]	;
	wire	tpem_ocfg_link_cmnd	=		edge_link_misc_cmnd[1]	;
	wire	tpem_nnex_link_cmnd	=		edge_link_misc_cmnd[2]	;
	wire	tpem_ivct_link_cmnd	=		edge_link_misc_cmnd[3]	;
	wire	tpem_ovct_link_cmnd	=		edge_link_misc_cmnd[4]	;
	wire	tpem_imtx_link_cmnd	=		edge_link_misc_cmnd[5]	;
	wire	tpem_omtx_link_cmnd	=		edge_link_misc_cmnd[6]	;
	
	reg			[31:0]					edge_misc_cmnd_acks	;
	
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_misc_cmnd_acks	<=	0	;
	else if(tpem_icfg_link_cmnd)		edge_misc_cmnd_acks	<=	32'H49434647	;
	else if(tpem_ocfg_link_cmnd)		edge_misc_cmnd_acks	<=	32'H4F434647	;
	else if(tpem_nnex_link_cmnd)		edge_misc_cmnd_acks	<=	32'H4E4E4558	;
	else if(tpem_ivct_link_cmnd)		edge_misc_cmnd_acks	<=	32'H49564354	;
	else if(tpem_ovct_link_cmnd)		edge_misc_cmnd_acks	<=	32'H4F564354	;
	else if(tpem_imtx_link_cmnd)		edge_misc_cmnd_acks	<=	32'H494D5458	;
	else if(tpem_omtx_link_cmnd)		edge_misc_cmnd_acks	<=	32'H4F4D5458	;
		
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_acks_resp_data	<=	0	;
	else if(edge_scut_acks_issu)		edge_acks_resp_data	<=	32'H41434B53	;//ACKS
	else if(edge_link_resp_issu)		edge_acks_resp_data	<=	32'H52455350	;//RESP
	else if(edge_scut_acks_argu)		edge_acks_resp_data	<=	edge_misc_cmnd_acks	;//
	else if(edge_scut_resp_argu)		edge_acks_resp_data	<=	gmsl_link_resp_word	;//
	else								edge_acks_resp_data	<=	0	;

	assign	flow_resp_fram_mbdo		={8{edge_acks_resp_fram		}}	;
	assign	flow_resp_dat3_mbdo		=	edge_acks_resp_data[31:24]	;
	assign	flow_resp_dat2_mbdo		=	edge_acks_resp_data[23:16]	;
	assign	flow_resp_dat1_mbdo		=	edge_acks_resp_data[15: 8]	;
	assign	flow_resp_dat0_mbdo		=	edge_acks_resp_data[ 7: 0]	;
/**********************************************************************************************************/
	reg									edge_link_cfig_mark	;
//	reg								edge_link_cfig_done	;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_link_cfig_mark	<=	0	;
	else if(edge_link_into_idle)		edge_link_cfig_mark	<=	edge_link_cfig_reqs	;
	else if(edge_link_cfig_done)		edge_link_cfig_mark	<=	0	;	

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_link_cfig_done	<=	0	;
	else if(~edge_link_cfig_reqs)		edge_link_cfig_done	<=	0	;
	else if( edge_norm_acks_issu)		edge_link_cfig_done	<=	edge_link_cfig_mark	;	
//----------------------------------------------------------------------------------------------------------
	reg									edge_link_odat_mark	;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_link_odat_mark	<=	0	;
	else if(edge_link_into_idle)		edge_link_odat_mark	<=	edge_link_odat_reqs	;
	else if(edge_link_odat_done)		edge_link_odat_mark	<=	0	;	

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_link_odat_done	<=	0	;
	else if(~edge_link_odat_reqs)		edge_link_odat_done	<=	0	;
	else if( edge_link_resp_issu)		edge_link_odat_done	<=	edge_link_odat_mark	;	
//----------------------------------------------------------------------------------------------------------
	reg									edge_link_idat_mark	;
	reg									edge_idat_data_done	;

	reg									edge_idat_resp_mark	;
	reg									edge_idat_resp_done	;
	
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_link_idat_mark	<=	0	;
	else if(edge_link_into_idle)		edge_link_idat_mark	<=	edge_link_idat_reqs	;
	else if(edge_link_idat_done)		edge_link_idat_mark	<=	0	;	

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_idat_data_done	<=	0	;
	else if(~edge_link_idat_reqs)		edge_idat_data_done	<=	0	;
	else if( gmsl_link_idat_done)		edge_idat_data_done	<=	edge_link_idat_mark	;	

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_idat_resp_mark	<=	0	;
	else if(edge_link_into_idle)		edge_idat_resp_mark	<=	edge_link_idat_reqs	;
	else if(edge_link_odat_done)		edge_idat_resp_mark	<=	0	;	

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						edge_idat_resp_done	<=	0	;
	else if(~edge_link_idat_reqs)		edge_idat_resp_done	<=	0	;
	else if( edge_link_resp_issu)		edge_idat_resp_done	<=	edge_link_idat_mark	;	

	assign	edge_link_idat_done	= &{	edge_idat_data_done	,	edge_idat_resp_done	};

/**********************************************************************************************************/

endmodule	

	
	


	
	
	

