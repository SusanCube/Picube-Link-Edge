/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
history : 
        2024/12/02, linsen, fix data CMND sequence 
        1. handshake with cube, waiting for re-cfig dvp ready
        2. dummy vsyn
----------------------------------------------------------------------*/
module	dvpx_link_txdo_pmau(
	input								dvp0_link_enab		,
	output	reg							dvp0_vsyn_pado		,
	output	reg							dvp0_hsyn_pado		,
	output	reg [15: 0]					dvp0_data_pado		,
	output								dvp0_pclk_pado		,

	input								dvp1_link_enab		,
	output	reg							dvp1_vsyn_pado		,
	output	reg							dvp1_hsyn_pado		,
	output	reg [15: 0]					dvp1_data_pado		,
	output								dvp1_pclk_pado		,
	
	input								dvpx_cmnd_enab		,
	input								dvpx_dmmy_enab		,
	input								dvpx_odat_enab		,
	input								dvpx_cmnd_vsyn		,
	input								dvpx_cmnd_hsyn		,
	input		[15:0]					dvpx_cmnd_dato		,
	input								dvpx_data_hsyn		,
	input		[15:0]					dvpx_data_dato		,
	
	input								dvpx_pclk			,
	input								dvpx_rstn			);
/**********************************************************************************************************************/
	reg									dvp0_vsyn_padm	;
	reg									dvp0_hsyn_padm	;
	reg		[15: 0]						dvp0_data_padm	;
	
	wire	dvp0_port_enab	= 	&{		dvp0_link_enab	, 	dvpx_odat_enab | dvpx_dmmy_enab } | dvpx_cmnd_enab ;

	always@(negedge dvpx_pclk)		begin
		dvp0_vsyn_pado	<=	dvp0_vsyn_padm	;
		dvp0_hsyn_pado	<=	dvp0_hsyn_padm	;
		dvp0_data_pado	<=	dvp0_data_padm	;
	end
	
	always@(posedge dvpx_pclk)
	if(~dvp0_port_enab)	begin
		dvp0_vsyn_padm	<=	0	;
		dvp0_hsyn_padm	<=	0	;
		dvp0_data_padm	<=	0	;
	end else						begin
		dvp0_vsyn_padm	<=	dvpx_cmnd_vsyn		;
		dvp0_hsyn_padm	<=	dvpx_cmnd_hsyn	|	dvpx_data_hsyn	;
		dvp0_data_padm	<=	dvpx_cmnd_vsyn  ?   dvpx_cmnd_dato	:   
							dvpx_data_hsyn  ?   dvpx_data_dato	: 0	;
	end
//------------------------------------------------------------------------------
	reg								dvp1_vsyn_padm	;
	reg								dvp1_hsyn_padm	;
	reg		[15: 0]					dvp1_data_padm	;

	wire	dvp1_port_enab	=	&{		dvp1_link_enab	,	dvpx_link_odat_enab | dvpx_link_dmmy_enab }	;
	
	always@(negedge dvpx_pclk)		begin
		dvp1_vsyn_pado	<=	dvp1_vsyn_padm	;
		dvp1_hsyn_pado	<=	dvp1_hsyn_padm	;
		dvp1_data_pado	<=	dvp1_data_padm	;
	end
	
	always@(posedge dvpx_pclk)
	if(~dvp1_port_enab)	begin
		dvp1_vsyn_padm	<=	0	;
		dvp1_hsyn_padm	<=	0	;
		dvp1_data_padm	<=	0	;
	end else						begin
		dvp1_vsyn_padm	<=	dvpx_cmnd_vsyn		;
		dvp1_hsyn_padm	<=	dvpx_cmnd_hsyn	|	dvpx_data_hsyn	;
		dvp1_data_padm	<=	dvpx_cmnd_vsyn  ?   dvpx_cmnd_dato	:   
							dvpx_data_hsyn  ?   dvpx_data_dato	: 0	;
	end
/**********************************************************************************************************************/	
	ODDR2 #(
    	.DDR_ALIGNMENT        			("C0"       		),
    	.INIT                 			(1'b0       		),
    	.SRTYPE               			("ASYNC"    		))
	u_dvp0_clko (
		.Q								(dvp0_clko_pado		),	// 1-bit output: Data output to IOB
		.D0								(1'B0				),	// 1-bit input: Parallel data input 1
		.D1								(1'B1				),	// 1-bit input: Parallel data input 2
		.C0								( dvpx_pclk			),	// 1-bit input: High-speed clock input
		.C1								(~dvpx_pclk			),	// 1-bit input: High-speed clock input
    	.CE             				(1'b1     			),
    	.S              				(1'b0     			),
		.R 								(1'B0				)); // 1-bit input: Active-High Async Reset
//------------------------------------------------------------------------------	
	ODDR2 #(
    	.DDR_ALIGNMENT        			("C0"       		),
    	.INIT                 			(1'b0       		),
    	.SRTYPE               			("ASYNC"    		))
	u_dvp1_clko (
		.Q								(dvp1_clko_pado		),	// 1-bit output: Data output to IOB
		.D0								(1'B0				),	// 1-bit input: Parallel data input 1
		.D1								(1'B1				),	// 1-bit input: Parallel data input 2
		.C0								( dvpx_pclk			),	// 1-bit input: High-speed clock input
		.C1								(~dvpx_pclk			),	// 1-bit input: High-speed clock input
    	.CE             				(1'b1     			),
    	.S              				(1'b0     			),
		.R 								(1'B0				)); // 1-bit input: Active-High Async Reset
//------------------------------------------------------------------------------	
	
endmodule

 