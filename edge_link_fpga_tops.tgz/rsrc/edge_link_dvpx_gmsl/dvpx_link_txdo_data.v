/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
----------------------------------------------------------------------*/
module	dvpx_link_txdo_data(
//FABRIC CONTROL
	input								isde_link_lead		,
	input								isde_link_wrcs		,
	input	[31: 0]						isde_link_word		,
	input								isde_sclk			,
	input								isde_rstn			,
		
	output	reg							dvpx_data_hsyn		,
	output	[15: 0]						dvpx_data_dato		,

	input								dvpx_data_enab		,
	output	reg							dvpx_data_done		,
	input	[19: 0]						dvpx_data_rows		,
	input	[19: 0]						dvpx_data_cols		,
	input								dvpx_pclk			,
	input								dvpx_rstn			);
/**********************************************************************************************************************/
	parameter	TXDO_TRIG_DPTH	=		16'H0004	;
/**********************************************************************************************************************/
	reg		[ 1: 0]						isde_link_samp		;

	wire	isde_link_enab	=			isde_link_samp[0]	;

	always@(posedge isde_sclk or negedge isde_rstn)
	if(~isde_rstn)						isde_link_samp	<=	0	;
	else								isde_link_samp	<={	dvpx_data_enab	,	isde_link_samp[1]	};
//------------------------------------------------------------------------------
	reg		[15:0]						isde_link_addr		;

	always@(posedge isde_sclk or negedge isde_rstn)
	if(~isde_rstn)						isde_link_addr	<=	0	;
	else if(~isde_link_enab)			isde_link_addr	<=	0	;
	else if( isde_link_lead)			isde_link_addr	<=	0	;
	else if( isde_link_wrcs)			isde_link_addr	<=	isde_link_addr	+ 1 ;
//------------------------------------------------------------------------------
	reg									isde_link_ovfl		;

	always@(posedge isde_sclk or negedge isde_rstn)
	if(~isde_rstn)						isde_link_ovfl	<=	0	;
	else if(~isde_link_enab)			isde_link_ovfl	<=	0	;
	else if( isde_link_lead)			isde_link_ovfl	<=	0	;
	else 								isde_link_ovfl	<=	isde_link_addr	> TXDO_TRIG_DPTH	;
/**********************************************************************************************************************/
	reg		[ 1: 0]						dvpx_txen_samp		;

	wire	dvpx_txdo_enab	=			isde_link_samp[0]	;

	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_txen_samp	<=	0	;
	else								dvpx_txen_samp	<={	dvpx_data_enab	,	dvpx_txen_samp[1]	};
//------------------------------------------------------------------------------
	reg		[ 2: 0]						dvpx_ovfl_samp	;

	wire	dvpx_txdo_reqs	=			dvpx_ovfl_samp[1:0]	==	2'B10			;

	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_ovfl_samp	<=	0	;
	else 								dvpx_ovfl_samp	<={	isde_link_ovfl	,	dvpx_ovfl_samp[2:1]	};
/**********************************************************************************************************************/
	reg		[19: 0]						dvpx_cols_indx	;
	reg		[19: 0]						dvpx_rows_indx	;
    wire    [31: 0]                 	dvpx_odat_word  ;
	reg		[19: 0]						dvpx_cols_dims	;
		
	wire	dvpx_rows_last	=			dvpx_rows_indx 		==	dvpx_data_rows	;
	wire	dvpx_cols_last	=			dvpx_cols_indx    	==	dvpx_cols_dims	;
	wire	dvpx_odat_last	=	  &{	dvpx_rows_last	,		dvpx_cols_last	};		
//------------------------------------------------------------------------------
	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_cols_dims	<=	0	;
	else								dvpx_cols_dims	<=	dvpx_data_cols	;
//------------------------------------------------------------------------------
	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_data_hsyn	<=	0	;
	else if(~dvpx_txdo_enab)			dvpx_data_hsyn	<=	0	;
	else if( dvpx_txdo_reqs)			dvpx_data_hsyn	<=	1	;
	else if( dvpx_cols_last)	    	dvpx_data_hsyn	<=	0	;
//------------------------------------------------------------------------------
	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_cols_indx	<=	0	;
	else if(~dvpx_txdo_enab)			dvpx_cols_indx	<=	0	;
	else if( dvpx_cols_last)			dvpx_cols_indx	<=	0	;
	else if(dvpx_txdo_reqs|dvpx_data_hsyn)
                            			dvpx_cols_indx	<=	dvpx_cols_indx + 1	;
//------------------------------------------------------------------------------
	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_rows_indx	<=	0	;
	else if(~dvpx_txdo_enab)			dvpx_rows_indx	<=	0	;
	else if( dvpx_txdo_reqs)			dvpx_rows_indx	<=	dvpx_rows_indx + 1	;
//------------------------------------------------------------------------------
	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_data_done	<=	0	;
	else if(~dvpx_txdo_enab)			dvpx_data_done	<=	0	;
	else if( dvpx_odat_last)			dvpx_data_done	<=	1	;
//------------------------------------------------------------------------------
	assign	dvpx_data_dato	=		dvpx_cols_indx[0] ?	dvpx_odat_word[15: 0]	:	
														dvpx_odat_word[31:16]	;
/**********************************************************************************************************************/
	dual_port_bram	#(	.ADDR_BITS ( 4	), .DATA_BITS ( 32 ) )	
								u_dvpx_data_fifo(
		.wport_csen					(isde_link_wrcs		),//input  				 		
		.wport_addr					(isde_link_addr[3:0]),//input		[ADDR_BITS-1:0]	
		.wport_data					(isde_link_word		),//input		[DATA_BITS-1:0]	
		.wport_clki					(isde_sclk			),//input						

		.rport_addr					(dvpx_cols_indx[4:1]),//input		[ADDR_BITS-1:0] 
		.rport_data					(dvpx_odat_word		),//output	reg	[DATA_BITS-1:0] 
		.rport_clki					(dvpx_pclk			));//input						
/**********************************************************************************************************************/
endmodule

 
