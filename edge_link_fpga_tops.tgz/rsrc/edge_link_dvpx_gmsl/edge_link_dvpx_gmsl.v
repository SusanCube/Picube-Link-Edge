/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
history : 
        2024/12/02, linsen, fix data CMND sequence 
        1. handshake with cube, waiting for re-cfig dvp ready
        2. dummy vsyn
----------------------------------------------------------------------*/
module	edge_link_dvpx_gmsl(
	output	reg							dvp0_vsyn_pado		,			
	output	reg							dvp0_hsyn_pado		,
	output	reg	[15: 0]					dvp0_data_pado		,

	output	reg							dvp1_vsyn_pado		,			
	output	reg							dvp1_hsyn_pado		,
	output	reg	[15: 0]					dvp1_data_pado		,

	input								gmsl_vsyn_padi		,
	input								gmsl_hsyn_padi		,
	input		[15: 0]					gmsl_data_padi		,
	input								gmsl_clki			,

	input								tpem_link_odat_lead	,
	input								tpem_link_odat_wrcs	,
	input	[31: 0]						tpem_link_odat_word	,

	input		[ 1: 0]					edge_link_dvpx_enab	,
	input		[ 1: 0]					edge_link_stat_gpio	,
	output								edge_link_comm_gpio	,
	output		[ 1: 0]					edge_link_comm_stat	,
	
	output		[ 7: 0]					flow_resp_fram_mbdo	,
	output		[ 7: 0]					flow_resp_dat3_mbdo	,
	output		[ 7: 0]					flow_resp_dat2_mbdo	,
	output		[ 7: 0]					flow_resp_dat1_mbdo	,
	output		[ 7: 0]					flow_resp_dat0_mbdo	,

	output		[ 7: 0]					edge_gmsl_fram_mbdo	,
	output		[ 7: 0]					edge_gmsl_dat3_mbdo	,
	output		[ 7: 0]					edge_gmsl_dat2_mbdo	,
	output		[ 7: 0]					edge_gmsl_dat1_mbdo	,
	output		[ 7: 0]					edge_gmsl_dat0_mbdo	,

	input		[ 6: 0]					edge_link_misc_cmnd	,
	input								edge_link_cfig_reqs	,
	input								edge_link_odat_reqs	,
	input								edge_link_idat_reqs	,
	output								edge_link_cfig_done	,
	output								edge_link_odat_done	,
	output								edge_link_idat_done	,

	output	[ 3: 0]						edge_link_cmnd_indx	,
	input	[31: 0]						edge_link_cmnd_word	,

	input	[ 3: 0]						edge_gmsl_resp_indx	,
	output	[31: 0]						edge_gmsl_resp_word	,

	input	[ 3: 0]						edge_gmsl_argu_selx	,

	input	[19: 0]						edge_link_xdat_rows	,
	input	[19: 0]						edge_link_xdat_cols	,
	
	input								dvpx_pclk			,
	input								osde_sclk			,
	input								osde_rstn			);
/**********************************************************************************************************************/
//FLOW-CONTROL
	wire	[31: 0]					edge_gmsl_argu_word	;
	
	edge_link_flow_ctrl				u_edge_link_flow_ctrl(
 		.edge_link_misc_cmnd			(edge_link_misc_cmnd	),//input   	[6:0]   
 		.edge_link_stat_gpio			(edge_link_stat_gpio	),//input   	[1:0]   
 		.edge_link_comm_gpio			(edge_link_comm_gpio	),//output	reg  	    
		.edge_link_comm_stat			(edge_link_comm_stat	),//output	reg	[1:0]		

		.edge_link_cfig_reqs			(edge_link_cfig_reqs	),//input				
		.edge_link_odat_reqs			(edge_link_odat_reqs	),//input				
		.edge_link_idat_reqs			(edge_link_idat_reqs	),//input				
		.edge_link_cfig_done			(edge_link_cfig_done	),//output				
		.edge_link_odat_done			(edge_link_odat_done	),//output				
		.edge_link_idat_done			(edge_link_idat_done	),//output				

		.dvpx_link_cmnd_enab			(dvpx_link_cmnd_enab	),//output				
		.dvpx_link_cmnd_done			(dvpx_link_cmnd_done	),//input				
		.dvpx_link_dmmy_enab			(dvpx_link_dmmy_enab	),//output				
		.dvpx_link_dmmy_done			(dvpx_link_dmmy_done	),//input				
		.dvpx_link_odat_enab			(dvpx_link_odat_enab	),//output				
		.dvpx_link_odat_done			(dvpx_link_odat_done	),//input				

		.gmsl_link_idat_enab			(gmsl_link_idat_enab	),//output				
		.gmsl_link_idat_reqs			(gmsl_link_idat_reqs	),//output				
		.gmsl_link_idat_done			(gmsl_link_idat_done	),//input				
		.gmsl_link_resp_word			(edge_gmsl_argu_word	),//input		[31:0]		

		.flow_resp_fram_mbdo			(flow_resp_fram_mbdo	),//output  reg	[7:0]	
 		.flow_resp_dat3_mbdo			(flow_resp_dat3_mbdo	),//output  reg	[7:0]	
 		.flow_resp_dat2_mbdo			(flow_resp_dat2_mbdo	),//output  reg	[7:0]	
 		.flow_resp_dat1_mbdo			(flow_resp_dat1_mbdo	),//output  reg	[7:0]	
 		.flow_resp_dat0_mbdo			(flow_resp_dat0_mbdo	),//output  reg	[7:0]	

 		.osde_sclk						(osde_sclk				),//input				
 		.osde_rstn						(osde_rstn				));//input				
/**********************************************************************************************************************/
//GMSL-CONTROL	
	
	gmsl_link_rxdi_unit				u_gmsl_link_rxdi_esse(
		.edge_gmsl_fram_mbdo	 		(edge_gmsl_fram_mbdo	),//output  reg [ 7: 0]
		.edge_gmsl_dat0_mbdo	 		(edge_gmsl_dat0_mbdo	),//output  reg [ 7: 0]
		.edge_gmsl_dat1_mbdo	 		(edge_gmsl_dat1_mbdo	),//output  reg [ 7: 0]
		.edge_gmsl_dat2_mbdo	 		(edge_gmsl_dat2_mbdo	),//output  reg [ 7: 0]
		.edge_gmsl_dat3_mbdo	 		(edge_gmsl_dat3_mbdo	),//output  reg [ 7: 0]

		.gmsl_link_data_enab			(gmsl_link_idat_enab	),
		.gmsl_link_data_reqs			(gmsl_link_idat_reqs	),
	    .gmsl_link_data_done			(gmsl_link_idat_done	),

		.edge_link_xdat_rows			(edge_link_xdat_rows 	),
	    .edge_link_xdat_cols			(edge_link_xdat_cols 	),

		.edge_gmsl_resp_indx			(edge_gmsl_resp_indx	),
	    .edge_gmsl_resp_word			(edge_gmsl_resp_word	),
		.edge_gmsl_argu_selx			(edge_gmsl_argu_selx	),
		.edge_gmsl_argu_word			(edge_gmsl_argu_word	),

	    .osde_sclk          	 		(osde_sclk           	),
	    .osde_rstn          	 		(osde_rstn           	),

		.gmsl_vsyn_padi					(gmsl_vsyn_padi			),//input				
		.gmsl_hsyn_padi					(gmsl_hsyn_padi			),//input				
		.gmsl_data_padi					(gmsl_data_padi			),//input		[15: 0]	
		.gmsl_clki						(gmsl_clki				));//input				
/**********************************************************************************************************************/
	wire								dvpx_cmnd_vsyn	;
	wire								dvpx_cmnd_hsyn	;
	wire		[15:0]					dvpx_cmnd_dato	;
	wire								dvpx_data_hsyn	;
	wire		[15:0]					dvpx_data_dato	;

	dvpx_link_txdo_cmnd				u_dvpx_link_txdo_cmnd(
		.dvpx_cmnd_vsyn					(dvpx_cmnd_vsyn			),//output	reg			
		.dvpx_cmnd_hsyn					(dvpx_cmnd_hsyn			),//output	reg			
		.dvpx_cmnd_dato					(dvpx_cmnd_dato			),//output	reg	[15: 0]	

		.dvpx_cmnd_enab					(dvpx_link_cmnd_enab	),//input				
        .dvpx_cmnd_done					(dvpx_link_cmnd_done	),//output				
		.dvpx_dmyv_enab         	    (dvpx_link_dmmy_enab    ),//input			
		.dvpx_dmyv_done					(dvpx_link_dmmy_done	),//output				

		.dvpx_cmnd_indx					(edge_link_cmnd_indx	),//output	[ 3: 0]		
		.dvpx_cmnd_word					(edge_link_cmnd_word	),//input	[31: 0]		
		.dvpx_pclk						(dvpx_pclk				),//input				
		.dvpx_rstn						(dvpx_rstn				));//input				

	dvpx_link_txdo_data				u_dvpx_link_txdo_data(
		.isde_link_lead					(tpem_link_odat_lead	),//input			
		.isde_link_wrcs					(tpem_link_odat_wrcs	),//input			
		.isde_link_word					(tpem_link_odat_word	),//input			
		.isde_sclk						(isde_sclk				),//input			
		.isde_rstn						(isde_rstn				)

		.dvpx_data_hsyn					(dvpx_data_hsyn			),//output	reg		
		.dvpx_data_dato					(dvpx_data_dato			),//output	[15: 0]	

		.dvpx_data_enab					(dvpx_link_odat_enab	),//input			
		.dvpx_data_done					(dvpx_link_odat_done	),//output	reg		
		.dvpx_data_rows					(edge_link_xdat_rows 	),//input	[15: 0]	
		.dvpx_data_cols					(edge_link_xdat_cols 	),//input	[15: 0]	
		.dvpx_pclk						(dvpx_pclk				),//input				
		.dvpx_rstn						(dvpx_rstn				));//input				

/***********************************************************************************************************/
	wire	dvp0_link_enab	=			edge_link_dvpx_enab[0]	;
	wire	dvp1_link_enab	=			edge_link_dvpx_enab[1]	;

	dvpx_link_txdo_pmau				u_dvpx_link_txdo_pmau(
		.dvp0_link_enab					(dvp0_link_enab		),//input				
		.dvp0_vsyn_pado					(dvp0_vsyn_pado		),//output	reg			
		.dvp0_hsyn_pado					(dvp0_hsyn_pado		),//output	reg			
		.dvp0_data_pado					(dvp0_data_pado		),//output	reg [15: 0]	
		.dvp0_pclk_pado					(dvp0_pclk_pado		),//output				

		.dvp1_link_enab					(dvp1_link_enab		),//input					
		.dvp1_vsyn_pado					(dvp1_vsyn_pado		),//output	reg				
		.dvp1_hsyn_pado					(dvp1_hsyn_pado		),//output	reg				
		.dvp1_data_pado					(dvp1_data_pado		),//output	reg [15: 0]		
		.dvp1_pclk_pado					(dvp1_pclk_pado		),//output					
	
		.dvpx_cmnd_enab					(dvpx_link_cmnd_enab),//input				
		.dvpx_dmmy_enab					(dvpx_link_dmmy_enab),//input				
		.dvpx_odat_enab					(dvpx_link_odat_enab),//input				
		.dvpx_cmnd_vsyn					(dvpx_cmnd_vsyn		),//input				
		.dvpx_cmnd_hsyn					(dvpx_cmnd_hsyn		),//input				
		.dvpx_cmnd_dato					(dvpx_cmnd_dato		),//input		[15:0]	
		.dvpx_data_hsyn					(dvpx_data_hsyn		),//input				
		.dvpx_data_dato					(dvpx_data_dato		),//input		[15:0]	
		.dvpx_pclk						(dvpx_pclk				),//input				
		.dvpx_rstn						(dvpx_rstn				));//input				

endmodule

 