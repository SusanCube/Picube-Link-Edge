/*----------------------------------------------------------------------
AUTHOR	: EDWARD YANG
history : 
        2024/12/02, linsen, fix data CMND sequence 
        1. handshake with cube, waiting for re-cfig dvp ready
        2. dummy vsyn
----------------------------------------------------------------------*/
module	dvpx_link_txdo_cmnd(
	output	reg							dvpx_cmnd_vsyn		,
	output	reg							dvpx_cmnd_hsyn		,
	output	reg [15: 0]					dvpx_cmnd_dato		,

	input								dvpx_cmnd_enab		,
	input								dvpx_dmyv_enab		,
	output								dvpx_cmnd_done		,
    output                          	dvpx_dmyv_done      ,

	output	reg	[ 3: 0]					dvpx_cmnd_indx		,
	input		[31: 0]					dvpx_cmnd_word		,

	input								dvpx_pclk			,
	input								dvpx_rstn			);
/**********************************************************************************************************************/
	reg 		[ 1: 0]					dvpx_tcmd_samp	;
	reg 		[ 1: 0]					dvpx_tdmy_samp	;

	wire								dvpx_tcmd_enab	=	dvpx_tcmd_samp[1]	;
	wire								dvpx_tdmy_enab	=	dvpx_tdmy_samp[1]	;

	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_tcmd_samp	<=	0	;
	else								dvpx_tcmd_samp	<={	dvpx_cmnd_enab	,	dvpx_tcmd_samp[1]	};

	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_tdmy_samp	<=	0	;
	else								dvpx_tdmy_samp	<={	dvpx_dmyv_enab	,	dvpx_tdmy_samp[1]	};
/**********************************************************************************************************************/
	reg		[ 2: 0]						dvpx_cmnd_mfsm	;
	reg		[ 3: 0]						dvpx_cmnd_time	;

	parameter							DVPX_CMND_IDLE	=	3'H0	;
	parameter							DVPX_CMND_PFIX	=	3'H1	;
	parameter							DVPX_CMND_MUTE	=	3'H2	;
	parameter							DVPX_CMND_DMMY	=	3'H3	;
	parameter							DVPX_CMND_DONE	=	3'H4	;
    parameter                       	DVPX_CMND_DMYV  =   3'H5    ;
    parameter                       	DVPX_DMYV_DONE  =   3'H6    ;

	wire								dvpx_pfix_last	;
	wire								dvpx_mute_last	;
	wire								dvpx_dmmy_last	;
    wire                            	dvpx_dmyv_last  ;

	wire								dvpx_cmnd_idle	;
	wire								dvpx_cmnd_pfix	;
	wire								dvpx_cmnd_mute	;
	wire								dvpx_cmnd_dmmy	;
	wire								dvpx_cmnd_dmyv	;
	
	assign	dvpx_pfix_last		= &{	dvpx_cmnd_pfix	,	dvpx_cmnd_time == 4'HF	};
	assign	dvpx_mute_last		= &{	dvpx_cmnd_mute	,	dvpx_cmnd_time == 4'H7	};
	assign	dvpx_dmmy_last		= &{	dvpx_cmnd_dmmy	,	dvpx_cmnd_time == 4'H7	};
    assign  dvpx_dmyv_last      = &{	dvpx_cmnd_dmyv  ,   dvpx_cmnd_time == 4'HF  };

	assign	dvpx_cmnd_idle		=	dvpx_cmnd_mfsm	==	DVPX_CMND_IDLE	;
	assign	dvpx_cmnd_pfix		=	dvpx_cmnd_mfsm	==	DVPX_CMND_PFIX	;
	assign	dvpx_cmnd_mute		=	dvpx_cmnd_mfsm	==	DVPX_CMND_MUTE	;
	assign	dvpx_cmnd_dmmy		=	dvpx_cmnd_mfsm	==	DVPX_CMND_DMMY	;
	assign	dvpx_cmnd_done		=	dvpx_cmnd_mfsm	==	DVPX_CMND_DONE	;
	assign	dvpx_cmnd_dmyv		=	dvpx_cmnd_mfsm	==	DVPX_CMND_DMYV	;
    assign  dvpx_dmyv_done      =   dvpx_cmnd_mfsm  ==  DVPX_DMYV_DONE  ;

	always@(posedge	dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)					dvpx_cmnd_mfsm	<=	DVPX_CMND_IDLE	;
	else begin
		case(dvpx_cmnd_mfsm)
			DVPX_CMND_IDLE	:		dvpx_cmnd_mfsm	<=	dvpx_tcmd_enab	?	DVPX_CMND_PFIX	
                                                    :	dvpx_tdmy_enab  ?   DVPX_CMND_DMYV 	:	DVPX_CMND_IDLE	;

			DVPX_CMND_PFIX	:		dvpx_cmnd_mfsm	<=  dvpx_pfix_last	?	DVPX_CMND_MUTE	:	DVPX_CMND_PFIX	;	

			DVPX_CMND_MUTE	:		dvpx_cmnd_mfsm	<=	dvpx_mute_last	?	DVPX_CMND_DMMY	:	DVPX_CMND_MUTE	;		
			
			DVPX_CMND_DMMY	:		dvpx_cmnd_mfsm	<=	dvpx_dmmy_last	?	DVPX_CMND_DONE	:	DVPX_CMND_DMMY	;		
			
			DVPX_CMND_DONE	:		dvpx_cmnd_mfsm	<=	dvpx_tcmd_enab	?	DVPX_CMND_DONE	:	DVPX_CMND_IDLE	;

            DVPX_CMND_DMYV  :       dvpx_cmnd_mfsm  <=  dvpx_dmyv_last  ?   DVPX_DMYV_DONE  :   DVPX_CMND_DMYV  ;

            DVPX_DMYV_DONE  :       dvpx_cmnd_mfsm  <=  dvpx_tdmy_enab  ?   DVPX_DMYV_DONE  :   DVPX_CMND_IDLE  ;

			default			:		dvpx_cmnd_mfsm	<=						DVPX_CMND_IDLE						;
		endcase	
	end
/**********************************************************************************************************************/	
	reg									dvpx_time_tggl	;
	wire								dvpx_tggl_csen	;
	assign	dvpx_tggl_csen	= |{		dvpx_cmnd_pfix	,	dvpx_cmnd_dmmy	,	dvpx_cmnd_dmyv	};

	always@(posedge dvpx_pclk or negedge dvpx_rstn)	
	if(~dvpx_rstn)						dvpx_time_tggl	<=	0	;
	else if(~dvpx_tggl_csen)			dvpx_time_tggl	<=	0	;		
	else								dvpx_time_tggl	<= ~dvpx_time_tggl	;		
//------------------------------------------------------------------------------
	wire								dvpx_time_goon	;
	wire								dvpx_time_last	;
    
	assign	dvpx_time_goon		= |{	dvpx_cmnd_pfix	,	dvpx_cmnd_mute	,	dvpx_cmnd_dmmy	,   dvpx_cmnd_dmyv	};
	assign	dvpx_time_last		= |{	dvpx_pfix_last	,	dvpx_mute_last	,	dvpx_dmmy_last	,   dvpx_dmyv_last	};

	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)						dvpx_cmnd_time	<=	0	;
	else if(dvpx_time_goon)				dvpx_cmnd_time	<=	dvpx_time_last	?	4'H0	:	dvpx_cmnd_time + 1	;		
	else 								dvpx_cmnd_time	<=	0	;

    always@(posedge dvpx_pclk or negedge dvpx_rstn)
    if(~dvpx_rstn)                  dvpx_cmnd_indx  <=  0   ;
    else if(dvpx_cmnd_pfix)         dvpx_cmnd_indx  <=  dvpx_cmnd_indx + dvpx_time_tggl	;
    else                            dvpx_cmnd_indx  <=  0   ;
//------------------------------------------------------------------------------
	wire							dvpx_vsyn_csen	;
	assign	dvpx_vsyn_csen	=	dvpx_cmnd_pfix	|	dvpx_cmnd_dmyv	;	

	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)					dvpx_cmnd_vsyn	<=	0	;
    else if( dvpx_vsyn_csen )		dvpx_cmnd_vsyn	<=	1	;
	else							dvpx_cmnd_vsyn	<=	0	;
	
	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)					dvpx_cmnd_hsyn	<=	0	;
	else if( dvpx_cmnd_dmmy)		dvpx_cmnd_hsyn	<=	1	;
	else 							dvpx_cmnd_hsyn	<=	0	;
 
    wire	[15:0]  dvpx_cmnd_datw      =   dvpx_cmnd_time[0] ? dvpx_cmnd_word[31:16] : dvpx_cmnd_word[15: 0];

	always@(posedge dvpx_pclk or negedge dvpx_rstn)
	if(~dvpx_rstn)					dvpx_cmnd_dato	<=	0	;
	else if( dvpx_cmnd_pfix)		dvpx_cmnd_dato	<=	dvpx_time_tggl	?	dvpx_cmnd_word[31:16] : dvpx_cmnd_word[15: 0];
	else 							dvpx_cmnd_dato	<=	0	;

endmodule

 