															(200Mhz)				 (50Mhz)
tpem_fclk_inpt ---> |BUFIO2| ---> isde_sclk--->	|PLL|--->	osde_fclk--->|BUFIO2|--->osde_sclk (core_mclk)
(300Mhz)							(75Mhz)		|PLL|--->	dvpx_pclk(150Mhz)

gmsl_pclk_inpt	
(080Mhz)
																
fpga_slx9_tops	---|
				   |---|slx9_clks_gens
