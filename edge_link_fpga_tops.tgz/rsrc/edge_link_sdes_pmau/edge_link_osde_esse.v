/**********************************************************************************************************************/
module	edge_link_osde_esse(
	input								edge_tune_osde	,

	output								edge_fclk_outp	,
	output								edge_fclk_outn	,
	output								edge_fram_outp	,
	output								edge_fram_outn	,
	output								edge_dat0_outp	,
	output								edge_dat0_outn	,
	output								edge_dat1_outp	,
	output								edge_dat1_outn	,
	output								edge_dat2_outp	,
	output								edge_dat2_outn	,
	output								edge_dat3_outp	,
	output								edge_dat3_outn	,

	input	[ 7: 0]						tack_fram_mbdo	,//tune_good' acks pack
	input	[ 7: 0]						tack_dat0_mbdo	,
	input	[ 7: 0]						tack_dat1_mbdo	,
	input	[ 7: 0]						tack_dat2_mbdo	,
	input	[ 7: 0]						tack_dat3_mbdo	,

	input	[ 7: 0]						scut_fram_mbdo	,
	input	[ 7: 0]						scut_dat0_mbdo	,
	input	[ 7: 0]						scut_dat1_mbdo	,
	input	[ 7: 0]						scut_dat2_mbdo	,
	input	[ 7: 0]						scut_dat3_mbdo	,//from sclk domain

	input	[ 7: 0]						acks_fram_mbdo	,
	input	[ 7: 0]						acks_dat0_mbdo	,
	input	[ 7: 0]						acks_dat1_mbdo	,
	input	[ 7: 0]						acks_dat2_mbdo	,
	input	[ 7: 0]						acks_dat3_mbdo	,//from sclk domain

	input	[ 7: 0]						dlnk_fram_mbdo	,
	input	[ 7: 0]						dlnk_dat0_mbdo	,
	input	[ 7: 0]						dlnk_dat1_mbdo	,
	input	[ 7: 0]						dlnk_dat2_mbdo	,
	input	[ 7: 0]						dlnk_dat3_mbdo	,//from sclk domain

	output								osde_sclk		,
	input								osde_fclk		,	
	input								osde_rstn		);
/**********************************************************************************************************************/
	wire								osde_tune_csen	;

	link_sign_slpf					u_edge_tune_osde(
		.mode_slpf						(osde_tune_csen		),//output	reg	
		.mode_sign						(edge_tune_osde		),//input								
		.link_sclk						(osde_sclk			),
		.link_rstn						(osde_rstn			));
//--------------------------------------
	OBUFDS							u_osde_fclk_pads(
		.I								(osde_fclk			),
		.O								(edge_fclk_outp		),
		.OB								(edge_fclk_outn		));		
/**********************************************************************************************************************/
	reg			[ 7: 0]					osde_fram_mbdo	;
	reg			[ 7: 0]					osde_dat0_mbdo	;
	reg			[ 7: 0]					osde_dat1_mbdo	;
	reg			[ 7: 0]					osde_dat2_mbdo	;
	reg			[ 7: 0]					osde_dat3_mbdo	;//from sclk domain

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						begin
		osde_fram_mbdo	<=	8'H00	;
		osde_dat3_mbdo	<=	8'H00	;
		osde_dat2_mbdo	<=	8'H00	;
		osde_dat1_mbdo	<=	8'H00	;
		osde_dat0_mbdo	<=	8'H00	;
	end else if(osde_tune_csen)			begin
		osde_fram_mbdo	<=	8'H9A	;
		osde_dat3_mbdo	<=	8'H9A	;
		osde_dat2_mbdo	<=	8'H9A	;
		osde_dat1_mbdo	<=	8'H9A	;
		osde_dat0_mbdo	<=	8'H9A	;
	end else 							begin
		osde_fram_mbdo	<=	acks_fram_mbdo | dlnk_fram_mbdo | scut_fram_mbdo | tack_fram_mbdo	;
		osde_dat3_mbdo	<=	acks_dat3_mbdo | dlnk_dat3_mbdo | scut_dat3_mbdo | tack_dat3_mbdo	;
		osde_dat2_mbdo	<=	acks_dat2_mbdo | dlnk_dat2_mbdo | scut_dat2_mbdo | tack_dat2_mbdo	;
		osde_dat1_mbdo	<=	acks_dat1_mbdo | dlnk_dat1_mbdo | scut_dat1_mbdo | tack_dat1_mbdo	;
		osde_dat0_mbdo	<=	acks_dat0_mbdo | dlnk_dat0_mbdo | scut_dat0_mbdo | tack_dat0_mbdo	;
	end
/**********************************************************************************************************************/
	wire		[ 4: 0]					osde_mbdo_data[ 7:0];
	wire		[ 4: 0]					osde_sbdo_padp		;
	wire		[ 4: 0]					osde_sbdo_padn		;
	wire	osde_rstb	= ~	osde_rstn	;	
//------------------------------------------------------------------------------
	edge_osde_link_pmau(
		.LVDS_OSDE_OUTP					(osde_sbdo_padp	),//output	[ 4: 0]		
  		.LVDS_OSDE_OUTN					(osde_sbdo_padn	),//output	[ 4: 0]		
  		.LVDS_OSDE_MBDI[7:0]			(osde_mbdo_data	),//input	[ 4: 0] 	
		.OSDE_SCLK						(osde_sclk		),//output				
		.OSDE_FCLK						(osde_fclk		),//input              
		.OSDE_RSTB						(osde_rstb		));//input              
//------------------------------------------------------------------------------
	assign		osde_mbdo_data[4]	=	osde_fram_mbdo	;
	assign		osde_mbdo_data[3]	=	osde_dat3_mbdo	;
	assign		osde_mbdo_data[2]	=	osde_dat2_mbdo	;
	assign		osde_mbdo_data[1]	=	osde_dat1_mbdo	;
	assign		osde_mbdo_data[0]	=	osde_dat0_mbdo	;

	assign		edge_fram_outp		=	osde_sbdo_padp[4]	;
	assign		edge_fram_outn		=	osde_sbdo_padn[4]	;
	assign		edge_dat3_outp		=	osde_sbdo_padp[3]	;
	assign		edge_dat3_outn		=	osde_sbdo_padn[3]	;
	assign		edge_dat2_outp		=	osde_sbdo_padp[2]	;
	assign		edge_dat2_outn		=	osde_sbdo_padn[2]	;
	assign		edge_dat1_outp		=	osde_sbdo_padp[1]	;
	assign		edge_dat1_outn		=	osde_sbdo_padn[1]	;
	assign		edge_dat0_outp		=	osde_sbdo_padp[0]	;
	assign		edge_dat0_outn		=	osde_sbdo_padn[0]	;
/**********************************************************************************************************************/
endmodule

 
