

module	edge_link_isde_tune	(
	output	reg							isde_tune_bslp	,
	input								isde_tune_csen	,
	input	[39 :0]						isde_tune_pack	,
	input								isde_sclk		,
	input								isde_rstb		,

	output	reg [39:0]					osde_tune_acks	,
    input								osde_sclk		,
	input                           	osde_rstn       );	
/**********************************************************************************************************************/
	reg		[ 2: 0]						isde_tune_mfsm	;
	reg		[14: 0]						tune_pdet_time	;
	reg		[ 3: 0]						tune_seek_time	;
	reg		[ 3: 0]						tune_meet_cnts	;
	reg									tune_good_case	;
		

	parameter	ISDE_TUNE_IDLE	=	3'H0	;
	parameter	ISDE_TUNE_PDET	=	3'H1	;
	parameter	ISDE_TUNE_SEEK	=	3'H2	;
	parameter	ISDE_TUNE_BSLP	=	3'H3	;
	parameter	ISDE_TUNE_GOOD	=	3'H4	;

	wire								tune_patn_fail	;	
	wire								tune_seek_tmax	;	
	wire								tune_patn_miss	;	
	wire								tune_pdet_tmax	;				

	wire								tune_hits_idle	;
	wire								tune_hits_pdet	;
	wire								tune_hits_seek	;
	wire								tune_hits_bslp	;
	wire								tune_hits_good	;


`ifdef	FAST_SIMU
	assign	tune_pdet_tmax	= &	tune_pdet_time[10:0]	;
`else
	assign	tune_pdet_tmax	= &	tune_pdet_time[14:0]	;
`endif
	
	assign	tune_patn_fail	=	isde_tune_pack !=	40'H9A9A9A9A9A	;
	assign	tune_seek_tmax	=	tune_seek_time 	==	4'HF	;
	assign	tune_patn_miss	=	tune_meet_cnts 	<=	4'H8	;
	
	assign	tune_hits_idle	=	isde_tune_mfsm	==	ISDE_TUNE_IDLE	;
	assign	tune_hits_pdet	=	isde_tune_mfsm	==	ISDE_TUNE_PDET	;
	assign	tune_hits_seek	=	isde_tune_mfsm	==	ISDE_TUNE_SEEK	;
	assign	tune_hits_bslp	=	isde_tune_mfsm	==	ISDE_TUNE_BSLP	;
	assign	tune_hits_good	=	isde_tune_mfsm	==	ISDE_TUNE_GOOD	;

	always@(posedge	isde_sclk or posedge isde_rstb )
	if( isde_rstb)						isde_tune_mfsm	<=	ISDE_TUNE_IDLE	;
	else if(~isde_tune_csen) 			isde_tune_mfsm	<=	ISDE_TUNE_IDLE	;
	else begin
		case(isde_tune_mfsm)
			ISDE_TUNE_IDLE	:			isde_tune_mfsm	<=											ISDE_TUNE_PDET	;
			ISDE_TUNE_PDET	:			isde_tune_mfsm	<=	tune_pdet_tmax	?	ISDE_TUNE_SEEK	:	ISDE_TUNE_PDET	;
			ISDE_TUNE_SEEK	:			isde_tune_mfsm	<=	tune_seek_tmax	?	ISDE_TUNE_BSLP	:	ISDE_TUNE_SEEK	;
			ISDE_TUNE_BSLP	:			isde_tune_mfsm	<=	tune_patn_miss	?	ISDE_TUNE_SEEK	:	ISDE_TUNE_GOOD	;
			ISDE_TUNE_GOOD	:			isde_tune_mfsm	<=											ISDE_TUNE_GOOD	;
			default			:			isde_tune_mfsm	<=											ISDE_TUNE_IDLE	;		
		endcase
	end	
/**********************************************************************************************************************/	
	always@(posedge	isde_sclk or posedge isde_rstb )
	if( isde_rstb)						tune_pdet_time	<=	0	;
	else if( tune_hits_pdet)			tune_pdet_time	<=	tune_pdet_time + 1	;
	else								tune_pdet_time	<=	0	;
//------------------------------------------------------------------------------
	always@(posedge	isde_sclk or posedge isde_rstb )
	if( isde_rstb)						tune_seek_time	<=	0	;
	else if(~tune_hits_seek)			tune_seek_time	<=	0	;
	else 								tune_seek_time	<=	tune_seek_time + 1	;
//------------------------------------------------------------------------------
	always@(posedge	isde_sclk or posedge isde_rstb )
	if( isde_rstb)						tune_meet_cnts	<=	0	;
	else if( tune_hits_seek)			tune_meet_cnts	<=	tune_patn_fail	?	4'H0	: tune_meet_cnts + 1	;
	else								tune_meet_cnts	<=	0	;
//------------------------------------------------------------------------------
	always@(posedge	isde_sclk or posedge isde_rstb )
	if( isde_rstb)						isde_tune_bslp	<=	0	;
	else if( tune_hits_bslp)			isde_tune_bslp	<=	tune_patn_miss	;
	else								isde_tune_bslp	<=	0	;
//------------------------------------------------------------------------------
	always@(posedge	isde_sclk or posedge isde_rstb )
	if( isde_rstb)						tune_good_case	<=	0	;
	else								tune_good_case	<=	tune_hits_good	;	
/**********************************************************************************************************************/	
	reg		[ 3: 0]						tune_good_samp	;

	wire								osde_good_acks	
	assign	osde_good_acks	= {	tune_good_samp[2] ,tune_good_samp[0]} ==	2'B10	;	
	
	always@(posedge	osde_sclk or negedge  osde_rstn)
	if(~osde_rstn)						tune_good_samp	<=	0	;
	else								tune_good_samp	<=	{tune_good_case	,	tune_good_samp[3:1]}	;
//------------------------------------------------------------------------------	
	always@(posedge	osde_sclkor negedge  osde_rstn)
	if(~osde_rstn)						osde_tune_acks	<=	40'H0	;
	else if( osde_good_acks) 			osde_tune_acks	<=	40'HFF41434B53	;
	else								osde_tune_acks	<=	40'H0	;

endmodule
