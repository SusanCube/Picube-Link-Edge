
`timescale 1ps/1ps
(* CORE_GENERATION_INFO = "lvds_isde_link_pmau,selectio_wiz_v4_1,{component_name=edge_link_320p,bus_dir=INPUTS,bus_sig_type=DIFF,bus_io_std=LVDS_33,use_serialization=true,use_phase_detector=false,serialization_factor=8,enable_bitslip=true,enable_train=false,system_data_width=5,bus_in_delay=FIXED,bus_out_delay=NONE,clk_sig_type=DIFF,clk_io_std=LVDS_33,clk_buf=BUFIO2,active_edge=BOTH_RISE_FALL,clk_delay=FIXED,v6_bus_in_delay=NONE,v6_bus_out_delay=NONE,v6_clk_buf=BUFIO,v6_active_edge=NOT_APP,v6_ddr_alignment=SAME_EDGE_PIPELINED,v6_oddr_alignment=SAME_EDGE,ddr_alignment=C0,v6_interface_type=NETWORKING,interface_type=RETIMED,v6_bus_in_tap=0,v6_bus_out_tap=0,v6_clk_io_std=LVCMOS18,v6_clk_sig_type=DIFF}" *)

module edge_isde_link_pmau(
  	input	[ 4: 0]						LVDS_INPT_PADP	,
  	input  	[ 4: 0] 					LVDS_INPT_PADN	,
  	output	[39: 0] 					ISDE_INPT_MBDI	,
	output             					ISDE_SCLK		, // Slow clock output

	input              					BIT_SLIP		,
	input              					CLK_INPP		,// Differential clock from IOB
	input              					CLK_INPN		,
	input              					ISDE_RSTB		);
/**********************************************************************************************************************/
/**********************************************************************************************************************/
	wire 	[ 4: 0] 					ISDE_SBDI_MDLY;
	wire 	[ 4: 0] 					ISDE_SBDI_SDLY;


	wire	[ 4: 0] 					ISDE_SBDI		;
  	wire 	[ 4: 0]  					ISDE_MBDO[0:7]	;//iserdes_q[0:7];   // fills in starting with 0

	wire 	[ 4: 0] 					ISDE_PDET_SHFT	;
	wire 	[ 4: 0] 					ISDE_PDET_BUSY	;
	wire 	[ 4: 0] 					ISDE_PDET_VLID	;//pd_valid;
	wire 	[ 4: 0] 					ISDE_PDET_IDEC	;//pd_inc_dec;


	wire	[ 4: 0]						IDLY_TUNE_INC1	;
	wire	[ 4: 0]						IDLY_TUNE_CKEN	;
	wire								IDLY_TAPS_CALM	;//pd_cal_master
	wire								IDLY_TAPS_CALS	;//pd_cal_slave
	wire								IDLY_TAPS_RSTB	;//pd_cal_rst
//----------------------------------------------------------------------------------------------------------------------
//CLOCK GEN	
  	IBUFGDS_DIFF_OUT	#(	
	  	.DIFF_TERM						("TRUE"			),
		.IOSTANDARD 					("LVDS_33"		))
   	LVDS_CLKI_BUFDS(
		.I          					(CLK_INPP		),
      	.IB         					(CLK_INPN		),
      	.O          					(clk_inpp		),
      	.OB         					(clk_inpn		));

	IODELAY2    #(
		.DATA_RATE                  	("DDR"			),
		.IDELAY_VALUE               	(0				),
		.IDELAY_TYPE                	("FIXED"		),
		.COUNTER_WRAPAROUND         	("STAY_AT_LIMIT"),
		.DELAY_SRC                  	("IDATAIN"		),
		.SERDES_MODE                	("NONE"			),
		.SIM_TAPDELAY_VALUE         	(75				))
	IODELAY2_CLKP(
		.IDATAIN                		(clk_inpp		),
		.DATAOUT                		(clk_inpp_dlys	),
		.T                      		(1'b1			),
		.DATAOUT2               		(				),
		.DOUT                   		(				),
		.ODATAIN                		(1'b0			),
		.TOUT                   		(				),
		.IOCLK0                 		(1'b0			),// No calibration needed
		.IOCLK1                 		(1'b0			),// No calibration needed
		.CLK                    		(1'b0			),
		.CAL                    		(1'b0			),
		.INC                    		(1'b0			),
		.CE                     		(1'b0			),
		.BUSY                   		(				),
		.RST                    		(1'b0			));

	IODELAY2    #(
		.DATA_RATE                  	("DDR"			),
		.IDELAY_VALUE               	(0				),
		.IDELAY_TYPE                	("FIXED"		),
		.COUNTER_WRAPAROUND         	("STAY_AT_LIMIT"),
		.DELAY_SRC                  	("IDATAIN"		),
		.SERDES_MODE                	("NONE"			),
		.SIM_TAPDELAY_VALUE         	(75				))
	IODELAY2_CLKN(
		.IDATAIN                		(clk_inpn		),
		.DATAOUT                		(clk_inpn_dlys	),
		.T                      		(1'b1			),
		.DATAOUT2               		(				),
		.DOUT                   		(				),
		.ODATAIN                		(1'b0			),
		.TOUT                   		(				),
		.IOCLK0                 		(1'b0			),                 // No calibration needed
		.IOCLK1                 		(1'b0			),                 // No calibration needed
		.CLK                    		(1'b0			),
		.CAL                    		(1'b0			),
		.INC                    		(1'b0			),
		.CE                     		(1'b0			),
		.BUSY                   		(				),
		.RST                    		(1'b0			));
// Set up the clock for use in the serdes
	BUFIO2_2CLK #(
		.DIVIDE   	     				(8				))
	CLKP_BUFIO2CK(
		.DIVCLK  	   					(clki_div4		),
		.IOCLK        					(ISDE_FCLK_P	),//OUT
		.SERDESSTROBE 					(ISDE_STRB		),
		.I            					(clk_inpp_dlys	),
		.IB           					(clk_inpn_dlys	));

	BUFG	ISDE_SCLK_BUFG(
		.O 								(ISDE_SCLK		),
		.I 								(clki_div4		));

 	BUFIO2	#(
		.DIVIDE_BYPASS 					("FALSE"		),
		.I_INVERT      					("FALSE"		),
		.USE_DOUBLER   					("FALSE"		),
		.DIVIDE        					(1				))
	CLKN_BUFIO2	(
		.DIVCLK 	      				(ISDE_FCLK_w	),
		.IOCLK      	  				(ISDE_FCLK_N	),//OUT
		.SERDESSTROBE 					(),
		.I            					(clk_inpn_dlys));

	BUFG	ISDE_FCLK_bufg	(
		.O		(ISDE_FCLK		),
		.I		(ISDE_FCLK_w	));
/******************************************************************************/

// Instantiate the serdes primitive
// local wire only for use in this generate loop
// We have multiple bits- step over every bit, instantiating the required elements
	wire 	[ 4: 0] 					icascade;
	
	genvar pin_count;
  	
	generate for (pin_count = 0; pin_count < 5; pin_count = pin_count + 1) begin: lvds_isde_pins
	    IBUFDS#(
			.DIFF_TERM  ("TRUE"),
	        .IOSTANDARD ("LVDS_33"))
	    ISDE_PADBUFDS(
			.I    						(LVDS_INPT_PADP [pin_count]),
	        .IB   						(LVDS_INPT_PADN [pin_count]),
	        .O    						(ISDE_SBDI		[pin_count]));

		IODELAY2 #(
			.DATA_RATE      			("DDR"							),// <SDR>, DDR
			.IDELAY_VALUE  				(0								),// {0 ... 255}
			.IDELAY_TYPE   				("DIFF_PHASE_DETECTOR"			),// "DEFAULT", "DIFF_PHASE_DETECTOR", "FIXED", "VARIABLE_FROM_HALF_MAX", "VARIABLE_FROM_ZERO"
			.COUNTER_WRAPAROUND 		("WRAPAROUND"					),// <STAY_AT_LIMIT>, WRAPAROUND
			.DELAY_SRC     				("IDATAIN" 						),// "IO", "IDATAIN", "ODATAIN"
			.SERDES_MODE   				("MASTER"						),// <NONE>, MASTER, SLAVE
			.SIM_TAPDELAY_VALUE   		(49								))//
		iodelay_m (	
			.IDATAIN  					(ISDE_SBDI	[pin_count]			), 	// data from primary IOB
			.TOUT     					(								),	// tri-state signal to IOB
			.DOUT     					(								),	// output data to IOB
			.T        					(1'b1							),	// tri-state control from OLOGIC/OSERDES2
			.ODATAIN  					(1'b0							),	// data from OLOGIC/OSERDES2
			.DATAOUT2 					(								),	// Output data 2 to ILOGIC/ISERDES2
			.DATAOUT  					(ISDE_SBDI_MDLY[pin_count]		),	// Output data 1 to ILOGIC/ISERDES2
			.IOCLK0         			(ISDE_FCLK_P					),  // High speed clock for calibration for SDR/DDR
			.IOCLK1         			(ISDE_FCLK_N					),  // High speed clock for calibration for DDR
			.CLK      					(ISDE_SCLK						), 	// Fabric clock (GCLK) for control signals
			.CAL      					(IDLY_TAPS_CALM					),	// Calibrate control signal
			.INC      					(IDLY_TUNE_INC1[pin_count]		), 	// Increment counter
			.CE       					(IDLY_TUNE_CKEN[pin_count]		), 	// Clock Enable
			.RST      					(IDLY_TAPS_RSTB					),	// Reset delay line
			.BUSY      					(								));	// output signal indicating sync circuit has finished / calibration has finished

		IODELAY2 #(
			.DATA_RATE      			("DDR"							),// <SDR>, DDR
			.IDELAY_VALUE  				(0								),// {0 ... 255}
			.IDELAY_TYPE   				("DIFF_PHASE_DETECTOR"			),// "DEFAULT", "DIFF_PHASE_DETECTOR", "FIXED", "VARIABLE_FROM_HALF_MAX", "VARIABLE_FROM_ZERO"
			.COUNTER_WRAPAROUND 		("WRAPAROUND"					),// <STAY_AT_LIMIT>, WRAPAROUND
			.DELAY_SRC     				("IDATAIN" 						),// "IO", "IDATAIN", "ODATAIN"
			.SERDES_MODE   				("SLAVE"						),// <NONE>, MASTER, SLAVE
			.SIM_TAPDELAY_VALUE 	  	(49								))//
		iodelay_s (
			.IDATAIN 					(ISDE_SBDI  [pin_count]			),// data from primary IOB
			.TOUT     					(								),// tri-state signal to IOB
			.DOUT     					(								),// output data to IOB
			.T        					(1'b1							),// tri-state control from OLOGIC/OSERDES2
			.ODATAIN  					(1'b0							),// data from OLOGIC/OSERDES2
			.DATAOUT2 					(								),// Output data 2 to ILOGIC/ISERDES2
		    .DATAOUT  					(ISDE_SBDI_SDLY[pin_count]		),// Output data 1 to ILOGIC/ISERDES2
			.IOCLK0         			(ISDE_FCLK_P					),// High speed clock for calibration for SDR/DDR
		    .IOCLK1         			(ISDE_FCLK_N					),// High speed clock for calibration for DDR
		    .CLK      					(ISDE_SCLK						), 		// Fabric clock (GCLK) for control signals
			.CAL      					(IDLY_TAPS_CALS					),	// Calibrate control signal
			.INC      					(IDLY_TUNE_INC1[pin_count]		), 		// Increment counter
			.CE       					(IDLY_TUNE_CKEN[pin_count]		), 		// Clock Enable
			.RST      					(IDLY_TAPS_RSTB					),		// Reset delay line
			.BUSY      					(ISDE_PDET_BUSY[pin_count]		)) ;		// output signal indicating sync circuit has finished / calibration has finished

	     // decalare the iserdes
	    ISERDES2	#(
			.BITSLIP_ENABLE 			("TRUE"							),
	    	.DATA_RATE      			("DDR"							),
	    	.DATA_WIDTH     			(8								),
	    	.INTERFACE_TYPE 			("RETIMED"						),
	    	.SERDES_MODE    			("MASTER"						))
	    ISDE2_MAST	(
			.Q1         				(ISDE_MBDO[3][pin_count]		),
	        .Q2         				(ISDE_MBDO[2][pin_count]		),
	        .Q3         				(ISDE_MBDO[1][pin_count]		),
	        .Q4         				(ISDE_MBDO[0][pin_count]		),
	        .INCDEC     				(ISDE_PDET_IDEC[pin_count]		), 	// 1-bit Output of Phase Detector (Dummy in slave)
	        .SHIFTOUT   				(icascade[pin_count]			), 	//1-bit Cascade out signal for Master/Slave IO. In Phase Detector mode used to send slave sampled data 
	        .VALID      				(ISDE_PDET_VLID[pin_count]		), 	// 1-bit Output of Phase Detector (Dummy in Slave). If the input data contains no
	                                             							// edges (no info for the phase detector to work with) the VALID signal will go
	                                             							// LOW to indicate that the fabric should ignore the INCDEC signal.

	        .BITSLIP    				(BIT_SLIP						), 	// 1-bit Invoke Bitslip. This can be used with any DATA_WIDTH, cascaded or not.
	                                     									// The amount of bitslip is fixed by the DATA_WIDTH selection.
	        .CE0        				(1'B1							),  // 1-bit Clock enable input
	        .CLK0       				(ISDE_FCLK_P					),
	        .CLK1       				(ISDE_FCLK_N					),
	        .CLKDIV     				(ISDE_SCLK						),	// 1-bit Global clock network input. This is the clock for the fabric domain.
	        .D          				(ISDE_SBDI_MDLY[pin_count]		), 	// 1-bit Input signal from IOB.
	        .IOCE       				(ISDE_STRB						),	// 1-bit Data strobe signal derived from BUFIO CE. Strobes data capture for_PIPELINES alignment modes.
	        .RST        				(ISDE_RSTB						),  // 1-bit Asynchronous reset only.
	        .SHIFTIN    				(ISDE_PDET_SHFT[pin_count		]),
	        
			.FABRICOUT  				(),
	        .CFB0       				(),
	        .CFB1       				(),
	        .DFB        				());

	    ISERDES2#(
			.BITSLIP_ENABLE 			("TRUE"							),
	        .DATA_RATE      			("DDR"							),
	        .DATA_WIDTH     			(8								),
	        .INTERFACE_TYPE 			("RETIMED"						),
	        .SERDES_MODE    			("SLAVE"						))

	    ISDE2_SLAV	(
		  	.Q1         				(ISDE_MBDO[7][pin_count]		),
	        .Q2         				(ISDE_MBDO[6][pin_count]		),
	        .Q3         				(ISDE_MBDO[5][pin_count]		),
	        .Q4         				(ISDE_MBDO[4][pin_count]		),
	        .INCDEC     				(								), // 1-bit Output of Phase Detector (Dummy in slave)
	        .SHIFTOUT   				(ISDE_PDET_SHFT[pin_count]		), // 1-bit Cascade out signal for Master/Slave IO. In Phase Detector mode used to send slave sampled data.
	        .VALID      				(								), 


	        .BITSLIP    				(BIT_SLIP						),     
	        .CE0        				(1'B1							),  // 1-bit Clock enable input
	        .CLK0       				(ISDE_FCLK_P					), 
	        .CLK1       				(ISDE_FCLK_N					),
	        .CLKDIV     				(ISDE_SCLK						),   
	        .D          				(ISDE_SBDI_SDLY[pin_count]		),
	        .IOCE       				(ISDE_STRB),   
			.RST        				(ISDE_RSTB						),	// 1-bit Asynchronous reset only.
	        .SHIFTIN    				(icascade[pin_count]			),
	        
			.FABRICOUT  				(),
	        .CFB0       				(),
	        .CFB1       				(),
	        .DFB        				());


	assign  ISDE_INPT_MBDI[(pin_count+1)*8-1:pin_count*8] =  {   ISDE_MBDO[7][pin_count]	,	ISDE_MBDO[6][pin_count]	,	ISDE_MBDO[5][pin_count]	,	ISDE_MBDO[4][pin_count]	,
                											ISDE_MBDO[3][pin_count]	,	ISDE_MBDO[2][pin_count]	,	ISDE_MBDO[1][pin_count]	,	ISDE_MBDO[0][pin_count]	};
  	end
	endgenerate

	lvds_isde_link_pdet	#(
		.D(5))
	ISDE_PDET_UNIT	(
		.use_phase_detector				(1'b1			),
    	.busy							(ISDE_PDET_BUSY	),//INPUT
    	.valid							(ISDE_PDET_VLID	),//INPUT
    	.inc_dec						(ISDE_PDET_IDEC	),//INPUT
    	.reset							(ISDE_RSTB		),//INPUT
    	.gclk							(ISDE_SCLK		),//INPUT
    	.debug_in						(2'H0			),//INPUT
    	.debug							(				),//OUT
    	.cal_master						(IDLY_TAPS_CALM	),//OUT
    	.cal_slave						(IDLY_TAPS_CALS	),//OUT
    	.rst_out						(IDLY_TAPS_RSTB	),//OUT
    	.ce								(IDLY_TUNE_CKEN	),//OUT
    	.inc							(IDLY_TUNE_INC1));//OUT
endmodule
