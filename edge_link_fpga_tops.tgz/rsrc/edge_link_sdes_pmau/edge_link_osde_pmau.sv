module	edge_osde_link_pmau(
	output	[ 4: 0]						LVDS_OSDE_OUTP		,
  	output	[ 4: 0]						LVDS_OSDE_OUTN		,
  	input	[ 4: 0] 					LVDS_OSDE_MBDI[7:0]	,
	
	output								OSDE_SCLK			,
	input              					OSDE_FCLK			,// Differential clock from IOB
	input              					OSDE_RSTB			);
/**********************************************************************************************************************/

	BUFIO2	#(
		.DIVIDE_BYPASS 					("FALSE"	),
		.I_INVERT      					("FALSE"	),
		.USE_DOUBLER   					("TRUE"		),
		.DIVIDE        					(8			))
	FCKP_IO2BUFG	(
		.DIVCLK       					(OSDE_SCLK	),
		.IOCLK        					(OSDE_FCKP	),
		.SERDESSTROBE 					(OSDE_STRB	),
		.I            					(OSDE_FCLK	));

	BUFIO2	#(
		.DIVIDE_BYPASS 					("FALSE"	),
		.I_INVERT      					("TRUE"		),
		.USE_DOUBLER   					("FALSE"	),
		.DIVIDE        					(8			))
	FCKN_IO2BUFG	(
		.DIVCLK       					(			),
	   	.IOCLK        					(OSDE_FCKN	),
	   	.SERDESSTROBE 					(			),
	   	.I            					(OSDE_FCLK	));
/**********************************************************************************************************************/
	wire		[ 4: 0]					OSDE_OUTP_SBDO	;

	genvar i;
  	
generate for (i = 0; i < 5; i = i + 1) begin: gens_osde_pmau

	OBUFDS							LVDS_OSDE_DPAD	(
		.I								(OSDE_OUTP_SBDO[i]	),
		.O								(LVDS_OUTP_PADP[i]	),
		.OB								(LVDS_OUTP_PADN[i]	));		

	lvds_osde_link_lane				LVDS_OSDE_LANE(
		.OSDE_OUTP_SBDO					(OSDE_OUTP_SBDO[i]		),//output			
		.OSDE_OUTP_MBDI					(OSDE_OUTP_MBDI[i][7:0]	),//input	[ 7: 0] 
		.OSDE_FCKP						(OSDE_FCKP			),//input           
		.OSDE_FCKN						(OSDE_FCKN			),//input           
		.OSDE_SCLK						(OSDE_SCLK			),//input			
		.OSDE_STRB						(OSDE_STRB			),//input           
		.OSDE_RSTB						(OSDE_RSTB			))//input           
	end
endgenerate



endmodule


