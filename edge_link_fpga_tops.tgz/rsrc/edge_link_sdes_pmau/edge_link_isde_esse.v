
module  edge_link_isde_esse(
    input                          		edge_tune_isde 	,

    input                          		edge_fclk_inpp  ,
    input                          		edge_fclk_inpn  ,
    input                          		edge_fram_inpp  ,
    input                          		edge_fram_inpn  ,
    input                          		edge_dat0_inpp  ,
    input                          		edge_dat0_inpn  ,
    input                          		edge_dat1_inpp  ,
    input                          		edge_dat1_inpn  ,
    input                          		edge_dat2_inpp  ,
    input                          		edge_dat2_inpn  ,
    input                          		edge_dat3_inpp  ,
    input                          		edge_dat3_inpn  ,
  //------------------------------------------------------------------------------  
	output		[ 0: 9]					isde_cmnd_mark	,
	output								isde_cmnd_lead	,
	output								isde_cmnd_wrcs	,
	output								isde_cmnd_coda	,
	output		[31: 0]					isde_cmnd_word	,
	
	output								isde_data_lead	,
	output								isde_data_wrcs	,
	output		[31: 0]					isde_data_word	,
//------------------------------------------------------------------------------		
    output      [39: 0]            		isde_tune_acks	,

	output								isde_sclk			,
	input								isde_rstn			,
	input								osde_sclk			,
	input								osde_rstn			);
/**********************************************************************************************************************/
    wire                            	tpem_tune_bslp  	;

    wire    [ 4: 0]                 	isde_sbdi_padp	;
    wire    [ 4: 0]                 	isde_sbdi_padn	;
    wire    [39: 0]               		isde_mbdi_pack 	;

	assign  isde_sbdi_padp      ={  	edge_fram_inpp  ,
                                    	edge_dat3_inpp  ,
                                    	edge_dat2_inpp  ,
                                    	edge_dat1_inpp  ,
                                    	edge_dat0_inpp  }   ;

    assign  isde_sbdi_padn      ={  	edge_fram_inpn  ,
                                    	edge_dat3_inpn  ,
                                    	edge_dat2_inpn  ,
                                    	edge_dat1_inpn  ,
                                    	edge_dat0_inpn  }   ;
    
/**********************************************************************************************************************/
	link_sign_slpf					u_edge_link_tune_isde(
		.mode_slpf						(isde_tune_csen		),//output	reg	
		.mode_sign						(edge_tune_isde		),//input								
		.link_sclk						(isde_sclk			),
		.link_rstn						(isde_rstn			));
//------------------------------------------------------------------------------	
	edge_link_isde_tune        	 	u_edge_link_isde_tune(
        .isde_tune_bslp	            	(isde_tune_bslp		),
        .isde_tune_csen	            	(isde_tune_csen    	),
        .isde_tune_pack	            	(isde_mbdi_pack    	),
        .isde_sclk						(isde_sclk			),
        .isde_rstn                  	(isde_rstn         	),
    
        .osde_tune_acks             	(isde_tune_acks    	),
        .osde_sclk        	          	(osde_sclk         	),
        .osde_rstn                  	(osde_rstn         	));	
//------------------------------------------------------------------------------
	edge_link_isde_pmau				u_edge_link_isde_pmau(
		.LVDS_INPT_PADP					(isde_sbdi_padp 	),
		.LVDS_INPT_PADN					(isde_sbdi_padn 	),
		.ISDE_INPT_MBDI					(isde_mbdi_pack		),
		.ISDE_SCLK						(isde_sclk			),//output

	    .BIT_SLIP						(isde_tune_bslp		),//input 
	    .CLK_INPP						(edge_fclk_inpp		),//input 
	    .CLK_INPN						(edge_fclk_inpn		),//input 
	    .IO_RESET						(~isde_rstn			));//input 
//------------------------------------------------------------------------------
    wire	[ 7: 0]  edge_isde_fram	 =	isde_mbdi_pack[39:32]  ;
    wire	[ 7: 0]  edge_isde_dat3	 =	isde_mbdi_pack[31:24]  ;
    wire	[ 7: 0]  edge_isde_dat2	 =	isde_mbdi_pack[23:16]  ;
    wire	[ 7: 0]  edge_isde_dat1	 =	isde_mbdi_pack[15: 8]  ;
    wire	[ 7: 0]  edge_isde_dat0	 =	isde_mbdi_pack[ 7: 0]  ;

	edge_link_isde_dmau				u_edge_link_isde_dmau(
		.rxdi_fram_mbdi					(edge_isde_fram		),//input	[7:0]
		.rxdi_dat3_mbdi					(edge_isde_dat3		),//input	[7:0]
		.rxdi_dat2_mbdi					(edge_isde_dat2		),//input	[7:0]
		.rxdi_dat1_mbdi					(edge_isde_dat1		),//input	[7:0]
		.rxdi_dat0_mbdi					(edge_isde_dat0		),//input	[7:0]

		.cmnd_icfg_mark					(isde_cmnd_mark[0]	),//output
		.cmnd_ocfg_mark					(isde_cmnd_mark[1]	),//output
		.cmnd_nnex_mark					(isde_cmnd_mark[2]	),//output
		.cmnd_ivct_mark					(isde_cmnd_mark[3]	),//output
		.cmnd_ovct_mark					(isde_cmnd_mark[4]	),//output
		.cmnd_imtx_mark					(isde_cmnd_mark[5]	),//output
		.cmnd_omtx_mark					(isde_cmnd_mark[6]	),//output
		.cmnd_aset_mark					(isde_cmnd_mark[7]	),//output
		.cmnd_dnld_mark					(isde_cmnd_mark[8]	),//output
		.cmnd_boot_mark					(isde_cmnd_mark[9]	),//output

		.icmd_pack_lead					(isde_cmnd_lead		),//output	reg				
		.icmd_pack_wrcs					(isde_cmnd_wrcs		),//output	reg				
		.icmd_pack_coda					(isde_cmnd_coda		),//output	reg				
        .icmd_pack_word 				(isde_cmnd_word		),//output  reg [31: 0]     

		.idat_pack_lead					(isde_data_lead		),//output	reg			
		.idat_pack_wrcs					(isde_data_wrcs		),//output	reg			
		.idat_pack_word					(isde_data_word		),//output	reg	[31: 0]	

		.isde_sclk						(isde_sclk			),//input	
		.isde_rstn						(isde_rstn			));//input	

/**********************************************************************************************************************/

endmodule