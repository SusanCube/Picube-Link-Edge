/*		lvds_rxdi_intf
	fram_sdi---->lvds_rxdi_line		
					|----IDLY----IDDR----SHFT----lane_trim_cell---->lvds_fram_mbo0

*/

`include	"agile_card_vars.vh"

module	edge_link_isde_dmau(
	input	[7:0]						rxdi_fram_mbdi	,
	input	[7:0]						rxdi_dat3_mbdi	,
	input	[7:0]						rxdi_dat2_mbdi	,
	input	[7:0]						rxdi_dat1_mbdi	,
	input	[7:0]						rxdi_dat0_mbdi	,

	output								cmnd_icfg_mark	,
	output								cmnd_ocfg_mark	,
	output								cmnd_nnex_mark	,
	output								cmnd_ivct_mark	,
	output								cmnd_ovct_mark	,
	output								cmnd_imtx_mark	,
	output								cmnd_omtx_mark	,
	output								cmnd_aset_mark	,
	output								cmnd_dnld_mark	,
	output								cmnd_boot_mark	,

	output	reg							icmd_pack_lead	,
	output	reg							icmd_pack_wrcs	,
	output	reg							icmd_pack_coda	,
    output  reg [31: 0]             	icmd_pack_word ,

	output	reg							idat_pack_lead	,
	output	reg							idat_pack_wrcs	,
	output	reg	[31: 0]					idat_pack_word	,

	input								isde_sclk		,
	input								isde_rstn		);
/**********************************************************************************************************************/
	reg		[7:0]						isde_fram_samp	;
	reg		[7:0]						isde_fram_samx	;
	reg		[7:0]						isde_dat3_samx	;
	reg		[7:0]						isde_dat2_samx	;
	reg		[7:0]						isde_dat1_samx	;
	reg		[7:0]						isde_dat0_samx	;

	always@(posedge isde_sclk or negedge isde_rstn)	
	if(~isde_rstn)	begin
		isde_fram_samp	<=	0	;
		isde_fram_samx	<=	0	;
		isde_dat3_samx	<=	0	;
		isde_dat2_samx	<=	0	;
		isde_dat1_samx	<=	0	;
		isde_dat0_samx	<=	0	;
	end 	else	begin
		isde_fram_samp	<=	rxdi_fram_mbdi	;
		isde_fram_samx	<=	isde_fram_samp	;
		isde_dat3_samx	<=	rxdi_dat3_mbdi	;
		isde_dat2_samx	<=	rxdi_dat2_mbdi	;
		isde_dat1_samx	<=	rxdi_dat1_mbdi	;
		isde_dat0_samx	<=	rxdi_dat0_mbdi	;
	end
/**********************************************************************************************************************/
//------------------------------------------------------------------------------		
	wire	[ 15: 0]				isde_fram_buff	;
	wire	[ 31: 0]				isde_data_buff	;
		
	wire	isde_fram_rise	=	isde_fram_buff	==	16'HFF00	;	
	wire	isde_fram_fall	=	isde_fram_buff	==	16'H00FF	;	
	wire	isde_fram_high	=	isde_fram_buff	==	16'HFFFF	;	
	
	assign	isde_fram_buff	={	isde_fram_samp	,	isde_fram_samx	};
	assign	isde_data_buff	={	isde_dat3_samx	,	isde_dat2_samx	,	isde_dat1_samx	,	isde_dat0_samx	};
//----------------------------------------------------------------------------------------------------------	
	assign	cmnd_icfg_mark	= &{isde_data_buff	==	`CUBE_LINK_ICFG_LEAD , isde_fram_rise	};
	assign	cmnd_ocfg_mark	= &{isde_data_buff	==	`CUBE_LINK_OCFG_LEAD , isde_fram_rise	};
	assign	cmnd_nnex_mark	= &{isde_data_buff	==	`CUBE_LINK_NNEX_LEAD , isde_fram_rise	};

	assign	cmnd_ivct_mark	= &{isde_data_buff	==	`CUBE_LINK_IVCT_LEAD , isde_fram_rise	};
	assign	cmnd_ovct_mark	= &{isde_data_buff	==	`CUBE_LINK_OVCT_LEAD , isde_fram_rise	};
	assign	cmnd_imtx_mark	= &{isde_data_buff	==	`CUBE_LINK_IMTX_LEAD , isde_fram_rise	};
	assign	cmnd_omtx_mark	= &{isde_data_buff	==	`CUBE_LINK_OMTX_LEAD , isde_fram_rise	};
	
	assign	cmnd_aset_mark	= &{isde_data_buff	==	`CUBE_LINK_ASET_LEAD , isde_fram_rise	};
	assign	cmnd_dnld_mark	= &{isde_data_buff	==	`CUBE_LINK_DNLD_LEAD , isde_fram_rise	};
	assign	cmnd_boot_mark	= &{isde_data_buff	==	`CUBE_LINK_BOOT_LEAD , isde_fram_rise	};

	wire	isde_data_mark	= &{isde_data_buff	==	`CUBE_LINK_DATA_LEAD , isde_fram_rise	};

	wire	isde_cmnd_mark	= |{cmnd_icfg_mark , cmnd_ocfg_mark , 
								cmnd_ivct_mark , cmnd_ovct_mark , 
								cmnd_imtx_mark , cmnd_omtx_mark , 
								cmnd_aset_mark , cmnd_dnld_mark , 
								cmnd_boot_mark , cmnd_nnex_mark };
/**********************************************************************************************************/	
	always@(posedge isde_sclk or negedge isde_rstn)	
	if(!isde_rstn)						icmd_pack_lead	<=	0	;
	else								icmd_pack_lead	<=	isde_cmnd_mark	;
//--------------------------------------
	always@(posedge isde_sclk or negedge isde_rstn)	
	if(!isde_rstn)						icmd_pack_wrcs	<=	0	;
	else if( icmd_pack_lead)			icmd_pack_wrcs	<=	1	;
	else if( isde_fram_fall)			icmd_pack_wrcs	<=	0	;
	else								icmd_pack_wrcs	<=	icmd_pack_wrcs	;
//--------------------------------------
	always@(posedge isde_sclk or negedge isde_rstn)	
	if(!isde_rstn)						icmd_pack_coda	<=	0	;
	else if( icmd_pack_wrcs)			icmd_pack_coda	<=	isde_fram_fall	;
	else								icmd_pack_coda	<=	0	;
//--------------------------------------
	wire	isde_cmnd_rxen	=	isde_cmnd_mark | isde_fram_high	;

    always@(posedge isde_sclk)
    if(!isde_rstn)                  	icmd_pack_word <=  0   ;
    else if (isde_cmnd_rxen)            icmd_pack_word <=  isde_data_buff ;
//--------------------------------------
	always@(posedge isde_sclk or negedge isde_rstn)	
	if(!isde_rstn)						idat_pack_lead	<=	0	;
	else								idat_pack_lead	<=	isde_data_mark	;
//--------------------------------------
	always@(posedge isde_sclk or negedge isde_rstn)	
	if(!isde_rstn)						idat_pack_wrcs	<=	0	;
	else if( idat_pack_lead)			idat_pack_wrcs	<=	1	;
	else if( isde_fram_fall)			idat_pack_wrcs	<=	0	;
	else								idat_pack_wrcs	<=	idat_pack_wrcs	;
//----------------------------------
	always@(posedge isde_sclk or negedge isde_rstn)	
	if(!isde_rstn)						idat_pack_word	<=	0	;
	else if( isde_fram_high)			idat_pack_word	<=	isde_data_buff	;
	else								idat_pack_word	<=	0	;
//----------------------------------------------------------------------	
 
endmodule
