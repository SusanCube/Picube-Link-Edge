
module  edge_link_sdes_esse(
	input								edge_tune_isde  ,
	input								edge_tune_osde  ,
//--------------------------------------	
    input								edge_fclk_inpp  ,
    input								edge_fram_inpp  ,
    input								edge_dat3_inpp  ,
    input								edge_dat2_inpp  ,
    input								edge_dat1_inpp  ,
    input								edge_dat0_inpp  ,

    input								edge_fclk_inpn  ,
    input								edge_fram_inpn  ,
    input								edge_dat3_inpn  ,
    input								edge_dat2_inpn  ,
    input								edge_dat1_inpn  ,
    input								edge_dat0_inpn  ,
//--------------------------------------
	output								edge_fclk_outp	,
	output								edge_fram_outp	,
	output								edge_dat3_outp	,
	output								edge_dat2_outp	,
	output								edge_dat1_outp	,
	output								edge_dat0_outp	,
	
	output								edge_fclk_outn	,
	output								edge_fram_outn	,
	output								edge_dat3_outn	,
	output								edge_dat2_outn	,
	output								edge_dat1_outn	,
	output								edge_dat0_outn	,
//--------------------------------------	
	output		[ 0: 9]					isde_cmnd_mark	,
	output								isde_cmnd_lead	,
	output								isde_cmnd_wrcs	,
	output								isde_cmnd_coda	,
	output		[31: 0]					isde_cmnd_word	,

	output								isde_data_lead	,
	output								isde_data_wrcs	,
	output		[31: 0]					isde_data_word	,
//--------------------------------------
	input		[ 7: 0]					scut_fram_mbdo 	,
    input		[ 7: 0]					scut_dat3_mbdo 	,
	input		[ 7: 0]					scut_dat2_mbdo 	,
    input		[ 7: 0]					scut_dat1_mbdo 	,
    input		[ 7: 0]					scut_dat0_mbdo 	,
    
	input		[ 7: 0]					acks_fram_mbdo 	,
    input		[ 7: 0]					acks_dat3_mbdo 	,
	input		[ 7: 0]					acks_dat2_mbdo 	,
    input		[ 7: 0]					acks_dat1_mbdo 	,
    input		[ 7: 0]					acks_dat0_mbdo 	,
    
	input		[ 7: 0]					dlnk_fram_mbdo 	,
    input		[ 7: 0]					dlnk_dat3_mbdo 	,
	input		[ 7: 0]					dlnk_dat2_mbdo 	,
    input		[ 7: 0]					dlnk_dat1_mbdo 	,
    input		[ 7: 0]					dlnk_dat0_mbdo 	,
//--------------------------------------	
	output 								isde_sclk		,
	output 								osde_sclk		,
	input								osde_fclk		,
	input  								isde_rstn		,
	input  								osde_rstn		);
/**********************************************************************************************************************/
	wire	[39: 0]						isde_tune_acks	;

  	wire      	[ 7: 0]             	tack_fram_mbdo =	isde_tune_acks[39:32]	;
    wire      	[ 7: 0]             	tack_dat0_mbdo =	isde_tune_acks[31:24]	;
    wire      	[ 7: 0]             	tack_dat1_mbdo =	isde_tune_acks[23:16]	;
    wire      	[ 7: 0]             	tack_dat2_mbdo =	isde_tune_acks[15: 8]	;
    wire      	[ 7: 0]             	tack_dat3_mbdo =	isde_tune_acks[ 7: 0]	;

	edge_link_isde_esse				u_edge_link_isde_esse(
    	.edge_tune_isde					(edge_tune_isde		),//input    
//------------------------------------------------------------------------------  
    	.edge_fclk_inpp 				(edge_fclk_inpp 	),//input    
    	.edge_fclk_inpn 				(edge_fclk_inpn 	),//input    
    	.edge_fram_inpp 				(edge_fram_inpp 	),//input    
    	.edge_fram_inpn 				(edge_fram_inpn 	),//input    
    	.edge_dat0_inpp 				(edge_dat0_inpp 	),//input    
    	.edge_dat0_inpn 				(edge_dat0_inpn 	),//input    
    	.edge_dat1_inpp 				(edge_dat1_inpp 	),//input    
    	.edge_dat1_inpn 				(edge_dat1_inpn 	),//input    
    	.edge_dat2_inpp 				(edge_dat2_inpp 	),//input    
    	.edge_dat2_inpn 				(edge_dat2_inpn 	),//input    
    	.edge_dat3_inpp 				(edge_dat3_inpp 	),//input    
    	.edge_dat3_inpn 				(edge_dat3_inpn 	),//input    
//------------------------------------------------------------------------------  
		.isde_cmnd_mark					(isde_cmnd_mark		),//output		[ 0: 9]	
		.isde_cmnd_lead					(isde_cmnd_lead		),//output				
		.isde_cmnd_wrcs					(isde_cmnd_wrcs		),//output				
		.isde_cmnd_coda					(isde_cmnd_coda		),//output				
		.isde_cmnd_word					(isde_cmnd_word		),//output		[31: 0]	

		.isde_data_lead					(isde_data_lead		),//output				
		.isde_data_wrcs					(isde_data_wrcs		),//output				
		.isde_data_word					(isde_data_word		),//output		[31: 0]	
//------------------------------------------------------------------------------		
		.isde_tune_stat					(isde_tune_acks		),//output      [39: 0]

		.isde_sclk						(isde_sclk			),//output		
		.isde_rstn						(isde_rstn			),//input		
		.osde_sclk						(osde_sclk			),//input		
		.osde_rstn						(osde_rstn			));//input		
/**********************************************************************************************************************/
	edge_link_osde_esse				u_edge_link_osde_esse(
		.edge_tune_osde					(edge_tune_osde		),//input	
//------------------------------------------------------------------------------  
		.edge_fclk_outp					(edge_fclk_outp		),//output	
		.edge_fclk_outn					(edge_fclk_outn		),//output	
		.edge_fram_outp					(edge_fram_outp		),//output	
		.edge_fram_outn					(edge_fram_outn		),//output	
		.edge_dat0_outp					(edge_dat0_outp		),//output	
		.edge_dat0_outn					(edge_dat0_outn		),//output	
		.edge_dat1_outp					(edge_dat1_outp		),//output	
		.edge_dat1_outn					(edge_dat1_outn		),//output	
		.edge_dat2_outp					(edge_dat2_outp		),//output	
		.edge_dat2_outn					(edge_dat2_outn		),//output	
		.edge_dat3_outp					(edge_dat3_outp		),//output	
		.edge_dat3_outn					(edge_dat3_outn		),//output	
//------------------------------------------------------------------------------
		.tack_fram_mbdo					(tack_fram_mbdo		),//input	[ 7: 0]		
		.tack_dat0_mbdo					(tack_dat0_mbdo		),//input	[ 7: 0]		
		.tack_dat1_mbdo					(tack_dat1_mbdo		),//input	[ 7: 0]		
		.tack_dat2_mbdo					(tack_dat2_mbdo		),//input	[ 7: 0]		
		.tack_dat3_mbdo					(tack_dat3_mbdo		),//input	[ 7: 0]		
//------------------------------------------------------------------------------
		.scut_fram_mbdo					(scut_fram_mbdo		),//input	[ 7: 0]			
		.scut_dat0_mbdo					(scut_dat0_mbdo		),//input	[ 7: 0]			
		.scut_dat1_mbdo					(scut_dat1_mbdo		),//input	[ 7: 0]			
		.scut_dat2_mbdo					(scut_dat2_mbdo		),//input	[ 7: 0]			
		.scut_dat3_mbdo					(scut_dat3_mbdo		),//input	[ 7: 0]			
//------------------------------------------------------------------------------
		.acks_fram_mbdo					(acks_fram_mbdo		),//input	[ 7: 0]			
		.acks_dat0_mbdo					(acks_dat0_mbdo		),//input	[ 7: 0]			
		.acks_dat1_mbdo					(acks_dat1_mbdo		),//input	[ 7: 0]			
		.acks_dat2_mbdo					(acks_dat2_mbdo		),//input	[ 7: 0]			
		.acks_dat3_mbdo					(acks_dat3_mbdo		),//input	[ 7: 0]			
//------------------------------------------------------------------------------
		.dlnk_fram_mbdo					(dlnk_fram_mbdo		),//input	[ 7: 0]			
		.dlnk_dat0_mbdo					(dlnk_dat0_mbdo		),//input	[ 7: 0]			
		.dlnk_dat1_mbdo					(dlnk_dat1_mbdo		),//input	[ 7: 0]			
		.dlnk_dat2_mbdo					(dlnk_dat2_mbdo		),//input	[ 7: 0]			
		.dlnk_dat3_mbdo					(dlnk_dat3_mbdo		),//input	[ 7: 0]	
//------------------------------------------------------------------------------
		.osde_sclk		,//output	
		.osde_fclk		,//input	
		.osde_rstn		);//input	



endmodule

 