module	edge_link_osde_lane(
	output								OSDE_OUTP_SBDO	,
  	
	input	[ 7: 0] 					OSDE_OUTP_MBDI	,
	input              					OSDE_FCKP		,// Differential clock from IOB
	input              					OSDE_FCKN		,// Differential clock from IOB
	input								OSDE_SCLK		,
	input              					OSDE_STRB		,// Differential clock from IOB
	input              					OSDE_RSTB		);
/**********************************************************************************************************************/
/**********************************************************************************************************************/
	wire 								cascade_ms_d	;
	wire 								cascade_ms_t	;
	wire 								cascade_sm_d	;
	wire 								cascade_sm_t	;
	wire 									;	

// declare the oserdes
	OSERDES2	#(
		.DATA_RATE_OQ   				("DDR"				),
        .DATA_RATE_OT   				("DDR"				),
        .TRAIN_PATTERN  				(0					),
        .DATA_WIDTH     				(8					),
        .SERDES_MODE    				("MASTER"			),
        .OUTPUT_MODE    				("SINGLE_ENDED"		))
    oserdes2_master     (
		.OQ         					(OSDE_OUTP_SBDO      	),
        
		.D1         					(OSDE_OUTP_MBDI[3] 	),
        .D2         					(OSDE_OUTP_MBDI[2] 	),
        .D3         					(OSDE_OUTP_MBDI[1] 	),
        .D4         					(OSDE_OUTP_MBDI[0] 	),
        .SHIFTIN3   					(cascade_sm_d		),
        .SHIFTIN4   					(cascade_sm_t		),
        .SHIFTOUT1  					(cascade_ms_d		),
        .SHIFTOUT2  					(cascade_ms_t		),
        .CLK0       					(OSDE_FCKP			),
        .CLK1       					(OSDE_FCKN			),
        .CLKDIV     					(OSDE_SCLK    		),
        .IOCE       					(OSDE_STRB   		),
        .RST        					(OSDE_RSTB       	),
		
		.SHIFTOUT3  					(					),
        .SHIFTOUT4  					(					),
        .TQ         					(               	),
        
		.TCE        					(1'B1           	),
		.T1         					(1'b0				),
        .T2         					(1'b0				),
        .T3         					(1'b0				),
        .T4         					(1'b0				),
        .SHIFTIN1   					(1'b1				),
        .SHIFTIN2   					(1'b1				),
        .TRAIN      					(1'b0				),
        .OCE        					(1'B1				));
//------------------------------------------------------------------------------
     OSERDES2	#(
		.DATA_RATE_OQ   				("DDR"				),
        .DATA_RATE_OT   				("DDR"				),
        .DATA_WIDTH     				(8					),
        .SERDES_MODE    				("SLAVE"			),
        .TRAIN_PATTERN  				(0					),
        .OUTPUT_MODE    				("SINGLE_ENDED"		))
    oserdes2_slave(
		.OQ         					(					),
        
		.D1         					(OSDE_OUTP_MBDI[7]	),
        .D2         					(OSDE_OUTP_MBDI[6]	),
        .D3         					(OSDE_OUTP_MBDI[5]	),
        .D4         					(OSDE_OUTP_MBDI[4]	),
        .SHIFTIN1   					(cascade_ms_d		),
        .SHIFTIN2   					(cascade_ms_t		),
        
		.SHIFTOUT1  					(					),
        .SHIFTOUT2  					(					),
        .TQ         					(					),
        
		.SHIFTOUT3  					(cascade_sm_d		),
        .SHIFTOUT4  					(cascade_sm_t		),
        .CLK0       					(OSDE_FCKP			),
        .CLK1       					(OSDE_FCKN			),
        .CLKDIV     					(OSDE_SCLK			),
        .IOCE       					(OSDE_STRB			),
        .RST        					(OSDE_RSTB			),
		
		.TCE        					(1'B1				),
        .T1         					(1'b0				),
        .T2         					(1'b0				),
        .T3         					(1'b0				),
        .T4         					(1'b0				),
        .SHIFTIN3   					(1'b1				),
        .SHIFTIN4   					(1'b1				),
        .TRAIN      					(1'b0				),
        .OCE        					(1'B1				));

endmodule


