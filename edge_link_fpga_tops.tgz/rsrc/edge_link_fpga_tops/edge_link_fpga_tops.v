
module  fpga_edge_link(
    output                          	edge_fclk_outp  ,
    output                          	edge_fclk_outn  ,
    output                          	edge_fram_outp  ,
    output                          	edge_fram_outn  ,
    output                          	edge_dat0_outp  ,
    output                          	edge_dat0_outn  ,
    output                          	edge_dat1_outp  ,
    output                          	edge_dat1_outn  ,
    output                          	edge_dat2_outp  ,
    output                          	edge_dat2_outn  ,
    output                          	edge_dat3_outp  ,
    output                          	edge_dat3_outn  ,

    input                           	edge_fclk_inpp  ,
    input                           	edge_fclk_inpn  ,
    input                           	edge_fram_inpp  ,
    input                           	edge_fram_inpn  ,
    input                           	edge_dat0_inpp  ,
    input                           	edge_dat0_inpn  ,
    input                           	edge_dat1_inpp  ,
    input                           	edge_dat1_inpn  ,
    input                           	edge_dat2_inpp  ,
    input                           	edge_dat2_inpn  ,
    input                           	edge_dat3_inpp  ,
    input                           	edge_dat3_inpn  ,
//------------------------------------------------------------------------------
    input                           	tpem_tune_txdo  ,
    input                           	tpem_tune_rxdi  ,
    input                           	tpem_rstn_inpp  ,
    output  reg                     	tpes_dftx_moni  ,
//------------------------------------------------------------------------------
	output								dvp0_vsyn_pado		,			
	output								dvp0_hsyn_pado		,
	output		[15: 0]					dvp0_data_pado		,
	output								dvp0_clko			,

	output								dvp1_vsyn_pado		,			
	output								dvp1_hsyn_pado		,
	output		[15: 0]					dvp1_data_pado		,
	output								dvp1_clko			,

	input								gmsl_vsyn_padi		,
	input								gmsl_hsyn_padi		,
	input		[15: 0]					gmsl_data_padi		,
	input								gmsl_clki			,

	output								cube_comm_gpio		,
	input		[ 1: 0]					cube_stat_gpio		,
	
    output                          	cube_uart_txdo		,
    input                           	cube_uart_rxdi		,

    output                         		cube_ispx_mode		,
    output                         		cube_ispx_rstn		,
    output                         		cube_chip_rstn		,
	output                          	cube_clko     		);
//------------------------------------------------------------
//	reg									tpes_sclk_cnts	= 0;
//
//	always@(posedge tpem_sclk)			tpes_sclk_cnts	<=   ~	tpes_sclk_cnts	;
//	always@(posedge tpem_sclk)			tpes_dftx_moni	<=		tpes_sclk_cnts	;
/**********************************************************************************************************/
    wire								osde_fclk  		;	
	wire                        	    dvpx_pclk       ;
    wire                        	    gnpu_bclk       ;

    wire       		                    isde_rstn       ;
    wire       		                    osde_rstn       ;
    wire       		                    gmsl_rstn       ;
	
    edge_link_fpga_mmcm				u_edge_link_fpga_mmcm(
        .osde_fclk                  	(osde_fclk    ),//output	200MHZ/
        .dvpx_pclk                  	(dvpx_pclk    ),//output	150MHZ//
		.dvp0_clko                  	(dvp0_clko    ),//output	150MHZ//
		.dvp1_clko                  	(dvp1_clko    ),//output	150MHZ//
		.gnpu_bclk                  	(cube_clko    ),//output
        
		.isde_rstn                  	(isde_rstn      ),//High Active//output	
        .osde_rstn                  	(osde_rstn      ),//High Active//output	
        .gmsl_rstn                  	(gmsl_rstn      ),//Low Active//output	

        .gmsl_clki                  	(gmsl_clki      ),//input
        .osde_sclk                  	(osde_sclk      ),//input	
        .isde_sclk                  	(isde_sclk      ),//input	
        .hubs_rstn                  	(tpem_rstn_inpp ));//input	
/***********************************************************************************************************/
//TPES LVDS TX_RX	LINK
	wire		[ 0: 9]					tpem_txdo_cmnd_mark		;
	wire								tpem_txdo_cmnd_lead		;
	wire								tpem_txdo_cmnd_wrcs		;
	wire								tpem_txdo_cmnd_coda		;
	wire		[31:0]					tpem_txdo_cmnd_word 	;

	wire								tpem_txdo_data_lead		;
	wire								tpem_txdo_data_wrcs		;
	wire		[31:0]					tpem_txdo_data_word 	;

	wire		[7:0]					tpes_scut_fram_mbdi 	;
	wire		[7:0]					tpes_scut_dat3_mbdi 	;
	wire		[7:0]					tpes_scut_dat2_mbdi 	;
	wire		[7:0]					tpes_scut_dat1_mbdi 	;
	wire		[7:0]					tpes_scut_dat0_mbdi 	;

	wire		[7:0]					soft_acks_fram_mbdi 	;
	wire		[7:0]					soft_acks_dat3_mbdi 	;
	wire		[7:0]					soft_acks_dat2_mbdi 	;
	wire		[7:0]					soft_acks_dat1_mbdi 	;
	wire		[7:0]					soft_acks_dat0_mbdi 	;

	wire		[7:0]					tpes_dlnk_fram_mbdi 	;
	wire		[7:0]					tpes_dlnk_dat3_mbdi 	;
	wire		[7:0]					tpes_dlnk_dat2_mbdi 	;
	wire		[7:0]					tpes_dlnk_dat1_mbdi 	;
	wire		[7:0]					tpes_dlnk_dat0_mbdi 	;

	edge_link_sdes_esse				u_edge_link_sdes_esse(
		.edge_tune_isde					(edge_tune_isde			),//input	
		.edge_tune_osde					(edge_tune_osde			),//input
//--------------------------------------
    	.edge_fclk_inpp					(edge_fclk_inpp			),//input	
    	.edge_fram_inpp					(edge_fram_inpp			),//input	
    	.edge_dat3_inpp					(edge_dat3_inpp			),//input	
    	.edge_dat2_inpp					(edge_dat2_inpp			),//input	
    	.edge_dat1_inpp					(edge_dat1_inpp			),//input	
    	.edge_dat0_inpp					(edge_dat0_inpp			),//input	

    	.edge_fclk_inpn					(edge_fclk_inpn			),//input	
    	.edge_fram_inpn					(edge_fram_inpn			),//input	
    	.edge_dat3_inpn					(edge_dat3_inpn			),//input	
    	.edge_dat2_inpn					(edge_dat2_inpn			),//input	
    	.edge_dat1_inpn					(edge_dat1_inpn			),//input	
    	.edge_dat0_inpn					(edge_dat0_inpn			),//input	

		.edge_fclk_outp					(edge_fclk_outp			),//output
		.edge_fram_outp					(edge_fram_outp			),//output
		.edge_dat0_outp					(edge_dat0_outp			),//output
		.edge_dat1_outp					(edge_dat1_outp			),//output
		.edge_dat2_outp					(edge_dat2_outp			),//output
		.edge_dat3_outp					(edge_dat3_outp			),//output

		.edge_fclk_outn					(edge_fclk_outn			),//output
		.edge_fram_outn					(edge_fram_outn			),//output
		.edge_dat3_outn					(edge_dat3_outn			),//output
		.edge_dat2_outn					(edge_dat2_outn			),//output
		.edge_dat1_outn					(edge_dat1_outn			),//output
		.edge_dat0_outn					(edge_dat0_outn			),//output
//--------------------------------------
		.isde_cmnd_mark					(tpem_txdo_cmnd_mark	),//output		[ 0: 9]	
		.isde_cmnd_lead					(tpem_txdo_cmnd_lead	),//output			
		.isde_cmnd_wrcs					(tpem_txdo_cmnd_wrcs	),//output			
		.isde_cmnd_coda					(tpem_txdo_cmnd_coda	),//output			
        .isde_cmnd_word 				(tpem_txdo_cmnd_word 	),//output	[31: 0] 

		.isde_data_lead					(tpem_txdo_data_lead	),//output			
		.isde_data_wrcs					(tpem_txdo_data_wrcs	),//output			
		.isde_data_word					(tpem_txdo_data_word	),//output	[31: 0]	

		.scut_fram_mbdo			 		(tpes_scut_fram_mbdi 	),//input		[ 7: 0]		
		.scut_dat3_mbdo			 		(tpes_scut_dat3_mbdi 	),//input		[ 7: 0]		
		.scut_dat2_mbdo			 		(tpes_scut_dat2_mbdi 	),//input		[ 7: 0]		
		.scut_dat1_mbdo			 		(tpes_scut_dat1_mbdi 	),//input		[ 7: 0]		
		.scut_dat0_mbdo			 		(tpes_scut_dat0_mbdi 	),//input		[ 7: 0]		
		
		.acks_fram_mbdo			 		(tpes_acks_fram_mbdi 	),//input		[ 7: 0]		
		.acks_dat3_mbdo			 		(tpes_acks_dat3_mbdi 	),//input		[ 7: 0]		
		.acks_dat2_mbdo			 		(tpes_acks_dat2_mbdi 	),//input		[ 7: 0]		
		.acks_dat1_mbdo			 		(tpes_acks_dat1_mbdi 	),//input		[ 7: 0]		
		.acks_dat0_mbdo			 		(tpes_acks_dat0_mbdi 	),//input		[ 7: 0]		
		
		.dlnk_fram_mbdo 				(tpes_dlnk_fram_mbdi 	),//input		[ 7: 0]		
		.dlnk_dat3_mbdo 				(tpes_dlnk_dat3_mbdi 	),//input		[ 7: 0]		
		.dlnk_dat2_mbdo 				(tpes_dlnk_dat2_mbdi 	),//input		[ 7: 0]		
		.dlnk_dat1_mbdo 				(tpes_dlnk_dat1_mbdi 	),//input		[ 7: 0]		
		.dlnk_dat0_mbdo 				(tpes_dlnk_dat0_mbdi 	),//input		[ 7: 0]		
//--------------------------------------
		.isde_sclk						(isde_sclk				),//input  		
		.osde_sclk						(osde_sclk				),//input  					
		.osde_fclk						(osde_fclk				),//input  					
		.isde_rstn						(isde_rstn				),//input  					
		.osde_rstn						(osde_rstn				));//input  					
/***********************************************************************************************************/
	wire		[19: 0]					cube_link_xdat_rows	;
	wire		[19: 0]					cube_link_xdat_cols	;

	wire		[ 1: 0]					dvpx_txdo_port_enab	;
	wire		[ 1: 0]					dvpx_comm_port_stat	;

	wire		[ 3: 0]					dvpx_cmnd_memo_indx	;
	wire		[31: 0]					dvpx_cmnd_memo_data	;

	wire		[ 3: 0]					gmsl_resp_memo_indx	;
	wire		[31: 0]					gmsl_resp_memo_word	;

	wire		[ 3: 0]					cube_gmsl_argu_selx	;

	wire		[ 6: 0]					cube_link_misc_cmnd	; 

	wire								tpes_link_test_stat	;
	
	edge_rv32_ctrl_tops				u_edge_rv32_ctrl_tops(
		.tpes_link_test_stat			(tpes_link_test_stat	),

		.cube_uart_txdo_port			(cube_uart_txdo			),//output						
		.cube_uart_rxdi_port			(cube_uart_rxdi			),//input						

		.cube_ispx_mode_csen			(cube_ispx_mode			),//output	
		.cube_ispx_mode_rstn			(cube_ispx_rstn			),//output	
		.cube_chip_cold_rstn			(cube_chip_rstn			),//output	

		.tpes_soft_acks_fram			(tpes_acks_fram_mbdi 	),//output		[ 7: 0]   
		.tpes_soft_acks_dat3			(tpes_acks_dat3_mbdi 	),//output		[ 7: 0]   
		.tpes_soft_acks_dat2			(tpes_acks_dat2_mbdi 	),//output		[ 7: 0]   
		.tpes_soft_acks_dat1			(tpes_acks_dat1_mbdi 	),//output		[ 7: 0]   
		.tpes_soft_acks_dat0			(tpes_acks_dat0_mbdi 	),//output		[ 7: 0]   

		.tpem_link_cmnd_mark			(tpem_txdo_cmnd_mark	),//input		[ 0: 9]	
		.tpem_link_cmnd_lead			(tpem_txdo_cmnd_lead	),//input				
		.tpem_link_cmnd_wrcs			(tpem_txdo_cmnd_wrcs	),//input				
		.tpem_link_cmnd_coda			(tpem_txdo_cmnd_coda	),//input				
		.tpem_link_cmnd_data			(tpem_txdo_cmnd_word	),//input		[31:0]	

		.cube_link_xdat_rows			(cube_link_xdat_rows	),//output		[19: 0]	
		.cube_link_xdat_cols			(cube_link_xdat_cols	),//output		[19: 0]	
	
		.dvpx_comm_port_enab			(dvpx_txdo_port_enab	),//output		[1: 0]	
		.dvpx_comm_port_stat			(dvpx_comm_port_stat	),//input		[1: 0]	
		
		.dvpx_cmnd_memo_indx			(dvpx_cmnd_memo_indx	),//input		[3: 0]	
		.dvpx_cmnd_memo_data			(dvpx_cmnd_memo_data	),//output		[31: 0]	
	
		.gmsl_resp_memo_indx			(gmsl_resp_memo_indx	),//output		[ 3: 0]	
		.gmsl_resp_memo_word			(gmsl_resp_memo_word	),//input		[31: 0]	

		.cube_acks_argu_selx			(cube_gmsl_argu_selx	),//output		[ 3: 0]	
		.cube_link_misc_cmnd			(cube_link_misc_cmnd	),	
		.cube_link_cfig_reqs			(cube_link_cfig_reqs	),//output	
		.cube_link_idat_reqs			(cube_link_idat_reqs	),//output	
		.cube_link_odat_reqs			(cube_link_odat_reqs	),//output	
		
		.cube_link_cfig_done			(cube_link_cfig_done	),//input	
		.cube_link_idat_done			(cube_link_idat_done	),//input	
		.cube_link_odat_done			(cube_link_odat_done	),//input	

		.isde_sclk						(isde_sclk				),//input				
		.isde_rstn						(isde_rstn				),//input				
		.osde_sclk						(osde_sclk				),//input				
		.osde_rstn						(osde_rstn				));//input				
/**********************************************************************************************************/	
//CUBE DVPX GMSL LINK
//	wire							dvp1_test_stat	;
//	assign	tpes_dftx_moni	=		dvp1_test_stat	;

    edge_link_dvpx_gmsl				u_cube_link_dvpx_gmsl(
		.gmsl_vsyn_padi					(gmsl_vsyn_padi			),//input				
		.gmsl_hsyn_padi					(gmsl_hsyn_padi			),//input				
		.gmsl_data_padi					(gmsl_data_padi			),//input		[15: 0]	
		.gmsl_clki						(gmsl_clki				),//input				

		.dvp0_vsyn_pado					(dvp0_vsyn_pado			),//output	reg				
		.dvp0_hsyn_pado					(dvp0_hsyn_pado			),//output	reg				
		.dvp0_data_pado					(dvp0_data_pado			),//output	reg	[15: 0]		
		
		.dvp1_vsyn_pado					(dvp1_vsyn_pado			),//output	reg				
		.dvp1_hsyn_pado					(dvp1_hsyn_pado			),//output	reg				
		.dvp1_data_pado					(dvp1_data_pado			),//output	reg	[15: 0]		

		.tpem_link_odat_lead			(tpem_txdo_data_lead	),//input			
		.tpem_link_odat_wrcs			(tpem_txdo_data_wrcs	),//input			
		.tpem_link_odat_word			(tpem_txdo_data_word	),//input	[31: 0]	
		
		.cube_link_dvpx_enab			(dvpx_txdo_port_enab	),
		.cube_link_stat_gpio			(cube_stat_gpio			),//input		[ 1: 0]	
		.cube_link_comm_gpio			(cube_comm_gpio			),//output				
		.cube_link_comm_stat			(dvpx_comm_port_stat	),//output		[ 1: 0]	

		.flow_resp_fram_mbdo			(tpes_scut_fram_mbdi 	),//output		[ 7: 0]	
		.flow_resp_dat3_mbdo			(tpes_scut_dat3_mbdi 	),//output		[ 7: 0]	
		.flow_resp_dat2_mbdo			(tpes_scut_dat2_mbdi 	),//output		[ 7: 0]	
		.flow_resp_dat1_mbdo			(tpes_scut_dat1_mbdi 	),//output		[ 7: 0]	
		.flow_resp_dat0_mbdo			(tpes_scut_dat0_mbdi 	),//output		[ 7: 0]	

		.cube_gmsl_fram_mbdo			(tpes_dlnk_fram_mbdi	),//output		[ 7: 0]	
		.cube_gmsl_dat3_mbdo			(tpes_dlnk_dat3_mbdi	),//output		[ 7: 0]	
		.cube_gmsl_dat2_mbdo			(tpes_dlnk_dat2_mbdi	),//output		[ 7: 0]	
		.cube_gmsl_dat1_mbdo			(tpes_dlnk_dat1_mbdi	),//output		[ 7: 0]	
		.cube_gmsl_dat0_mbdo			(tpes_dlnk_dat0_mbdi	),//output		[ 7: 0]	

		.cube_link_misc_cmnd			(cube_link_misc_cmnd	),	
		.cube_link_cfig_reqs			(cube_link_cfig_reqs	),//output	
		.cube_link_idat_reqs			(cube_link_idat_reqs	),//output	
		.cube_link_odat_reqs			(cube_link_odat_reqs	),//output	
		.cube_link_cfig_done			(cube_link_cfig_done	),//input	
		.cube_link_idat_done			(cube_link_idat_done	),//input	
		.cube_link_odat_done			(cube_link_odat_done	),//input	


		.cube_link_cmnd_indx			(dvpx_cmnd_memo_indx	),//output	[ 3: 0]	
		.cube_link_cmnd_word			(dvpx_cmnd_memo_data	),//input	[31: 0]	

		.cube_gmsl_resp_indx			(gmsl_resp_memo_indx	),//input	[ 3: 0]	
		.cube_gmsl_resp_word			(gmsl_resp_memo_word	),//output	[31: 0]	

		.cube_gmsl_argu_selx			(cube_gmsl_argu_selx	),//input	[ 3: 0]	

		.cube_link_xdat_rows			(cube_link_xdat_rows	),//input	[19: 0]	
		.cube_link_xdat_cols			(cube_link_xdat_cols	),//input	[19: 0]	

		.dvpx_pclk						(dvpx_pclk				),//input	
		.osde_sclk						(osde_sclk				),//input	
		.osde_rstn						(osde_rstn				));//input	

endmodule
 