module	edge_link_fpga_mmcm(
	output								osde_fclk		,
	output								dvpx_pclk		,
	output								dvp0_clko		,
	output								dvp1_clko		,
	output	reg							gnpu_bclk		,
	
	output								isde_rstn		,
	output								osde_rstn		,
	output								gmsl_rstn		,

	input								gmsl_clki		,//input < 	100Mhz	
	input								osde_sclk		,//input 	050Mhz	
	input								isde_sclk		,//input 	075Mhz	
	input								hubs_rstn		);
/**********************************************************************************************************************/
	wire								osde_fclk		;
	wire								dvpx_pclk		;

	wire								mmcm_lock		;
	wire								mmcm_rstn		;

	MMCM_EDGE		          	  	u_MMCM_EDGE(
        .mmcm_200m	            	    (osde_fclk	),
        .mmcm_150m           	      	(dvpx_pclk	),
        
        .mmcm_lock	          	      	(mmcm_lock	),
		.mmcm_clki	          	      	(isde_sclk	),//input         
		.mmcm_rstb	          	      	(~mmcm_rstn	));
/**********************************************************************************************************************/
	wire	mixs_rstn	= 	hubs_rstn &	mmcm_lock		;
//------------------------------------------------------------------------------
	gens_sync_rstn					u_gens_mmcm_rstn(
    	.rstn_gens						(mmcm_rstn			), //output		
		.main_clki						(isde_sclk			), //75Mhz
		.rstn_reqs						(hubs_rstn			));//input
//------------------------------------------------------------------------------
	gens_sync_rstn					u_gens_isde_rstn(
    	.rstn_gens						(isde_rstn			), //output		
		.main_clki						(isde_sclk			), //75Mhz
		.rstn_reqs						(mixs_rstn			));//input
//------------------------------------------------------------------------------
	gens_sync_rstn					u_gens_gmsl_rstn(
    	.rstn_gens						(gmsl_rstn			), //output		
		.main_clki						(gmsl_clki			), //80MHz
		.rstn_reqs						(mixs_rstn			));//input		
//------------------------------------------------------------------------------
	gens_sync_rstn					u_gens_core_rstn(
    	.rstn_gens						(osde_rstn			), //output		
		.main_clki						(osde_sclk			), //50MHz
		.rstn_reqs						(mixs_rstn			));//input		

/**********************************************************************************************************************/
	always@(posedge osde_sclk or negedge osde_rstn)
	if(osde_rstn)						gnpu_bclk	<=	0			;
	else								gnpu_bclk	<= ~gnpu_bclk	;
/**********************************************************************************************************************/
	ODDR2 #(
    	.DDR_ALIGNMENT       			("C0"       ),
    	.INIT                			(1'b0       ),
    	.SRTYPE              			("ASYNC"    ))
	u_dvp0_clko (
		.Q								(dvp0_clko			),	// 1-bit output: Data output to IOB
		.D0								(1'B0				),	// 1-bit input: Parallel data input 1
		.D1								(1'B1				),	// 1-bit input: Parallel data input 2
		.C0								( dvpx_pclk			),	// 1-bit input: High-speed clock input
		.C1								(~dvpx_pclk			),	// 1-bit input: High-speed clock input
    	.CE             				(1'b1     			),
    	.S              				(1'b0     			),
		.R 								(1'B0				)); // 1-bit input: Active-High Async Reset
/**********************************************************************************************************************/
	ODDR2 #(
    	.DDR_ALIGNMENT       			("C0"       ),
    	.INIT                			(1'b0       ),
    	.SRTYPE              			("ASYNC"    ))
	u_dvp1_clko (
		.Q								(dvp1_clko			),	// 1-bit output: Data output to IOB
		.D0								(1'B0				),	// 1-bit input: Parallel data input 1
		.D1								(1'B1				),	// 1-bit input: Parallel data input 2
		.C0								( dvpx_pclk			),	// 1-bit input: High-speed clock input
		.C1								(~dvpx_pclk			),	// 1-bit input: High-speed clock input
    	.CE             				(1'b1     			),
    	.S              				(1'b0     			),
		.R 								(1'B0				)); // 1-bit input: Active-High Async Reset
/******************************************************************************/
endmodule

/**********************************************************************************************************************/
module	MMCM_EDGE(  
  	output        						mmcm_200m	,
	output        						mmcm_150m	,
  						
  	output        						mmcm_lock	,
	input         						mmcm_clki	,	//75Mhz
  	input         						mmcm_rstb	);
//------------------------------------------------------------------------------
	wire        						mmcm_fdbk_o	;
	wire        						mmcm_fdbk_i	;

	wire								mmcm_200m_w	;
	wire								mmcm_150m_w	;
	

  	PLL_BASE	#(
		.BANDWIDTH              		("HIGH"					),
    	.CLK_FEEDBACK           		("CLKFBOUT"				),
    	.COMPENSATION           		("SYSTEM_SYNCHRONOUS"	),
    	.CLKIN_PERIOD           		(13.333					),	//75Mhz 
    	.REF_JITTER             		(0.001					),
		.DIVCLK_DIVIDE          		(1						),
    	.CLKFBOUT_MULT          		(8						),	//75Mhz * 8 = 600mhz
    	.CLKFBOUT_PHASE         		(0.000					),

    	.CLKOUT0_DIVIDE         		(3						),	//200Mhz
    	.CLKOUT0_PHASE          		(0.000					),
    	.CLKOUT0_DUTY_CYCLE     		(0.500					),

    	.CLKOUT1_DIVIDE         		(4						),	//150Mhz
    	.CLKOUT1_PHASE          		(0.000					),
    	.CLKOUT1_DUTY_CYCLE     		(0.500					))
  	
	MMCM_PLLB(
		.CLKFBOUT              			(mmcm_fdbk_o			),
		.CLKFBIN						(mmcm_fdbk_i			),
    
    	.CLKOUT0               			(mmcm_200m_w			),
    	.CLKOUT1               			(mmcm_150m_w			),
    	.CLKOUT2               			(						),
    	.CLKOUT3               			(						),
    	.CLKOUT4               			(						),
    	.CLKOUT5               			(						),
    
		.LOCKED                			(mmcm_lock				),
    	.CLKIN                 			(mmcm_clki				),
		.RST                   			(mmcm_rstb				));
/**********************************************************************************************************************/

  // Output buffering
  //-----------------------------------
  	BUFG 							u_MMCM_CKFB_BUFG(
		.O 								(mmcm_fdbk_i			),
  		.I 								(mmcm_fdbk_o			));

  	BUFG 							u_MMCM_200M_BUFG(
   		.O   							(mmcm_200m				),
    	.I   							(mmcm_200m_w			));
		
  	BUFG 							u_MMCM_150M_BUFG(
   		.O   							(mmcm_150m		),
    	.I   							(mmcm_150m_w	));

endmodule

module	gens