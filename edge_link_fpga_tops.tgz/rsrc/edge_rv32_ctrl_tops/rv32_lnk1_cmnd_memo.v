/***********************************************************************************************************
WORD_00	:	TPEM_LINK_CMND_STAT
***********************************************************************************************************/

module	rv32_lnk1_cmnd_memo(
	output		[ 31:0 ]				rv32_tpes_link_rout	,
	input								rv32_tpes_link_csen	,
	input		[  3:0 ]				rv32_tpes_link_addr	,
//-------------------------------------------------------
	input								tpem_link_cmnd_lead	,
	input								tpem_link_cmnd_wrcs	,
	input		[31: 0]					tpem_link_cmnd_data	,
//-------------------------------------------------------
	output		[19: 0]					cube_link_xdat_rows	,
	output		[19: 0]					cube_link_xdat_cols	,
	output		[31: 0]					cube_link_dvpx_dest	,
//-------------------------------------------------------
	input		[3: 0]					dvpx_cmnd_memo_indx	,
	output		[31: 0]					dvpx_cmnd_memo_data	,
//-------------------------------------------------------
	input								isde_sclk			,
	input								isde_rstn			);
/**********************************************************************************************************/
	reg			[ 3:0]					tpem_cmnd_memo_wadd	;
	reg			[31:0]					tpem_cmnd_memo_cell	[0:8]	;

	always@(posedge isde_sclk or negedge isde_rstn)
	if(~isde_rstn)						tpem_cmnd_memo_wadd	<=	0	;
	else if(tpem_link_cmnd_lead)		tpem_cmnd_memo_wadd	<=	0	;
	else if(tpem_link_cmnd_wrcs)		tpem_cmnd_memo_wadd	<=	tpem_cmnd_memo_wadd + 1	;
/**********************************************************************************************************/
	wire		[ 0:8]					tpem_cmnd_memo_wrid	;
	wire		[ 0:8]					rv32_cmnd_memo_rdid	;
	wire		[ 0:8]					dvpx_cmnd_memo_rdid	;
	
genvar i	;
generate
	for(i = 0 ; i < 9 ; i = i + 1) begin	:	tpem_wrcs_cmnd_memo

		assign tpem_cmnd_memo_wrid[i]=&{tpem_cmnd_memo_wadd	==	i	,	tpem_link_cmnd_wrcs	};
		assign rv32_cmnd_memo_rdid[i]=&{rv32_tpes_link_addr	==	i	};
		assign dvpx_cmnd_memo_rdid[i]=&{dvpx_cmnd_memo_indx	==	i	};

		always@(posedge isde_sclk or negedge isde_rstn)
		if(~isde_rstn)					tpem_cmnd_memo_cell[i]	<=	0	;
		else if(tpem_cmnd_memo_wrid[i])	tpem_cmnd_memo_cell[i]	<=	tpem_link_cmnd_data	;

	end
endgenerate	
/**********************************************************************************************************/
	assign	rv32_tpes_link_rout	=		rv32_cmnd_memo_rdid[0]	?	tpem_cmnd_memo_cell[0]	:
										rv32_cmnd_memo_rdid[1]	?	tpem_cmnd_memo_cell[1]	:
										rv32_cmnd_memo_rdid[2]	?	tpem_cmnd_memo_cell[2]	:
										rv32_cmnd_memo_rdid[3]	?	tpem_cmnd_memo_cell[3]	:
										rv32_cmnd_memo_rdid[4]	?	tpem_cmnd_memo_cell[4]	:
										rv32_cmnd_memo_rdid[5]	?	tpem_cmnd_memo_cell[5]	:
										rv32_cmnd_memo_rdid[6]	?	tpem_cmnd_memo_cell[6]	:
										rv32_cmnd_memo_rdid[7]	?	tpem_cmnd_memo_cell[7]	:
										rv32_cmnd_memo_rdid[8]	?	tpem_cmnd_memo_cell[8]	:	32'H0	;

	assign	dvpx_cmnd_memo_data	=		dvpx_cmnd_memo_rdid[0]	?	tpem_cmnd_memo_cell[1]	:
										dvpx_cmnd_memo_rdid[1]	?	tpem_cmnd_memo_cell[2]	:
										dvpx_cmnd_memo_rdid[2]	?	tpem_cmnd_memo_cell[3]	:
										dvpx_cmnd_memo_rdid[3]	?	tpem_cmnd_memo_cell[4]	:
										dvpx_cmnd_memo_rdid[4]	?	tpem_cmnd_memo_cell[5]	:
										dvpx_cmnd_memo_rdid[5]	?	tpem_cmnd_memo_cell[6]	:
										dvpx_cmnd_memo_rdid[6]	?	tpem_cmnd_memo_cell[7]	:
										dvpx_cmnd_memo_rdid[7]	?	tpem_cmnd_memo_cell[8]	:	32'H0	;
/**********************************************************************************************************/
	wire	[31: 0]	tpem_cmnd_memo_cel1=tpem_cmnd_memo_cell[1]	;
	wire	[31: 0]	tpem_cmnd_memo_cel3=tpem_cmnd_memo_cell[3]	;
	wire	[31: 0]	tpem_cmnd_memo_cel4=tpem_cmnd_memo_cell[4]	;
	
	assign	cube_link_xdat_rows	=		tpem_cmnd_memo_cel3[19:0]		;
	assign	cube_link_xdat_cols	=		tpem_cmnd_memo_cel4[19:0]		;
	assign	cube_link_dvpx_dest	=		tpem_cmnd_memo_cel1				;

endmodule

 