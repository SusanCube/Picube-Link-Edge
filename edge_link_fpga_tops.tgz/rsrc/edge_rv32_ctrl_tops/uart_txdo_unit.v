
module	uart_txdo_unit(
	output								uart_txdo_port	,
	output								uart_txdo_done	,
	input								uart_txdo_enab	,

	input		[11: 0]					uart_txdo_baud	,
	input								uart_txdo_drdy	,
	input		[31: 0]					uart_txdo_data	,

	input								osde_sclk		,
	input								osde_rstn		);
//********************************************************************************************************//
	reg		[ 3: 0]						uart_txdo_wadd	;
	
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						uart_txdo_wadd	<=	0	;
	else if(~uart_txdo_enab)			uart_txdo_wadd	<=	0	;
	else if( uart_txdo_drdy)			uart_txdo_wadd	<=	uart_txdo_wadd + 1	;
//********************************************************************************************************//
	reg		[ 2: 0]						uart_txdo_mfsm	;
		
	parameter	TXDO_PORT_IDLE	=	3'H0	;
	parameter	TXDO_WORD_LOAD	=	3'H1	;
	parameter	TXDO_BYTE_LOAD	=	3'H2	;
	parameter	TXDO_BYTE_SHFT	=	3'H3	;
	parameter	TXDO_BYTE_MUTE	=	3'H4	;
	parameter	TXDO_BYTE_DONE	=	3'H5	;
	
	wire	txdo_port_idle	=	uart_txdo_mfsm	==	TXDO_PORT_IDLE	;
	wire	txdo_word_load	=	uart_txdo_mfsm	==	TXDO_WORD_LOAD	;
	wire	txdo_byte_load	=	uart_txdo_mfsm	==	TXDO_BYTE_LOAD	;
	wire	txdo_byte_shft	=	uart_txdo_mfsm	==	TXDO_BYTE_SHFT	;
	wire	txdo_byte_mute	=	uart_txdo_mfsm	==	TXDO_BYTE_MUTE	;
	wire	txdo_byte_done	=	uart_txdo_mfsm	==	TXDO_BYTE_DONE	;
	
	wire								txdo_data_vlid	;
	wire								txdo_sbit_last	;
	wire								txdo_byte_last	;
	wire								txdo_mute_last	;

	wire								txdo_full_baud	;
	wire								txdo_half_baud	;
	
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						uart_txdo_mfsm	<=	TXDO_PORT_IDLE	;
	else if(~uart_txdo_enab)			uart_txdo_mfsm	<=	TXDO_PORT_IDLE	;
	else begin	
		case(uart_txdo_mfsm)		
			TXDO_PORT_IDLE	:			uart_txdo_mfsm	<=	txdo_data_vlid	?	TXDO_WORD_LOAD	:	TXDO_PORT_IDLE	;
			TXDO_WORD_LOAD	:			uart_txdo_mfsm	<=											TXDO_BYTE_LOAD	;
			TXDO_BYTE_LOAD	:			uart_txdo_mfsm	<=											TXDO_BYTE_SHFT	;
			TXDO_BYTE_SHFT	:			uart_txdo_mfsm	<=	txdo_sbit_last	?	TXDO_BYTE_MUTE	:	TXDO_BYTE_SHFT	;
			TXDO_BYTE_MUTE	:			uart_txdo_mfsm	<=	txdo_mute_last	?	TXDO_BYTE_DONE	:	TXDO_BYTE_MUTE	;
			TXDO_BYTE_DONE	:			uart_txdo_mfsm	<=	txdo_byte_last	?	TXDO_PORT_IDLE	:	TXDO_BYTE_LOAD	;

			default			:			uart_txdo_mfsm	<=											TXDO_PORT_IDLE	;
		endcase
	end		
//********************************************************************************************************//
	reg			[ 3: 0]					uart_txdo_radd	;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						uart_txdo_radd	<=	0	;
	else if(~uart_txdo_enab)			uart_txdo_radd	<=	0	;
	else if( txdo_word_load)			uart_txdo_radd	<=	uart_txdo_radd + 1	;

//********************************************************************************************************//
	wire		[31: 0]					txdo_memo_rout	;

	reg			[ 2: 0]					txdo_byte_indx	;
	reg			[31: 0]					txdo_word_buff	;

	assign	txdo_byte_last	=	txdo_byte_indx	==	2'H3	;
		
	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						txdo_byte_indx	<=	0	;
	else if(txdo_port_idle)				txdo_byte_indx	<=	0	;
	else if(txdo_word_load)				txdo_byte_indx	<=	0	;
	else if(txdo_byte_done)				txdo_byte_indx	<=	txdo_byte_indx + 1 ;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						txdo_word_buff	<=	0	;
	else if(txdo_port_idle)				txdo_word_buff	<=	0	;
	else if(txdo_word_load)				txdo_word_buff	<=	txdo_memo_rout	;

	wire		[9: 0]					txdo_byte_patn	;
	wire		[7: 0]					txdo_byte_sect	;	

	assign	txdo_byte_sect	=	txdo_byte_indx == 0	?	txdo_word_buff[ 7: 0]	:
								txdo_byte_indx == 1	?	txdo_word_buff[15: 8]	:
								txdo_byte_indx == 2	?	txdo_word_buff[23:16]	:	txdo_word_buff[31:24]	;
								
	assign	txdo_byte_patn	=	{		2'B10	,
										txdo_byte_sect[0] , txdo_byte_sect[1]	,txdo_byte_sect[2]	,txdo_byte_sect[3]	,
										txdo_byte_sect[4] , txdo_byte_sect[5]	,txdo_byte_sect[6]	,txdo_byte_sect[7]	};

//----------------------------------------------------------------------

	wire		[9: 0]					txdo_shft_patn	;
	reg			[9: 0]					txdo_byte_buff	;

	assign	txdo_shft_patn	=	{	txdo_byte_buff[8:0],	1'B1		};

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						txdo_byte_buff	<=	10'H3FF	;
	else if(txdo_port_idle)				txdo_byte_buff	<=	10'H3FF	;
	else if(txdo_word_load)				txdo_byte_buff	<=	10'H3FF	;
	else if(txdo_byte_load)				txdo_byte_buff	<=	txdo_byte_patn	;
	else if(txdo_byte_shft)				txdo_byte_buff	<=	txdo_full_baud	?	txdo_shft_patn	:	txdo_byte_buff	;

	assign	uart_txdo_port	=	txdo_byte_buff[9]	;
//----------------------------------------------------------------------
	reg			[ 3: 0]					txdo_sbit_cnts	;
	
	assign	txdo_sbit_last	=	txdo_sbit_cnts	==	4'HB	;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)						txdo_sbit_cnts	<=	4'H0	;
	else if(txdo_port_idle)				txdo_sbit_cnts	<=	4'H0	;
	else if(txdo_word_load)				txdo_sbit_cnts	<=	4'H0	;
	else if(txdo_byte_load)				txdo_sbit_cnts	<=	4'H0 	;	
	else if(txdo_byte_shft)				txdo_sbit_cnts	<=	txdo_sbit_cnts + txdo_half_baud	;	
//----------------------------------------------------------------------
	reg			[11: 0]					txdo_band_time	;

	wire		txdo_baud_clrs	= |{txdo_port_idle	,	txdo_word_load	,	
									txdo_byte_load	,	txdo_byte_done	};

	assign	txdo_full_baud	=		txdo_band_time	==		uart_txdo_baud	;
	assign	txdo_half_baud	=		txdo_band_time	=={1'b0,uart_txdo_baud[11:1]}	;
		

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					txdo_band_time	<=	12'H00	;
	else if( txdo_baud_clrs)		txdo_band_time	<=	12'H00	;
	else if(~txdo_full_baud)		txdo_band_time	<=	txdo_band_time + 1 	;
	else							txdo_band_time	<=	12'H00	;
//----------------------------------------------------------------------
	reg								txdo_mute_cnts	;

	always@(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					txdo_mute_cnts	<=	0					;
	else if(~txdo_byte_mute)		txdo_mute_cnts	<=	0					;
	else if( txdo_full_baud)		txdo_mute_cnts	<=	txdo_mute_cnts + 1 	;
	
	assign	txdo_mute_last	= &{	txdo_full_baud	,	txdo_mute_cnts		};
//********************************************************************************************************//
	wire		txdo_wadd_real	=	uart_txdo_wadd != 0	;
	wire		txdo_radd_real	=	uart_txdo_radd != 0	;

	assign		txdo_data_vlid	=&{	uart_txdo_wadd	>	uart_txdo_radd	,
									uart_txdo_enab	,	txdo_port_idle	};	

	assign		uart_txdo_done	= &{txdo_wadd_real	,	txdo_radd_real	,
									uart_txdo_wadd	==	uart_txdo_radd	,txdo_port_idle	};
//********************************************************************************************************//
	dual_port_bram	#(	.ADDR_BITS ( 4	), .DATA_BITS ( 32 ) )	
		u_uart_txdo_fifo(
		.wport_csen					(uart_txdo_drdy		),//input  				 		
		.wport_addr					(uart_txdo_wadd		),//input		[ADDR_BITS-1:0]	
		.wport_data					(uart_txdo_data		),//input		[DATA_BITS-1:0]	
		.wport_clki					(osde_sclk			),//input						

		.rport_addr					(uart_txdo_radd		),//input		[ADDR_BITS-1:0] 
		.rport_data					(txdo_memo_rout		),//output	reg	[DATA_BITS-1:0] 
		.rport_clki					(osde_sclk			));//input						


		
	

endmodule
 