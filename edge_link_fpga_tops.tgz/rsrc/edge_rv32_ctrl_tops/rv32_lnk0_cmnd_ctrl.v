/***********************************************************************************************************
WORD_00	:	TPEM_LINK_CMND_STAT
***********************************************************************************************************/

module	rv32_lnk0_cmnd_ctrl(
//-------------------------------------------------------
	output		[ 31:0 ]				rv32_tpes_link_rout	,
	input								rv32_tpes_link_csen	,
	input								rv32_tpes_link_wrcs	,
	input		[  3:0 ]				rv32_tpes_link_addr	,
	input		[ 31:0 ]				rv32_tpes_link_wdin	,
//-------------------------------------------------------
	output	reg	[ 7: 0]             	tpes_soft_acks_fram ,
	output	reg	[ 7: 0]             	tpes_soft_acks_dat3 ,
	output	reg	[ 7: 0]             	tpes_soft_acks_dat2 ,
	output	reg	[ 7: 0]             	tpes_soft_acks_dat1 ,
	output	reg	[ 7: 0]             	tpes_soft_acks_dat0 ,
//-------------------------------------------------------
	input		[ 0: 9]					tpem_link_cmnd_mark	,
	input								tpem_link_cmnd_coda	,
//-------------------------------------------------------
	output	reg	[ 3: 0]					cube_acks_argu_selx	,	
//-------------------------------------------------------
	output	reg							cube_ispx_mode_csen	,
	output	reg							cube_ispx_mode_rstn	,
	output	reg							cube_chip_cold_rstn	,
//-------------------------------------------------------
	input		[31: 0]					cube_link_dvpx_dest	,
	input		[1: 0]					dvpx_comm_port_stat	,
	output	reg	[1: 0]					dvpx_comm_port_enab	,
//-------------------------------------------------------
	input								cube_uart_txdo_done	,	
	output	reg							cube_uart_txdo_enab	,	
	output	reg							cube_uart_txdo_drdy	,
	output	reg	[31:0]					cube_uart_txdo_data	,

	output	reg	[11: 0]					cube_uart_baud_rate	,

	output	reg							cube_uart_rxdi_enab	,
	output	reg	[7: 0]					cube_uart_quiz_enab	,
	input		[7: 0]					cube_uart_quiz_stat	,
//-------------------------------------------------------
	output		[ 6: 0]					cube_link_misc_cmnd	,
	output								cube_link_cfig_reqs	,
	output								cube_link_idat_reqs	,
	output								cube_link_odat_reqs	,

	input								cube_link_cfig_done	,
	input								cube_link_idat_done	,
	input								cube_link_odat_done	,
//-------------------------------------------------------
	input								isde_sclk			,
	input								isde_rstn			,
	input								core_mclk			,//same as osde_sclk
	input								core_rstn			);
/**********************************************************************************************************************/
	wire		[ 0:15]					rv32_tpes_link_csid	;
	wire		[ 0:15]					rv32_tpes_link_wrid	;
		
	wire								rv32_tpes_link_wren	;
	assign	rv32_tpes_link_wren	= &{	rv32_tpes_link_csen	,	rv32_tpes_link_wrcs	};

	genvar m	;
generate
	for(m = 0 ; m <16 ; m = m + 1) begin	:	gens_tpes_rwcs_ctrl
		assign	rv32_tpes_link_csid[m]	= 	rv32_tpes_link_addr	==	m	;
		assign	rv32_tpes_link_wrid[m]	= &{rv32_tpes_link_wren	,	rv32_tpes_link_csid[m]	};
	end
endgenerate	
//------------------------------------------------------------------------------
	wire		[31:0]					tpes_misc_ctrl_wrd0	;//{	22'H0 ,	tpecube_uart_txdo_enabs_cmnd_mark_stat	};
	wire		[31:0]					tpes_misc_ctrl_wrd1	;//				tpes_soft_acks_data
	wire		[31:0]					tpes_misc_ctrl_wrd2	;//{ 	28'H0 ,	cube_acks_argu_selx	};
	wire		[31:0]					tpes_misc_ctrl_wrd3	;//{	31'H0 , cube_ispx_mode_csen	};
	wire		[31:0]					tpes_misc_ctrl_wrd4	;//{	30'H0 ,	cube_ispx_mode_rstn	,	cube_chip_cold_rstn	};	
	wire		[31:0]					tpes_misc_ctrl_wrd5	;//{	dvpx_comm_port_stat	,	28'H0 ,	dvpx_comm_port_enab	};	
	wire		[31:0]					tpes_misc_ctrl_wrd6	;//{	20'H0 ,	cube_uart_baud_rate	};	
	wire		[31:0]					tpes_misc_ctrl_wrd7	;//				cube_uart_txdo_data
	wire		[31:0]					tpes_misc_ctrl_wrd8	;//{	31'H0 ,	cube_uart_txdo_mpty	};	
	wire		[31:0]					tpes_misc_ctrl_wrd9	;//{	24'H0 ,	edge_uart_quiz_stat	};	
	wire		[31:0]					tpes_misc_ctrl_wrda	;//{	24'H0 ,	cube_misc_cmnd_stat	};	
	wire		[31:0]					tpes_misc_ctrl_wrdb	;//		tpes_ecos_link_cmnd		
	wire		[31:0]					tpes_misc_ctrl_wrdc	;//		tpes_ecos_stat_var1		
	wire		[31:0]					tpes_misc_ctrl_wrdd	;//		tpes_ecos_stat_var0		
	wire		[31:0]					tpes_misc_ctrl_wrde	;//		tpes_ecos_stat_var3		
	wire		[31:0]					tpes_misc_ctrl_wrdf	;//		tpes_ecos_stat_var4		
	
	assign	rv32_tpes_link_rout	=		rv32_tpes_link_csid[ 0]	?	tpes_misc_ctrl_wrd0	:
										rv32_tpes_link_csid[ 1]	?	tpes_misc_ctrl_wrd1	:
										rv32_tpes_link_csid[ 2]	?	tpes_misc_ctrl_wrd2	:
										rv32_tpes_link_csid[ 3]	?	tpes_misc_ctrl_wrd3	:
										rv32_tpes_link_csid[ 4]	?	tpes_misc_ctrl_wrd4	:
										rv32_tpes_link_csid[ 5]	?	tpes_misc_ctrl_wrd5	:
										rv32_tpes_link_csid[ 6]	?	tpes_misc_ctrl_wrd6	:
										rv32_tpes_link_csid[ 7]	?	tpes_misc_ctrl_wrd7	:
										rv32_tpes_link_csid[ 8]	?	tpes_misc_ctrl_wrd8	:
										rv32_tpes_link_csid[ 9]	?	tpes_misc_ctrl_wrd9	:	
										rv32_tpes_link_csid[10]	?	tpes_misc_ctrl_wrda	:	
										rv32_tpes_link_csid[11]	?	tpes_misc_ctrl_wrdb	:	
										rv32_tpes_link_csid[12]	?	tpes_misc_ctrl_wrdc	:	
										rv32_tpes_link_csid[13]	?	tpes_misc_ctrl_wrdd	:	
										rv32_tpes_link_csid[14]	?	tpes_misc_ctrl_wrde	:	
																	tpes_misc_ctrl_wrdf	;
/**********************************************************************************************************************/
/**********************************************************************************************************************/
//	TPEM LINK STATUS--ADDR:0
//		.link_rxdi_icfg_mark		(tpem_link_cmnd_mark[0 ]),//output	
//		.link_rxdi_ocfg_mark		(tpem_link_cmnd_mark[1 ]),//output	
//		.link_rxdi_nnex_mark		(tpem_link_cmnd_mark[2 ]),//output	
//		.link_rxdi_ivct_mark		(tpem_link_cmnd_mark[3 ]),//output	
//		.link_rxdi_ovct_mark		(tpem_link_cmnd_mark[4 ]),//output	
//		.link_rxdi_imtx_mark		(tpem_link_cmnd_mark[5 ]),//output	
//		.link_rxdi_omtx_mark		(tpem_link_cmnd_mark[6 ]),//output	
//		.link_rxdi_aset_mark		(tpem_link_cmnd_mark[7 ]),//output	
//		.link_rxdi_dnld_mark		(tpem_link_cmnd_mark[8 ]),//output	
//		.link_rxdi_boot_mark		(tpem_link_cmnd_mark[9 ]),//output	
	
	reg			[ 9: 0]					tpem_cmnd_mark_keep	;
	reg			[ 9: 0]					tpem_cmnd_mark_flag	;
	wire		[ 9: 0]					tpes_cmnd_mark_stat	;

	wire								rv32_cmnd_mark_clrs	=	rv32_tpes_link_wrid[0 ]	;

	assign	cube_link_misc_cmnd	=		tpem_cmnd_mark_flag[6:0]	;
	assign	tpes_misc_ctrl_wrd0	={22'H0,tpes_cmnd_mark_stat};

	gens_edge_slow_fast 			u_gens_cmnd_mark_clear(	
		.fast_edge   					(isde_cmnd_mark_clrs	),
		.fast_clki						(isde_sclk				),
		.fast_rstn						(isde_rstn				),

		.slow_sign						(rv32_cmnd_mark_clrs	),//input
		.slow_clki						(core_mclk				),//input
		.slow_rstn						(core_rstn				));//input

//------------------------------------------------------------------------------
	genvar i	;

generate
	for(i = 0 ; i < 10 ; i = i + 1 ) begin	:	gens_misc_mark_stat

		always@(posedge isde_sclk or negedge core_rstn)
		if(~core_rstn)					tpem_cmnd_mark_keep[i]	<=	0	;
		else if(rv32_cmnd_mark_clrs)	tpem_cmnd_mark_keep[i]	<=	0	;
		else if(tpem_link_cmnd_mark[i])	tpem_cmnd_mark_keep[i]	<=	1	;

		always@(posedge isde_sclk or negedge core_rstn)
		if(~core_rstn)					tpem_cmnd_mark_flag[i]	<=	0	;
		else if(rv32_cmnd_mark_clrs)	tpem_cmnd_mark_flag[i]	<=	0	;
		else if(tpem_link_cmnd_coda)	tpem_cmnd_mark_flag[i]	<=	tpem_cmnd_mark_keep[i]	;

		asyn_fast_sync_slow #(	.EXTN_MULT (3)	)	
			u_gens_tpes_mark_samp(	
				.slow_mark			(tpes_cmnd_mark_stat[i]	),//output	
				.slow_clrs			(rv32_cmnd_mark_clrs	),//input	
				.slow_clki			(core_mclk				),//input	
				.slow_rstn			(core_rstn				),//input	

				.fast_mark  		(tpem_cmnd_mark_flag[i]	),//input   
				.fast_clki			(isde_sclk				),//input	
				.fast_rstn			(core_rstn				));//input	
	end
endgenerate	
/**********************************************************************************************************************/
//	TPEM LINK SOFT ACKS--ADDR:1
	reg			[31:0]					tpes_soft_acks_data	;
	reg									tpes_txdo_acks_sync	;
	reg									tpes_txdo_acks_issu	;
	reg									tpes_txdo_acks_argu	;

	assign	tpes_misc_ctrl_wrd1	= 		tpes_soft_acks_data	;
//------------------------------------------------------------------------------
	wire	tpes_txdo_acks_reqs	=	&{ ~rv32_tpes_link_wrid[1], tpes_txdo_acks_sync	};

	always@(posedge core_mclk or negedge core_rstn )
	if(~core_rstn)						tpes_txdo_acks_sync	<=	0	;	
	else 								tpes_txdo_acks_sync	<=	rv32_tpes_link_wrid[1]	;	

	always@(posedge core_mclk or negedge core_rstn )
	if(~core_rstn)						tpes_txdo_acks_issu	<=	0	;	
	else 								tpes_txdo_acks_issu	<=	tpes_txdo_acks_reqs	;	
	
	always@(posedge core_mclk or negedge core_rstn )
	if(~core_rstn)						tpes_txdo_acks_argu	<=	0	;	
	else 								tpes_txdo_acks_argu	<=	tpes_txdo_acks_issu	;	

	always@(posedge core_mclk or negedge core_rstn )
	if(~core_rstn)						begin
		tpes_soft_acks_fram	<=	8'H00	;				
		tpes_soft_acks_dat3	<=	8'H00	;				
		tpes_soft_acks_dat2	<=	8'H00	;				
		tpes_soft_acks_dat1	<=	8'H00	;				
		tpes_soft_acks_dat0	<=	8'H00	;				
	end else if(tpes_txdo_acks_issu)	begin
		tpes_soft_acks_fram	<=	8'HFF	;				
		tpes_soft_acks_dat3	<=	8'H41	;				
		tpes_soft_acks_dat2	<=	8'H43	;				
		tpes_soft_acks_dat1	<=	8'H4B	;				
		tpes_soft_acks_dat0	<=	8'H53	;				
	end else if(tpes_txdo_acks_argu)	begin
		tpes_soft_acks_fram	<=	8'HFF	;				
		tpes_soft_acks_dat3	<=	tpes_soft_acks_data	[31:24];				
		tpes_soft_acks_dat2	<=	tpes_soft_acks_data	[23:16];				
		tpes_soft_acks_dat1	<=	tpes_soft_acks_data	[15: 8];				
		tpes_soft_acks_dat0	<=	tpes_soft_acks_data	[ 7: 0];				
	end else 							begin
		tpes_soft_acks_fram	<=	8'H00	;				
		tpes_soft_acks_dat3	<=	8'H00	;				
		tpes_soft_acks_dat2	<=	8'H00	;				
		tpes_soft_acks_dat1	<=	8'H00	;				
		tpes_soft_acks_dat0	<=	8'H00	;				
	end
/**********************************************************************************************************************/
//	CUBE ACKS ARGU SELX--ADDR:2
	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_acks_argu_selx	<=	0	;
	else if(rv32_tpes_link_wrid[2])		cube_acks_argu_selx	<=	rv32_tpes_link_wdin[3:0];

	assign	tpes_misc_ctrl_wrd2	={ 	28'H0 ,	cube_acks_argu_selx	};
/**********************************************************************************************************************/
//	CUBE ISP MODE CTRL--ADDR:3
	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_ispx_mode_csen	<=	0	;
	else if(rv32_tpes_link_wrid[3])		cube_ispx_mode_csen	<=	0	;//	rv32_tpes_link_wdin[0]	;

	assign	tpes_misc_ctrl_wrd3	= {	31'H0 , cube_ispx_mode_csen	};
/**********************************************************************************************************************/
//	CUBE  RESET_N CTRL--ADDR:4
	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_ispx_mode_rstn	<=	0	;
	else if(rv32_tpes_link_wrid[4])		cube_ispx_mode_rstn	<=	rv32_tpes_link_wdin[1]	;

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_chip_cold_rstn	<=	0	;
	else if(rv32_tpes_link_wrid[4])		cube_chip_cold_rstn	<=	rv32_tpes_link_wdin[0]	;

	assign	tpes_misc_ctrl_wrd4	= {	30'H0	,	cube_ispx_mode_rstn	,	cube_chip_cold_rstn	};	
/**********************************************************************************************************************/
//	CUBE  DVPX PORT ENAB--ADDR:5
	wire								cube_misc_enab_dvpx	;	
	wire								cube_misc_cmnd_done	;	

	wire	cube_issu_dvp0_port	=		cube_link_dvpx_dest	==	32'H3	;
	wire	cube_issu_dvp1_port	=		cube_link_dvpx_dest	==	32'H4	;
	wire	cube_issu_dvpd_port	=		cube_link_dvpx_dest	==	32'H5	;


	assign	cube_misc_cmnd_done	=		cube_link_cfig_reqs	?	cube_link_cfig_done	:
										cube_link_idat_reqs	?	cube_link_idat_done	:
										cube_link_odat_reqs	?	cube_link_odat_done	: 0	;

	assign	cube_misc_enab_dvpx	= &{	rv32_tpes_link_wrid[10]	,|rv32_tpes_link_wdin[1:0] };
	
	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						dvpx_comm_port_enab	<=	0	;
	else if(rv32_tpes_link_wrid[5])		dvpx_comm_port_enab	<=	rv32_tpes_link_wdin[1:0]	;
	else if(cube_misc_cmnd_done   )		dvpx_comm_port_enab	<=	0	;
	else if(cube_misc_enab_dvpx   )		dvpx_comm_port_enab	<=	cube_issu_dvpd_port	?	2'B11	:	
																cube_issu_dvp1_port	?	2'B10	:	2'B01	;
	
	assign	tpes_misc_ctrl_wrd5	= {		dvpx_comm_port_stat	,	28'H0 ,	dvpx_comm_port_enab	};	
/**********************************************************************************************************************/
//	CUBE  UART BAUD RATE--ADDR:6
	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_uart_baud_rate	<=	12'H15A	;//346
	else if(rv32_tpes_link_wrid[6])		cube_uart_baud_rate	<=	rv32_tpes_link_wdin[11:0]	;

	assign	tpes_misc_ctrl_wrd6	= {	20'H0 ,	cube_uart_baud_rate	};	
/**********************************************************************************************************************/
//	CUBE  UART TXDO ENAB--ADDR:7
	reg									cube_uart_txdo_wrcs	;

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_uart_txdo_data	<=	0	;
	else if(rv32_tpes_link_wrid[7])		cube_uart_txdo_data	<=	rv32_tpes_link_wdin	;

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_uart_txdo_wrcs	<=	0	;
	else								cube_uart_txdo_wrcs	<=	rv32_tpes_link_wrid[7]	;

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_uart_txdo_drdy	<=	0	;
	else								cube_uart_txdo_drdy	<=&{rv32_tpes_link_wrid[7]	, ~	cube_uart_txdo_wrcs	};

	assign	tpes_misc_ctrl_wrd7	= 	cube_uart_txdo_data	;	
/**********************************************************************************************************************/
//	CUBE  UART TXDO STAT--ADDR:8
	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_uart_txdo_enab	<=	0	;
	else if(rv32_tpes_link_wrid[8])		cube_uart_txdo_enab	<=	rv32_tpes_link_wdin[0];

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_uart_rxdi_enab	<=	0	;
	else if(rv32_tpes_link_wrid[8])		cube_uart_rxdi_enab	<=	rv32_tpes_link_wdin[1];

	assign	tpes_misc_ctrl_wrd8	= {		cube_uart_txdo_done	,	29'H0	,	
										cube_uart_rxdi_enab	,	cube_uart_txdo_enab	};	
/**********************************************************************************************************************/
//	CUBE  UART QUIZ STAT--ADDR:9
	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_uart_quiz_enab	<=	0	;
	else if(rv32_tpes_link_wrid[9])		cube_uart_quiz_enab	<=	rv32_tpes_link_wdin[7:0];

	assign	tpes_misc_ctrl_wrd9	= {	16'H0,cube_uart_quiz_enab ,	cube_uart_quiz_stat	};	
/**********************************************************************************************************************/
	reg			[1:0]					cube_misc_cmnd_ctrl	;
	reg									cube_misc_cmnd_stat	;

	
	assign	cube_link_cfig_reqs	=		cube_misc_cmnd_ctrl	==	2'H1	;
	assign	cube_link_odat_reqs	=		cube_misc_cmnd_ctrl	==	2'H2	;
	assign	cube_link_idat_reqs	=		cube_misc_cmnd_ctrl	==	2'H3	;

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_misc_cmnd_ctrl	<=	0	;
	else if(rv32_tpes_link_wrid[10])	cube_misc_cmnd_ctrl	<=	rv32_tpes_link_wdin[1:0];
	else if(cube_misc_cmnd_done	)		cube_misc_cmnd_ctrl	<=	0	;

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						cube_misc_cmnd_stat	<=	0	;
	else if(rv32_tpes_link_wrid[10])	cube_misc_cmnd_stat	<=	0	;
	else if(cube_misc_cmnd_done	)		cube_misc_cmnd_stat	<=	1	;

	assign	tpes_misc_ctrl_wrda	= {	31'H0,	cube_misc_cmnd_stat	};	
/**********************************************************************************************************************/
	reg			[31: 0]					tpes_ecos_link_cmnd	;
	assign	tpes_misc_ctrl_wrdb	= tpes_ecos_link_cmnd	;	
	
	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						tpes_ecos_link_cmnd	<=	0	;
	else if(rv32_tpes_link_wrid[11])	tpes_ecos_link_cmnd	<=	rv32_tpes_link_wdin	;
/**********************************************************************************************************************/
	reg			[31: 0]					tpes_ecos_time_cnts	;
	wire	tpes_time_cnts_zero	=		tpes_ecos_time_cnts	==	32'H0	;
	assign	tpes_misc_ctrl_wrdc	= 		tpes_ecos_time_cnts	;	

	reg			[9:0]					tpes_usec_time_cnts	;
	wire	tpes_usec_time_flag	=		tpes_usec_time_cnts	==	10'H27;//40 CLOCKS

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						tpes_usec_time_cnts	<=	0	;
	else if(tpes_usec_time_flag)		tpes_usec_time_cnts	<=	0	;
	else 								tpes_usec_time_cnts	<=	tpes_usec_time_cnts + 1	;

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						tpes_ecos_time_cnts	<=	0	;
	else if(rv32_tpes_link_wrid[12])	tpes_ecos_time_cnts	<=	rv32_tpes_link_wdin	;
	else if(~tpes_time_cnts_zero)		tpes_ecos_time_cnts	<=	tpes_ecos_time_cnts - tpes_usec_time_flag	;
/**********************************************************************************************************************/
	reg			[31: 0]					tpes_ecos_stat_var0	;
	reg			[31: 0]					tpes_ecos_stat_var1	;
	reg			[31: 0]					tpes_ecos_stat_var2	;

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						tpes_ecos_stat_var0	<=	0	;
	else if(rv32_tpes_link_wrid[13])	tpes_ecos_stat_var0	<=	rv32_tpes_link_wdin	;

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						tpes_ecos_stat_var1	<=	0	;
	else if(rv32_tpes_link_wrid[14])	tpes_ecos_stat_var1	<=	rv32_tpes_link_wdin	;

	always@(posedge core_mclk or negedge core_rstn)
	if(~core_rstn)						tpes_ecos_stat_var2	<=	0	;
	else if(rv32_tpes_link_wrid[15])	tpes_ecos_stat_var2	<=	rv32_tpes_link_wdin	;
	
	assign	tpes_misc_ctrl_wrdd	= 		tpes_ecos_stat_var0	;	
	assign	tpes_misc_ctrl_wrde	= 		tpes_ecos_stat_var1	;	
	assign	tpes_misc_ctrl_wrdf	= 		tpes_ecos_stat_var2	;	
/**********************************************************************************************************************/



	

endmodule

 