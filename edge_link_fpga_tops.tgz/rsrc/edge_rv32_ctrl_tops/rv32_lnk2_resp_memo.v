/***********************************************************************************************************
WORD_00	:	TPEM_LINK_CMND_STAT

***********************************************************************************************************/

module	rv32_lnk2_resp_memo(
	output		[ 31:0 ]			rv32_tpes_link_rout	,
	input							rv32_tpes_link_csen	,
	input		[  3:0 ]			rv32_tpes_link_addr	,
//-------------------------------------------------------
	output		[ 3: 0]				gmsl_resp_memo_indx	,
	input		[31: 0]				gmsl_resp_memo_word	);

/**********************************************************************************************************/
	assign	rv32_tpes_link_rout	=	gmsl_resp_memo_word	;
	assign	gmsl_resp_memo_indx	=	rv32_tpes_link_csen	?	rv32_tpes_link_addr	:	0	;
 
endmodule

 