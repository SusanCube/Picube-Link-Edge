
module	uart_rxdi_port	(
	input	[11: 0]						uart_baud_rate	,
	input								uart_rxdi_enab	,
	input								uart_rxdi_port	,
	output	reg							uart_rxdi_drdy	,	
	output	reg [ 7: 0]					uart_rxdi_data	,
	input								osde_sclk		,	
	input								osde_rstn		);
//********************************************************************************************************//
	reg		[ 2: 0]					uart_rxdi_samp		;
	wire	uart_rxdi_sdin		=	uart_rxdi_samp[0]	;	
	wire	uart_rxdi_rise		=	uart_rxdi_samp[1:0]	==	2'B10	;	
	wire	uart_rxdi_fall		=	uart_rxdi_samp[1:0]	==	2'B01	;	
	wire	uart_rxdi_xchg		= |{uart_rxdi_rise	,	uart_rxdi_fall	};
//----------------------------------------------------------------------
	always@(posedge osde_sclk or negedge osde_rstn  )
	if(~osde_rstn)					uart_rxdi_samp	<=	3'H7	;
	else if(~uart_rxdi_enab) 		uart_rxdi_samp	<=	3'H7	;
	else							uart_rxdi_samp	<= {uart_rxdi_port	,	uart_rxdi_samp[2:1]	};
//********************************************************************************************************//	
	reg		[ 1: 0]					uart_rxdi_mfsm	;
	reg		[ 2: 0]					uart_rxdi_bcnt	;

	parameter	UART_RXDI_IDLE	=	2'H0	;
	parameter	UART_RXDI_LEAD	=	2'H1	;
	parameter	UART_RXDI_SBIT	=	2'H2	;
	parameter	UART_RXDI_STOP	=	2'H3	;

	wire	rxdi_hits_idle	=	uart_rxdi_mfsm	==	UART_RXDI_IDLE	;
	wire	rxdi_hits_lead	=	uart_rxdi_mfsm	==	UART_RXDI_LEAD	;
	wire	rxdi_hits_sbit	=	uart_rxdi_mfsm	==	UART_RXDI_SBIT	;
	wire	rxdi_hits_stop	=	uart_rxdi_mfsm	==	UART_RXDI_STOP	;
//********************************************************************************************************//	

	reg		[11: 0]					uart_baud_time	;
	
	wire							uart_full_baud	;
	wire							uart_half_baud	;
	
	assign	uart_full_baud	=		uart_baud_time	==		uart_baud_rate			;
	assign	uart_half_baud	=		uart_baud_time	=={1'B0,uart_baud_rate[11: 1]	};
	
	always@(posedge osde_sclk or negedge osde_rstn  )
	if(~osde_rstn)					uart_baud_time	<=	12'B0	;
	else if(~uart_rxdi_enab) 		uart_baud_time	<=	12'B0	;
	else if( rxdi_hits_idle)		uart_baud_time	<=	12'B0	;
	else if( uart_full_baud)		uart_baud_time	<=	12'B0	;
	else							uart_baud_time	<=	uart_baud_time + 1	;
//----------------------------------------------------------------------
	reg			uart_good_lead		;
	reg			uart_byte_rdok		;

	always@(posedge osde_sclk or negedge osde_rstn  )
	if(~osde_rstn)					uart_good_lead	<=	0	;
	else if(~uart_rxdi_enab)		uart_good_lead	<=	0	;
	else if( rxdi_hits_lead&uart_half_baud )
									uart_good_lead	<= ~uart_rxdi_sdin	;


	wire	uart_good_stop	= &{	uart_rxdi_sdin , uart_full_baud	, rxdi_hits_stop	};
	wire	uart_full_sbit	= &{	uart_rxdi_bcnt , uart_half_baud , rxdi_hits_sbit	};

	always@(posedge osde_sclk or negedge osde_rstn  )
	if(~osde_rstn)					uart_byte_rdok	<=	0	;
	else if(~rxdi_hits_sbit)		uart_byte_rdok	<=	0	;
	else							uart_byte_rdok	<=	uart_full_sbit	;


	always@(posedge osde_sclk or negedge osde_rstn  )
	if(~osde_rstn)					uart_rxdi_bcnt	<=	0	;
	else if(~rxdi_hits_sbit)	uart_rxdi_bcnt	<=	0	;
	else if( uart_half_baud)		uart_rxdi_bcnt	<=	uart_rxdi_bcnt	+ 1	;
//----------------------------------------------------------------------
	always@(posedge osde_sclk or negedge osde_rstn  )
	if(~osde_rstn)					uart_rxdi_data	<=	0	;
	else if(rxdi_hits_idle)			uart_rxdi_data	<=	0	;
	else if(rxdi_hits_sbit&uart_half_baud)		uart_rxdi_data	<={ uart_rxdi_sdin	,	uart_rxdi_data[7:1]}	;	
	
	always@(posedge osde_sclk or negedge osde_rstn  )
	if(~osde_rstn)					uart_rxdi_drdy	<=	0	;
	else							uart_rxdi_drdy	<=	uart_byte_rdok	;
//----------------------------------------------------------------------
	always@(posedge osde_sclk or negedge osde_rstn  )
	if(~osde_rstn)					uart_rxdi_mfsm	<=	UART_RXDI_IDLE	;
	else if(~uart_rxdi_enab)		uart_rxdi_mfsm	<=	UART_RXDI_IDLE	;
	else begin
		case(uart_rxdi_mfsm)
			UART_RXDI_IDLE	:		uart_rxdi_mfsm	<=	uart_rxdi_fall	?	UART_RXDI_LEAD	:	UART_RXDI_IDLE	;

			UART_RXDI_LEAD	:		
				if(uart_full_baud)	uart_rxdi_mfsm	<=	uart_good_lead	? 	UART_RXDI_SBIT	:	UART_RXDI_IDLE	;
				else				uart_rxdi_mfsm	<=											UART_RXDI_LEAD	;

			UART_RXDI_SBIT	:		uart_rxdi_mfsm	<=	uart_byte_rdok	?	UART_RXDI_STOP	:	UART_RXDI_SBIT	;
			
			UART_RXDI_STOP	:		uart_rxdi_mfsm	<=	uart_full_baud	? 	UART_RXDI_IDLE	:	UART_RXDI_STOP	;
			default			:		uart_rxdi_mfsm	<=						UART_RXDI_IDLE	;	
		endcase
	end



endmodule	
