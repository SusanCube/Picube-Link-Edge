
module	uart_rxdi_unit(
	input								uart_rxdi_port		,
	input								uart_rxdi_enab		,
	input		[ 7: 0]					uart_quiz_enab		,
	output		[ 7: 0]					uart_quiz_stat		,		

	input		[11: 0]					uart_baud_rate		,

	input								osde_sclk			,
	input								osde_rstn			);
//********************************************************************************************************//
	wire		[7:0]					uart_rxdi_data		;

	uart_rxdi_port					u_uart_rxdi_port(
		.uart_rxdi_port					(uart_rxdi_port		),//input					
		.uart_rxdi_enab					(uart_rxdi_enab		),//input					

		.uart_baud_rate					(uart_baud_rate		),//input	[11: 0]			

		.uart_rxdi_drdy					(uart_rxdi_drdy		),//output	reg				
		.uart_rxdi_data					(uart_rxdi_data		),//output	reg [ 7: 0]		
		.tpes_clki						(osde_sclk			),//input					
		.osde_rstn						(osde_rstn			));//input					
//********************************************************************************************************//
	uart_rxdi_quiz					u_uart_rxdi_quiz(
		.uart_rxdi_drdy					(uart_rxdi_drdy		),
		.uart_rxdi_data					(uart_rxdi_data		),
		
		.uart_quiz_enab					(uart_quiz_enab		),
		.uart_quiz_stat					(uart_quiz_stat		),

		.osde_sclk						(osde_sclk			),//input			
		.osde_rstn						(osde_rstn			));//input			
		


endmodule




