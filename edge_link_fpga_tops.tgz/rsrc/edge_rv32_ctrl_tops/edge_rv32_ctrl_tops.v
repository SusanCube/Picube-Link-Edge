//**********************************************************************************************************
//
//	output		[24:0]				ecos_tpuc_ddrs_base	,
//	output		[ 7:0]				ecos_tpuc_tpem_port	,
//	output		[ 3:0]				ecos_tpuc_mgth_port	,
//**********************************************************************************************************
module	core_rv32_ctrl_tops			(
	output								cube_uart_txdo_port	,
	input								cube_uart_rxdi_port	,

	output								cube_ispx_mode_csen	,
	output								cube_ispx_mode_rstn	,
	output								cube_chip_cold_rstn	,

	output		[ 7: 0]             	tpes_soft_acks_fram ,
	output		[ 7: 0]             	tpes_soft_acks_dat3 ,
	output		[ 7: 0]             	tpes_soft_acks_dat2 ,
	output		[ 7: 0]             	tpes_soft_acks_dat1 ,
	output		[ 7: 0]             	tpes_soft_acks_dat0 ,

	input		[ 0: 9]					tpem_link_cmnd_mark	,
	input								tpem_link_cmnd_lead	,
	input								tpem_link_cmnd_wrcs	,
	input								tpem_link_cmnd_coda	,
	input		[31:0]					tpem_link_cmnd_data	,

	output		[19: 0]					cube_link_xdat_rows	,
	output		[19: 0]					cube_link_xdat_cols	,

	output		[1: 0]					dvpx_comm_port_enab	,
	input		[1: 0]					dvpx_comm_port_stat	,

	input		[3: 0]					dvpx_cmnd_memo_indx	,
	output		[31: 0]					dvpx_cmnd_memo_data	,

	output		[ 3: 0]					gmsl_resp_memo_indx	,
	input		[31: 0]					gmsl_resp_memo_word	,

	output		[ 3: 0]					cube_acks_argu_selx	,

	output		[ 6: 0]					cube_link_misc_cmnd	,
	output								cube_link_cfig_reqs	,
	output								cube_link_idat_reqs	,
	output								cube_link_odat_reqs	,

	input								cube_link_cfig_done	,
	input								cube_link_idat_done	,
	input								cube_link_odat_done	,

	input								isde_sclk			,
	input								isde_rstn			,
	input								osde_sclk			,
	input								osde_rstn			);
/**********************************************************************************************************/
	wire		         				rv32_link_tpec_csen		;
	wire		         				rv32_link_tpec_wrcs		;
	wire		 [ 7: 0] 				rv32_link_tpec_addr		;
	wire		 [31: 0] 				rv32_link_tpec_wdata	;
	reg			 [31: 0] 				rv32_link_tpec_rdata	;

	edge_rv32_core_tops				u_edge_rv32_core_tops(
    	.rv32_dtcm_csen  				(rv32_link_tpec_csen	),//output  reg         
    	.rv32_dtcm_wrcs  				(rv32_link_tpec_wrcs	),//output  reg         
    	.rv32_dtcm_addr  				(rv32_link_tpec_addr	),//output  reg [ 7: 0] 
    	.rv32_dtcm_wdata 				(rv32_link_tpec_wdata	),//output  reg [31: 0] 
    	.rv32_dtcm_rdata 				(rv32_link_tpec_rdata	),//input       [31: 0] 
    	.mclk            				(tpes_sclk				),//input               
    	.rstn       	    			(tpes_rstn				));//input               

	wire								rv32_tpes_link_csen		;
	wire								rv32_cmnd_memo_csen		;
	wire								rv32_resp_memo_csen		;

	wire		[31: 0]					rv32_tpes_link_rout		;
	wire		[31: 0]					rv32_cmnd_memo_rout		;
	wire		[31: 0]					rv32_resp_memo_rout		;

	wire		[ 3: 0]					rv32_link_tpec_lsba		;

	assign	rv32_link_tpec_lsba	=		rv32_link_tpec_addr[3:0];

	assign	rv32_tpes_link_csen	=&{		rv32_link_tpec_csen	,	rv32_link_tpec_addr[7:4]==4'H0	};
	assign	rv32_cmnd_memo_csen	=&{		rv32_link_tpec_csen	,	rv32_link_tpec_addr[7:4]==4'H1	};
	assign	rv32_resp_memo_csen	=&{		rv32_link_tpec_csen	,	rv32_link_tpec_addr[7:4]==4'H2	};

	always@(posedge tpes_sclk or negedge tpes_rstn)
	if(~tpes_rstn)						rv32_link_tpec_rdata	<=	0	;
	else 								rv32_link_tpec_rdata	<=	rv32_tpes_link_csen	?	rv32_tpes_link_rout	:
																	rv32_cmnd_memo_csen	?	rv32_cmnd_memo_rout	:
																	rv32_resp_memo_csen	?	rv32_resp_memo_rout	:	32'H0	;
/**********************************************************************************************************/
	wire		[ 7: 0]					cube_uart_quiz_stat	;
	wire		[ 7: 0]					cube_uart_quiz_enab	;
	wire								cube_uart_rxdi_enab	;
		
	wire								cube_uart_txdo_done	;
	wire								cube_uart_txdo_enab	;
	wire		[11: 0]					cube_uart_baud_rate	;
	wire								cube_uart_txdo_drdy	;
	wire		[31:0]					cube_uart_txdo_data	;
	
	wire		[31: 0]					cube_link_dvpx_dest	;


	rv32_lnk0_cmnd_ctrl				u_rv32_lnk0_cmnd_ctrl(
		.rv32_tpes_link_rout			(rv32_tpes_link_rout	),//output		[ 31:0 ]
		.rv32_tpes_link_csen			(rv32_tpes_link_csen	),//input				
		.rv32_tpes_link_addr			(rv32_link_tpec_lsba	),//input		[  3:0 ]
		.rv32_tpes_link_wrcs			(rv32_link_tpec_wrcs	),//input				
		.rv32_tpes_link_wdin			(rv32_link_tpec_wdata	),//input		[ 31:0 ]

		.tpes_soft_acks_fram 			(tpes_soft_acks_fram	),//output		[ 7: 0]   
		.tpes_soft_acks_dat3 			(tpes_soft_acks_dat3	),//output		[ 7: 0]   
		.tpes_soft_acks_dat2 			(tpes_soft_acks_dat2	),//output		[ 7: 0]   
		.tpes_soft_acks_dat1 			(tpes_soft_acks_dat1	),//output		[ 7: 0]   
		.tpes_soft_acks_dat0 			(tpes_soft_acks_dat0	),//output		[ 7: 0]   

		.tpem_link_cmnd_mark			(tpem_link_cmnd_mark	),//input		[ 0: 9]	
		.tpem_link_cmnd_coda			(tpem_link_cmnd_coda	),//input				

		.cube_ispx_mode_csen			(cube_ispx_mode_csen	),//output	reg			
		.cube_ispx_mode_rstn			(cube_ispx_mode_rstn	),//output	reg			
		.cube_chip_cold_rstn			(cube_chip_cold_rstn	),//output	reg			

		.cube_link_dvpx_dest			(cube_link_dvpx_dest	),
		.dvpx_comm_port_enab			(dvpx_comm_port_enab	),//output	reg	[1: 0]	
		.dvpx_comm_port_stat			(dvpx_comm_port_stat	),//output	reg	[1: 0]	

		.cube_uart_txdo_done			(cube_uart_txdo_done	),//output	reg	[11: 0]	
		.cube_uart_txdo_enab			(cube_uart_txdo_enab	),	//input				
		.cube_uart_txdo_drdy			(cube_uart_txdo_drdy	),//output	reg			
		.cube_uart_txdo_data			(cube_uart_txdo_data	),//output	reg	[31:0]	

		.cube_uart_baud_rate			(cube_uart_baud_rate	),//output	reg	[11: 0]	

		.cube_uart_rxdi_enab			(cube_uart_rxdi_enab	),//output	reg	[31:0]	
		.cube_uart_quiz_enab			(cube_uart_quiz_enab	),//output	reg	[31:0]	
		.cube_uart_quiz_stat			(cube_uart_quiz_stat	),//input		[ 7: 0]	

		.cube_acks_argu_selx			(cube_acks_argu_selx	),//output				

		.cube_link_misc_cmnd			(cube_link_misc_cmnd	),
		.cube_link_cfig_reqs			(cube_link_cfig_reqs	),//output	
		.cube_link_idat_reqs			(cube_link_idat_reqs	),//output	
		.cube_link_odat_reqs			(cube_link_odat_reqs	),//output	

		.cube_link_cfig_done			(cube_link_cfig_done	),//input	
		.cube_link_idat_done			(cube_link_idat_done	),//input	
		.cube_link_odat_done			(cube_link_odat_done	),//input	

		.isde_sclk						(isde_sclk				),//input				
		.isde_rstn						(isde_rstn				),//input				
		.osde_sclk						(osde_sclk				),//input				
		.osde_rstn						(osde_rstn				));//input				
/**********************************************************************************************************/
	rv32_lnk1_cmnd_memo				u_rv32_lnk1_cmnd_memo(
		.rv32_tpes_link_rout			(rv32_cmnd_memo_rout	),//output		[ 31:0 ]
		.rv32_tpes_link_csen			(rv32_cmnd_memo_csen	),//input				
		.rv32_tpes_link_addr			(rv32_link_tpec_lsba	),//input		[  3:0 ]

		.tpem_link_cmnd_lead			(tpem_link_cmnd_lead	),//input				
		.tpem_link_cmnd_wrcs			(tpem_link_cmnd_wrcs	),//input				
		.tpem_link_cmnd_data			(tpem_link_cmnd_data	),//input		[31: 0]	

		.cube_link_xdat_rows			(cube_link_xdat_rows	),//output		[19: 0]	
		.cube_link_xdat_cols			(cube_link_xdat_cols	),//output		[19: 0]	
		.cube_link_dvpx_dest			(cube_link_dvpx_dest	),

		.dvpx_cmnd_memo_indx			(dvpx_cmnd_memo_indx	),//input		[3: 0]	
		.dvpx_cmnd_memo_data			(dvpx_cmnd_memo_data	),//output		[31: 0]	
		.isde_sclk						(isde_sclk				),//input				
		.isde_rstn						(isde_rstn				));//input				
/**********************************************************************************************************/
	rv32_lnk2_resp_memo				u_rv32_lnk2_resp_memo(
		.rv32_tpes_link_rout			(rv32_resp_memo_rout	),//output		[ 31:0 ]	
		.rv32_tpes_link_csen			(rv32_resp_memo_csen	),//input					
		.rv32_tpes_link_addr			(rv32_link_tpec_lsba	),//input		[  3:0 ]	

		.gmsl_resp_memo_indx			(gmsl_resp_memo_indx	),//output		[ 3: 0]		
		.gmsl_resp_memo_word			(gmsl_resp_memo_word	));//input					
/**********************************************************************************************************/
	uart_txdo_unit					u_uart_txdo_unit(
		.uart_txdo_port					(cube_uart_txdo_port	),//output	reg			
		.uart_txdo_done					(cube_uart_txdo_done	),//output	reg			
		.uart_txdo_enab					(cube_uart_txdo_enab	),//input				
		.uart_txdo_baud					(cube_uart_baud_rate	),//input		[11: 0]	
		.uart_txdo_drdy					(cube_uart_txdo_drdy	),//input				
		.uart_txdo_data					(cube_uart_txdo_data	),//input		[31: 0]	
		.osde_sclk						(osde_sclk				),//input				
		.osde_rstn						(osde_rstn				));//input				

	uart_rxdi_unit					u_uart_rxdi_unit(
		.uart_rxdi_port					(cube_uart_rxdi_port	),//input				
		.uart_rxdi_enab					(cube_uart_rxdi_enab	),//input				
		.uart_quiz_enab					(cube_uart_quiz_enab	),//input		[ 7: 0]	
		.uart_quiz_stat					(cube_uart_quiz_stat	),//output		[ 7: 0]	
		.uart_baud_rate					(cube_uart_baud_rate	),//input		[11: 0]	
		.osde_sclk						(osde_sclk				),//input				
		.osde_rstn						(osde_rstn				));//input				


endmodule


	


















//		.ecos_link_port_enab		(ecos_link_port_enab	),//output		[ 7: 0]	
//		.ecos_mast_ddrs_base		(ecos_mast_ddrs_base	),//output		[24: 0]	
//		.ecos_slav_ddrs_base		(ecos_slav_ddrs_base	),//output		[24: 0]	

 