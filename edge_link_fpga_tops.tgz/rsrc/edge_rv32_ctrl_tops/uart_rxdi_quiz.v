
module	uart_rxdi_quiz(
	input								uart_rxdi_drdy		,
	input		[ 7: 0]					uart_rxdi_data		,

	input		[ 7: 0]					uart_quiz_enab		,//
	output		[ 7: 0]					uart_quiz_stat		,	

	input								osde_sclk			,//50MHZ
	input								osde_rstn			);
/**********************************************************************/
	wire	enab_ispm_entr_quiz =	uart_quiz_enab[0]	;
	wire	enab_ispm_down_quiz =	uart_quiz_enab[1]	;
	wire	enab_ispm_gook_quiz =	uart_quiz_enab[2]	;
	wire	enab_ispm_boot_quiz =	uart_quiz_enab[3]	;
	wire	enab_ddrs_init_quiz =	uart_quiz_enab[4]	;
	wire	enab_ddrs_scan_quiz =	uart_quiz_enab[5]	;
	wire	enab_ddr0_scan_quiz =	uart_quiz_enab[6]	;
	wire	enab_ddr1_scan_quiz =	uart_quiz_enab[7]	;
/**********************************************************************************************************/
	wire                  			quiz_ispm_entr_beok ;
	wire                  			quiz_ispm_down_beok ;
	wire                  			quiz_ispm_gook_beok ;
	wire                  			quiz_ispm_boot_beok ;
	wire                  			quiz_ddrs_init_beok ;
	wire                  			quiz_ddrs_scan_beok ;
	wire                  			quiz_ddr0_scan_fail	;
	wire                  			quiz_ddr1_scan_fail	;

	assign	uart_quiz_stat	=	{	quiz_ddr1_scan_fail	,
									quiz_ddr0_scan_fail ,		
									quiz_ddrs_scan_beok ,
									quiz_ddrs_init_beok ,
									quiz_ispm_boot_beok ,
									quiz_ispm_gook_beok ,
									quiz_ispm_down_beok ,
									quiz_ispm_entr_beok	};
//----------------------------------------------------------------------------------------------------------
//  key words: "ISP OK"
//    ASCII (0x):49 53 50 20 4F 4B
	reg     [ 3: 0] 				quiz_ispm_entr_mfsm	;
	assign    quiz_ispm_entr_beok = quiz_ispm_entr_mfsm == 4'H6	;
	
	always  @(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					quiz_ispm_entr_mfsm    <= 4'H0	;
	else if(~enab_ispm_entr_quiz)	quiz_ispm_entr_mfsm    <= 4'H0	;
	else if(uart_rxdi_drdy)			begin
		case  (quiz_ispm_entr_mfsm)
			4'H0	:				quiz_ispm_entr_mfsm		<=	(uart_rxdi_data	==	8'H49)	?	4'H1	:	4'H0	;
			4'H1	:				quiz_ispm_entr_mfsm		<=	(uart_rxdi_data	==	8'H53)	?	4'H2	:	4'H0	;
			4'H2	:				quiz_ispm_entr_mfsm		<=	(uart_rxdi_data	==	8'H50)	?	4'H3	:	4'H0	;
			4'H3	:				quiz_ispm_entr_mfsm		<=	(uart_rxdi_data	==	8'H20)	?	4'H4	:	4'H0	;
			4'H4	:				quiz_ispm_entr_mfsm		<=	(uart_rxdi_data	==	8'H4f)	?	4'H5	:	4'H0	;
			4'H5	:				quiz_ispm_entr_mfsm		<=	(uart_rxdi_data	==	8'H4b)	?	4'H6	:	4'H0	;
			4'H6	:				quiz_ispm_entr_mfsm		<=									4'H6	;
			default	:				quiz_ispm_entr_mfsm 	<=									4'H0	;
    	endcase
	end
//----------------------------------------------------------------------------------------------------------
//  key words when dnld ok: "W_OK"
//    ASCII(0x): 57 5f 4F 4B
	reg		[ 3: 0]       			quiz_ispm_down_mfsm	;
	assign	quiz_ispm_down_beok = 	quiz_ispm_down_mfsm == 4'H4	;

	always  @(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					quiz_ispm_down_mfsm    <= 4'H0	;
	else if(~enab_ispm_down_quiz)	quiz_ispm_down_mfsm    <= 4'H0	;
	else if(uart_rxdi_drdy)			begin
		case  (quiz_ispm_down_mfsm)
			4'H0		:			quiz_ispm_down_mfsm  	<= (uart_rxdi_data	==	8'H57)	?	4'H1	:	4'H0	;
	    	4'H1		:			quiz_ispm_down_mfsm  	<= (uart_rxdi_data	==	8'H5f)	?	4'H2	:	4'H0	;
	    	4'H2		:			quiz_ispm_down_mfsm  	<= (uart_rxdi_data	==	8'H4f)	?	4'H3	:	4'H0	;
	    	4'H3		:			quiz_ispm_down_mfsm  	<= (uart_rxdi_data	==	8'H4b)	?	4'H4	:	4'H0	;
	    	4'H4		:			quiz_ispm_down_mfsm  	<= 									4'H4	;
	    	default		:			quiz_ispm_down_mfsm 	<= 							  		4'H0	;
		endcase
	end		
//----------------------------------------------------------------------------------------------------------
//  key words: "G_OK"
//    ASCII (0x):47 5f 4f 4b
	reg     [ 3: 0] 				quiz_ispm_gook_mfsm	;
	assign    quiz_ispm_gook_beok = quiz_ispm_gook_mfsm == 4'H4	;
	
	always  @(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					quiz_ispm_gook_mfsm    <= 4'H0	;
	else if(~enab_ispm_gook_quiz)	quiz_ispm_gook_mfsm    <= 4'H0	;
	else if(uart_rxdi_drdy)			begin
		case  (quiz_ispm_gook_mfsm)
			4'H0	:				quiz_ispm_gook_mfsm		<=	(uart_rxdi_data	==	8'H47)	?	4'H1	:	4'H0	;
			4'H1	:				quiz_ispm_gook_mfsm		<=	(uart_rxdi_data	==	8'H5f)	?	4'H2	:	4'H0	;
			4'H2	:				quiz_ispm_gook_mfsm		<=	(uart_rxdi_data	==	8'H4f)	?	4'H3	:	4'H0	;
			4'H3	:				quiz_ispm_gook_mfsm		<=	(uart_rxdi_data	==	8'H4b)	?	4'H4	:	4'H0	;
			4'H4	:				quiz_ispm_gook_mfsm		<=									4'H4	;
			default	:				quiz_ispm_gook_mfsm 	<=									4'H0	;
    	endcase
	end
//----------------------------------------------------------------------------------------------------------
//  key words: "2nd OK"
//    ASCII (0x): 32 6E  64  20 4F 4B
	reg		[ 3: 0]					quiz_ispm_boot_mfsm	;
	assign	quiz_ispm_boot_beok	= 	quiz_ispm_boot_mfsm == 4'H6	;

	always  @(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					quiz_ispm_boot_mfsm    <= 4'H0	;
	else if(~enab_ispm_boot_quiz)	quiz_ispm_boot_mfsm    <= 4'H0	;
	else if(uart_rxdi_drdy)			begin
		case  (quiz_ispm_boot_mfsm)
			4'H0	: 				quiz_ispm_boot_mfsm		<=	(uart_rxdi_data	==	8'H32)	?	4'H1	:	4'H0	;
    		4'H1	: 				quiz_ispm_boot_mfsm		<=	(uart_rxdi_data	==	8'H6e)	?	4'H2	:	4'H0	;
    		4'H2	: 				quiz_ispm_boot_mfsm		<=	(uart_rxdi_data	==	8'H64)	?	4'H3	:	4'H0	;
    		4'H3	: 				quiz_ispm_boot_mfsm		<=	(uart_rxdi_data	==	8'H20)	?	4'H4	:	4'H0	;
    		4'H4	: 				quiz_ispm_boot_mfsm		<=	(uart_rxdi_data	==	8'H4f)	?	4'H5	:	4'H0	;
    		4'H5	: 				quiz_ispm_boot_mfsm		<=	(uart_rxdi_data	==	8'H4b)	?	4'H6	:	4'H0	;
    		4'H6	: 				quiz_ispm_boot_mfsm		<=									4'H6	;
    		default	: 				quiz_ispm_boot_mfsm 	<= 									4'H0	;
    	endcase
	end	
//----------------------------------------------------------------------------------------------------------
//  key words: "DDRIOK"
//    ASCII (0x):44 44 52 49 4F 4B
	reg     [ 3: 0] 				quiz_ddrs_init_mfsm	;
	assign    quiz_ddrs_init_beok = quiz_ddrs_init_mfsm == 4'H6	;
	
	always  @(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					quiz_ddrs_init_mfsm    <= 4'H0	;
	else if(~enab_ddrs_init_quiz)	quiz_ddrs_init_mfsm    <= 4'H0	;
	else if(uart_rxdi_drdy)			begin
		case  (quiz_ddrs_init_mfsm)
			4'H0	:				quiz_ddrs_init_mfsm		<=	(uart_rxdi_data	==	8'H44)	?	4'H1	:	4'H0	;
			4'H1	:				quiz_ddrs_init_mfsm		<=	(uart_rxdi_data	==	8'H44)	?	4'H2	:	4'H0	;
			4'H2	:				quiz_ddrs_init_mfsm		<=	(uart_rxdi_data	==	8'H52)	?	4'H3	:	4'H0	;
			4'H3	:				quiz_ddrs_init_mfsm		<=	(uart_rxdi_data	==	8'H49)	?	4'H4	:	4'H0	;
			4'H4	:				quiz_ddrs_init_mfsm		<=	(uart_rxdi_data	==	8'H4f)	?	4'H5	:	4'H0	;
			4'H5	:				quiz_ddrs_init_mfsm		<=	(uart_rxdi_data	==	8'H4b)	?	4'H6	:	4'H0	;
			4'H6	:				quiz_ddrs_init_mfsm		<=									4'H6	;
			default	:				quiz_ddrs_init_mfsm 	<=									4'H0	;
    	endcase
	end
//----------------------------------------------------------------------------------------------------------
//  key words: "DDRSOK"
//    ASCII (0x):44 44 52 53 4F 4B
	reg     [ 3: 0] 				quiz_ddrs_scan_mfsm	;
	assign    quiz_ddrs_scan_beok =	quiz_ddrs_scan_mfsm == 4'H6	;
	
	always  @(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					quiz_ddrs_scan_mfsm    <= 4'H0	;
	else if(~enab_ddrs_scan_quiz)	quiz_ddrs_scan_mfsm    <= 4'H0	;
	else if(uart_rxdi_drdy)			begin
		case  (quiz_ddrs_scan_mfsm)
			4'H0	:				quiz_ddrs_scan_mfsm		<=	(uart_rxdi_data	==	8'H44)	?	4'H1	:	4'H0	;
			4'H1	:				quiz_ddrs_scan_mfsm		<=	(uart_rxdi_data	==	8'H44)	?	4'H2	:	4'H0	;
			4'H2	:				quiz_ddrs_scan_mfsm		<=	(uart_rxdi_data	==	8'H52)	?	4'H3	:	4'H0	;
			4'H3	:				quiz_ddrs_scan_mfsm		<=	(uart_rxdi_data	==	8'H53)	?	4'H4	:	4'H0	;
			4'H4	:				quiz_ddrs_scan_mfsm		<=	(uart_rxdi_data	==	8'H4f)	?	4'H5	:	4'H0	;
			4'H5	:				quiz_ddrs_scan_mfsm		<=	(uart_rxdi_data	==	8'H4b)	?	4'H6	:	4'H0	;
			4'H6	:				quiz_ddrs_scan_mfsm		<=									4'H6	;
			default	:				quiz_ddrs_scan_mfsm 	<=									4'H0	;
    	endcase
	end
//----------------------------------------------------------------------------------------------------------
//  key words: "DDRFAIL0"
//    ASCII (0x):44 44 52 46 41 49 4C 30
	reg     [ 3: 0] 				quiz_ddr0_fail_mfsm	;
	assign    quiz_ddr0_scan_fail = 	quiz_ddr0_fail_mfsm == 4'H8	;

	always  @(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					quiz_ddr0_fail_mfsm    <= 4'H0	;
	else if(~enab_ddr0_scan_quiz)	quiz_ddr0_fail_mfsm    <= 4'H0	;
	else if(uart_rxdi_drdy)			begin
		case  (quiz_ddr0_fail_mfsm)
			4'H0	:				quiz_ddr0_fail_mfsm		<=	(uart_rxdi_data	==	8'H44)	?	4'H1	:	4'H0	;
			4'H1	:				quiz_ddr0_fail_mfsm		<=	(uart_rxdi_data	==	8'H44)	?	4'H2	:	4'H0	;
			4'H2	:				quiz_ddr0_fail_mfsm		<=	(uart_rxdi_data	==	8'H52)	?	4'H3	:	4'H0	;
			4'H3	:				quiz_ddr0_fail_mfsm		<=	(uart_rxdi_data	==	8'H46)	?	4'H4	:	4'H0	;
			4'H4	:				quiz_ddr0_fail_mfsm		<=	(uart_rxdi_data	==	8'H41)	?	4'H5	:	4'H0	;
			4'H5	:				quiz_ddr0_fail_mfsm		<=	(uart_rxdi_data	==	8'H49)	?	4'H6	:	4'H0	;
			4'H6	:				quiz_ddr0_fail_mfsm		<=	(uart_rxdi_data	==	8'H4C)	?	4'H7	:	4'H0	;
			4'H6	:				quiz_ddr0_fail_mfsm		<=	(uart_rxdi_data	==	8'H30)	?	4'H8	:	4'H0	;
			4'H8	:				quiz_ddr0_fail_mfsm		<=									4'H8	;
			default	:				quiz_ddr0_fail_mfsm 	<=									4'H0	;
	 	endcase
	end
//----------------------------------------------------------------------------------------------------------
//  key words: "DDRFAIL1"
//    ASCII (0x):44 44 52 46 41 49 4C 31
	reg     [ 3: 0] 				quiz_ddr1_fail_mfsm	;
	assign    quiz_ddr1_scan_fail = quiz_ddr1_fail_mfsm == 4'H8	;

	always  @(posedge osde_sclk or negedge osde_rstn)
	if(~osde_rstn)					quiz_ddr1_fail_mfsm    <= 4'H0	;
	else if(~enab_ddr1_scan_quiz)	quiz_ddr1_fail_mfsm    <= 4'H0	;
	else if(uart_rxdi_drdy)			begin
		case  (quiz_ddr1_fail_mfsm)
			4'H0	:				quiz_ddr1_fail_mfsm		<=	(uart_rxdi_data	==	8'H44)	?	4'H1	:	4'H0	;
			4'H1	:				quiz_ddr1_fail_mfsm		<=	(uart_rxdi_data	==	8'H44)	?	4'H2	:	4'H0	;
			4'H2	:				quiz_ddr1_fail_mfsm		<=	(uart_rxdi_data	==	8'H52)	?	4'H3	:	4'H0	;
			4'H3	:				quiz_ddr1_fail_mfsm		<=	(uart_rxdi_data	==	8'H46)	?	4'H4	:	4'H0	;
			4'H4	:				quiz_ddr1_fail_mfsm		<=	(uart_rxdi_data	==	8'H41)	?	4'H5	:	4'H0	;
			4'H5	:				quiz_ddr1_fail_mfsm		<=	(uart_rxdi_data	==	8'H49)	?	4'H6	:	4'H0	;
			4'H6	:				quiz_ddr1_fail_mfsm		<=	(uart_rxdi_data	==	8'H4C)	?	4'H7	:	4'H0	;
			4'H6	:				quiz_ddr1_fail_mfsm		<=	(uart_rxdi_data	==	8'H31)	?	4'H8	:	4'H0	;
			4'H8	:				quiz_ddr1_fail_mfsm		<=									4'H8	;
			default	:				quiz_ddr1_fail_mfsm 	<=									4'H0	;
	 	endcase
	end



endmodule





//	reg                  			stat_ispm_entr_beok	;
//	reg                  			stat_ispm_down_beok	;
//	reg                  			stat_ispm_gook_beok	;
//	reg                  			stat_ispm_boot_beok	;
//	reg                  			stat_ddrs_init_beok	;
//	reg                  			stat_ddrs_scan_beok	;
//	reg                  			stat_ddr0_scan_fail	;
//	reg                  			stat_ddr1_scan_fail	;
//

//	always  @(posedge osde_sclk or negedge osde_rstn)
//	if(~osde_rstn)					begin
//		stat_ddr1_scan_fail <=	0	;	
//		stat_ddr0_scan_fail <=	0	;	
//		stat_ddrs_scan_beok <=	0	;	
//		stat_ddrs_init_beok <=	0	;	
//		stat_ispm_boot_beok <=	0	;	
//		stat_ispm_gook_beok <=	0	;	
//		stat_ispm_down_beok <=	0	;	
//		stat_ispm_entr_beok <=	0	;	
//	end else if()				begin
//		stat_2805_crom_beok <=	(~enab_2805_crom_quiz )	?	1'B0	:	quiz_ispm_down_beok ?	1'B1	:	stat_2805_crom_beok	;
//		stat_2805_cram_beok <=	(~enab_2805_cram_quiz )	?	1'B0	:	quiz_ispm_boot_beok ?	1'B1	:	stat_2805_cram_beok	;
//		stat_gnpu_cram_beok <=	(~enab_gnpu_cram_quiz )	?	1'B0	:	quiz_gnpu_cram_beok ?	1'B1	:	stat_gnpu_cram_beok	;
//		stat_ddrs_init_beok <=	(~enab_ddrs_init_quiz )	?	1'B0	:	quiz_ddrs_init_beok ?	1'B1	:	stat_ddrs_init_beok	;
//		stat_ddrs_scan_beok <=	(~enab_ddrs_scan_quiz )	?	1'B0	:	quiz_ddrs_scan_beok ?	1'B1	:	stat_ddrs_scan_beok	;
//		stat_ispm_entr_beok <=	(~enab_ispm_entr_quiz )	?	1'B0	:	quiz_ispm_entr_beok ?	1'B1	:	stat_ispm_entr_beok	;
//		stat_ispm_gook_beok <=	(~enab_ispm_gook_quiz )	?	1'B0	:	quiz_ispm_gook_beok ?	1'B1	:	stat_ispm_gook_beok	;
//		stat_ddrs_scan_fail <=	(~enab_ddrs_scan_fail )	?	1'B0	:	quiz_ddrs_scan_fail ?	1'B1	:	stat_ddrs_scan_fail	;
//	end




//----------------------------------------------------------------------------------------------------------
//  key words: "3rd OK"
//    ASCII (0x):33 72  64  20 4F 4B
//	reg		[ 3: 0]    				quiz_gnpu_cram_mfsm	;
//	assign	quiz_gnpu_cram_beok	=	quiz_gnpu_cram_mfsm == 4'H6;
//	
//	always  @(posedge osde_sclk or negedge osde_rstn)
//	if(~osde_rstn)					quiz_gnpu_cram_mfsm    <= 4'H0	;
//	else if(~enab_gnpu_cram_quiz)	quiz_gnpu_cram_mfsm    <= 4'H0	;
//	else if(uart_rxdi_drdy)			begin
//		case  (quiz_gnpu_cram_mfsm)
//			4'H0	:				quiz_gnpu_cram_mfsm		<=	(uart_rxdi_data ==	8'H33)	?	4'H1	:	4'H0	;
//			4'H1	:				quiz_gnpu_cram_mfsm		<=	(uart_rxdi_data ==	8'H72)	?	4'H2	:	4'H0	;
//			4'H2	:				quiz_gnpu_cram_mfsm		<=	(uart_rxdi_data ==	8'H64)	?	4'H3	:	4'H0	;
//			4'H3	:				quiz_gnpu_cram_mfsm		<=	(uart_rxdi_data ==	8'H20)	?	4'H4	:	4'H0	;
//			4'H4	:				quiz_gnpu_cram_mfsm		<=	(uart_rxdi_data ==	8'H4f)	?	4'H5	:	4'H0	;
//			4'H5	:				quiz_gnpu_cram_mfsm		<=	(uart_rxdi_data ==	8'H4b)	?	4'H6	:	4'H0	;
//			4'H6	:				quiz_gnpu_cram_mfsm		<=									4'H0	;
//			default	:				quiz_gnpu_cram_mfsm 	<=									4'H0	;
// 	endcase
//	end
//----------------------------------------------------------------------------------------------------------
//  key words: "DDRFAIL"
//    ASCII (0x):44 44 52 46 41 49 4C
//	reg     [ 3: 0] 				quiz_ddrs_fail_mfsm	;
//	assign    quiz_ddrs_scan_fail = 	quiz_ddrs_fail_mfsm == 4'H7	;
//	
//	always  @(posedge osde_sclk or negedge osde_rstn)
//	if(~osde_rstn)					quiz_ddrs_fail_mfsm    <= 4'H0	;
//	else if(~enab_ddrs_scan_fail)	quiz_ddrs_fail_mfsm    <= 4'H0	;
//	else if(uart_rxdi_drdy)			begin
//		case  (quiz_ddrs_fail_mfsm)
//			4'H0	:				quiz_ddrs_fail_mfsm		<=	(uart_rxdi_data	==	8'H44)	?	4'H1	:	4'H0	;
//			4'H1	:				quiz_ddrs_fail_mfsm		<=	(uart_rxdi_data	==	8'H44)	?	4'H2	:	4'H0	;
//			4'H2	:				quiz_ddrs_fail_mfsm		<=	(uart_rxdi_data	==	8'H52)	?	4'H3	:	4'H0	;
//			4'H3	:				quiz_ddrs_fail_mfsm		<=	(uart_rxdi_data	==	8'H46)	?	4'H4	:	4'H0	;
//			4'H4	:				quiz_ddrs_fail_mfsm		<=	(uart_rxdi_data	==	8'H41)	?	4'H5	:	4'H0	;
//			4'H5	:				quiz_ddrs_fail_mfsm		<=	(uart_rxdi_data	==	8'H49)	?	4'H6	:	4'H0	;
//			4'H6	:				quiz_ddrs_fail_mfsm		<=	(uart_rxdi_data	==	8'H4c)	?	4'H7	:	4'H0	;
//			4'H7	:				quiz_ddrs_fail_mfsm		<=									4'H0	;
//			default	:				quiz_ddrs_fail_mfsm 	<=									4'H0	;
//  	endcase
//	end
/**********************************************************************************************************/
 
