
module  code_rams  #(
  parameter             AW  = 8 ,
  parameter             DW  = 32)
(
  input                 csea    ,
  input                 wrcs    ,
  input   [AW-1:0]      addr    ,
  input   [DW-1:0]      wdat    ,
  output
  reg     [DW-1:0]      rdat    ,
  input                 clk     );
/**************************************************/
  (* RAM_STYLE="BLOCK" *)
  reg     [DW-1:0]      mem [(2**AW)-1:0] ;

  always  @(posedge clk)
    if (csea) begin
      rdat              <= mem[addr];
      if (wrcs)
        mem[addr]       <= wdat     ;
    end

endmodule 
