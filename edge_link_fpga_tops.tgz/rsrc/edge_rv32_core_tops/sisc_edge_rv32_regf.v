`include "sisc_edge_rv32_defs.v"

`define             VLG_LEGACY_STYLE  1

module sisc_edge_rv32_regf(
`ifdef RV_TRACE
	input                        		ras_keep	,
	input                        		pc_push		,
	input                        		pc_pop 		,
	output     [31:0]            		sp_reg0		,
	output reg [12:0][31:0]      		ras    		,
	input      [31:0]            		PC_WB  		,
`endif		
	input                        		pre_int		,
	input                        		spr_en		,
	input                        		spr_sync_sp	,
	input                        		spr_sync_all,
	input                        		reset		,
	input                        		clk			,
	input  [`REG_ADDR_WIDTH-1:0] 		ra1			,
	output [`RV_XLEN-1:0]        		rd1			,
	input  [`REG_ADDR_WIDTH-1:0] 		ra2			,
	output [`RV_XLEN-1:0]        		rd2			,
	input  [`REG_ADDR_WIDTH-1:0] 		ra3			,
	output [`RV_XLEN-1:0]        		rd3			,
	input                        		wen			,
	input  [1:0]                 		bwen		,
	input  [`REG_ADDR_WIDTH-1:0] 		wa			,
	input  [`RV_XLEN-1:0]        		wd			,
	output [`RV_XLEN*16-1:0]     		mon		    );

  `ifndef VLG_LEGACY_STYLE
   reg [`RV_XLEN-1:0]                             data [31:0];
  `else
  // coding legacy style for ISE 
  reg   [`RV_XLEN-1:0]                             data_01; 
  reg   [`RV_XLEN-1:0]                             data_02; 
  reg   [`RV_XLEN-1:0]                             data_03; 
  reg   [`RV_XLEN-1:0]                             data_04; 
  reg   [`RV_XLEN-1:0]                             data_05; 
  reg   [`RV_XLEN-1:0]                             data_06; 
  reg   [`RV_XLEN-1:0]                             data_07; 
  reg   [`RV_XLEN-1:0]                             data_08; 
  reg   [`RV_XLEN-1:0]                             data_09; 
  reg   [`RV_XLEN-1:0]                             data_10; 
  reg   [`RV_XLEN-1:0]                             data_11; 
  reg   [`RV_XLEN-1:0]                             data_12; 
  reg   [`RV_XLEN-1:0]                             data_13; 
  reg   [`RV_XLEN-1:0]                             data_14; 
  reg   [`RV_XLEN-1:0]                             data_15; 
  reg   [`RV_XLEN-1:0]                             data_16; 
  reg   [`RV_XLEN-1:0]                             data_17; 
  reg   [`RV_XLEN-1:0]                             data_18; 
  reg   [`RV_XLEN-1:0]                             data_19; 
  reg   [`RV_XLEN-1:0]                             data_20; 
  reg   [`RV_XLEN-1:0]                             data_21; 
  reg   [`RV_XLEN-1:0]                             data_22; 
  reg   [`RV_XLEN-1:0]                             data_23; 
  reg   [`RV_XLEN-1:0]                             data_24; 
  reg   [`RV_XLEN-1:0]                             data_25; 
  reg   [`RV_XLEN-1:0]                             data_26; 
  reg   [`RV_XLEN-1:0]                             data_27; 
  reg   [`RV_XLEN-1:0]                             data_28; 
  reg   [`RV_XLEN-1:0]                             data_29; 
  reg   [`RV_XLEN-1:0]                             data_30; 
  reg   [`RV_XLEN-1:0]                             data_31; 
  `endif
   wire                                           wen_internal;

   assign wen_internal = wen && |wa;

  `ifndef VLG_LEGACY_STYLE  
   assign rd1 = |ra1 ? (data[ra1]) : 0 ;
   assign rd2 = |ra2 ? (data[ra2]) : 0 ;
   assign rd3 = |ra3 ? (data[ra3]) : 0 ;
  `else
    `define DATA_AS_FUNC_INPUTS data_01,data_02,data_03,data_04,data_05,data_06,data_07,data_08,data_09,data_10,data_11,data_12,data_13,data_14,data_15,data_16,data_17,data_18,data_19,data_20,data_21,data_22,data_23,data_24,data_25,data_26,data_27,data_28,data_29,data_30,data_31
   assign rd1 = data_idxd(ra1,`DATA_AS_FUNC_INPUTS);
   assign rd2 = data_idxd(ra2,`DATA_AS_FUNC_INPUTS);
   assign rd3 = data_idxd(ra3,`DATA_AS_FUNC_INPUTS);
  function  [`RV_XLEN-1:0]  data_idxd;
    input   [`REG_ADDR_WIDTH-1:0] ra;
    input   [`RV_XLEN-1:0]        idat_01; 
    input   [`RV_XLEN-1:0]        idat_02; 
    input   [`RV_XLEN-1:0]        idat_03; 
    input   [`RV_XLEN-1:0]        idat_04; 
    input   [`RV_XLEN-1:0]        idat_05; 
    input   [`RV_XLEN-1:0]        idat_06; 
    input   [`RV_XLEN-1:0]        idat_07; 
    input   [`RV_XLEN-1:0]        idat_08; 
    input   [`RV_XLEN-1:0]        idat_09; 
    input   [`RV_XLEN-1:0]        idat_10; 
    input   [`RV_XLEN-1:0]        idat_11; 
    input   [`RV_XLEN-1:0]        idat_12; 
    input   [`RV_XLEN-1:0]        idat_13; 
    input   [`RV_XLEN-1:0]        idat_14; 
    input   [`RV_XLEN-1:0]        idat_15; 
    input   [`RV_XLEN-1:0]        idat_16; 
    input   [`RV_XLEN-1:0]        idat_17; 
    input   [`RV_XLEN-1:0]        idat_18; 
    input   [`RV_XLEN-1:0]        idat_19; 
    input   [`RV_XLEN-1:0]        idat_20; 
    input   [`RV_XLEN-1:0]        idat_21; 
    input   [`RV_XLEN-1:0]        idat_22; 
    input   [`RV_XLEN-1:0]        idat_23; 
    input   [`RV_XLEN-1:0]        idat_24; 
    input   [`RV_XLEN-1:0]        idat_25; 
    input   [`RV_XLEN-1:0]        idat_26; 
    input   [`RV_XLEN-1:0]        idat_27; 
    input   [`RV_XLEN-1:0]        idat_28; 
    input   [`RV_XLEN-1:0]        idat_29; 
    input   [`RV_XLEN-1:0]        idat_30; 
    input   [`RV_XLEN-1:0]        idat_31; 
    reg     [`RV_XLEN-1:0]        data   ;
    reg     [`RV_XLEN-1:0]        data_01; 
    reg     [`RV_XLEN-1:0]        data_02; 
    reg     [`RV_XLEN-1:0]        data_03; 
    reg     [`RV_XLEN-1:0]        data_04; 
    reg     [`RV_XLEN-1:0]        data_05; 
    reg     [`RV_XLEN-1:0]        data_06; 
    reg     [`RV_XLEN-1:0]        data_07; 
    reg     [`RV_XLEN-1:0]        data_08; 
    reg     [`RV_XLEN-1:0]        data_09; 
    reg     [`RV_XLEN-1:0]        data_10; 
    reg     [`RV_XLEN-1:0]        data_11; 
    reg     [`RV_XLEN-1:0]        data_12; 
    reg     [`RV_XLEN-1:0]        data_13; 
    reg     [`RV_XLEN-1:0]        data_14; 
    reg     [`RV_XLEN-1:0]        data_15; 
    reg     [`RV_XLEN-1:0]        data_16; 
    reg     [`RV_XLEN-1:0]        data_17; 
    reg     [`RV_XLEN-1:0]        data_18; 
    reg     [`RV_XLEN-1:0]        data_19; 
    reg     [`RV_XLEN-1:0]        data_20; 
    reg     [`RV_XLEN-1:0]        data_21; 
    reg     [`RV_XLEN-1:0]        data_22; 
    reg     [`RV_XLEN-1:0]        data_23; 
    reg     [`RV_XLEN-1:0]        data_24; 
    reg     [`RV_XLEN-1:0]        data_25; 
    reg     [`RV_XLEN-1:0]        data_26; 
    reg     [`RV_XLEN-1:0]        data_27; 
    reg     [`RV_XLEN-1:0]        data_28; 
    reg     [`RV_XLEN-1:0]        data_29; 
    reg     [`RV_XLEN-1:0]        data_30; 
    reg     [`RV_XLEN-1:0]        data_31; 

    begin
      data_01   = idat_01; 
      data_02   = idat_02; 
      data_03   = idat_03; 
      data_04   = idat_04; 
      data_05   = idat_05; 
      data_06   = idat_06; 
      data_07   = idat_07; 
      data_08   = idat_08; 
      data_09   = idat_09; 
      data_10   = idat_10; 
      data_11   = idat_11; 
      data_12   = idat_12; 
      data_13   = idat_13; 
      data_14   = idat_14; 
      data_15   = idat_15; 
      data_16   = idat_16; 
      data_17   = idat_17; 
      data_18   = idat_18; 
      data_19   = idat_19; 
      data_20   = idat_20; 
      data_21   = idat_21; 
      data_22   = idat_22; 
      data_23   = idat_23; 
      data_24   = idat_24; 
      data_25   = idat_25; 
      data_26   = idat_26; 
      data_27   = idat_27; 
      data_28   = idat_28; 
      data_29   = idat_29; 
      data_30   = idat_30; 
      data_31   = idat_31; 

    `ifdef RV16_REGF
      data      = (ra == 15) ? data_15
    `else // RV32 REG FILE
      data      = (ra == 31) ? data_31 
                : (ra == 30) ? data_30
                : (ra == 29) ? data_29
                : (ra == 28) ? data_28
                : (ra == 27) ? data_27
                : (ra == 26) ? data_26
                : (ra == 25) ? data_25
                : (ra == 24) ? data_24
                : (ra == 23) ? data_23
                : (ra == 22) ? data_22
                : (ra == 21) ? data_21
                : (ra == 20) ? data_20
                : (ra == 19) ? data_19
                : (ra == 18) ? data_18
                : (ra == 17) ? data_17
                : (ra == 16) ? data_16
                : (ra == 15) ? data_15
    `endif // end of RV32\16 REGFILE
                : (ra == 14) ? data_14
                : (ra == 13) ? data_13
                : (ra == 12) ? data_12
                : (ra == 11) ? data_11
                : (ra == 10) ? data_10
                : (ra ==  9) ? data_09
                : (ra ==  8) ? data_08
                : (ra ==  7) ? data_07
                : (ra ==  6) ? data_06
                : (ra ==  5) ? data_05
                : (ra ==  4) ? data_04
                : (ra ==  3) ? data_03
                : (ra ==  2) ? data_02
                : (ra ==  1) ? data_01
                :              0      ;
      data_idxd = data;
    end
  endfunction
  `endif
`ifdef RV_TRACE
   assign sp_reg0 = data[2];

   always @(posedge clk or posedge reset)
   if (reset)
     ras[0] <= 32'h00;
   else if (~ras_keep && wen_internal && (wa == 1) && pc_push)
     ras[0] <= wd ;
   else if (~ras_keep && pc_pop)
     ras[0] <= ras[1];

   always @(posedge clk or posedge reset)
   if (reset)
     ras[12] <= 32'h00;
   else if (~ras_keep && wen_internal && (wa == 1) && pc_push)
     ras[12] <= ras[11] ;
   else if (~ras_keep && pc_pop)
     ras[12] <= 32'h00;

   generate for (genvar i=1; i<12; i++) begin
     always @(posedge clk or posedge reset)
     if (reset)
       ras[i] <= 32'h00;
     else if (~ras_keep && wen_internal && (wa == 1) && pc_push)
       ras[i] <= ras[i-1];
     else if (~ras_keep && pc_pop)
       ras[i] <= ras[i+1];
   end endgenerate
`endif

  `ifndef   VLG_LEGACY_STYLE
    always @(posedge clk or posedge reset) begin
      if (reset) begin
        data[0] <= 32'h00;
        data[1] <= 32'h00;
        data[2] <= 32'h00;
        data[3] <= 32'h00;
        data[4] <= 32'h00;
        data[5] <= 32'h00;
        data[6] <= 32'h00;
        data[7] <= 32'h00;
        data[8] <= 32'h00;
        data[9] <= 32'h00;
        data[10] <= 32'h00;
        data[11] <= 32'h00;
        data[12] <= 32'h00;
        data[13] <= 32'h00;
        data[14] <= 32'h00;
        data[15] <= 32'h00;
        `ifndef RV16_REGF
        data[16] <= 32'h00;
        data[17] <= 32'h00;
        data[18] <= 32'h00;
        data[19] <= 32'h00;
        data[20] <= 32'h00;
        data[21] <= 32'h00;
        data[22] <= 32'h00;
        data[23] <= 32'h00;
        data[24] <= 32'h00;
        data[25] <= 32'h00;
        data[26] <= 32'h00;
        data[27] <= 32'h00;
        data[28] <= 32'h00;
        data[29] <= 32'h00;
        data[30] <= 32'h00;
        data[31] <= 32'h00;
        `endif
      end else if (wen_internal) begin 
        data[wa][15: 0] <= bwen[0] ? wd[15: 0] : data[wa][15: 0];
        data[wa][31:16] <= bwen[1] ? wd[31:16] : data[wa][31:16];
      end
    end		
  `else 
    always @(posedge clk or posedge reset) begin
      if (reset) begin
        data_01[15:0]  <= 16'h00;
        data_02[15:0]  <= 16'h00;
        data_03[15:0]  <= 16'h00;
        data_04[15:0]  <= 16'h00;
        data_05[15:0]  <= 16'h00;
        data_06[15:0]  <= 16'h00;
        data_07[15:0]  <= 16'h00;
        data_08[15:0]  <= 16'h00;
        data_09[15:0]  <= 16'h00;
        data_10[15:0]  <= 16'h00;
        data_11[15:0]  <= 16'h00;
        data_12[15:0]  <= 16'h00;
        data_13[15:0]  <= 16'h00;
        data_14[15:0]  <= 16'h00;
        data_15[15:0]  <= 16'h00;
        `ifndef RV16_REGF
        data_16[15:0]  <= 16'h00;
        data_17[15:0]  <= 16'h00;
        data_18[15:0]  <= 16'h00;
        data_19[15:0]  <= 16'h00;
        data_20[15:0]  <= 16'h00;
        data_21[15:0]  <= 16'h00;
        data_22[15:0]  <= 16'h00;
        data_23[15:0]  <= 16'h00;
        data_24[15:0]  <= 16'h00;
        data_25[15:0]  <= 16'h00;
        data_26[15:0]  <= 16'h00;
        data_27[15:0]  <= 16'h00;
        data_28[15:0]  <= 16'h00;
        data_29[15:0]  <= 16'h00;
        data_30[15:0]  <= 16'h00;
        data_31[15:0]  <= 16'h00;
        `endif
      end else if (wen_internal) begin 
        data_01[15:0] <=  ((wa ==  1) & bwen[0]) ?  wd[15: 0] : data_01[15:0];
        data_02[15:0] <=  ((wa ==  2) & bwen[0]) ?  wd[15: 0] : data_02[15:0];
        data_03[15:0] <=  ((wa ==  3) & bwen[0]) ?  wd[15: 0] : data_03[15:0];
        data_04[15:0] <=  ((wa ==  4) & bwen[0]) ?  wd[15: 0] : data_04[15:0];
        data_05[15:0] <=  ((wa ==  5) & bwen[0]) ?  wd[15: 0] : data_05[15:0];
        data_06[15:0] <=  ((wa ==  6) & bwen[0]) ?  wd[15: 0] : data_06[15:0];
        data_07[15:0] <=  ((wa ==  7) & bwen[0]) ?  wd[15: 0] : data_07[15:0];
        data_08[15:0] <=  ((wa ==  8) & bwen[0]) ?  wd[15: 0] : data_08[15:0];
        data_09[15:0] <=  ((wa ==  9) & bwen[0]) ?  wd[15: 0] : data_09[15:0];
        data_10[15:0] <=  ((wa == 10) & bwen[0]) ?  wd[15: 0] : data_10[15:0];
        data_11[15:0] <=  ((wa == 11) & bwen[0]) ?  wd[15: 0] : data_11[15:0];
        data_12[15:0] <=  ((wa == 12) & bwen[0]) ?  wd[15: 0] : data_12[15:0];
        data_13[15:0] <=  ((wa == 13) & bwen[0]) ?  wd[15: 0] : data_13[15:0];
        data_14[15:0] <=  ((wa == 14) & bwen[0]) ?  wd[15: 0] : data_14[15:0];
        data_15[15:0] <=  ((wa == 15) & bwen[0]) ?  wd[15: 0] : data_15[15:0];
        `ifndef RV16_REGF
        data_16[15:0] <=  ((wa == 16) & bwen[0]) ?  wd[15: 0] : data_16[15:0];
        data_17[15:0] <=  ((wa == 17) & bwen[0]) ?  wd[15: 0] : data_17[15:0];
        data_18[15:0] <=  ((wa == 18) & bwen[0]) ?  wd[15: 0] : data_18[15:0];
        data_19[15:0] <=  ((wa == 19) & bwen[0]) ?  wd[15: 0] : data_19[15:0];
        data_20[15:0] <=  ((wa == 20) & bwen[0]) ?  wd[15: 0] : data_20[15:0];
        data_21[15:0] <=  ((wa == 21) & bwen[0]) ?  wd[15: 0] : data_21[15:0];
        data_22[15:0] <=  ((wa == 22) & bwen[0]) ?  wd[15: 0] : data_22[15:0];
        data_23[15:0] <=  ((wa == 23) & bwen[0]) ?  wd[15: 0] : data_23[15:0];
        data_24[15:0] <=  ((wa == 24) & bwen[0]) ?  wd[15: 0] : data_24[15:0];
        data_25[15:0] <=  ((wa == 25) & bwen[0]) ?  wd[15: 0] : data_25[15:0];
        data_26[15:0] <=  ((wa == 26) & bwen[0]) ?  wd[15: 0] : data_26[15:0];
        data_27[15:0] <=  ((wa == 27) & bwen[0]) ?  wd[15: 0] : data_27[15:0];
        data_28[15:0] <=  ((wa == 28) & bwen[0]) ?  wd[15: 0] : data_28[15:0];
        data_29[15:0] <=  ((wa == 29) & bwen[0]) ?  wd[15: 0] : data_29[15:0];
        data_30[15:0] <=  ((wa == 30) & bwen[0]) ?  wd[15: 0] : data_30[15:0];
        data_31[15:0] <=  ((wa == 31) & bwen[0]) ?  wd[15: 0] : data_31[15:0];
        `endif
      end 
    end
    
    always @(posedge clk or posedge reset) begin
      if (reset) begin
        data_01[31:16]  <= 16'h00;
        data_02[31:16]  <= 16'h00;
        data_03[31:16]  <= 16'h00;
        data_04[31:16]  <= 16'h00;
        data_05[31:16]  <= 16'h00;
        data_06[31:16]  <= 16'h00;
        data_07[31:16]  <= 16'h00;
        data_08[31:16]  <= 16'h00;
        data_09[31:16]  <= 16'h00;
        data_10[31:16]  <= 16'h00;
        data_11[31:16]  <= 16'h00;
        data_12[31:16]  <= 16'h00;
        data_13[31:16]  <= 16'h00;
        data_14[31:16]  <= 16'h00;
        data_15[31:16]  <= 16'h00;
        `ifndef RV16_REGF
        data_16[31:16]  <= 16'h00;
        data_17[31:16]  <= 16'h00;
        data_18[31:16]  <= 16'h00;
        data_19[31:16]  <= 16'h00;
        data_20[31:16]  <= 16'h00;
        data_21[31:16]  <= 16'h00;
        data_22[31:16]  <= 16'h00;
        data_23[31:16]  <= 16'h00;
        data_24[31:16]  <= 16'h00;
        data_25[31:16]  <= 16'h00;
        data_26[31:16]  <= 16'h00;
        data_27[31:16]  <= 16'h00;
        data_28[31:16]  <= 16'h00;
        data_29[31:16]  <= 16'h00;
        data_30[31:16]  <= 16'h00;
        data_31[31:16]  <= 16'h00;
        `endif
      end else if (wen_internal) begin 
        data_01[31:16] <=  ((wa ==  1) & bwen[1]) ?  wd[31:16] : data_01[31:16];
        data_02[31:16] <=  ((wa ==  2) & bwen[1]) ?  wd[31:16] : data_02[31:16];
        data_03[31:16] <=  ((wa ==  3) & bwen[1]) ?  wd[31:16] : data_03[31:16];
        data_04[31:16] <=  ((wa ==  4) & bwen[1]) ?  wd[31:16] : data_04[31:16];
        data_05[31:16] <=  ((wa ==  5) & bwen[1]) ?  wd[31:16] : data_05[31:16];
        data_06[31:16] <=  ((wa ==  6) & bwen[1]) ?  wd[31:16] : data_06[31:16];
        data_07[31:16] <=  ((wa ==  7) & bwen[1]) ?  wd[31:16] : data_07[31:16];
        data_08[31:16] <=  ((wa ==  8) & bwen[1]) ?  wd[31:16] : data_08[31:16];
        data_09[31:16] <=  ((wa ==  9) & bwen[1]) ?  wd[31:16] : data_09[31:16];
        data_10[31:16] <=  ((wa == 10) & bwen[1]) ?  wd[31:16] : data_10[31:16];
        data_11[31:16] <=  ((wa == 11) & bwen[1]) ?  wd[31:16] : data_11[31:16];
        data_12[31:16] <=  ((wa == 12) & bwen[1]) ?  wd[31:16] : data_12[31:16];
        data_13[31:16] <=  ((wa == 13) & bwen[1]) ?  wd[31:16] : data_13[31:16];
        data_14[31:16] <=  ((wa == 14) & bwen[1]) ?  wd[31:16] : data_14[31:16];
        data_15[31:16] <=  ((wa == 15) & bwen[1]) ?  wd[31:16] : data_15[31:16];
        `ifndef RV16_REGF
        data_16[31:16] <=  ((wa == 16) & bwen[1]) ?  wd[31:16] : data_16[31:16];
        data_17[31:16] <=  ((wa == 17) & bwen[1]) ?  wd[31:16] : data_17[31:16];
        data_18[31:16] <=  ((wa == 18) & bwen[1]) ?  wd[31:16] : data_18[31:16];
        data_19[31:16] <=  ((wa == 19) & bwen[1]) ?  wd[31:16] : data_19[31:16];
        data_20[31:16] <=  ((wa == 20) & bwen[1]) ?  wd[31:16] : data_20[31:16];
        data_21[31:16] <=  ((wa == 21) & bwen[1]) ?  wd[31:16] : data_21[31:16];
        data_22[31:16] <=  ((wa == 22) & bwen[1]) ?  wd[31:16] : data_22[31:16];
        data_23[31:16] <=  ((wa == 23) & bwen[1]) ?  wd[31:16] : data_23[31:16];
        data_24[31:16] <=  ((wa == 24) & bwen[1]) ?  wd[31:16] : data_24[31:16];
        data_25[31:16] <=  ((wa == 25) & bwen[1]) ?  wd[31:16] : data_25[31:16];
        data_26[31:16] <=  ((wa == 26) & bwen[1]) ?  wd[31:16] : data_26[31:16];
        data_27[31:16] <=  ((wa == 27) & bwen[1]) ?  wd[31:16] : data_27[31:16];
        data_28[31:16] <=  ((wa == 28) & bwen[1]) ?  wd[31:16] : data_28[31:16];
        data_29[31:16] <=  ((wa == 29) & bwen[1]) ?  wd[31:16] : data_29[31:16];
        data_30[31:16] <=  ((wa == 30) & bwen[1]) ?  wd[31:16] : data_30[31:16];
        data_31[31:16] <=  ((wa == 31) & bwen[1]) ?  wd[31:16] : data_31[31:16];
        `endif
      end
    end
  `endif

  `ifndef VLG_LEGACY_STYLE
   assign mon = { {`RV_XLEN{1'b0}},
                  data[15][`RV_XLEN-1:0],
                  data[14][`RV_XLEN-1:0],
                  data[13][`RV_XLEN-1:0],
                  data[12][`RV_XLEN-1:0],
                  data[11][`RV_XLEN-1:0],
                  data[10][`RV_XLEN-1:0],
                  data[ 9][`RV_XLEN-1:0],
                  data[ 8][`RV_XLEN-1:0],
                  data[ 7][`RV_XLEN-1:0],
                  data[ 6][`RV_XLEN-1:0],
                  data[ 5][`RV_XLEN-1:0],
                  data[ 4][`RV_XLEN-1:0],
                  data[ 3][`RV_XLEN-1:0],
                  data[ 2][`RV_XLEN-1:0],
                  data[ 1][`RV_XLEN-1:0]
   };
  `endif

`ifdef CPU_DEBUG
reg [31:0] reg_name [31:0];
initial begin
  reg_name[00] = "zero" ;
  reg_name[01] = "ra"   ;
  reg_name[02] = "sp"   ;
  reg_name[03] = "gp"   ;
  reg_name[04] = "tp"   ;
  reg_name[05] = "t0"   ;
  reg_name[06] = "t1"   ;
  reg_name[07] = "t2"   ;
  reg_name[08] = "s0"   ;
  reg_name[09] = "s1"   ;
  reg_name[10] = "a0"   ;
  reg_name[11] = "a1"   ;
  reg_name[12] = "a2"   ;
  reg_name[13] = "a3"   ;
  reg_name[14] = "a4"   ;
  reg_name[15] = "a5"   ;
  reg_name[16] = "a6"   ;
  reg_name[17] = "a7"   ;
  reg_name[18] = "s2"   ;
  reg_name[19] = "s3"   ;
  reg_name[20] = "s4"   ;
  reg_name[21] = "s5"   ;
  reg_name[22] = "s6"   ;
  reg_name[23] = "s7"   ;
  reg_name[24] = "s8"   ;
  reg_name[25] = "s9"   ;
  reg_name[26] = "s10"  ;
  reg_name[27] = "s11"  ;
  reg_name[28] = "t3"   ;
  reg_name[29] = "t4"   ;
  reg_name[30] = "t5"   ;
  reg_name[31] = "t6"   ;
end
`endif

  `ifndef VLG_LEGACY_STYLE
//wire [31:0] data00     = data[00];
//wire [31:0] data01_ra  = data[01];
//wire [31:0] data02_sp  = data[02];
//wire [31:0] data03_gp  = data[03];
//wire [31:0] data04_tp  = data[04];
//wire [31:0] data05_t0  = data[05];
//wire [31:0] data06_t1  = data[06];
//wire [31:0] data07_t2  = data[07];
//wire [31:0] data08_s0  = data[08];
//wire [31:0] data09_s1  = data[09];
//wire [31:0] data10_a0  = data[10];
//wire [31:0] data11_a1  = data[11];
//wire [31:0] data12_a2  = data[12];
//wire [31:0] data13_a3  = data[13];
//wire [31:0] data14_a4  = data[14];
//wire [31:0] data15_a5  = data[15];
//wire [31:0] data16_a6  = data[16];
//wire [31:0] data17_a7  = data[17];
//wire [31:0] data18_s2  = data[18];
//wire [31:0] data19_s3  = data[19];
//wire [31:0] data20_s4  = data[20];
//wire [31:0] data21_s5  = data[21];
//wire [31:0] data22_s6  = data[22];
//wire [31:0] data23_s7  = data[23];
//wire [31:0] data24_s8  = data[24];
//wire [31:0] data25_s9  = data[25];
//wire [31:0] data26_s10 = data[26];
//wire [31:0] data27_s11 = data[27];
//wire [31:0] data28_t3  = data[28];
//wire [31:0] data29_t4  = data[29];
//wire [31:0] data30_t5  = data[30];
//wire [31:0] data31_t6  = data[31];
  `endif
endmodule // sisc32_regfile

`include "sisc_edge_rv32_udef.v"
