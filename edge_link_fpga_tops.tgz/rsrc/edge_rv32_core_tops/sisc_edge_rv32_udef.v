`undef RV_TRACE
`undef NO_CACHE
`undef RV16_REGF
