
`include "sisc_edge_rv32_defs.v"

module sisc_edge_rv32_core #(
	parameter	PC_SIZE   = 32  ,
	parameter	HART_NUM  = 1   )
(
	output                				dmem_men   ,
	output [31:0]         				dmem_madr  ,
	output                				dmem_mwes  ,
	output [31:0]         				dmem_mwdt  ,
	input  [31:0]         				dmem_mrdt  ,
	input                 				dmem_rdy   , 
	output reg [31:0]     				imem_madr  ,
	input  [31:0]         				imem_mrdt  ,
	input                 				clk        ,
	input                 				rstn       );

	wire   [31:0]         				imem_wadr  ;
	wire                  				imem_wait  = 0;
	wire                  				imem_miss  = rstn ? ~imem_flag[0]  : 1'b0;

	reg    [ 2:0]         				imem_flag  ;  
	
	always@(posedge clk)	imem_madr  <= imem_wadr;
	always@(posedge clk)	imem_flag  <= rstn ? {imem_flag[1:0],imem_flag[2]} : 'b001;

  
(* keep_hierarchy = "yes" *)
  	sisc_edge_rv32_ppls  			u_sisc_edge_rv32_ppls(
`ifdef RV_TRACE
    .inst_WB            				( inst_WB       ),
    .cycle              				( cycle         ),
    .trace_int          				( trace_int     ),
    .pc_reg0            				( pc_reg0       ),
    .sp_reg0            				( sp_reg0       ),
    .ras                				( ras           ),
`endif
    .mmpu               				(               ),
    .mrac               				(               ),
    .dc_wr_stall        				( 1'b0          ),
    .fence_line         				(               ),
    .fence_rwrw         				(               ),
    .fence_iorw         				(               ),
    .cacheable          				( 1'b0          ),
    .fence_i            				(               ),
    .redirect           				(               ),
				
    .inst_DX            				(               ),
				
    .clk                				(clk            ),
    .ext_interrupts     				({(`N_EXT_INTS){1'b0}}),
    .reset              				(~rstn          ),
    .imem_wait          				(imem_wait      ),
    .imem_miss          				(imem_miss      ),
    .imem_addr          				(imem_wadr      ),
    .imem_rdata         				(imem_mrdt      ),
    .imem_badmem_e      				(1'b0           ),
    .dmem_wait          				(~dmem_rdy      ),
    .dmem_en            				(dmem_men       ),
    .dmem_wen           				(dmem_mwes      ),
    .dmem_size          				(               ),
    .dmem_addr          				(dmem_madr      ),
    .dmem_wdata_delayed 				(),
    .dmem_wdata         				(dmem_mwdt      ),
    .dmem_rdata         				(dmem_mrdt      ),
    .dmem_badmem_e      				(1'b0           ),
    .dbg_ndreset        				(1'b0           ),
    .dbg_fullreset      				(1'b0           ),
    .dbg_irq            				(1'b0           ),
    .debug              				(               ));

endmodule

`include "sisc_edge_rv32_udef.v"

