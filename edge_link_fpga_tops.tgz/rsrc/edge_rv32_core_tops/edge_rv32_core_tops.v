
//  - to compatible to microblaze v4.1 IO mapping
// cpu address mapping:
//        | START     |   SIZE/byte|
// CROM   | 0x0       | 0x1000
// CRAM   | 0x1000    | 0x1000
// DRAM   | 0x2000    | 0x1000
// host IO| 0xC0000000| 0x1FF

module  edge_rv32_core_tops(
    output  reg                     	rv32_dctm_csen  ,
    output  reg                     	rv32_dctm_wrcs  ,
    output  reg [ 7: 0]             	rv32_dctm_addr  ,// access unit of 32b
    output  reg [31: 0]             	rv32_dctm_wdata ,
    input       [31: 0]             	rv32_dctm_rdata ,
    input                           	mclk            ,
    input                           	rstn       	    );
//----------------------------------------------------------------------
    wire                            	sysc_csea       ;
    wire                            	sysc_rdcs       ;
    reg                             	sysc_rdcs_buff  ;
    wire                            	core_dmea       ;
    wire        [31:0]              	core_dadr       ;
    wire                            	core_dwcs       ;
    wire        [31:0]              	core_dwdt       ;
    wire        [31:0]              	core_drdt       ;
    wire                            	core_drdy       ;
    wire        [31:0]              	core_iadr       ;
    wire        [31:0]              	core_irdt       ;
    wire                            	crom_csea       ;
    wire        [31:0]              	crom_idat       ;
    wire                            	cram_csea       ;
    wire        [31:0]              	cram_idat       ;
    wire        [ 9:0]              	cram_addr       ;
    wire                            	cram_icse       ;
    wire                            	cram_dcse       ;
    wire                            	cram_wrcs       ;
    reg                             	dram_csea       ;
    wire                            	dram_csea_curr  ;
    wire        [31:0]              	dram_rdat       ;
    reg         [ 9:0]              	dram_addr       ;
    reg                             	dram_wrcs       ;
    reg         [31:0]              	dram_wdat       ;
    reg                             	dram_csea_vlid  ;
    reg                             	cram_icse_vlid  ;
    reg                             	core_drdy_ctrl  ;
    reg         [31:0]              	tpuc_rdat_buff  ;

    assign      sysc_csea       =   core_dmea & (core_dadr[31:12] == 'hC);
    assign      sysc_rdcs       =   sysc_csea & ~core_dwcs;
    assign      core_drdy       =   core_drdy_ctrl  ;

    always@(posedge mclk) begin
        rv32_dctm_csen          <=  sysc_csea       ;
        rv32_dctm_wrcs          <=  core_dwcs       ;
        rv32_dctm_addr          <=  core_dadr[9:2]  ;
        rv32_dctm_wdata         <=  core_dwdt       ;
        tpuc_rdat_buff          <=  rv32_dctm_rdata ;
        sysc_rdcs_buff          <=  sysc_rdcs       ;
    end

    always@(posedge mclk)
    if (!rstn)  core_drdy_ctrl  <=  1'b1            ;
    else        core_drdy_ctrl  <=  sysc_rdcs | sysc_rdcs_buff ? 1'b0 
                                :   dram_csea_curr & core_drdy_ctrl ? 1'b0 : 1'b1;

 
    assign      crom_csea       =   core_iadr[31:12] == 'h00;
    assign      cram_icse       =               (core_iadr[31:12] == 'h01);
    assign      cram_dcse       =   core_dmea & (core_dadr[31:12] == 'h01);
    assign      cram_csea       =   cram_dcse | cram_icse;
    assign      cram_addr       =   cram_dcse ? core_dadr[11:2] : core_iadr[11:2];
    assign      cram_wrcs       =   cram_dcse & core_dwcs & !cram_icse;
    assign      core_irdt       =   crom_idat;
    assign      core_drdt       =   dram_csea_vlid ? dram_rdat : tpuc_rdat_buff;
    assign      dram_csea_curr  =   core_dmea & (core_dadr[31:12] == 'h02);
    always@(posedge mclk) begin
        dram_csea         <=    dram_csea_curr;
        dram_csea_vlid          <=  dram_csea       ;
        cram_icse_vlid          <=  cram_icse       ;
        dram_addr               <=  core_dadr[11:2] ;
        dram_wrcs               <=  core_dwcs       ;
        dram_wdat               <=  core_dwdt       ;
    end

    sisc_edge_rv32_core         	u_sisc_edge_rv32_core  (
        .dmem_men                   	(core_dmea      ),
        .dmem_madr                  	(core_dadr      ),
        .dmem_mwes                  	(core_dwcs      ),
        .dmem_mwdt                  	(core_dwdt      ),
        .dmem_mrdt                  	(core_drdt      ),
        .dmem_rdy                   	(core_drdy      ),
        .imem_madr                  	(core_iadr      ),
        .imem_mrdt                  	(core_irdt      ),
        .clk                        	(mclk           ),
        .rstn                       	(rstn           ));

    code_roms	              #(
        .FN                         	("../fpga_file/tpes_crom_2026012604.hex"),
        .AW                         	(10             ),
        .DW                         	(32             ))
    								u_code_rom(
        .csea                       	(crom_csea      ),
        .addr                       	(core_iadr[11:2]),
        .dout                       	(crom_idat      ),
        .clk                        	(mclk           ));


    code_rams	              #(
        .AW                         (10             ))
    								u_code_ram(
        .csea                       	(dram_csea      ),
        .wrcs                       	(dram_wrcs      ),
        .addr                       	(dram_addr      ),
        .wdat                       	(dram_wdat      ),
        .rdat                       	(dram_rdat      ),
        .clk                        	(mclk           ));


endmodule
