
module  code_roms  #(
  parameter             FN    = "rom.hex" ,
  parameter             AW    = 8   ,
  parameter             DW    = 32  )
(
  input                 csea  ,
  input   [AW-1:0]      addr  ,
  output
  reg     [DW-1:0]      dout  ,
  input                 clk   );
/*******************************************/

  (* RAM_STYLE="AUTO" *)
  reg     [DW-1:0]      rom [(2**AW)-1:0] ;


  initial $readmemh     (FN,rom);
  always  @(posedge clk)
    if (csea)
      dout              <= rom[addr];


endmodule
