`include "tpes_sisc32_core_params.v"
module tpes_sisc32_PC_mux(
                     input                         reset,
                     input                         IF_is_compress,
                     input [`PC_SRC_SEL_WIDTH-1:0] PC_src_sel,
                     input [`INST_WIDTH-1:0]       inst_DX,
                     input [`RV_XLEN-1:0]          rs1_data,
                     input [`RV_XLEN-1:0]          PC_IF,
                     input [`RV_XLEN-1:0]          PC_DX,
                     input [`RV_XLEN-1:0]          handler_PC,
                     input [`RV_XLEN-1:0]          epc,
                     input [`RV_XLEN-1:0]          dpc,
                     output [`RV_XLEN-1:0]         PC_PIF
                     );

   wire [`RV_XLEN-1:0]                             imm_b = { {20{inst_DX[31]}}, inst_DX[7], inst_DX[30:25], inst_DX[11:8], 1'b0 };
   wire [`RV_XLEN-1:0]                             jal_offset = { {12{inst_DX[31]}}, inst_DX[19:12], inst_DX[20], inst_DX[30:25], inst_DX[24:21], 1'b0 };
   wire [`RV_XLEN-1:0]                             jalr_offset = { {21{inst_DX[31]}}, inst_DX[30:21], 1'b0 };

   reg [`RV_XLEN-1:0]                              base;
   reg [`RV_XLEN-1:0]                              offset;

   always @(*) begin
      case (PC_src_sel)
        `PC_JAL_TARGET : begin
           base = PC_DX;
           offset = jal_offset;
        end
        `PC_JALR_TARGET : begin
           base = rs1_data;
           offset = jalr_offset;
        end
        `PC_BRANCH_TARGET : begin
           base = PC_DX;
           offset = imm_b;
        end
        `PC_REPLAY : begin
           base = PC_IF;
           offset = `RV_XLEN'h0;
        end
        `PC_HANDLER : begin
           base = handler_PC;
           offset = `RV_XLEN'h0;
        end
        `PC_EPC : begin
           base = epc;
           offset = `RV_XLEN'h0;
        end
        `PC_DPC : begin
           base = dpc;
           offset = `RV_XLEN'h0;
        end
        `PC_DBG : begin
           base = `CUSTOM_DBG_PC;
           offset = `RV_XLEN'h0;
        end
        `PC_DBG_E : begin
           base = `CUSTOM_DBG_PC;
           offset = `RV_XLEN'h8;
        end
        default : begin
           base = PC_IF;
           offset = IF_is_compress===1 ? `RV_XLEN'h2 
                  : reset ? 0
                  : `RV_XLEN'h4;
        end
      endcase // case (PC_src_sel)
   end // always @ (*)

   assign PC_PIF = base + offset;


endmodule // sisc32_PC_mux
`include "undef.v"
